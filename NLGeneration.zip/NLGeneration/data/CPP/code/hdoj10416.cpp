// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef pair<int, int> P;
const int inf = 1e9;
int n;
int land[130][130];
int dx[4] = {0, 0, 1, -1};
int dy[4] = {1, -1, 0, 0};
int exps[130][130];
bool legal(int x, int y){
    return x >= 0 && x < n && y >= 0 && y < n;
}
void bfs(){
    queue<P> que;
    que.push(P(0,0));
    exps[0][0] = land[0][0];
    while(!que.empty()){
        P p = que.front();
        que.pop();
        for(int i = 0; i < 4; i++){
            int nx = p.first + dx[i];
            int ny = p.second + dy[i];
            if(legal(nx, ny)){
                
                
                
                
                if(exps[nx][ny] > exps[p.first][p.second] + land[nx][ny]){
                    exps[nx][ny] = exps[p.first][p.second] + land[nx][ny];
                    que.push(P(nx, ny));
                }
            }
        }
    }   
}
int main()
{   
    int cs = 1;
    while(scanf("%d", &n)){
        if(n == 0) break;
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                scanf("%d", &land[i][j]);
                exps[i][j] = inf;
            }
        }
        bfs();
        printf("Problem %d: %d\n", cs++, exps[n-1][n-1]);
    }
    return 0;
}