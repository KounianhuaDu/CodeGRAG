// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[32]={1,3,2,1,10,2, 4, 1,3, 9, 9, 11,  6,14,6, 8, 5,13,5, 7, 13,15,5,7,  2,4,12,10,3,1,11,9};
int b[32]={2,4,4,3,12,10,12,9,11,11,10,12,  8,16,14,16,7,15,13,15,14,16,6,8,  6,8,16,14,7,5,15,13};
int vis[1000000];
int getState(int *st)
{
    int ans=0;
    for(int i=0;i<16;i++)
    {
        if(st[i])
        {
            ans|=(1<<i);
        }
    }
    return ans;
}
void bfs(int s)
{
    vis[s]=0;
    queue<int> q;
    q.push(s);
    while(!q.empty())
    {
        int fr=q.front();
        q.pop();
        if(vis[fr]>=3)
            continue;
        for(int i=0;i<32;i++)
        {
            int temp=fr;
            int j1=fr&(1<<(a[i]-1));
            int j2=fr&(1<<(b[i]-1));
            if(j1==j2)
                continue;
            temp^=(1<<(a[i]-1));
            temp^=(1<<(b[i]-1));
            if(vis[temp]==-1)
            {
                vis[temp]=vis[fr]+1;
                if(vis[temp]<3)
                    q.push(temp);
            }
        }
    }
}
int main()
{
    int st[16]={0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1};
    int s=getState(st);
    memset(vis,-1,sizeof(vis));
    bfs(s);
    int T;
    scanf("%d",&T);
    for(int cas=1;cas<=T;cas++)
    {
        for(int i=0;i<16;i++)
            scanf("%d",&st[i]);
        s=getState(st);
        printf("Case #%d: ",cas);
        if(vis[s]==-1||vis[s]>3)
            printf("more\n");
        else
            printf("%d\n",vis[s]);
    }
    return 0;
}