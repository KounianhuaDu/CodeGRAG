// Graph Algorithm->Kruskal's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 5005;
int pre0[N];
int num;
double sum;
struct edges
{
    int pre;
    int suc;
    int wei;
}edge[N];
struct point
{
    int x;
    int y;
}poi[101];
int cmp(edges x, edges y)
{
    return (x.wei < y.wei) ? 1 : 0;
}
void init(int vs)
{
    for(int i = 1; i <= vs; i ++)
        pre0[i] = i;
}
int findd(int x)
{
    int r = x;
    while(r != pre0[r])
        r = pre0[r];
    return r;
}
void Union(int x, int y, int z)
{
    int f1, f2;
    f1 = findd(x);
    f2 = findd(y);
    if(f1 != f2)
    {
        pre0[f2] = f1;
        num ++;
        sum += sqrt(z);
    }
}
double kruskal(int es, int vs)
{
    num = 1;
    sum = 0;
    init(vs);
    sort(edge, edge + es, cmp);
    for(int i = 1; i < es; i ++)
        Union(edge[i].pre, edge[i].suc, edge[i].wei);
  
    if(num == vs) return sum;
    else return -1;
}
int main()
{
  
    int T, C, m;
    __int64_t w;
    double ans;
    scanf("%d", &T);
    while(T --)
    {
        scanf("%d", &C);
        for(int i = 1; i <= C; i ++)
            scanf("%d%d", &poi[i].x, &poi[i].y);
        if(C == 0 || C == 1) { printf("0.0\n"); continue; }
        int num0 = 1;
        for(int i = 1; i <= C - 1; i ++)
            for(int j = i + 1; j <= C; j ++)
            {
                w = (poi[j].x - poi[i].x) * (poi[j].x - poi[i].x) + (poi[j].y - poi[i].y) * (poi[j].y - poi[i].y);
 
                if(w >= 100 && w <= 1000000)
                {
                    edge[num0].pre = i;
                    edge[num0].suc = j;
                    edge[num0].wei = w;
 
                    num0 ++;
                }
            }
        ans = kruskal(num0, C);
        if(ans < 0) printf("oh!\n");
        else printf("%.1lf\n", ans * 100);
    }
    return 0;
}