// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define dbg(x) cout<<#x<<" = "<< (x)<< endl
const int MAX_N = 2222222;
int ans_MAX, ans_MIN;
struct node {
    int ans_max;
    int ans_min;
};
int MAX[MAX_N << 2], MIN[MAX_N << 2];
int Max(int a, int b) {
    if(a > b)
        return a;
    else
        return b;
}
int Min(int a, int b) {
    if(a < b)
        return a;
    else
        return b;
}
void up(int p) {
    MAX[p] = Max(MAX[p * 2], MAX[p * 2 + 1]);
    MIN[p] = Min(MIN[p * 2], MIN[p * 2 + 1]);
}
void build(int p, int l, int r) {
    if(l == r) {
        scanf("%d", &MAX[p]);
        MIN[p] = MAX[p];
        return;
    }
    int mid = (l + r) >> 1;
    build(p * 2, l, mid);
    build(p * 2 + 1, mid + 1, r);
    up(p);
}
node query(int p, int l, int r, int x, int y) {
    if(x <= l && r <= y) {
        node tmp;
        tmp.ans_max = MAX[p];
        tmp.ans_min = MIN[p];
        return tmp;
    }
    int mid = (l + r) >> 1;
    node tmp1, tmp2, ans_tmp;
    tmp1.ans_max = tmp2.ans_max = -0x3f3f3f3f;
    tmp1.ans_min = tmp2.ans_min = 0x3f3ff3f;
    if(x <= mid) {
        tmp1 = query(p * 2, l, mid, x, y);
    }
    if(y > mid)
        tmp2 = query(p * 2 + 1, mid + 1, r, x, y);
    ans_tmp.ans_max = Max(tmp1.ans_max, tmp2.ans_max);
    ans_tmp.ans_min = Min(tmp1.ans_min, tmp2.ans_min);
    return ans_tmp;
}
int main() {
    int n, k;
    scanf("%d%d", &n, &k);
    build(1, 1, n);
    while(k--) {
        int x, y;
        scanf("%d%d", &x, &y);
        ans_MAX = query(1, 1, n, x, y).ans_max;
        ans_MIN = query(1, 1, n, x, y).ans_min;
        printf("%d\n", ans_MAX - ans_MIN);
    }
    return 0;
}