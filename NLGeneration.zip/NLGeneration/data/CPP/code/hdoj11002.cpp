// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 500002
int l, n, m;
int a[MAXN];
int check(int x)
{
	int t = x;
	int cnt=0;
	for(int i=1; i<n+2; t=x)		
	{
		while(t>=a[i]-a[i-1])		
		{
			t-=a[i]-a[i-1];
			i++;
		}
		cnt++;
		if(cnt>m) return 0;
	}
	return 1;
}
int main()
{
	while(cin>>l>>n>>m)
	{
		a[0]=0; a[n+1]=l;
		for(int i=1; i<=n; i++)		
		{
			cin>>a[i];
		}
		sort(a, a+n+2);				
		int min1=l%m? l/m+1: l/m;
		int max1 = l;
		while(min1<max1)					
		{
			int mid = (min1+max1)/2;
			if(check(mid))
			{
				max1 = mid;
			}
			else
			{
				min1 = mid+1;
			}
		}	
		cout<<min1<<endl;
	}
}