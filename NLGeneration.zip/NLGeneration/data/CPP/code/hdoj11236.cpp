// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
typedef pair<int, int>pii;
const int maxn = 1e6 + 10;
int a[maxn], b[maxn], Next[maxn];
void getNext(int n) {
    int i = 0, j = -1;
    Next[i] = j;
    while(i <= n - 1) {
        if(j == -1 || (b[i + 1] == b[j + 1] && b[i + 1] == b[j + 1])) {
            i++;
            j++;
            Next[i] = j;
        } else
            j = Next[j];
    }
}
int KMP(int n, int m, int q, int x) {
    int ans = 0;
    int i = x, j = 0;
    while(i <= n) {
        if(j == -1 || (a[i] == b[j + 1]))
            i += q, ++j;
        else {
            j = Next[j];
        }
        if(j == m) {
            ans++;
        }
    }
    return ans;
}
int main() {
    int t, Test = 1;
    cin >> t;
    int n, m, q;
    while(t--) {
        scanf("%d%d%d", &n, &m, &q);
        memset(b, 0, sizeof(b));
        for(int i = 1; i <= n; ++i) {
            scanf("%d", &a[i]);
        }
        for(int i = 1; i <= m; ++i) {
            scanf("%d", &b[i]);
        }
        getNext(m);
        int ans = 0;
        for(int i = 1; i <= q && i <= n; ++i) {
            ans += KMP(n, m, q, i);
        }
        printf("Case #%d: %d\n", Test++, ans);
    }
    return 0;
}