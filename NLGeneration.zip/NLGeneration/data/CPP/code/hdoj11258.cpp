// Data Structure->Stack,Basic Algorithm->Memorization,Graph Algorithm->Tarjan's Algorithm,Graph Algorithm->Strongly Connected Components,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
using namespace std;
const int N = 10005;
const int M = 300005;
int dfn[N],low[N],cnt,belong[N],book[N],sum[N];
int n,m,dfnum,val[N],a[M],b[M],cnt2,head[M];
int f[N];
stack<int> s;
struct E{
	int u,v,nxt;
};
E edge[M];
void add(int u,int v){
	++cnt2;
	edge[cnt2].v = v;
	edge[cnt2].nxt = head[u];
	head[u] = cnt2;
}
void tarjan(int u){
	dfn[u] = low[u] = ++dfnum;
	s.push(u); book[u]=1;
	for(int v,i = head[u];i;i=edge[i].nxt){
		v = edge[i].v;
		if(!dfn[v]){
			tarjan(v);
			low[u] = min(low[v],low[u]);
		}else if(book[v])low[u] = min(dfn[v],low[u]);
		
	}
	if(dfn[u]==low[u]){
		belong[u] = ++cnt;
		int v;
		do{
			v = s.top();
			book[v]=0;
			s.pop();
			belong[v]=cnt;
			sum[cnt]+=val[v];
		}while(u!=v);
	}
}
void dfs(int u){
	int ans=0;
	f[u] = sum[u];
	for(int v,i=head[u];i;i=edge[i].nxt){
		v = edge[i].v;
		if(!f[v])dfs(v);
		ans=max(ans,f[v]);
	}
	f[u]+=ans;
}
int main()
{
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)scanf("%d",&val[i]);
	for(int i=1;i<=m;i++){
	int u,v;
	scanf("%d %d",&a[i],&b[i]);
	u = a[i]; v = b[i];
	edge[i].v = v; edge[i].nxt = head[u]; head[u]=i;
	}
	for(int i=1;i<=n;i++){
		if(!dfn[i]){
			tarjan(i);
		}
	}
	memset(head,0,sizeof(head));
	for(int i=1;i<=m;i++){
		if(belong[a[i]]!=belong[b[i]]){
			add(belong[a[i]],belong[b[i]]);
		}
	}
	int ans=0;
	for(int i=1;i<=cnt;i++){
		if(!f[i]){
			dfs(i);ans = max(ans,f[i]);
		}
	}
	printf("%d\n",ans);
	return 0;
 }