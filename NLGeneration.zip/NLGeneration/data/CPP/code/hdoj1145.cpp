// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define N 200010
#define M 1000000007
using namespace std;
ll s[N];
void init()
{
	s[0]=1;
	for(int i=1;i<=N;i++)
	{
		s[i]=s[i-1]*i%M;
	}
}
ll ks(ll n,ll k)
{
	ll s=1;
	while(k)
	{
		if(k&1)
			s=s*n%M;
		n=n*n%M;
		k>>=1;
	}
	return s;
}
ll C(ll n,ll k)
{
	ll a=s[n];
	ll b=s[k]*s[n-k]%M;
	ll p=ks(b,M-2);
	return a*p%M;
}
int main()
{
	ll n,m;
	init();
	while(scanf("%lld%lld",&n,&m)!=EOF)
	{
		ll ans=C(n+m-4,m-2);
		printf("%lld\n",ans);
	}
	return 0;
}