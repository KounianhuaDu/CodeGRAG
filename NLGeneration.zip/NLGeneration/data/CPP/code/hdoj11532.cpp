// Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 1000005
using namespace std;
char s1[maxn],s2[maxn];
int nnext[maxn];
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%s%s",s2+1,s1+1);
        memset(nnext,0,sizeof(nnext));
        int ans=0,i,j,k,len1=strlen(s1+1),len2=strlen(s2+1);
        nnext[1]=0;
        j=1;k=0;
        while(j<=len2)
        {
            if(k==0||s2[j]==s2[k])
            {
                k++;
                j++;
                nnext[j]=k;
            }
            else k=nnext[k];
        }
        i=1,j=1;
        while(i<=len1)
        {
            if(j==0||s1[i]==s2[j])
            {
                i++;
                j++;
            }
            else j=nnext[j];
            if(j>len2)
            {
                ans++;
                j=nnext[len2+1];
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}