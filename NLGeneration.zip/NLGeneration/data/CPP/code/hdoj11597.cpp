// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x7f7f7f7f
#define maxn 100050
#define N 100100
#define P 2
typedef long long ll;
typedef struct {
    int u, v, next, w;
} Edge;
Edge e[10*maxn];
int cnt, head[maxn];
inline void add(int u, int v) {
    e[cnt].u = u;
    e[cnt].v = v;
    
    e[cnt].next = head[u];
    head[u] = cnt++;
    e[cnt].u = v;
    e[cnt].v = u;
    
    e[cnt].next = head[v];
    head[v] = cnt++;
}
inline void write(int x) {
    if (x < 0)
        putchar('-'), x = -x;
    if (x > 9)
        write(x / 10);
    putchar(x % 10 + '0');
}
inline int read() {
    int x = 0, f = 1;
    char c = getchar();
    while (c < '0' || c > '9') {
        if (c == '-')
            f = -1;
        c = getchar();
    }
    while (c >= '0' && c <= '9') {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x * f;
}
int n,m,s,t,color[maxn];
int bfs(){
    color[0]=0;
    queue<int>q;
    q.push(0);
    while(!q.empty()){
        int u=q.front();q.pop();
        for(int i=head[u];i!=-1;i=e[i].next){
            int v=e[i].v;
            if(color[v]==-1){
                color[v]=color[u]^1;
                q.push(v);
            }else if(color[v]==color[u])return 0;
        }
    }
    for(int i=0;i<n;i++){
        if(color[i]==-1)return 1;
    }
    return 1;
}
int main(){
    t=read();
    for(int k=1;k<=t;k++){
        cnt=0;
        scanf("%d%d%d", &n, &m, &s);
        memset(head, -1, sizeof(head));
        memset(color,-1,sizeof(color));
        int x, y;
        for (int i = 0; i < m; i++) {
            x = read(), y = read();
            add(x, y);
        }
        printf("Case %d: %s\n",k,bfs()?"NO":"YES");
    }
}