// Math and Computational Geometry->Greatest Common Divisor (GCD)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL __int64_t
const int N = 100000;
bool a[N];
int p[N];
int num;
void Prime() {
    memset(a, 0, sizeof(a));
    int i, j;
    for(i = 2; i <= N; i++) {
        if(!(a[i]))
            p[num++] = i;
        for(j = 0; j < num && i * p[j] < N; j++) {
            a[i * p[j]] = 1;
            if(!i % p[j])
                break;
        }
    }
}
int main() {
    int T, g, l, t, i;
    num = 0;
    Prime();
    LL ans;
    while(~scanf("%d", &T)) {
        while(T--) {
            ans = 1;
            scanf("%d%d", &g, &l);
            if(l % g) {
                cout << "0" << endl;
                continue;
            }
            t = l / g;
            for(i = 0; i < num; i++) {
                if(p[i] > t)
                    break;
                LL a = 0;
                while(t % p[i] == 0) {
                    a++;
                    t /= p[i];
                }
                if(a) {
                    ans = ans * 6 * a;
                }
            }
            if(t > 1)
                ans *= 6;
            cout << ans << endl;
        }
    }
    return 0;
}