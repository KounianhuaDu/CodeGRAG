// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
void mult(int a[4][4], int b[4][4]) {
    int c[4][4];
    memset(c, 0, sizeof(c));
    for(int i = 1; i <= 3; i++)
        for(int j = 1; j <= 3; j++)
            for(int k = 1; k <= 3; k++)
                c[i][j] += a[i][k] * b[k][j] % 10007;
    memcpy(a, c, sizeof(c));
}
int main() {
    int n, i, j;
    int m[4][4], res[4][4];
    int a[5] = {0, 0, 0, 2, 6};
    while(cin >> n) {
        if(n < 4) {
            cout << a[n] << endl;
            continue;
        }
        m[1][1] = m[1][2] = m[1][3] = m[2][1] = 1;
        m[2][2] = m[2][3] = m[3][1] = m[3][2] = 0;
        m[3][3] = 2;
        for(i = 1; i <= 3; i++)
            for(j = 1; j <= 3; j++)
                if(i == j)
                    res[i][j] = 1;
                else
                    res[i][j] = 0;
        n -= 4;
        while(n) {
            if(n & 1) {
                mult(res, m);
                n--;
            } else {
                mult(m, m);
                n >>= 1;
            }
        }
        int k = (res[1][1] * 6 + res[1][2] * 2 + res[1][3] * 8) % 10007;
        cout << k << endl;
    }
}