// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 100000 + 10;
int   a[maxn];
int   n, m, k;
int   maxQue[maxn], minQue[maxn];
void solve() {
    int mintail = 0, minhead = 0, maxtail = 0, maxhead = 0;
    int ans = 0, st = 0;
    for(int i = 0; i < n; ++i) {
        while(minhead < mintail && a[minQue[mintail - 1]] >= a[i])
            --mintail;
        minQue[mintail++] = i;
        while(maxhead < maxtail && a[maxQue[maxtail - 1]] <= a[i])
            --maxtail;
        maxQue[maxtail++] = i;
        while(a[maxQue[maxhead]] - a[minQue[minhead]] > k) {
            if(maxQue[maxhead] < minQue[minhead])
                st = maxQue[maxhead++] + 1;
            else
                st = minQue[minhead++] + 1;
        }
        if(a[maxQue[maxhead]] - a[minQue[minhead]] >= m)
            ans = max(ans, i - st + 1);
    }
    cout << ans << endl;
}
int main() {
    while(cin >> n >> m >> k) {
        for(int i = 0; i < n; ++i)
            scanf("%d", a + i);
        solve();
    }
    return 0;
}