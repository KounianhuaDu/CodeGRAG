// Math and Computational Geometry->Inclusion–Exclusion Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

__int64_t p[100],k;
void getp(__int64_t n)
{
	__int64_t i;
	k=0;
	for(i=2;i*i<=n;i++)
	{
		if(n%i==0)
			p[k++]=i;
		while(n%i==0)
			n/=i;
	}
	if(n>1)
		p[k++]=n;
}
__int64_t nop(__int64_t m)
{
	__int64_t que[111111],i,j,sum,t,top=0;
	que[top++]=-1;
	for(i=0;i<k;i++)
	{
		t=top;
		for(j=0;j<t;j++)
		{
			que[top++]=que[j]*p[i]*(-1);
		}
	}
	sum=0;
	for(i=1;i<top;i++)
	{
		sum+=m/que[i];
	}
	return sum;
}
int main()
{
	__int64_t a,b,c;
	int T,kcase=1;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%I64d%I64d%I64d",&a,&b,&c);
		getp(c);
		printf("Case #%d: %I64d\n",kcase++,b-nop(b)-(a-1-nop(a-1)));
	}
	return 0;
}