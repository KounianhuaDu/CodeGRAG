// Basic Algorithm->Discretization,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 99999999
#define min(a,b) (a<b?a:b)
using namespace std;
const int MAXN = 100010;
int n, m; 
int cnt;
int k; 
int shop[12]; 
int dis[12][MAXN];  
int head[MAXN]; 
int fg[MAXN];  
struct Ed {
    int v, w, next;
} e[MAXN * 2];
void addEd(int u, int v, int w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}
void spfa(int s0, int s) {
    queue<int>Q;
    int i, u;
    int f[MAXN];
    for(i = 0; i < n; i++) {
        dis[s][i] = INF;
        f[i] = 0;
    }
    dis[s][s0] = 0;
    Q.push(s0);
    while(!Q.empty()) {
        u = Q.front();
        Q.pop();
        f[u] = 0;
        for(i = head[u]; i != -1; i = e[i].next) {
            if(dis[s][u] + e[i].w < dis[s][e[i].v]) {
                dis[s][e[i].v] = dis[s][u] + e[i].w;
                f[e[i].v] = 1;
                Q.push(e[i].v);
            }
        }
    }
}
void solve() {
    int i, sum = INF, ans;
    do {
        ans = dis[fg[shop[0]]][0];
        for(i = 1; i < k; i++)
            ans += dis[fg[shop[i - 1]]][shop[i]];
        ans += dis[fg[shop[i - 1]]][0];
        sum = min(sum, ans);
    } while(next_permutation(shop, shop + k));
    printf("%d\n", sum);
}
void input() {
    int i, u, v, w, T;
    scanf("%d", &T);
    while(T--) {
        cnt = 0;
        memset(head, -1, sizeof(head));
        scanf("%d%d", &n, &m);
        for(i = 0; i < m; i++) {
            scanf("%d %d %d", &u, &v, &w);
            addEd(u, v, w);
            addEd(v, u, w);
        }
        scanf("%d", &k);
        for(i = 0; i < k; i++) {
            scanf("%d", &shop[i]);
            fg[shop[i]] = i;
            spfa(shop[i], i);
        }
        sort(shop, shop + k);
        solve();
    }
}
int main() {
    input();
    return 0;
}