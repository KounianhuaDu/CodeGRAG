// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 200010;
int a[N],sum[N*4];
int laz[N*4];
int minn[N*4],maxx[N*4];
void push_down(int rt,int m)
{
    sum[rt<<1]+=laz[rt]*(m-(m>>1));
    sum[rt<<1|1]+=laz[rt]*(m>>1);
    laz[rt<<1]+=laz[rt];
    laz[rt<<1|1]+=laz[rt];
    laz[rt]=0;
}
int n,m;
void push_down2(int rt)
{
    maxx[rt<<1]=max(maxx[rt<<1],maxx[rt]);
    minn[rt<<1]=min(minn[rt<<1],minn[rt]);
    maxx[rt<<1|1]=max(maxx[rt<<1|1],maxx[rt]);
    minn[rt<<1|1]=min(minn[rt<<1|1],minn[rt]);
}
void update(int L,int R,int l,int r,int rt,int add)
{
    if(L<=l&&R>=r){
        sum[rt]+=(r-l+1)*add;
        laz[rt]+=add;
        return ;
    }
    if(laz[rt])
        push_down(rt,r-l+1);
    int mid=(l+r)>>1;
    if(L<=mid) update(L,R,l,mid,rt<<1,add);
    if(R>mid) update(L,R,mid+1,r,rt<<1|1,add);
}
void build(int l,int r,int rt)
{
    if(l==r)
    {
        if(minn[rt]<=maxx[rt])
            update(minn[rt],maxx[rt],1,m,1,a[l]);
        return ;
    }
    push_down2(rt);
    int mid=(l+r)>>1;
    build(l,mid,rt<<1);
    build(mid+1,r,rt<<1|1);
}
void update2(int l,int r,int L,int R,int rt,int id)
{
    if(L<=l&&R>=r){
        maxx[rt]=max(maxx[rt],id);
        minn[rt]=min(minn[rt],id);
        return ;
    }
    push_down2(rt);
    int mid=(l+r)>>1;
    if(L<=mid) update2(l,mid,L,R,rt<<1,id);
    if(R>mid) update2(mid+1,r,L,R,rt<<1|1,id);
}
int query(int l,int r,int d,int rt)
{
    if(l==r&&l==d)
        return sum[rt];
    if(laz[rt])
        push_down(rt,r-l+1);
    int mid=(l+r)>>1;
    if(d<=mid) return query(l,mid,d,rt<<1);
    else return query(mid+1,r,d,rt<<1|1);
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        memset(sum,0,sizeof(sum));
        memset(minn,0x3f,sizeof(minn));
        memset(maxx,0,sizeof(maxx));
        memset(laz,0,sizeof(laz));
        n--;
        for(int i=1;i<=n;i++)
            scanf("%d",&a[i]);
        for(int i=1;i<=m;i++)
        {
            int L,R;
            scanf("%d%d",&L,&R);
            if(L>R) swap(L,R);
            update2(1,n,L,R-1,1,i);
        }
        build(1,n,1);
        for(int i=1;i<=m;i++)
            printf("%d\n",query(1,m,i,1) );
    }
}