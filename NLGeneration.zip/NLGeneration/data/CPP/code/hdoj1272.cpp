// Basic Algorithm->Recursion,Basic Algorithm->Memorization,Data Structure->Spanning Tree,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
using namespace std;
int Map[1100][1100],dis[1100],dp[1100];
bool vis[1100];
int n;
void dijik(int st)
{
    int i,j,ma,pos=-1;
    memset(vis,false,sizeof(vis));
    for(i=1;i<=n;i++)
        dis[i]=Map[st][i];
    vis[st]=true;
    dis[st]=0;
    for(i=1;i<n;i++)
    {
        ma=inf;
        for(j=1;j<=n;j++)
        {
            if(ma>dis[j]&&!vis[j])
            {
                ma=dis[j];
                pos=j;
            }
        }
        vis[pos]=true;
        for(j=1;j<=n;j++)
        {
            if(!vis[j]&&Map[pos][j]!=inf&&dis[j]>dis[pos]+Map[pos][j])
            {
                dis[j]=dis[pos]+Map[pos][j];
            }
        }
    }
}
int merdfs(int x)
{
    if(dp[x]!=-1)
        return dp[x];
    if(x==2)
        return 1;
    int s=0;
    for(int i=1;i<=n;i++)
    {
        if(Map[x][i]!=inf&&dis[x]>dis[i])
        {
            s+=merdfs(i);
        }
    }
    dp[x]=s;
    return dp[x];
}
int main()
{
    int m,i,j;
    while(~scanf("%d",&n),n)
    {
        scanf("%d",&m);
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                Map[i][j]=i==j?0:inf;
        int a,b,c;
        for(i=0;i<m;i++)
        {
            scanf("%d%d%d",&a,&b,&c);
            if(Map[a][b]>c)
            {
                Map[a][b]=c;
                Map[b][a]=c;
            }
        }
        dijik(2);
        memset(dp,-1,sizeof(dp));
        printf("%d\n",merdfs(1));
    }
    return 0;
}