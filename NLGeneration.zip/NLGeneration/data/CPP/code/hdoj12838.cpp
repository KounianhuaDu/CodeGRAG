// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 10000+10
#define MAXM 400000+10
using namespace std;
struct Edge
{
    int from, to, cut, next;
};
Edge edge[MAXM];
int head[MAXN], edgenum;
int low[MAXN], dfn[MAXN];
int dfs_clock;
int N, M;
map<string ,int> fp;
map<int, string> mp;
void init()
{
    edgenum = 0;
    memset(head, -1, sizeof(head));
}
void addEdge(int u, int v)
{
    Edge E1 = {u, v, 0, head[u]};
    edge[edgenum] = E1;
    head[u] = edgenum++;
}
void getMap()
{
    init();
    scanf("%d%d", &N, &M);
    char a[20], b[20];
    fp.clear(), mp.clear();
    int k = 0;
    for(int i = 1; i <= M; i++)
    {
        scanf("%s%s", a, b);
        if(!fp[a]) fp[a] = ++k;
        mp[fp[a]] = a;
        if(!fp[b]) fp[b] = ++k;
        mp[fp[b]] = b;
        addEdge(fp[a], fp[b]);
        addEdge(fp[b], fp[a]);
    }
}
int bridge;
void tarjan(int u, int fa)
{
    low[u] = dfn[u] = ++dfs_clock;
    int have = 1;
    for(int i = head[u]; i != -1; i = edge[i].next)
    {
        int v = edge[i].to;
        if(have && v == fa)
        {
            have = 0;
            continue;
        }
        if(!dfn[v])
        {
            tarjan(v, u);
            low[u] = min(low[u], low[v]);
            if(low[v] > dfn[u])
            {
                bridge++;
                edge[i].cut = edge[i^1].cut = 1;
            }
        }
        else
            low[u] = min(low[u], dfn[v]);
    }
}
int num;
void find_cut(int l, int r)
{
    memset(low, 0, sizeof(low));
    memset(dfn, 0, sizeof(dfn));
    dfs_clock = num = bridge = 0;
    for(int i = l; i <= r; i++)
        if(!dfn[i]) tarjan(i, -1), num++;
}
void solve()
{
    find_cut(1, N);
    if(num != 1)
    {
        printf("0\n");
        return ;
    }
    printf("%d\n", bridge);
    for(int i = 0; i < edgenum; i+=2)
    {
        if(edge[i].cut == 1)
            printf("%s %s\n", mp[edge[i].from].c_str(), mp[edge[i].to].c_str());
    }
}
int main()
{
    int t;
    scanf("%d", &t);
    while(t--)
    {
        getMap();
        solve();
    }
    return 0;
}