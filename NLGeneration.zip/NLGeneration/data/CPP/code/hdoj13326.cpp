// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define mst(ss,b) memset((ss),(b),sizeof(ss))
#define maxn 0x3f3f3f3f
#define MAX 1000100
typedef long long ll;
typedef unsigned long long ull;
#define INF (1ll<<60)-1
using namespace std;
#define mod 1000000007
int n,m;
ll fac[1000010];
ll ppow(ll k,ll n) {
    ll c=1;
    while(n) {
        if(n%2) c=(c*k)%mod;
        k=(k*k)%mod;
        n>>=1;
    }
    return c;
}
ll C(ll a,ll b) {
    return (((fac[b]*ppow((fac[a]*fac[b-a])%mod,mod-2)))%mod)%mod;
}
int main(){
    fac[0]=1;
    for(int i=1;i<=1000000;i++) fac[i]=(fac[i-1]*i)%mod;
    while(scanf("%d%d",&n,&m)!=EOF){
        if(n==2 || m==2) {
            cout<<1<<endl;
            continue;
        }
        int x=n+m-4;
        int y=n-2;
        ll ans=C(y,x)%mod;
        cout<<ans%mod<<endl;
    }
    return 0;
}