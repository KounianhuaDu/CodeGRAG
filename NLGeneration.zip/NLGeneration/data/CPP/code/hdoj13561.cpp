// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
#define lld __int64_t
const double PI = 3.1415926 ;
const double esp = 1e-4 ;
const int  md= 2810778 ;
const lld INF = 0x7fffffffffffffff ;
const lld MX = 45 ;
lld n,m,ans ;
lld g[MX],sum[MX] ;
void dfs(lld x,lld num,lld cnt)
{
    if(ans>cnt)  ans=cnt ;
    if(x==n||num==m)  return ;
    lld sx=cnt&sum[x] ;
    if(sx>=ans)  return ;
    dfs(x+1,num+1,cnt&g[x]) ; 
    dfs(x+1,num,cnt) ;
}
int main()
{
    lld Tx,q=1 ;
    scanf("%I64d",&Tx) ;
    while(Tx--)
    {
        scanf("%I64d%I64d",&n,&m) ;
        for(int i=0 ;i<n ;i++)
           scanf("%I64d",&g[i]) ;
        sort(g,g+n) ;
        sum[n-1]=g[n-1] ;
        for(lld j=n-2 ;j>=0 ;j--) 
           sum[j]=g[j]&sum[j+1] ;
        ans=INF ;
        dfs(0,0,ans) ;
        printf("Case #%I64d: %I64d\n",q++,ans) ;
    }
    return 0 ;
}