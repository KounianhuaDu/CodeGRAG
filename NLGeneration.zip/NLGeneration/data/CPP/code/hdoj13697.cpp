// Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
int in[120] ;
int Map[120][120] ;
queue <int> que ;
int main()
{
	int n , m , u , v , i ;
	while( scanf("%d %d", &n, &m) != EOF )
	{
		while( !que.empty() )
			que.pop() ;
		memset(in,0,sizeof(in)) ;
		memset(Map,0,sizeof(Map)) ;
		while(m--)
		{
			scanf("%d %d", &u, &v) ;
			Map[v][u]++ ;
			in[u]++ ;
		}
		for(i = 1 ; i <= n ; i++)
			if( in[i] == 0 )
				que.push(i) ;
		while( !que.empty() )
		{
			u = que.front() ;
			que.pop() ;
			for(i = 1 ; i <= n ; i++)
			{
				if( Map[u][i] != 0 )
				{
					in[i] -= Map[u][i] ;
					Map[u][i] = 0 ;
					if( in[i] == 0 )
						que.push(i) ;
				}
			}
		}
		for(i = 1 ; i <= n ; i++)
			if( in[i] )
				break ;
		if( i <= n )
			printf("NO\n") ;
		else
			printf("YES\n") ;
	}
	return 0;
}