// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef __int64_t ll;
ll sum1[1005][1005];
ll sum2[1005][1005];
ll mod=1000000007;
void init()
{
	ll i,j;
	for(i=1;i<=1000;i++)
	{
		sum1[i][1]=1;
		sum1[1][i]=i;
	}
	for(i=2;i<=1000;i++)
		for(j=2;j<=1000;j++)
			sum1[i][j]=(sum1[i-1][j]+sum1[i][j-1])%mod;
	for(i=1;i<=1000;i++)
	{
		sum2[i][1]=1;
		sum2[i][i]=1;
	}
	for(i=2;i<=1000;i++)
		for(j=2;j<=i;j++)
			sum2[i][j]=(j*sum2[i-1][j]+sum2[i-1][j-1])%mod;
}
ll cal(ll n,ll m)
{
	ll i,sum=0;
	for(i=1;i<=m;i++)
		sum=(sum+sum2[n][i])%mod;
	return sum;
}
int main()
{
	ll n,r,k,m,tmp,ans;
	init();
	while(scanf("%I64d%I64d%I64d%I64d",&n,&r,&k,&m)!=EOF)
	{
		tmp=k*(r-1)+1;
		if(tmp>n)
		{
			printf("0\n");
			continue;
		}
		tmp=n-k*(r-1);
		ans=cal(r,m)*sum1[r][tmp]%mod;
		printf("%I64d\n",ans);
	}
	return 0;
}