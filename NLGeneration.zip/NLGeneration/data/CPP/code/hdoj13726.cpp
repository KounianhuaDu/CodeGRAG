// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int row=3,col=4;
int maptt1[3][4];
int flag[3][4];
int vis[10];
int dis[8][2]={
0,1,
0,-1,
1,0,
-1,0,
1,1,
-1,1,
1,-1,
-1,-1,
}; 
int ans=0;
void init(){
	
   	for(int i=0;i<10;i++){
   		vis[i]=0;
	   }
	for(int i=0;i<row;i++){
		for(int j=0;j<col;j++){
			maptt1[i][j]=0;
			flag[i][j]=1;
		}
	}
	
	flag[0][0]=0;
	flag[2][3]=0;
}
void check(){
	int temp=1;
	for(int i=0;i<3;i++){
		for(int j=0;j<4;j++){
			if(flag[i][j]==0) continue;
			for(int k=0;k<8;k++){
				int x=i+dis[k][0];
				int y=j+dis[k][1];
				
				if(x<0||x>=3||y<0||y>=4||flag[x][y]==0) continue;
				if(abs(maptt1[i][j]-maptt1[x][y])==1) temp=0;
			}
		}
	}
	if(temp){
		ans++;
	}
}
void dfs(int n){
	int x=n/4;
	int y=n%4;
	if(x==3){
	
		check();
		return ;
	}
	if(flag[x][y]){
		for(int i=0;i<=9;i++){
			if(vis[i]==0){
				maptt1[x][y]=i;
				vis[i]=1;
				dfs(n+1);
				vis[i]=0; 
			}
		}
	}
	else{
		dfs(n+1);
	}
}
int main()
{
	init();
	dfs(0);
	cout<<ans<<endl;
   return 0;
 }