// Data Structure->Queue,Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int vis[105],a[105][105],n,m,u,v;
void topsort()
{
    int blag=0,i,j;
    for(i=0;i<n;i++)   
    {
        for(j=0;j<n;j++)    
        {
            if(vis[j]==0)
            {
                vis[j]--;
                for(int k=0;k<n;k++)   
                  if(a[j][k])
                    vis[k]--;
                break;
            }
        }
        if(j==n)    
        {
            blag=1;
            break;
        }
    }
    if(blag)
      cout<<"NO"<<endl;
    else
      cout<<"YES"<<endl;
}
int main()
{
    while(cin>>n>>m&&n)
    {
        memset(a,0,sizeof(a));
        memset(vis,0,sizeof(vis));
        for(int i=0;i<m;i++)
        {
            cin>>u>>v;
            if(!a[u][v])
            {
               a[u][v]=1;
               vis[v]++;    
            }
        }
        topsort();
    }
    return 0;
}