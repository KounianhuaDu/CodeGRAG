// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define inf 0x3f3f3f3f
using namespace std;
const int maxn=100010;
int n,m,k,ans,flag,cnt,tmp;
int x,y,z;
int a[maxn],vis[maxn];
vector<int>vc[maxn];
void dfs(int k,int f)
{
    vis[k]=1;
    
    if(f&1) ans=ans^a[k];
    else tmp=tmp^a[k];
    
    for(int i=0;i<vc[k].size();i++)
    {
        int v=vc[k][i];
        if(!vis[v])dfs(v,f^1);
    }
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        memset(vis,0,sizeof(vis));
        for(int i=1;i<=n;i++)
        {
            vc[i].clear();
            scanf("%d",&a[i]);
        }
        for(int i=1;i<n;i++)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            vc[x].push_back(y);
            vc[y].push_back(x);
        }
        ans=0;tmp=0;
        dfs(1,1);
        
        if(ans==tmp)printf("D\n");
        else printf("Q\n");
    }
      
    return 0;
}