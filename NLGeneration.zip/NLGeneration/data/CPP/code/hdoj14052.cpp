// Graph Algorithm->Maximum Flow Algorithm,Data Structure->Disjoint Set Union (DSU),Graph Algorithm->Euler Circuit / Euler Path
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 30
int pre[MAXN], in[MAXN], out[MAXN];
bool visit[MAXN];
int find(int x)
{
	return x == pre[x] ? x : find(pre[x]);
}
void join(int x, int y)
{
	int root1, root2;
	root1 = find(x);
	root2 = find(y);
	if(root1 != root2)
		pre[root2] = root1;
}
int main()
{
	int ncase;
	int wordnum, len; 
	int start, end1; 
	char str[1010];
	int innum, outnum; 
	int root; 
	bool flag; 
	bool flag1; 
	scanf("%d", &ncase);
	while(ncase--)
	{
		memset(in, 0, sizeof(in));
		memset(out, 0, sizeof(out));
		memset(visit, false, sizeof(visit));
		for(int i = 1; i < MAXN; ++i)
			pre[i] = i;
		innum = outnum = root = 0;
		flag = flag1 = true;
		scanf("%d", &wordnum);
		for(int i = 1; i <= wordnum; ++i)
		{
			scanf("%s", str);
			len = strlen(str);
			start = str[0] - 'a' + 1;
			end1 = str[len - 1] - 'a' + 1;
			visit[start] = true;
			visit[end1] = true;
			out[start]++;
			in[end1]++;
			join(start, end1);
		}
		for(int i = 1; i < MAXN; ++i)
		{
			if(visit[i])
			{
				if(pre[i] == i)
					root++;
				if(in[i] != out[i])
				{
					if(in[i] - out[i] == 1)
						innum++;
					else if(out[i] - in[i] == 1)
						outnum++;
					else
						flag1 = false;
				}
			}
			if(root > 1)
			{
				flag = false;
				break;
			}
		}
		if((flag && innum == 0 && outnum == 0 && flag1) || (flag && innum == 1 && outnum == 1 && flag1))
			printf("Ordering is possible.\n");
		else
			printf("The door cannot be opened.\n");
	}
	return 0;
}