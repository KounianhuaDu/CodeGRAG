// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define CLR(a, b) memset(a, (b), sizeof(a))
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
const int MAXN = 1e5 + 10;
const int MOD = 1e9 + 7;
const int INF = 0x3f3f3f3f;
pii a[MAXN], b[MAXN];
multiset<int> B;
multiset<int> :: iterator it;
int main()
{
    int t; scanf("%d", &t);
    while(t--) {
        int n; scanf("%d", &n);
        for(int i = 1; i <= n; i++) {
            scanf("%d%d", &b[i].fi, &b[i].se);
        }
        for(int i = 1; i <= n; i++) {
            scanf("%d%d", &a[i].fi, &a[i].se);
        }
        sort(a+1, a+n+1); sort(b+1, b+n+1);
        int j = 1; B.clear(); int ans = 0;
        for(int i = 1; i <= n; i++) {
            while(j <= n && a[j].fi <= b[i].fi) {
                B.insert(a[j].se); j++;
            }
            if(B.size() == 0) continue;
            it = B.upper_bound(b[i].se);
            if(it != B.begin()) {
                it--; ans++;
                B.erase(it);
            }
        }
        printf("%d\n", ans);
    }
    return 0;
}