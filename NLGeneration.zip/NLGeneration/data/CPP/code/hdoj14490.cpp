// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int sum,id;
}q[2000010];
int a[2000010];
int sum[2000010];
int main(){
    int n;
    while(scanf("%d",&n) && n)
    {
        for (int i = 1; i <= n; i++)
        {
            scanf("%d",&a[i]);
            sum[i] = sum[i - 1] + a[i];
        } 
        for (int i = 1; i <= n; i++) 
        {
            sum[i + n] = sum[i + n - 1] + a[i];
        }
        int front = 0,head = 0,ans = 0;   
        for (int i = 1; i <= 2 * n; i++)
        {
            while(front < head && sum[i] < q[head - 1].sum) head--; 
            q[head].sum = sum[i];   
            q[head++].id = i;   
            if (i > n && q[front].sum >= sum[i - n]) ans++;    
            while(front < head && q[front].id <= i - n + 1) front++; 
        }
        printf("%d\n",ans);
    }
    return 0;
}