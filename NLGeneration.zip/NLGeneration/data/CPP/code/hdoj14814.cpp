// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define _CRT_SECURE_NO_DEPRECATE
using namespace std;
int a[32] = { 1,3,2,1,10,2, 4, 1,3, 9, 9, 11,  6,14,6, 8, 5,13,5, 7, 13,15,5,7,  2,4,12,10,3,1,11,9 };
int b[32] = { 2,4,4,3,12,10,12,9,11,11,10,12,  8,16,14,16,7,15,13,15,14,16,6,8,  6,8,16,14,7,5,15,13 };
int dis[1000000];
int getKey(int* p)
{
	int ans = 0;
	for (int i = 0; i < 16; i++)
		if (p[i])
			ans |= (1 << i);
	return ans;
}
void bfs(int x)
{
	dis[x] = 0;
	queue<int> Q;
	Q.push(x);
	while (!Q.empty())
	{
		int cur = Q.front();
		Q.pop();
		for (int i = 0; i < 32; i++)
		{
			int temp = cur;
			int j1 = cur & (1 << (a[i] - 1));
			int j2 = cur & (1 << (b[i] - 1));
			if (j1 == j2)
				continue;
			temp ^= (1 << (a[i] - 1));
			temp ^= (1 << (b[i] - 1));
			if (dis[temp] == -1)
			{
				dis[temp] = dis[cur] + 1;
				if (dis[temp] < 3)
					Q.push(temp);
			}
		}
	}
}
int main()
{
	
	int x[16] = { 0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1 };
	memset(dis, -1, sizeof(dis));
	int xx = getKey(x);
	bfs(xx);
	
	int T;
	scanf("%d", &T);
	for (int cas = 1; cas <= T; cas++)
	{
		for (int i = 0; i < 16; i++)
			scanf("%d", x + i);
		xx = getKey(x);
		printf("Case #%d: ", cas);
		if (dis[xx] == -1 || dis[xx] > 3)
			printf("more\n");
		else
			printf("%d\n", dis[xx]);
	}
	return 0;
}