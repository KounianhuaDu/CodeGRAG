// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int INF=-0x3f3f3f3f;
const int N=2e2+10;
bool isprime[40010];
void sushu()
{
    memset(isprime,0,sizeof(isprime));
    isprime[1]=1;
    for(int i=2;i<=40000;i++)
    {
        if(isprime[i]) continue;
        for(int j=i+i;j<=40000;j+=i)
            isprime[j]=1;
    }
}
struct asd{
    int x,y;
};
int dx[4]={0,0,-1,1};
int dy[4]={1,-1,0,0};
int step[N][N];
int ma[N][N];
int sx,sy,ex,ey;
void init()
{
    int i,j,m;
    i=j=0;
    memset(ma,0,sizeof(ma));
    m=ma[0][0]=40000;
    while(m>1)
    {
        while(j+1<200&&ma[i][j+1]==0)
            ma[i][++j]=--m;
        while(i+1<200&&ma[i+1][j]==0)
            ma[++i][j]=--m;
        while(j-1>=0&&ma[i][j-1]==0)
            ma[i][--j]=--m;
        while(i-1>=0&&ma[i-1][j]==0)
            ma[--i][j]=--m;
    }
}
void BFS()
{
    asd now,ne;
    queue<asd>q;
    memset(step,-1,sizeof(step));
    now.x=sx;
    now.y=sy;
    step[sx][sy]=0;
    q.push(now);
    while(!q.empty())
    {
        now=q.front();
        q.pop();
        if(now.x==ex&&now.y==ey)
        {
            printf("%d\n",step[ex][ey]);
            return;
        }
        for(int i=0;i<4;i++)
        {
            int xx=dx[i]+now.x;
            int yy=dy[i]+now.y;
            if(xx<0||yy<0||xx>=200||yy>=200||step[xx][yy]!=-1||!isprime[ma[xx][yy]])
                continue;
            step[xx][yy]=step[now.x][now.y]+1;
            ne.x=xx;
            ne.y=yy;
            q.push(ne);
        }
    }
    if(step[ex][ey]==-1)
        puts("impossible");
}
int main()
{
    int cas=1;
    sushu();
    init();
    int x,y;
    while(~scanf("%d%d",&x,&y))
    {
        printf("Case %d: ",cas++);
        if(!isprime[x]||!isprime[y])
        {
            puts("impossible");
            continue;
        }
        for(int i=0;i<200;i++)
            for(int j=0;j<200;j++)
            {
                if(ma[i][j]==x)
                {
                    sx=i;
                    sy=j;
                }
                if(ma[i][j]==y)
                {
                    ex=i;
                    ey=j;
                }
            }
        BFS();
    }
    return 0;
}