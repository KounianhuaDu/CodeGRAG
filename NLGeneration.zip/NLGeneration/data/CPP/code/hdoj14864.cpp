// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n;
struct Node
{
    int par;
    int son[105];
    int num;
    int mson[105];
    int len;
    int mx;
    int mx_;
    int mx2;
    int ft;
}a[10005];
void init(int n)
{
    for(int i=0;i<=n;i++)
    {
        a[i].par=i;
        a[i].num=0;
        a[i].len=0;
        a[i].mx=0;
        a[i].mx_=0;
        a[i].mx2=0;
        a[i].ft=0;
    }
}
int v[10005];
int dfs(int x)
{
    if(v[x]!=0)return a[x].mx;
    for(int i=0;i<a[x].num;i++)
    {
        a[x].mson[i]=dfs(a[x].son[i])+a[a[x].son[i]].len;
        if(a[x].mson[i]>a[x].mx)
        {
            if(a[x].mx!=0)
            {
                a[x].mx2=a[x].mx;
            }
            a[x].mx=a[x].mson[i];
            a[x].mx_=a[x].son[i];
        }
        else if(a[x].mson[i]>a[x].mx2){a[x].mx2=a[x].mson[i];}
    }
    v[x]=1;
    return a[x].mx;
}
int Ft(int x)
{
    if(v[x])return a[x].ft;
    v[x]=1;
    int xx=Ft(a[x].par);
    if(a[a[x].par].mx>xx)
    {
        if(a[a[x].par].mx_!=x)a[x].ft=a[a[x].par].mx;
        else
        {
            if(a[a[x].par].mx2>xx){a[x].ft=a[a[x].par].mx2;}
            else a[x].ft=xx;
        }
    }
    else a[x].ft=xx;
    a[x].ft+=a[x].len;
    return a[x].ft;
}
int main()
{
    while(scanf("%d",&n)!=EOF)
    {
        memset(v,0,sizeof(v));
        init(n);
        int x,y;
        for(int i=2;i<=n;i++)
        {
            scanf("%d%d",&x,&y);
            a[i].par=x;
            a[x].son[a[x].num]=i;
            a[i].len=y;
            a[x].num++;
        }
        dfs(1);
        memset(v,0,sizeof(v));
        v[1]=1;
        for(int i=2;i<=n;i++)
        {
            Ft(i);
        }
        for(int i=1;i<=n;i++)
        {
            printf("%d\n",max(a[i].ft,a[i].mx));
        }
    }
    return 0;
}