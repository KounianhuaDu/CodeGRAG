// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=2000010;
int Next[MAXN];
int extend[MAXN];
void EKMP(char s[],char t[])
{
    int i,j,p,L;
    int lens=strlen(s);
    int lent=strlen(t);
    Next[0]=lent;
    j=0;
    while(j+1<lent && t[j]==t[j+1])j++;
    Next[1]=j;
    int a=1;
    for(i=2; i<lent; i++)
    {
        p=Next[a]+a-1;
        L=Next[i-a];
        if(i+L<p+1)Next[i]=L;
        else
        {
            j=max(0,p-i+1);
            while(i+j<lent && t[i+j]==t[j])j++;
            Next[i]=j;
            a=i;
        }
    }
    j=0;
    while(j<lens && j<lent && s[j]==t[j])j++;
    extend[0]=j;
    a=0;
    for(i=1; i<lens; i++)
    {
        p=extend[a]+a-1;
        L=Next[i-a];
        if(L+i<p+1)extend[i]=L;
        else
        {
            j=max(0,p-i+1);
            while(i+j<lens && j<lent && s[i+j]==t[j])j++;
            extend[i]=j;
            a=i;
        }
    }
}
void getNext(char T[],int len)
{
    int j,k;
    j=0;
    k=-1;
    Next[0]=-1;
    while(j<len)
    {
        if(k==-1 || T[j]==T[k])
            Next[++j]=++k;
        else k=Next[k];
    }
}
char str1[MAXN],str2[MAXN];
int main()
{
    int T;
    int iCase=0;
    scanf("%d",&T);
    while(T--)
    {
        iCase++;
        scanf("%s",str1);
        int len=strlen(str1);
        strcpy(str2,str1);
        strcat(str2,str1);
        EKMP(str2,str1);
        int cnt1=0,cnt2=0,cnt3=0;
        for(int i=0; i<len; i++)
        {
            if(extend[i]>=len)cnt2++;
            else
            {
                if(str2[i+extend[i]]<str1[extend[i]])cnt1++;
                else cnt3++;
            }
        }
        getNext(str1,len);
        int t=len-Next[len];
        int tol=1;
        if(len%t==0)tol=len/t;
        printf("Case %d: %d %d %d\n",iCase,cnt1/tol,cnt2/tol,cnt3/tol);
    }
    return 0;
}