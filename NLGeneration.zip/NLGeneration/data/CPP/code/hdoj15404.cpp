// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
#define INF		0x3f3f3f3f
#define MAXN	1002
#define min(x, y)	((x) < (y) ? (x) : (y))
#define max(x, y)	((x) > (y) ? (x) : (y))
#define MEM(a, v)	memset (a, v, sizeof (a))
struct EDGE {
	int to ;
	int hei, dis ;
};
bool	used[MAXN] ;
int		c, r ;
int		dist[MAXN] ;
vector<EDGE>	maptt1[MAXN] ;
int spfa (const int beg, const int end1, const int lim)
{
	queue<int>	q ;
	EDGE		e ;
	int i, t ;
	MEM (dist, INF) ;
	MEM (used, 0) ;
	q.push (beg) ;
	used[beg] = 1 ;
	dist[beg] = 0 ;
	while (!q.empty ())
	{
		t = q.front () ;
		q.pop () ;
		for (i = 0 ; i < maptt1[t].size() ; ++i)
		{
			e = maptt1[t][i] ;
			if (e.hei >= lim && dist[t] + e.dis < dist[e.to])
			{
				
				dist[e.to] = dist[t] + e.dis ;
				if (!used[e.to])
				{
					used[e.to] = 1 ;
					q.push (e.to) ;
				}
			}
		}
		used[t] = 0 ;
	}
	return dist[end1] ;
}
void init ()
{
	int i ;
	for (i = 1 ; i <= c ; ++i)
		maptt1[i].clear () ;
}
int main ()
{
	int i ;
	int x, y, h, d ;
	int res, low, high, mid, ans ;
	int tcase ;
	tcase = 0 ;
	while (scanf ("%d%d", &c, &r), c | r)
	{
		EDGE	e ;
		init () ;
		for (i = 1 ; i <= r ; ++i)
		{
			scanf ("%d%d%d%d", &x, &y, &h, &d) ;
			h = (h == -1 ? INF : h) ;
			e.to  = y ;
			e.hei = h ;
			e.dis = d ;
			maptt1[x].push_back(e) ;
			e.to  = x ;
			maptt1[y].push_back(e) ;
		}
		scanf ("%d%d%d", &x, &y, &high) ;
		
		low = 1 ;
		res = INF ;
		while (low <= high)
		{
			mid = (low + high) / 2 ;
			res = spfa (x, y, mid) ;
			if (INF == res)
				high = mid - 1 ;
			else
			{
				low = mid + 1 ;
				ans = res ;
				h   = mid ;
			}
		}
		if (tcase)
			putchar ('\n') ;
		printf ("Case %d:\n", ++tcase) ;
		if (ans != INF)
		{
			printf ("maximum height = %d\nlength of shortest route = %d\n",
				h, ans) ;
		}
		else
			printf ("cannot reach destination\n") ;
	}
	return 0 ;
}