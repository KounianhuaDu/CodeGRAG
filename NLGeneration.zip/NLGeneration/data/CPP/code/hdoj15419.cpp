// Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define max_size 1048576
using namespace std;
int tree[max_size + 1] = { 0 };
void insert(int root, int num) {
	if (tree[root] == 0) {
		tree[root] = num;
		return;
	}
	else if (num > tree[root]) {
		if (tree[root * 2] == 0) {
			tree[root * 2] = num;
			return;
		}
		else
			insert(root * 2, num);
	}
	else {
		if (tree[root * 2 + 1] == 0) {
			tree[root * 2 + 1] = num;
			return;
		}
		else
			insert(root * 2 + 1, num);
	}
	return;
}
int main() {
	
	int N;
	cin >> N;
	for (int i = 0; i < N; i++) {
		int num;
		cin >> num;
		insert(1, num);
	}
	bool flag = true;
	int num_node = 1;
	for (int i = 1; i <= max_size; i++) {
		if (num_node > N)
			break;
		if (tree[i] != 0) {
			if (i != 1)
				cout << " ";
			cout << tree[i];
			num_node++;
		}
		else
			flag = false;
	}
	cout << endl;
	if (flag)
		cout << "YES";
	else
		cout << "NO";
	return 0;
}