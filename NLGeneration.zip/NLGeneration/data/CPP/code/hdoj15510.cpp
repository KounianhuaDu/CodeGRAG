// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 100000
using namespace std;
int vis[1005],mp[1005][1005],dis1[1005],dis2[1005],tar,n,k;
void dijkstra(){
	int i,m,x,j;
	memset(vis,0,sizeof(vis));
	for(i=1;i<=n;i++)dis1[i]=dis2[i]=inf;
	dis1[tar]=dis2[tar]=0;
	for(i=1;i<=n;i++){
		x=0,m=inf;
		for(j=1;j<=n;j++){
			if(!vis[j]&&dis1[j]<m){
				x=j;
				m=dis1[j];
			}
		}
		vis[x]=1;
		for(j=1;j<=n;j++){
			if(!vis[j])
			dis1[j]=min(dis1[j],dis1[x]+mp[x][j]);
		}
	}
	memset(vis,0,sizeof(vis));
	for(i=1;i<=n;i++){
		x=0,m=inf;
		for(j=1;j<=n;j++){
			if(!vis[j]&&dis2[j]<m){
				x=j;
				m=dis2[j];
			}
		}
		vis[x]=1;
		for(j=1;j<=n;j++){
			if(!vis[j])
			dis2[j]=min(dis2[j],dis2[x]+mp[j][x]);
		}
	}
	return ;
}
int main()
{
	int x,y,w,i,j;
	scanf("%d%d%d",&n,&k,&tar);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)mp[i][j]=inf;
	while(k--){
		scanf("%d%d%d",&x,&y,&w);
		mp[x][y]=w;
	}
	dijkstra();
	int maxn=0;
	for(i=1;i<=n;i++)maxn=max(maxn,dis1[i]+dis2[i]);
	printf("%d\n",maxn);
    return 0;
}