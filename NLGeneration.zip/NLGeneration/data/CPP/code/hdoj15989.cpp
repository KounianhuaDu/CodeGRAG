// Data Structure->Stack,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main()
{
    int i,j,m,n;
    string s;
    int ss;
    cin>>n;
    while(n--)
    {
        cin>>m>>s;
        if(s[2]=='F')
        {
            queue<int>q;
            while(m--)
            {
                cin>>s;
                if(s[0]=='I')
                {
                    cin>>ss;
                    q.push(ss);
                }
                else if(s[0]=='O')
                {
                    if(!q.empty())
                    {
                        cout<<q.front()<<endl;
                        q.pop();
                    }
                    else
                        cout<<"None"<<endl;
                }
            }
        }
        else if(s[2]=='L')
        {
            stack<int>k;
            while(m--)
            {
                cin>>s;
                if(s[0]=='I')
                {
                    cin>>ss;
                    k.push(ss);
                }
                else if(s[0]=='O')
                {
                    if(!k.empty())
                    {
                        cout<<k.top()<<endl;
                        k.pop();
                    }
                    else
                        cout<<"None"<<endl;
                }
            }
        }
    }
    return 0;
}