// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define ull unsigned long long
#define all(x) (x).begin(), (x).end()
#define clr(a, v) memset( a , v , sizeof(a) )
#define pb push_back
#define mp make_pair
#define read(f) freopen(f, "r", stdin)
#define write(f) freopen(f, "w", stdout)
using namespace std;
struct node
{
    int x;
    int y;
};
int adj[50][50];
int m, n, k;
int maxn;
void dfs ( int x, int y, int cnt )
{
    if ( x >= n )
    {
        maxn = max ( maxn, cnt );
        return;
    }
    if ( y >= n )
    {
        dfs ( x + 1, 0, cnt );
        return;
    }
    if ( adj[x][y] == 1 )
    {
        dfs ( x, y + 1, cnt );
        return;
    }
    dfs ( x, y + 1, cnt );
    bool flag = false;
    int t;
    for ( int i = x - 1; i >= 0; i -- )
    {
        if ( adj[i][y] )
        {
            if ( flag == false )
            {
                flag = true;
                continue;
            }
            else
            {
                if ( adj[i][y] == 2 )
                {
                    return;
                }
                else
                {
                    break;
                }
            }
        }
    }
    flag = false;
    for ( int i = y - 1; i >= 0; i -- )
    {
        if ( adj[x][i] )
        {
            if ( flag == false )
            {
                flag = true;
                continue;
            }
            else
            {
                if ( adj[x][i] == 2 )
                {
                    return;
                }
                else
                {
                    break;
                }
            }
        }
    }
    adj[x][y] = 2;
    dfs ( x, y + 1, cnt + 1 );
    adj[x][y] = 0;
}
int main()
{
    while ( cin >> n >> m >> k )
    {
        struct node p[50];
        maxn = 0;
        memset ( p, 0, sizeof ( p ) );
        memset ( adj, 0, sizeof ( adj ) );
        for ( int i = 0; i < k; i ++ )
        {
            cin >> p[i].x >> p[i].y;
            adj[p[i].x][p[i].y] = 1;
        }
        dfs ( 0, 0, 0 );
        cout << maxn << endl;
    }
    return 0;
}