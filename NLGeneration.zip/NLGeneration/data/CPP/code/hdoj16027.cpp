// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 1300
#define INF 1000000007
using namespace std;
int dp[2][MAXN];
int ma[10][10]={{0,1,2,3},{0,0,1,1},{2,-1,3,-1}};
bool vi[10][10];
int n,m,s,sum;
int cal(int pre,int now)
{
    int ans=0;
    int num[5]={0},num2[5]={0};
    for(int i=m-1;i>=0;--i,now/=3,pre/=4)
        num[i]=now%3,num2[i]=pre%4;
    for(int i=0;i<m;++i)
    {
        int a=num2[i],b=num[i];
        if(ma[b][a]==-1)    return -1;
        ans=ans*4+ma[b][a];
    }
    return ans;
}
void dfs(int h,int po,int ty,int pre,int now)
{
    if(po==m)
    {
        int newt;
        for(int i=0;i<MAXN;++i)
        {
            newt=cal(i,pre);
            if(newt!=-1)
                dp[!s][newt]=max(dp[!s][newt],now+dp[s][i]),sum=max(sum,now+dp[s][i]);
        }
    }
    else    if(vi[h][po])   dfs(h,po+1,ma[1][ty],pre*3+1,now);
    else
    {
        if(ty!=3&&ty!=1)    dfs(h,po+1,ma[2][ty],pre*3+2,now+1);
        dfs(h,po+1,ty,pre*3,now);
    }
}
int main()
{
    int q,ans=0;
    while(scanf("%d%d%d",&n,&m,&q)==3)
    {
        for(int i=0;i<2;++i)
            for(int j=0;j<MAXN;++j)
                dp[i][j]=-INF;
        dp[0][0]=0;
        sum=0;
        memset(vi,0,sizeof(vi));
        for(int i=0;i<q;++i)
        {
            int a,b;
            scanf("%d%d",&a,&b);
            vi[a][b]=1;
        }
        s=0;
        for(int i=0;i<n;++i)
        {
            for(int j=0;j<MAXN;++j)
                dp[!s][j]=-INF;
            dfs(i,0,0,0,0);
            s=!s;
        }
        ans=sum;
        for(int i=0;i<MAXN;++i)
            ans=max(ans,dp[s][i]);
        printf("%d\n",ans);
    }
    return 0;
}