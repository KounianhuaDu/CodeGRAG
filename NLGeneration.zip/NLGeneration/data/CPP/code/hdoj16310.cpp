// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define rep(i,n) for(int i=0; i<n; i++)
#define repf(i,n,m) for(int i=(n); i<=(m); ++i)
#define repd(i,n,m) for(int i=(n); i>=(m); --i)
#define max(a,b) (a)>(b)?(a):(b)
#define min(a,b) (a)<(b)?(a):(b)
#define fab(a) ((a)>0?(a):(0-(a)))
#define ll long long
#define arc(a) ((a)*(a))
#define inf 100000
#define exp 0.000001
#define N 100000
struct node
{
	int y,pre;
}a[N+10];
int pre[N+10];
int n,m;
int len,cont;
int h[N+10];
int fa[N+10];
int pp[N+10];
void addpage(int x,int y)
{
	a[len].y=y;a[len].pre=pre[x];pre[x]=len++;
}
void dfs(int stage,int s)
{
    h[s]=stage;
	for(int i=pre[s]; i!=-1; i=a[i].pre)
	{
		int y=a[i].y;
		fa[y]=s;
		dfs(stage+1,y);
	}
}
int lcy(int x,int y)
{
     int sum=0;
	 if(h[x]>h[y]){
		 while(h[x]>h[y]){
			 x=fa[x];sum++;
		 }
	 }
	  if(x==y)  return sum;
	 if(h[y]>h[x])
		{
		 while(h[y]>h[x]) y=fa[y];
		}
	 while(x!=y)
	 {
		 sum+=1;
		 x=fa[x];
		 y=fa[y];
	 }
	 sum++;
	 return sum;
}
void fun()
{
	scanf("%d%d",&n,&m);
	cont=1;
	int x,y;
    map<string,int> q;
	string s1,s2;
	 map<string,int>::iterator iter;
	repf(i,1,n-1)
	{
		cin>>s1>>s2;
		iter=q.find(s1);
		if(iter==q.end())
		{
		   	x=cont++;q.insert(map<string,int>::value_type(s1,x));
		}
		else
			x=iter->second;
		iter=q.find(s2);
		if(iter==q.end())
		{
			y=cont++;q.insert(map<string,int>::value_type(s2,y));
		}
		else
			y=iter->second;
	   addpage(y,x);
	   pp[x]++;
	}
	repf(i,1,cont-1)
		if(pp[i]==0)
		{  dfs(1,i); break;}
	while(m--){
    if(n==1)  {printf("0\n");continue;}
	cin>>s1>>s2;
    iter=q.find(s1); x=iter->second;
	iter=q.find(s2); y=iter->second;
	printf("%d\n",lcy(x,y));
	}
}
int main()
{
	int test;
	scanf("%d",&test);
	while(test--)
	{
		len=1;
		memset(fa,-1,sizeof(fa));
		memset(pre,-1,sizeof(pre));
		memset(h,-1,sizeof(h));
		memset(pp,0,sizeof(pp));
		fun();
	}
   return 0;
}