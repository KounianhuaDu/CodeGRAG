// Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int main(){
    int T,a[5005],i,k,n,m;
    scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        for(i=0;i<5005;i++)
            a[i]=1;
            m=n;
        while(m>3){
            k=0;
            m=0;
            for(i=1;i<=n;i++){
                if(a[i]){
                    k+=1;
                    if(k%2==0)
                        a[i]=0;
                    m+=a[i];
                }
            }
            k=0;
            if(m<=3) break;
            else m=0;
            for(i=1;i<=n;i++){
                if(a[i]){
                    k+=1;
                    if(k%3==0)
                        a[i]=0;
                }
                m+=a[i];
            }
        }
        for(i=1;i<=n;i++){
            if(a[i]){
                if(i==1) printf("%d",i);
            else printf(" %d",i);
            }
        }
        printf("\n");
    }
    return 0;
}