// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define debug puts("YES");
#define rep(x,y,z) for(int (x)=(y);(x)<(z);(x)++)
#define read(x,y) scanf("%d%d",&x,&y)
#define lrt int l,int r,int rt
#define root l,r,rt
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
const int  maxn =6e4+5;
const int INF = 1e8;
int maxv[maxn<<2],minv[maxn<<2];
void pushup(lrt)
{
    maxv[rt]=max(maxv[rt<<1],maxv[rt<<1|1]);
    minv[rt]=min(minv[rt<<1],minv[rt<<1|1]);
}
void build(lrt)
{
    if(l==r) {  minv[rt]=INF;maxv[rt]=-INF; return ; }
    int mid=l+r>>1;
    build(lson),build(rson),pushup(root);
}
void Clear(lrt,int pos,int v1,int v2)
{
    if(l==r) {maxv[rt]=v1;minv[rt]=v2;return ;}
    int mid=l+r>>1;
    if(pos<=mid) Clear(lson,pos,v1,v2);
    if(mid<pos) Clear(rson,pos,v1,v2);
    pushup(root);
}
int n,m;
int x,y;
int s[maxn][10],op[maxn];
int ans[maxn];
void init()
{
    memset(ans,0,sizeof(ans));
    memset(op,0,sizeof(op));
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&op[i]);
        if(op[i]) scanf("%d",&op[i]);
        else    for(int j=0;j<m;j++) scanf("%d",&s[i][j]);
    }
}
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        init();
        for(int i=0;i<(1<<m);i++)
        {
            build(1,n,1);
            for(int j=1;j<=n;j++)
            {
                if(op[j]) Clear(1,n,1,op[j],-INF,INF);
                else
                {
                    int tp=0;
                    for(int k=0;k<m;k++)
                    {
                        if((1<<k)&i) tp+=s[j][k];
                        else tp-=s[j][k];
                    }
                    Clear(1,n,1,j,tp,tp);
                }
                ans[j]=max(ans[j],maxv[1]-minv[1]);
            }
        }
        for(int i=1;i<=n;i++) printf("%d\n",ans[i]);
    }
    return 0;
}