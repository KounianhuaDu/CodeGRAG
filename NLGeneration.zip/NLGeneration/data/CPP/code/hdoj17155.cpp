// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
typedef  long long ll;
const int maxn=1000100;
int head[maxn],tot,ans;
struct node
{
    int next;
    int to;
} edge[maxn*2];
void addedge(int from,int to)
{
    edge[tot].to=to;
    edge[tot].next=head[from];
    head[from]=tot++;
}
int dfs(int u,int fa)
{
    int num=0;
    for(int i=head[u]; ~i; i=edge[i].next)
    {
        int v=edge[i].to;
        if(v==fa) continue;
        num+=dfs(v,u);
    }
    if(num>1)
    {
        if(fa==-1) ans+=num-2;
        else ans+=num-1;
        return 0;
    }
    return 1;
}
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        int n;
        memset(head,-1,sizeof(head));
        tot=0;
        scanf("%d",&n);
        for(int i=0; i<n-1; i++)
        {
            int a,b;
            scanf("%d %d",&a,&b);
            addedge(a,b);
            addedge(b,a);
        }
        ans=0;
        dfs(1,-1);
        printf("%d\n",ans+ans+1);
    }
    return 0;
}