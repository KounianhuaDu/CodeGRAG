// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
using namespace std;
typedef long long ll;
const int N=5e3+5;
const int M=5e6+5;
struct node
{
    int v,w,ne;
}edge[M];
int head[N],low[N],dfn[N];
int cut,top,e,ans;
int m,n;
void init()
{
    memset(head,-1,sizeof(head));
    e=0;
}
void add(int a,int b,int c)
{
    edge[e].v=b;
    edge[e].w=c;
    edge[e].ne=head[a];
    head[a]=e++;
}
void tarjan(int now,int pre)
{
    low[now]=dfn[now]=++top;
    bool flag=1;
    for(int i=head[now];i!=-1;i=edge[i].ne)
    {
        int v=edge[i].v;
        if(v==pre&&flag)
        {
            flag=0;
            continue;
        }
        if(!dfn[v])
        {
            tarjan(v,now);
            low[now]=min(low[now],low[v]);
            if(dfn[now]<low[v])
                ans=min(edge[i].w,ans);
        }
        else
            low[now]=min(low[now],dfn[v]);
    }
}
void solve()
{
    memset(low,0,sizeof(low));
    memset(dfn,0,sizeof(dfn));
    top=0;
    cut=0;
    ans=inf;
    for(int i=1;i<=n;i++)
    {
        if(!dfn[i])
        {
            tarjan(i,-1);
            cut++;
        }
    }
    if(cut>1) ans=0;
    else if(ans==inf) ans=-1;
    else if(ans==0) ans=1;
    printf("%d\n",ans);
}
int main()
{
    while(~scanf("%d %d",&n,&m))
    {
        if(!n&&!m) break;
        int a,b,c;
        init();
        for(int i=0;i<m;i++)
        {
            scanf("%d %d %d",&a,&b,&c);
            add(a,b,c);
            add(b,a,c);
        }
        solve();
    }
    return 0;
}