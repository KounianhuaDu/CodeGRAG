// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char str[1111111];
int Next[1111111];
void GetNext()
{
	Next[0] = -1;
	int k,len;
	len = strlen(str);
	for(int i = 1; i < len; ++i)
	{
		k = Next[i-1];
		while(k != -1 && str[k+1] != str[i]) k = Next[k];
		if(k == -1 && str[0] != str[i]) Next[i] = -1;
		else if(k == -1 && str[0] == str[i]) Next[i] = 0;
		else Next[i] = k+1;
	}
}
int num[1111111],tp;
int main()
{
	int n,m,t,i,j,u,v,w,len,k,mm,mlen,l,r;
	int pos;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%s",str);
		GetNext();
		len = strlen(str);
		tp = 0;
		num[tp++] = len;
		k = Next[len-1];
		while(k != -1)
		{
			num[tp++] = k+1;
			k = Next[k];
		}
		sort(num,num+tp);
		mm = -1;
		for(i = 0; num[i] <= len/3; ++i)
		{
			if(mm == -1 || num[mm] < num[i]) mm = i;
		}
		while(mm != -1)
		{
			l = strstr(str+num[mm],str+len-num[mm])-str;
			if(l >= num[mm] && l+num[mm] <= len-num[mm]) break;
			--mm;
		}
		if(mm == -1) puts("0");
		else printf("%d\n",num[mm]);
	}
    return 0;
}