// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL long long
const int maxn=1005;
const int mod=1000003;
LL c[maxn][maxn]= {};
void cinit()
{
    for(int i=0; i<maxn; i++)
    {
        c[i][0]=c[i][i]=1;
        for(int j=1; j<i; j++)
            c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
    }
}
int bit[40];
int main()
{
    cinit();
    int n;
    while(scanf("%d", &n)!=EOF)
    {
        memset(bit, 0, sizeof(bit));
        for(int i=1; i<=n; i++)
        {
            int x, cnt=0, tem;
            scanf("%d", &x);
            while(x)
            {
                tem=x%2;
                x/=2;
                bit[++cnt]+=tem;
            }
        }
        for(int i=1; i<=n; i++)
        {
            LL ans=0;
            for(int j=1; j<=32; j++)
            {
                for(int k=1; k<=bit[j]&&k<=i; k+=2)
                {
                    if(i-k>n-bit[j]) continue;
                    ans=(ans+c[bit[j]][k]*c[n-bit[j]][i-k]*((1LL<<(j-1))%mod))%mod;
                }
            }
            printf("%I64d%c", ans, i==n?'\n':' ');
        }
    }
    return 0;
}