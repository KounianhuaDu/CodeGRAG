// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

long long g[21];
long long jie(int t)
{
	int i;
	long long s=1;
	for(i=2;i<=t;i++)
	s*=i;
	return s;
}
long long  pailie(int a,int b)
{
	int i,j;
	long long m=1,h;
	for(i=a;i>a-b;i--)
	m*=i;
	h=jie(b);
	return m/h;
}
void f(int n)
{
	int i;
	for(i=3;i<=n;i++)
	{
		g[i]=(i-1)*(g[i-1]+g[i-2]);
	}
}
int main()
{
	int i,j,n,a,b;
	long long k;
	scanf("%d",&n);
	g[1]=0;
	g[2]=1;
	for(i=0;i<n;i++)
	{
		scanf("%d%d",&a,&b);
		f(b);
		k=pailie(a,b);
		printf("%lld\n",k*g[b]);
	}
	return 0;
}