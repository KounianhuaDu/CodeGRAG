// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Del(a,b) memset(a,b,sizeof(a))
const long long N = 1600;
using namespace std;
long long dp[N][N];
int main()
{
    long long T;
    scanf("%I64d",&T);
    for(long long cas=1;cas<=T;cas++)
    {
        long long n,x,y,z,t;
        scanf("%I64d%I64d%I64d%I64d%I64d",&n,&x,&y,&z,&t);
        memset(dp,0,sizeof(dp));
        long long ans = n * x * t;
        for(long long i=1;i<=n;i++)
        {
            for(long long j=0;j<=i;j++)
            {
                dp[i][j]=max(dp[i][j],dp[i-1][j]+(i-j-1)*y*(t+j*z));
                if(j!=0)
                    dp[i][j]=max(dp[i][j],dp[i-1][j-1]+(i-j)*y*(t+(j-1)*z));
                ans=max(ans,dp[i][j]+(n-i)*(x+(i-j)*y)*(t+j*z));
            }
        }
        printf("Case #%I64d: %I64d\n",cas,ans);
    }
    return 0;
}