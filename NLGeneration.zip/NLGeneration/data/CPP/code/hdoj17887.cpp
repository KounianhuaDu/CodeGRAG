// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAX 1555
__int64_t x,y,z;
int n,t;
int T,C=0;
__int64_t dp[MAX][MAX];
__int64_t ans,dge;
__int64_t Max(__int64_t a,__int64_t b)
{
    if(a>b) return a;
    return b;
}
void init()
{
    int i,j;
    memset(dp,0,sizeof(dp));
    
    for(i=2;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            if(i==j) {dp[i][j]=dp[i-1][j-1]+((i-j)*z+t)*y*(j-1);break;}
            dp[i][j]=Max( dp[i-1][j-1]+((i-j)*z+t)*y*(j-1),dp[i-1][j]+((i-j-1)*z+t)*y*j );
        }
    }
}
void work()
{
    int i,j;
    C++;
    ans=dge=0;
    for(i=0;i<=n;i++)
    {
        for(j=0;j<=i;j++)
        {
            dge=Max( dge,dp[i][j]+(n-i)*(x+j*y)*((i-j)*z+t) );
        }
        ans=Max(ans,dge);
    }
    printf("Case #%d: %I64d\n",C,ans);
}
int main()
{
    int i,j;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%I64d%I64d%I64d%d",&n,&x,&y,&z,&t);
        init();
        work();
    }
    return 0;
}