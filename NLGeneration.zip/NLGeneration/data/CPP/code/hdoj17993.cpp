// Data Structure->Segment Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int N = 100010;
const int INF = 1e8;
struct line
{
    __int64_t l, r;
    __int64_t sum;
    __int64_t maxx;
    __int64_t lazy;
}tree[8*N];
void push_up(__int64_t i)
{
    tree[i].maxx = max(tree[i*2].maxx, tree[i*2+1].maxx);
    tree[i].sum = tree[i*2].sum+tree[i*2+1].sum;
    return;
}
void push_down(__int64_t i)
{
    if(tree[i].l == tree[i].r || tree[i].lazy == 0) return;
    tree[i*2].lazy += tree[i].lazy;
    tree[i*2+1].lazy += tree[i].lazy;
    tree[i*2].maxx <<= tree[i].lazy;
    tree[i*2].sum <<= tree[i].lazy;
    tree[i*2+1].maxx <<= tree[i].lazy;
    tree[i*2+1].sum <<= tree[i].lazy;
    tree[i].lazy = 0;
}
void build(__int64_t i, __int64_t l, __int64_t r)
{
    tree[i].l = l;
    tree[i].r = r;
    tree[i].lazy = 0;
    if(l == r)
    {
        tree[i].sum = (__int64_t)1;
        tree[i].maxx = (__int64_t)1;
        return;
    }
    __int64_t mid = (l+r) >> (__int64_t)1;
    build(i*2, l, mid);
    build(i*2+1, mid+1, r);
    push_up(i);
}
void update(__int64_t i, __int64_t l, __int64_t r, __int64_t st)
{
    if(st == l && st+tree[i].sum-1 == r)
    {
        tree[i].lazy++;
        tree[i].maxx <<= (__int64_t)1;
        tree[i].sum <<= (__int64_t)1;
        return;
    }
    if(tree[i].l == tree[i].r)
    {
        tree[i].sum += (__int64_t)(r-(l-1));
        tree[i].maxx = tree[i].sum;
        return;
    }
    push_down(i);
    __int64_t mid = st-1+tree[i*2].sum;
    if(mid >= r)
        update(i*2, l, r, st);
    else if(mid < l)
        update(i*2+1, l, r, mid+1);
    else
    {
        update(i*2, l, mid, st);
        update(i*2+1, mid+1, r, mid+1);
    }
    push_up(i);
}
__int64_t query(__int64_t i, __int64_t l, __int64_t r, __int64_t st)
{
    if(st == l && st-1+tree[i].sum == r)
    {
        return tree[i].maxx;
    }
    if(tree[i].l == tree[i].r)
    {
        return (__int64_t)(r-(l-1));
    }
    push_down(i);
    __int64_t mid = st-1+tree[i*2].sum;
    if(mid >= r)
        return query(i*2, l, r, st);
    else if(mid < l)
        return query(i*2+1, l, r, mid+1);
    else
    {
        return max(query(i*2, l, mid, st),query(i*2+1, mid+1, r, mid+1));
    }
}
int main()
{
  
    __int64_t t, n, m, l, r, Case = 1;
    char s[5];
    scanf("%I64d", &t);
    while(t--)
    {
        scanf("%I64d%I64d", &n, &m);
        build(1, 1, n);
        printf("Case #%I64d:\n", Case++);
        for(__int64_t i = 1; i <= m; i++)
        {
            scanf("%s", s);
            if(s[0] == 'D')
            {
                scanf("%I64d%I64d", &l, &r);
                update(1, l, r, 1);
            }
            else if(s[0] == 'Q')
            {
                scanf("%I64d%I64d", &l, &r);
                printf("%I64d\n", query(1, l, r, 1));
            }
        }
    }
    return 0;
}