// Math and Computational Geometry->Greatest Common Divisor (GCD),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int mod=(1e9+7);
long long int  euler_phi(int n)
{
    int m=(int)sqrt(n+0.5);
    long long int ans=n;
    for(int i=2;i<=m;i++)
    if(n%i==0)
    {
        ans=ans/i*(i-1);
        while(n%i==0)
            n/=i;
    }
    if(n>1)
        ans=ans/n*(n-1);
    return ans;
}
int n,k;
int main()
{
    while(scanf("%d%d",&n,&k)!=EOF)
    {
        if(n==1) puts("1");
        else if(k>2) puts("0");
        else if(k==2) puts("1");
        else
        {
            long long int ans=0;
            for(int g=1;g<=n;g++)
            {
                if(n<g*g) break;
                if(n%g==0)
                {
                    if(g!=n/g)
                        ans=(ans+(euler_phi(n/g)*euler_phi(g))%mod*2)%mod;
                    else
                        ans=(ans+(euler_phi(n/g)*euler_phi(g))%mod)%mod;
                }
            }
            printf("%I64d\n",ans%mod);
        }
    }
    return 0;
}