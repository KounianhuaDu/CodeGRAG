// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define N 50010
#define inf 0x7fffffff
inline int read(){
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
    return x*f;
}
int n,m,h[N],num=0,a[N];
int size[N],fa[N],dep[N],son[N];
int id[N],top[N],dfn=0,w[N];
struct edge{
    int to,next;
}data[N<<1];
struct Data{
    int x,mn,mx;
    Data(){x=0;mn=inf;mx=0;}
    Data operator+(Data b){
        Data res;
        res.mx=max(mx,b.mx);
        res.mn=min(mn,b.mn);
        res.x=max(x,b.x);
        res.x=max(res.x,b.mx-mn);
        return res;
    }
};
struct node{
    Data x,y;
    int lazy;
}tree[N<<2];
void dfs1(int x){
    size[x]=1;
    for(int i=h[x];i;i=data[i].next){
        int y=data[i].to;
        if(fa[x]==y) continue;
        fa[y]=x;dep[y]=dep[x]+1;dfs1(y);size[x]+=size[y];
        if(size[y]>size[son[x]]) son[x]=y;
    }
}
void dfs2(int x,int tp){
    id[x]=++dfn;w[dfn]=a[x];top[x]=tp;
    if(son[x]) dfs2(son[x],tp);
    for(int i=h[x];i;i=data[i].next){
        int y=data[i].to;
        if(y==fa[x]||y==son[x]) continue;
        dfs2(y,y);
    }
}
inline void pushup(int p){
    tree[p].x=tree[p<<1].x+tree[p<<1|1].x;
    tree[p].y=tree[p<<1|1].y+tree[p<<1].y;
}
void build(int p,int l,int r){
    tree[p].x.x=0;tree[p].y.x=0;tree[p].lazy=0;
    if(l==r){
        tree[p].x.mx=tree[p].y.mx=w[l];
        tree[p].x.mn=tree[p].y.mn=w[l];return;
    }
    int mid=l+r>>1;
    build(p<<1,l,mid);build(p<<1|1,mid+1,r);
    pushup(p);
}
void pushdown(int p){
    if(!tree[p].lazy) return;
    tree[p<<1].lazy+=tree[p].lazy;tree[p<<1|1].lazy+=tree[p].lazy;
    tree[p<<1].x.mx+=tree[p].lazy;tree[p<<1|1].x.mx+=tree[p].lazy;
    tree[p<<1].x.mn+=tree[p].lazy;tree[p<<1|1].x.mn+=tree[p].lazy;
    tree[p<<1].y.mx+=tree[p].lazy;tree[p<<1|1].y.mx+=tree[p].lazy;
    tree[p<<1].y.mn+=tree[p].lazy;tree[p<<1|1].y.mn+=tree[p].lazy;
    tree[p].lazy=0;
}
Data query(int p,int l,int r,int x,int y,bool f,int v){
    if(x<=l&&r<=y){
        tree[p].lazy+=v;tree[p].x.mn+=v;tree[p].x.mx+=v;
        tree[p].y.mn+=v;tree[p].y.mx+=v;
        return f?tree[p].x:tree[p].y;
    }
    int mid=l+r>>1;pushdown(p);Data res;
    if(x<=mid) res=res+query(p<<1,l,mid,x,y,f,v);
    if(y>mid) res= f?res+query(p<<1|1,mid+1,r,x,y,f,v):query(p<<1|1,mid+1,r,x,y,f,v)+res;
    pushup(p);
    return res;
}
void solve(int x,int y,int v){
    Data ansl,ansr;
    while(top[x]!=top[y]){
        if(dep[top[x]]>=dep[top[y]]){
            ansl=ansl+query(1,1,n,id[top[x]],id[x],0,v);
            x=fa[top[x]];
        }
        else{
            ansr=query(1,1,n,id[top[y]],id[y],1,v)+ansr;
            y=fa[top[y]];
        }
    }
    if(id[x]<id[y]) ansl=ansl+query(1,1,n,id[x],id[y],1,v);
    else ansl=ansl+query(1,1,n,id[y],id[x],0,v);
    ansl=ansl+ansr;
    printf("%d\n",ansl.x);
}
int main(){
    int tt=read();
    while(tt--){
        n=read();num=dfn=0;
        memset(fa,0,sizeof(fa));memset(son,0,sizeof(son));
        memset(h,0,sizeof(h));
        for(int i=1;i<=n;++i) a[i]=read();
        for(int i=1;i<n;++i){
            int x=read(),y=read();
            data[++num].to=y;data[num].next=h[x];h[x]=num;
            data[++num].to=x;data[num].next=h[y];h[y]=num;
        }
        dep[1]=1;dfs1(1);dfs2(1,1);build(1,1,n);
        m=read();
        while(m--){
            int x=read(),y=read(),v=read();
            solve(x,y,v);
        }
    }
    return 0;
}