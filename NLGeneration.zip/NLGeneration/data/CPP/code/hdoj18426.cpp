// Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:1024000000,1024000000")
#define exp 1e-10
using namespace std;
const int N = 105;
const int M = 10005;
const int inf = 1000000000;
const int mod = 2009;
char s1[N],s2[N];
int main()
{
    int t,n,i,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        scanf("%s",s1);
        scanf("%s",s2);
        for(i=j=0;i<n;i++,j++)
            if(s1[i]=='A'&&s2[j]=='U'||s1[i]=='C'&&s2[j]=='G'||s1[i]=='G'&&s2[j]=='C'||s1[i]=='T'&&s2[j]=='A')
                continue;
            else
                break;
        if(i!=n)
            puts("NO");
        else
            puts("YES");
    }
    return 0;
}