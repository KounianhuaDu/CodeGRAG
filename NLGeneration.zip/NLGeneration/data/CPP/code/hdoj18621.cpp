// Graph Algorithm->Hungarian (KM) Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
bool a[205][205];
struct jx{
    LL x[4],y[4];
}data[50000];
int main()
{
    int n,x,y;
    while(scanf("%d",&n)&&n)
    {
        memset(a,false,sizeof(a));
        while(n--)
        {
            scanf("%d%d",&x,&y);
            a[x][y]=true;
        }
        int num=0;
        for(int i=0;i<202;i++)
            for(int j=0;j<202;j++)
        {
            if(a[i][j])
            {
                for(int k=j+1;k<202;k++)
                {
                    if(a[i][k])
                    {
                        for(int l=i+1;l<202;l++)
                        {
                            if(a[l][k])
                            {
                                if(a[l][j])
                                {
                                    data[num].x[0]=i;data[num].y[0]=j;
                                    data[num].x[1]=i;data[num].y[1]=k;
                                    data[num].x[2]=l;data[num].y[2]=k;
                                    data[num].x[3]=l;data[num].y[3]=j;
                                    num++;
                                }
                            }
                        }
                    }
                }
            }
        }
        
      
        LL maxn=0;
       for(int i=0;i<num;i++)
            for(int j=i+1;j<num;j++)
       {
           if(data[j].x[0]>data[i].x[2]||data[j].y[0]>data[i].y[2])
           {
               LL s1=(data[i].x[2]-data[i].x[0])*(data[i].y[2]-data[i].y[0]);
               LL s2=(data[j].x[2]-data[j].x[0])*(data[j].y[2]-data[j].y[0]);
               LL answer=s1+s2;
               
               if(answer>maxn)
                maxn=answer;
           }
           if(data[i].x[0]<data[j].x[0]&&data[i].y[0]<data[j].y[0]&&data[i].x[2]>data[j].x[2]&&data[i].y[2]>data[j].y[2])
           {
               LL s1=(data[i].x[2]-data[i].x[0])*(data[i].y[2]-data[i].y[0]);
               
               LL answer=s1;
               
               if(answer>maxn)
                maxn=answer;
           }
       }
        if(maxn==0)
            printf("imp\n");
        else
            printf("%lld\n",maxn);
    }
    return 0;
}