// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define ll __int64_t
#define N 50007
int a[N],pre[N],suf[N],C[N];
int lowbit(int x)
{
    return x&(-x);
}
void add(int pos,int val)
{
    while(pos<N)
    {
        C[pos]+=val;
        pos+=lowbit(pos);
    }
}
int getsum(int x)
{
    int result=0;
    while(x>0)
    {
        result+=C[x];
        x-=lowbit(x);
    }
    return result;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
            scanf("%d",&a[i]);
        memset(C,0,sizeof(C));
        for(int i=1;i<=n;i++)
        {
            pre[i]=getsum(a[i]);
            add(a[i],1);
        }
        memset(C,0,sizeof(C));
        for(int i=n;i>=1;i--)
        {
            suf[i]=n-i-getsum(a[i]);
            add(a[i],1);
        }
        ll ans=0,p=0;
        for(int i=1;i<n;i++)
        {
            ans+=suf[i]*p;
            p+=pre[i];
        }
        printf("%I64d\n",ans);
    }
}