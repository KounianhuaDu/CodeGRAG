// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=100;
int n,m;
long long ans=0;
struct Node{
	int a,b;
}A[70];
int ol[maxn],of[maxn],vis[10];;
bool judge(){
	for(int i=1;i<=m;++i){
		if(of[A[i].a]!=ol[A[i].a]||of[A[i].b]!=ol[A[i].b])return false;
	}
	return true;
}
void dfs(int k){
	if(k==m+1){
		
		ans++;
		return ;
	}
	ol[A[k].a]++;ol[A[k].b]++;
	if(ol[A[k].a]<=vis[A[k].a]/2&&ol[A[k].b]<=vis[A[k].b]/2)dfs(k+1);
	ol[A[k].a]--;ol[A[k].b]--;
	of[A[k].a]++;of[A[k].b]++;
	if(of[A[k].a]<=vis[A[k].a]/2&&of[A[k].b]<=vis[A[k].b]/2)dfs(k+1);
	of[A[k].a]--;of[A[k].b]--;
}
int main()
{
	int t,i,j,k;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		memset(ol,0,sizeof(ol));
		memset(of,0,sizeof(of));
		memset(vis,0,sizeof(vis));
		for(i=1;i<=m;++i){
			scanf("%d%d",&A[i].a,&A[i].b);
			vis[A[i].a]++;vis[A[i].b]++;
		}
		for(i=1;i<=n;++i){
			if(vis[i]&1)break;
		}
		if(i<=n){
			printf("0\n");
			continue;
		}
		ans=0;dfs(1);
		printf("%lld\n",ans);
	}
	return 0;
}