// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f3f3f3f3f
using namespace std;
const int maxn=1e5+10;
typedef long long ll;
struct node{
	int l, r;
	ll oo, oe, eo, ee;
}tr[maxn<<2];
void pushup(int m){
	tr[m].oo=max(max(tr[m<<1].oo, tr[m<<1|1].oo), max(tr[m<<1].oo+tr[m<<1|1].eo, tr[m<<1].oe+tr[m<<1|1].oo));
	tr[m].oe=max(max(tr[m<<1].oe, tr[m<<1|1].oe), max(tr[m<<1].oo+tr[m<<1|1].ee, tr[m<<1].oe+tr[m<<1|1].oe));
	tr[m].eo=max(max(tr[m<<1].eo, tr[m<<1|1].eo), max(tr[m<<1].eo+tr[m<<1|1].eo, tr[m<<1].ee+tr[m<<1|1].oo));
	tr[m].ee=max(max(tr[m<<1].ee, tr[m<<1|1].ee), max(tr[m<<1].eo+tr[m<<1|1].ee, tr[m<<1].ee+tr[m<<1|1].oe));
}
void build(int m, int l, int r){
	tr[m].l=l;
	tr[m].r=r;
	if(l==r){
		ll x;
		scanf("%lld", &x);
		if(l%2){
			tr[m].oo=x;
			tr[m].oe=tr[m].eo=tr[m].ee=-inf;
		}
		else{
			tr[m].ee=x;
			tr[m].oe=tr[m].eo=tr[m].oo=-inf;
		}
		return;
	}
	int mid=(l+r)>>1;
	build(m<<1, l, mid);
	build(m<<1|1, mid+1, r);
	pushup(m);
}
void updata(int m, int index, ll val){
	if(tr[m].l==tr[m].r){
		if(index%2){
			tr[m].oo=val;
		}
		else{
			tr[m].ee=val;
		}
		return;
	}
	int mid=(tr[m].l+tr[m].r)>>1;
	if(index<=mid) updata(m<<1, index, val);
	else updata(m<<1|1, index, val);
	pushup(m);
}
node Union(node a, node b){
	node t;
	t.oo=max(max(a.oo, b.oo), max(a.oo+b.eo, a.oe+b.oo));
	t.oe=max(max(a.oe, b.oe), max(a.oe+b.oe, a.oo+b.ee));
	t.eo=max(max(a.eo, b.eo), max(a.eo+b.eo, a.ee+b.oo));
	t.ee=max(max(a.ee, b.ee), max(a.ee+b.oe, a.eo+b.ee));
	return t;
}
node query(int m, int l, int r){
	if(tr[m].l==l&&tr[m].r==r){
		return tr[m];
	}
	int mid=(tr[m].l+tr[m].r)>>1;
	node temp;
	if(r<=mid) temp=query(m<<1, l, r);
	else if(l>mid) temp=query(m<<1|1, l, r);
	else{
		temp=Union(query(m<<1, l, mid), query(m<<1|1, mid+1, r));
	}
	return temp;
}
int main(){
	int T;
	scanf("%d", &T);
	while(T--){
		int n, m;
		scanf("%d%d", &n, &m);
		build(1, 1, n);
		int type, a, b;
		while(m--){
			scanf("%d%d%d", &type, &a, &b);
			if(type){
				updata(1, a, (ll)b);
			}
			else{
				node t=query(1, a, b);
				printf("%lld\n", max(max(t.oo, t.oe), max(t.eo, t.ee)));
			}
		}
	}
	return 0;
}