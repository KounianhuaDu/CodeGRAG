// Math and Computational Geometry->Greatest Common Divisor (GCD),Data Structure->Segment Tree,Data Structure->Prefix Array,Basic Algorithm->CDQ Divide and Conquer
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int p[111111],tp,num[1000005],qz[1000005][8],cs[8];
bool IsPrim[1000001];
void Get()
{
    memset(IsPrim,0,sizeof(IsPrim));
    tp = 0;
    int i,j;
    for(i = 2; i <= 1000000; ++i)
    {
        if(!IsPrim[i]) p[tp++] = i;
        for(j = 0; j < tp && p[j]*i <= 1000000; ++j)
        {
            IsPrim[p[j]*i] = true;
            if(!(i%p[j])) break;
        }
    }
}
int Getg(int x)
{
    int i;
    i = 0;
    if(!IsPrim[x]) return 1;
    while(x%p[i] && i < tp)
    {
        i++;
    }
    if(x%p[i]) return 1;
    return !((x/p[i])%p[i])? num[x/p[i]]: num[x/p[i]]+1;
}
int main()
{
    
    
    int i,j,l,r,t,ans;
    num[1] = 0;
    Get();
    for(i = 2; i <= 1000000; ++i)
    {
        num[i] = Getg(i);
    }
    memset(qz,0,sizeof(qz));
    for(i = 2; i <= 1000000; ++i)
    {
        for(j = 1; j <= 7; ++j) qz[i][j] = qz[i-1][j];
        qz[i][num[i]]++;
    }
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d",&l,&r);
        for(i = 1; i <= 7; ++i) cs[i] = qz[r][i] - qz[l-1][i];
        ans = -1;
        for(i = 1; i <= 7; ++i)
        {
            if(!cs[i]) continue;
            for(j = i; j <= 7; ++j)
            {
                if(cs[j] && (j != i || (j == i && cs[j] >= 2) ))
                    ans = max(ans,__gcd(i,j));
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}