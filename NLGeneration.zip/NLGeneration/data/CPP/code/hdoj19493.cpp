// Basic Algorithm->Discretization,Data Structure->Balanced Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 50005
int n;
int id[maxn];
struct Point
{
    int x,y,z;
    bool operator<(Point const &a)const{return y==a.y?x<a.x:y<a.y;}
}a[maxn];
bool cmp(Point a,Point b){return a.x<b.x;}
struct Node{
    
    Node *son[2];
    int rank;
    
    int key;
    int id,len;
    
    int bid,blen;
    bool operator<(const Node &a)const{return rank<a.rank;}
    int cmp(int x)const{if(x==key)return -1;return x<=key?0:1;}
    void maintain()
    {
        blen = len,bid = id;
         if(blen<son[0]->blen)blen = son[0]->blen,bid = son[0]->bid;
        if(blen<son[1]->blen)blen = son[1]->blen,bid = son[1]->bid;
    }
    void initial()
    {
        rank =key=id=len=bid=blen = 0;
    }
};
Node *null = new Node();
struct Treap{
    Node node[maxn*30];
    int cntnode;
    void initial(){cntnode = 0;}
    Node* newNode()
    {
        node[++cntnode].initial();
        node[cntnode].son[0] = node[cntnode].son[1] = null;
        return &node[cntnode];
    }
    void rotate(Node* &o,int d)
    {
        Node*  k = o->son[d^1];o->son[d^1] = k -> son[d];k->son[d] = o;
        o->maintain();k->maintain();o = k;
    }
     void ins(Node*  &o,int x,int id,int len)
    {
        if(o==null)
            {
                o = newNode();
                o->id = id;
                o->len = len;
                o->rank = rand();
                o->bid = o->id;o->blen = o->len;
                o->key = x;o->son[0] = o->son[1] = null;
            }
        else
        {
            int d = o->cmp(x);
            if(d == -1)
            {
                if(len > o->len || len == o->len && id < o->id)
                {
                    o->len = len;
                    o->id = id;
                    o->maintain();
                    return;
                }
            }
            ins(o->son[d],x,id,len);
            o->maintain();
            if(o < o->son[d])
                rotate(o,d^1);
        }
    }
    Node search(Node* &o,int v2)
    {
        
        if(o == null)
        {
            return Node();
        }
        if(v2 < o->key) return search(o->son[0],v2);
        else
        {
            Node tmp = Node();
            tmp.id= o->id;
            tmp.len = o->len;
            if(o->son[0]->blen>tmp.len || o->son[0]->blen == tmp.len
                && o->son[0]->bid < tmp.id)
            {
                tmp.len = o->son[0]->blen;
                tmp.id = o->son[0]->bid;
            }
            Node tmp1  = search(o->son[1],v2);
            if(tmp1.len>tmp.len||tmp1.len == tmp.len && tmp.id>tmp1.id)
                tmp = tmp1;
            return tmp;
        }
    }
}treap;
struct {
    Node *fwt[maxn];
    int N;
    int lowbit(int x) {return x&(-x);}
    void initial(int n){N = n;for(int i = 0;i<=n;i++)fwt[i] = null;}
    void ins(int v1,int v2,Node p)
    {
        while(v1<=N)
        {
            
            treap.ins(fwt[v1],v2,p.id,p.len);
            v1+=lowbit(v1);
        }
    }
    Node search(int v1,int v2)
    {
        Node ans = Node();
        Node tmp;
        while(v1!=0)
        {
            tmp = treap.search(fwt[v1],v2);
            
            if(ans.len<tmp.len || ans.len == tmp.len && ans.id>tmp.id)  ans = tmp;
            v1-=lowbit(v1);
        }
        ans.len++;
        return ans;
    }
}BIT;
void print(Node ans)
{
    printf("%d\n",ans.len);
    int t = ans.id;
    while(id[t])
    {
        printf("%d ",t);
        t = id[t];
    }
    printf("%d\n",t);
}
int main()
{
    #ifdef ACBang
            freopen("1009.in","r",stdin);
            freopen("1.out","w",stdout);
    #endif 
    while(~scanf("%d",&n))
    {
        
        treap.initial();
        for(int i = 1;i<=n;i++){a[i].x= i;scanf("%d",&a[i].y);}
        for(int i = 1;i<=n;i++){scanf("%d",&a[i].z);a[i].z = -a[i].z;}
        sort(a+1,a+n+1);
        int m = 0;id[1] = ++m;
        for(int i = 2;i<=n;i++)if(a[i].y == a[i-1].y) id[i] = m;else  id[i]=++m;
        for(int i=1;i<=n;i++)a[i].y = id[i];
        sort(a+1,a+n+1,cmp);
        BIT.initial(m+1);
        
        Node ans = Node();
        Node tmp;
        for(int i = n;i>=1;i--)
        {
            
            tmp = BIT.search(a[i].y,a[i].z);
           
            id[i] = tmp.id;
            tmp.id = i;
            tmp.key = a[i].z;
            if(ans.len<=tmp.len) ans = tmp;
            BIT.ins(a[i].y,a[i].z,tmp);
        }
        print(ans);
    }
    return 0;
}