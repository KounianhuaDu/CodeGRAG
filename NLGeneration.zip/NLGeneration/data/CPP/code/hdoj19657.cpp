// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long int LL;
LL n,m;
vector<int> vi[10];
set<int> v;
void init()
{
	for(int i=0;i<10;i++) vi[i].clear();
}
int main()
{
	
	
	int T_T;
	scanf("%d",&T_T);
	while(T_T--)
	{
		cin>>n>>m;
		init();
		LL sum=n*(n+1)/2;
		if(sum%m||n+1<2*m)
		{
			puts("NO"); continue;
		}
		LL c=(n-m*2+1)%(m*2)+m*2-1;  
		v.clear();
		for(int i=1;i<=c;i++)
		{
			v.insert(i);
		}
		LL s=c*(c+1)/(m*2);
		for(int i=0;i<m;i++)
		{
			set<int>::iterator it;
			LL ts=0;
			while(ts<s)
			{
				it=v.upper_bound(s-ts);
				LL tmp=*--it;
				vi[i].push_back(tmp);
				ts+=tmp;
				v.erase(it);
			}
		}
		int st=c+1;
		int ed=n;
		int k=(n-c)/(2*m);
		for(int i=0;i<m;i++)
		{
			for(int j=0;j<k;j++)
			{
				vi[i].push_back(st); st++;
				vi[i].push_back(ed); ed--;
			}
		}
		puts("YES");
		for(int i=0;i<m;i++)
		{
			int sz=vi[i].size();
			printf("%d",sz);
			for(int j=0;j<sz;j++)
			{
				printf(" %d",vi[i][j]);
			}
			putchar(10);
		}
	}
    
    return 0;
}