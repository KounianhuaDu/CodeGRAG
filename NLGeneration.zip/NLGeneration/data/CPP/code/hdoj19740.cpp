// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int nwm[200002];
int p[200002];
void Manacher(int n)
{
    nwm[0] = -2;
    int i;
    for(i = 0; i < n; i++)
    {
        nwm[i*2+1] = -1;
        scanf("%d",&nwm[i*2+2]);
    }
    nwm[n*2+1] = -1;
    nwm[n*2+2] = -3;
    int maxid = 0,id;
    n = n*2+2;
    for(i = 2; i < n; ++i)
    {
        if(maxid > i) p[i] = min(p[id*2-i],maxid-i);
        else p[i] = 1;
        while(nwm[i+p[i]] == nwm[i-p[i]]) p[i]++;
        if(p[i]+i > maxid)
        {
            maxid = p[i]+i;
            id = i;
        }
    }
}
int main()
{
    int t,n,z = 0,i,mm,x;
    scanf("%d",&t);
    while(t--)
    {
        mm = 0;
        scanf("%d",&n);
        Manacher(n);
        for(i = 3; i +4< n*2+2; i+=2)
        {
            if(p[i]-1 > mm)
            {
                x = p[i]-1;
                while(x > mm && p[i+x] < x)
                    x--;
                mm = max(mm,x);
            }
        }
        printf("Case #%d: %d\n",++z,mm/2*3);
    }
    return 0;
}