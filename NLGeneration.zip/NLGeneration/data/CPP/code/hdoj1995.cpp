// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=5100;
struct node
{
    string ans;
    int mod;
};
int use[16],vis[N],n,c,flag;
string res;
void init()
{
    flag=-1;
    memset(use,0,sizeof(use));
    memset(vis,0,sizeof(vis));
    res="";
}
void solve()
{
    queue<node>q;
    node u,v;
    if(n==0){
        if(use[0]){printf("0\n");return;}
        else{printf("give me the bomb please\n");return;}
    }
    for(int i=1;i<16;i++){
        if(use[i]){
            vis[i%n]=1;
            if(i<10) u.ans=i+'0';
            else u.ans='A'+i-10;
            u.mod=i%n;
            q.push(u);
        }
    }
    while(!q.empty()){
        u=q.front();q.pop();
        if(u.mod==0){
            if(flag==-1){
                res=u.ans;
                flag=1;
            }
            else if((u.ans.size()<res.size())||(u.ans.size()==res.size()&&u.ans<res))
                res=u.ans;
        }
        for(int i=0;i<16;i++){
            if(use[i]){
                v=u;
                if(i<10)v.ans+=i+'0';
                else v.ans+=i+'A'-10;
                v.mod=(u.mod*c+i)%n;
                if(v.ans.size()<=500&&!vis[v.mod]){
                    vis[v.mod]=1;
                    q.push(v);
                }
            }
        }
    }
    if(flag==1)cout<<res<<endl;
    else printf("give me the bomb please\n");
}
int main()
{
    int T,m;
    char ch[2];
    scanf("%d",&T);
    while(T--){
        init();
        scanf("%d%d%d",&n,&c,&m);
        for(int i=1;i<=m;i++){
            scanf("%s",ch);
            if(ch[0]>='0'&&ch[0]<='9')use[ch[0]-'0']=1;
            else use[ch[0]-'A'+10]=1;
        }
        solve();
    }
    return 0;
}