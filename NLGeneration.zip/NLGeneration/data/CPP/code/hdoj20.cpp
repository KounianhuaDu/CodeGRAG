// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 30
using namespace std;
char maptt1[N],tt[10],gg[10];
int pp,n,pre[N];
int vis[N];
void dfs(int k)
{
	int tmp,i;
	if(k==5)
	{
		tmp=pre[tt[0]-'A']-pow(pre[tt[1]-'A'],2)+pow(pre[tt[2]-'A'],3)-pow(pre[tt[3]-'A'],4)+pow(pre[tt[4]-'A'],5);
        if(tmp==pp&&strcmp(tt,gg)>0)
        {
        	strcpy(gg,tt);
        }
        return;
	}
	for(i=0;i<n;i++)
	{
		if(!vis[maptt1[i]-'A'])
		{
			tt[k]=maptt1[i];
			vis[maptt1[i]-'A']=1;
			dfs(k+1);
			vis[maptt1[i]-'A']=0;
		}
	}
}
int main()
{
	int i;
	for(i=0;i<26;i++)
	pre[i]=i+1;
	while(scanf("%d",&pp)!=EOF,pp)
	{
		scanf("%s",maptt1);
		if(strcmp(maptt1,"END")==0)
		break;
		memset(vis,0,sizeof(vis));
		memset(tt,'\0',sizeof(tt));
		memset(gg,'\0',sizeof(gg));
		n=strlen(maptt1);
		dfs(0);
		if(strlen(gg)==0)
		printf("no solution\n");
		else
		printf("%s\n",gg);
	}
	return 0;
}