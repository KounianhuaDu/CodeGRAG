// Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
using namespace std;
const int maxn=1e4+5;
int n,m,L[maxn],R[maxn],C[maxn];
ll W[maxn];
int vis[maxn],degree[maxn];
int F[maxn];
vector<int >G[maxn];
int findset(int x)
{
    if(F[x]==-1)
        return x;
    return F[x]=findset(F[x]);
}
void init()
{
    scanf("%d%d",&n,&m);
    memset(vis,0,sizeof(vis));
    memset(degree,0,sizeof(degree));
    memset(F,-1,sizeof(F));
    for(int i=1;i<=n;i++)
        G[i].clear();
    for(int i=1;i<=n;i++)
        scanf("%lld",&W[i]);
    int u,v;
    for(int i=0;i<m;i++)
    {
        scanf("%d%d",&u,&v);
        degree[u]++,degree[v]++;
        G[u].push_back(v);
        G[v].push_back(u);
        L[i]=u,R[i]=v;
    }
}
ll solve()
{
    queue<int >Q;
    for(int i=1;i<=n;i++)
    {
        if(degree[i]<2)
        {
            Q.push(i);
            vis[i]=1;
        }
    }
    while(!Q.empty())
    {
        int u=Q.front();Q.pop();
        for(int i=0;i<G[u].size();i++)
        {
            int v=G[u][i];
            if(vis[v]) continue;
            degree[v]--;
            if(degree[v]<2)
            {
                Q.push(v);
                vis[v]=1;
            }
        }
    }
    for(int i=0;i<=n;i++)
    {
        C[i]=1;
    }
    for(int i=0;i<m;i++)
    {
        int u=L[i],v=R[i];
        if(vis[u]||vis[v]) continue;
        if(findset(u)!=findset(v))
        {
            C[findset(v)]+=C[findset(u)];
            W[findset(v)]+=W[findset(u)];
            F[findset(u)]=findset(v);
        }
    }
    ll ans=0;
    for(int i=1;i<=n;i++)
    {
        if(vis[i]||findset(i)!=i) continue;
        if(C[i]&1)
            ans+=W[i];
    }
    return ans;
}
int main()
{
    int T;scanf("%d",&T);
    while(T--)
    {
        init();
        cout<<solve()<<endl;
    }
    return 0;
}