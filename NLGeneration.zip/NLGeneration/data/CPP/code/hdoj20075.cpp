// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1000+5;
#define lson i*2,l,m
#define rson i*2+1,m+1,r
#define INF 1e9
int maxv[maxn*4];
void PushUP(int i)
{
    maxv[i]=max(maxv[i*2],maxv[i*2+1]);
}
void build(int i,int l,int r)
{
    if(l==r)
    {
        scanf("%d",&maxv[i]);
        return;
    }
    int m=(l+r)/2;
    build(lson);
    build(rson);
    PushUP(i);
}
int query(int ql,int qr,int i,int l,int r)
{
    if(ql<=l&&qr>=r) return maxv[i];
    int m=(l+r)/2;
    int ans=-INF;
    if(ql<=m) ans=max(ans,query(ql,qr,lson));
    if(m<qr) ans=max(ans,query(ql,qr,rson));
    return ans;
}
void update(int id,int val,int i,int l,int r)
{
    if(l==r)
    {
        maxv[i]=val;
        return;
    }
    int m=(r+l)/2;
    if(id<=m) update(id,val,lson);
    else update(id,val,rson);
    PushUP(i);
}
int main()
{
    int n,t,T;
    scanf("%d",&T);
    while(T--)
    {
     scanf("%d",&n);
     build(1,1,n);
     scanf("%d",&t);
     for(int i=1;i<=t;i++)
     {
         int a,b;
       scanf("%d%d",&a,&b);
       printf("%d\n",query(a,b,1,1,n));
     }
    }
    return 0;
}