// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int pri[100005];
int num[100005];
int find(int x)
{
	int r=x;
	while(r!=pri[r])
	{
		r=pri[r];
	}
	int i=x,j;
	while(i!=r)
	{
		j=pri[i];
		pri[i]=r;
		i=j;
	}
	return r;
}
void connect(int xx,int yy)
{
	int a=find(xx);
	int b=find(yy);
	if(a!=b)
	pri[b]=a;
}
int main()
{
	int n,m;
	int i,f,d;
	while(scanf("%d%d",&n,&m)!=EOF,n)
	{
		for(i=1;i<=n;i++)
		pri[i]=i;
		for(i=1;i<=m;i++)
		{
			scanf("%d%d",&f,&d);
			connect(f,d);
		}
		int sum=0;
		memset(num,0,sizeof(num));
		for(i=1;i<=n;i++)
		num[find(i)]=1;
		for(i=1;i<=n;i++)
		if(num[i])
		sum++;
		printf("%d\n",sum-1);
	}
	return 0;
}