// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
typedef pair<ll, int> pii;
const int maxn = 1e5 + 5;
const ll INF = 1e18;
int n, m;
vector <pii> edge[maxn];
ll dis[maxn];
int x[maxn], y[maxn], w[maxn];
ll c[maxn];
priority_queue <pii, vector<pii>, greater<pii> > q;
ll dijkstra() {
	while(!q.empty()) {
		pii tmp = q.top();
		q.pop();
		int u = tmp.second;
		if(dis[u] < tmp.first)
			continue;
		for(int i = 0; i < edge[u].size(); i++) {
			ll d = edge[u][i].first + dis[u];
			int v = edge[u][i].second;
			if(dis[v] > d) {
				dis[v] = d;
				q.push(pii(dis[v], v));
			}
		}
	}
	ll ans = 0;
	for(int i = 1; i <= m; i++) {
		if(w[i] == 2) {
			if(dis[i] != INF) {
				ans += dis[i];
			} else {
				return -1;
			}
		}
	}
	return ans;
} 
int main() {
#ifndef ONLINE_JUDGE
	freopen("in.txt", "r", stdin);
#endif
	int T, Case = 1;
	scanf("%d", &T);
	while(T--) {
		scanf("%d%d", &n, &m);
		for(int i = 1; i <= n; i++) {
			scanf("%d", &x[i]);
		}
		for(int i = 1; i <= n; i++) {
			scanf("%d", &y[i]);
		}
		for(int i = 1; i <= n; i++) {
			scanf("%lld", &c[i]);
		}
		for(int i = 1; i <= m; i++) {
			scanf("%d", &w[i]);
		}
		fill(dis + 1, dis + m + 1, INF); 
		for(int i = 1; i <= n; i++) {
			edge[y[i]].push_back(pii(c[i], x[i]));
			if(w[y[i]] == 0 && dis[y[i]] == INF) {
				dis[y[i]] = 0;
				q.push(pii(dis[y[i]], y[i]));
			}
		}
		ll ans = dijkstra();
		printf("Case #%d: %lld\n", Case++, ans);
		for(int i = 1; i <= n; i++) 
			edge[i].clear();
	}
	return 0;
}