// Basic Algorithm->Memorization,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define debug puts("YES");
#define rep(x,y,z) for(int (x)=(y);(x)<(z);(x)++)
#define ll long long
#define lrt int l,int r,int rt
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
#define root l,r,rt
#define mst(a,b) memset((a),(b),sizeof(a))
#define pii pair<ll,ll>
#define mk(x,y) make_pair(x,y)
const int mod=1e9+7;
const int maxn=2e5+9;
const int ub=1e6;
ll powmod(ll x,ll y){ll t; for(t=1;y;y>>=1,x=x*x%mod) if(y&1) t=t*x%mod; return t;}
ll gcd(ll x,ll y){return y?gcd(y,x%y):x;}
int n,m,x,y;
ll ans;
int a[20],cnt[maxn][20];
int bitcnt(int x){int ret=0;while(x) x-=x&-x,ret++;return ret; }
int dfs(int S,int pos){
    if(S==0) return 0;
    if(cnt[S][pos]) return cnt[S][pos];
    int ret=bitcnt(S);
    rep(i,pos,n) ret=min(ret,dfs(S^a[i],i+1)+1);
    return cnt[S][pos]=ret;
}
int main(){
    int t;scanf("%d",&t);
    while(t--){
        mst(cnt,0),ans=0;
        scanf("%d%d",&n,&m);
        rep(i,0,n) scanf("%d",&a[i]);
        rep(i,1,m+1){
            scanf("%d%d",&x,&y);
            ans=(ans+1LL*i*dfs(x^y,0)%mod)%mod;
        }
        printf("%lld\n",ans);
    }
    return 0;
}