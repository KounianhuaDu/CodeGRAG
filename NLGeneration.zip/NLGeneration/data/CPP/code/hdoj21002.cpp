// Math and Computational Geometry->Inverse Element,Math and Computational Geometry->Number Theory,Math and Computational Geometry->Fermat's Little Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int maxn=1111;
int num[maxn];
char s[maxn];
typedef long long ll;
const int mod=1e9+7;
ll f[maxn];
void init()
{
    f[0]=1;
    f[1]=1;
    for(int i=2;i<maxn;i++)
       f[i]=f[i-1]*i%mod;
}
ll cal(ll x)
{
    ll res=1;
    int k=mod-2;
    while(k)
    {
        if(k&1)
        {
            res*=x;
            res%=mod;
        }
        x*=x;
        x%=mod;
        k>>=1;
    }
    return res;
}
int main()
{
    int T;
    init();
    while(scanf("%d",&T)!=EOF)
    while(T--)
    {
        scanf("%s",s);
        int n=strlen(s);
        memset(num,0,sizeof(num));
        for(int i=0;i<n;i++)
           num[s[i]-'a']++;
        int len=0;
        for(int i=0;i<26;i++)
        if(num[i]%2)
        len++;
        if(len>1)
        {
            printf("0\n");
            continue;
        }
        int total=0;
        for(int i=0;i<26;i++)
        {
            num[i]/=2;
            total+=num[i];
        }
        ll res=f[total];
        for(int i=0;i<26;i++)
        if(num[i])
        {
            res=res*cal(f[num[i]])%mod;
        }
        printf("%lld\n",res);
    }
    return 0;
}