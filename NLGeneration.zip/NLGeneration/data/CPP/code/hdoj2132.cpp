// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define EPS 1e-6
#define INF INT_MAX / 10
#define LL long long
#define MOD 100000000
#define PI acos(-1.0)
struct node
{
    int x;
    int y;
    int z;
    int time;
}p,q,r;
using namespace std;
const int maxn = 55;
int maze[maxn][maxn][maxn];
int dir[6][3] = {{0,0,1},{0,-1,0},{0,0,-1},{0,1,0},{1,0,0},{-1,0,0}};
int A,B,C,T;
int bfs()
{
    p.x = 0,p.y = 0,p.z = 0,p.time = 0;
    queue<node> que;
    que.push(p);
    maze[p.x][p.y][p.z] = 1;
    while(que.size()){
        q = que.front();
        que.pop();
        if(q.x ==  A - 1 && q.y == B - 1 && q.z == C - 1)
            return q.time;
        for(int i = 0;i < 6;i++){
            int nx = q.x + dir[i][0];
            int ny = q.y + dir[i][1];
            int nz = q.z + dir[i][2];
            if(0 <= nx && nx < A && 0 <= ny && ny < B && 0 <= nz && nz < C && maze[nx][ny][nz] != 1){
                r.x = nx;
                r.y = ny;
                r.z = nz;
                r.time = q.time + 1;
                que.push(r);
                maze[r.x][r.y][r.z] = 1;
            }
        }
    }
    return T + 1;
    
    
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        scanf("%d %d %d %d",&A,&B,&C,&T);
        for(int i = 0;i < A;i++){
            for(int j = 0;j < B;j++){
                for(int k = 0;k < C;k++){
                    scanf("%d",&maze[i][j][k]);
                }
            }
        }
        int ans = bfs();
        printf("%d\n",ans <= T ? ans : -1);
    }
    return 0;
}