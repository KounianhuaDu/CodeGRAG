// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define Pr pair<int,int>
#define fread(ch) freopen(ch,"r",stdin)
#define fwrite(ch) freopen(ch,"w",stdout)
using namespace std;
const int INF = 0x3f3f3f3f;
const int msz = 1e6;
const int mod = 1e9+7;
const double eps = 1e-8;
bool Isprim[msz+1];
bool vis[msz+1];
int p[msz+1];
int f[msz+1],cnt[msz+1];
int C[msz+1][22],D[msz+1];
int low[1<<22];
vector <int> ys[msz+1];
vector <Pr> sy[msz+1];
int tp;
void init()
{
    memset(Isprim,0,sizeof(Isprim));
    cnt[1] = 0;
    for(int i = 0; i <= 20; ++i)
        low[1<<i] = i;
    tp = 0;
    for(int i = 2; i <= msz; ++i)
    {
        if(!Isprim[i])
        {
            p[tp++] = i;
            f[i] = i;
            cnt[i] = 1;
        }
        for(int j = 0; j < tp && p[j]*i <= msz; ++j)
        {
            f[p[j]*i] = p[j];
            cnt[p[j]*i] = cnt[p[j]]+cnt[i];
            Isprim[p[j]*i] = 1;
            if(i%p[j] == 0) break;
        }
    }
}
void cal(int x)
{
    int pos = x;
    int c,tmp;
#ifdef Debug
    printf("solve:%d\n",x);
#endif
    while(x > 1)
    {
        c = 0;
        tmp = f[x];
        while(x%tmp == 0)
        {
            x /= tmp;
            c++;
        }
#ifdef Debug
        printf("prim:%d cnt:%d\n",tmp,c);
#endif
        sy[pos].push_back(Pr(tmp,c));
    }
#ifdef Debug
    puts("------");
#endif
}
void solve(int x,int k,int f)
{
    if(k == sy[x].size()) ys[x].push_back(f);
    else
    {
        solve(x,k+1,f);
        for(int i = 0; i < sy[x][k].second; ++i)
        {
            f *= sy[x][k].first;
            solve(x,k+1,f);
        }
    }
}
void Insert(int x)
{
    if(vis[x]) return;
    vis[x] = 1;
    if(!sy[x].size()) cal(x);
    if(!ys[x].size()) solve(x,0,1);
    int y;
#ifdef Debug
    printf("%d:\n",x);
#endif
    for(int i = 0; i < ys[x].size(); ++i)
    {
        y = ys[x][i];
        if(!C[y][cnt[x/y]]) 
        {
            D[y] ^= (1<<cnt[x/y]);
#ifdef Debug
            printf("Change! %d:%d\n",y,D[y]);
#endif
        }
#ifdef Debug
        printf("%d<-%d %d\n",x,y,cnt[x/y]);
#endif
        C[y][cnt[x/y]]++;
    }
#ifdef Debug
    puts("//");
#endif
}
void Delete(int x)
{
    if(!vis[x]) return;
    vis[x] = 0;
#ifdef Debug
    printf("%d:",x);
#endif
    for(int i = 0; i < ys[x].size(); ++i)
    {
        int y = ys[x][i];
#ifdef Debug
        printf("%d ",y);
#endif
        C[y][cnt[x/y]]--;
        if(!C[y][cnt[x/y]]) D[y] ^= (1<<cnt[x/y]);
    }
#ifdef Debug
    puts("//");
#endif
}
int Lowbit(int x)
{
    return x&(-x);
}
int Query(int x)
{
    if(!sy[x].size()) cal(x);
    if(!ys[x].size()) solve(x,0,1);
    int ans = -1;
#ifdef Debug
    printf("Query %d:\n",x);
#endif
    for(int i = 0; i < ys[x].size(); ++i)
    {
        int y = ys[x][i];
        if(!D[y]) continue;
        int tmp = cnt[x/y];
#ifdef Debug
        printf("%d->%d: %d\n",x,y,tmp);
#endif
        tmp += low[Lowbit(D[y])];
#ifdef Debug
        printf("MIN%d: %d\n",y,Lowbit(D[x/y])>>1);
#endif
        if(ans == -1 || ans > tmp) ans = tmp;
    }
#ifdef Debug
    puts("//");
#endif
    return ans;
}
int main()
{
    
    
    init();
    int q,x,z = 1;
    char opt[3];
    while(~scanf("%d",&q) && q)
    {
        memset(vis,0,sizeof(vis));
        memset(C,0,sizeof(C));
        memset(D,0,sizeof(D));
        printf("Case #%d:\n",z++);
        while(q--)
        {
            scanf("%s%d",opt,&x);
            if(opt[0] == 'I') Insert(x);
            else if(opt[0] == 'D') Delete(x);
            else printf("%d\n",Query(x));
        }
    }
    return 0;
}