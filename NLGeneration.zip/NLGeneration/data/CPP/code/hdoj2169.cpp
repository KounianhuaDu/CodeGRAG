// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int num[100],n,m,a[100];
int ans;
void dfs(int pre,int x,int r)
{
	if(pre==n)
	{
		ans++;
		printf("%d",a[0]);
		for(int i=1;i<r;i++)
		printf("+%d",a[i]);
		printf("\n");
	}
	else
	{
		for(int i=x;i<m;i++)
	    {
	        if(pre+num[i]<=n)
	        {
	            a[r]=num[i];
	            dfs(pre+num[i],i+1,r+1);
	            while(i+1<m&&num[i]==num[i+1])  
	            i++;
	        }
	    }
	}
}
int cmp(int a,int b)
{
	return a>b;
}
int main()
{
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		if(m==0&&n==0) break;
		memset(num,0,sizeof(num));
		memset(a,0,sizeof(a));
		for(int i=0;i<m;i++)
		scanf("%d",&num[i]);
		sort(num,num+m,cmp);
		printf("Sums of %d:\n",n);
		ans=0;
		dfs(0,0,0);
		if(ans==0)
		printf("NONE\n");
	}
	return 0;
}