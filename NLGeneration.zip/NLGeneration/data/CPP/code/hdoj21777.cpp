// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL __int64_t
int n,c;
struct Node{
    int w,v;
}node[1050];
map<LL,LL> dp,temp;
map<LL,LL>::iterator it;
int main(){
    while(scanf("%d%d",&n,&c)!=EOF){
        dp.clear();
        dp[0]=0;
        for(int i=1;i<=n;i++)
            scanf("%d%d",&node[i].w,&node[i].v);
        for(int i=1;i<=n;i++){
            temp.clear();
            for(it=dp.begin();it!=dp.end();it++){
                LL w,v;
                w=it->first;
                v=it->second;
                if (temp.find(w)==temp.end())
                    temp[w]=v;
                else
                    temp[w]=max(temp[w],v);
                if (w+node[i].w<=c&&temp[w+node[i].w]<v+node[i].v)
                    temp[w+node[i].w]=v+node[i].v;
            }
            LL MAX=-1;
            dp.clear();
            for(it=temp.begin();it!=temp.end();it++)
            if (it->second>MAX){
                dp[it->first]=it->second;
                MAX=it->second;
            }
            if (i==n) cout<<MAX<<endl;
        }
    }
    return 0;
}