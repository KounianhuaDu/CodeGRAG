// Math and Computational Geometry->Inverse Element
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const ll maxn = 5e4+10;
const ll mod = 1e9+7;
ll sum[maxn],mul[maxn];
ll quick_mod(ll a,ll b,ll mod)
{
    ll ans = 1;
    while(b)
    {
        if(b&1)
            ans = (ans*a)%mod;
        a = (a*a)%mod;
        b >>= 1;
    }
    return ans;
}
void init(){
    sum[1] = 0;mul[1] = 1;
    for(ll i = 2; i < maxn;i++) sum[i] = sum[i-1]+i;
    for(ll i = 2; i < maxn;i++) mul[i] = (mul[i-1]*i)%mod;
}
int main(){
    ll T,x;
    scanf("%lld",&T);
    init();
    while(T--){
        scanf("%lld",&x);
        if(x < 5) {printf("%lld\n",x);continue;}
        ll l = 2,r = maxn,mid = (l+r)>>1;
        while(l+1 < r){
            if(sum[mid] > x) r = mid;
            else l = mid;
            mid = (l+r)>>1;
        }
        ll k = x-sum[l];
        ll ans;
        if(2 + k > l) ans = mul[l]*quick_mod(2,mod-2,mod)%mod*(k+2)%mod;
        else ans = mul[l]*quick_mod(l+1-k,mod-2,mod)%mod*(l+1)%mod;
        printf("%lld\n",(ans+mod)%mod);
    }
    return 0;
}