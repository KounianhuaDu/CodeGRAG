// Math and Computational Geometry->Inverse Element
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define eps 1e-8
#define INF 0x3f3f3f3f
#define PI acos(-1)
#define lson l,mid,rt<<1
#define rson mid+1,r,(rt<<1)+1
#define CLR(x,y) memset((x),y,sizeof(x))
#define fuck(x) cerr << #x << "=" << x << endl
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int seed = 131;
const int maxn = 1e5 + 5;
const ll mod = 1e9 + 7;
ll Pow(ll base, ll n) {
    ll res = 1;
    while (n) {
        if (n & 1) res = res * base % mod ;
        n >>= 1;
        base = base * base % mod;
    }
    return res;
}
ll sum[maxn], mul[maxn], MX;
void init() {
    sum[1] = 0;
    mul[1] = 1;
    for (int i = 2; i <= maxn; i++) {
        sum[i] = sum[i - 1] + i;
        mul[i] = mul[i - 1] * i;
        mul[i] %= mod;
        if (sum[i] >= 1e9) {
            MX = i;
            return;
        }
    }
}
int T;
ll x;
int main() {
    init();
    scanf("%d", &T);
    while (T--) {
        scanf("%lld", &x);
        if (x == 1) {
            printf("1\n");
            continue;
        }
        int t = lower_bound(sum, sum + MX, x) - sum;
        if (sum[t] > x) t--;
        ll rest = x - sum[t];
        if (rest == t) {
            ll ans = mul[t + 2] * Pow(2, mod - 2) % mod * Pow(t + 1, mod - 2) % mod;
            printf("%lld\n", ans % mod);
        } else {
            ll ans = mul[t + 1] * Pow(t + 1 - rest, mod - 2) % mod;
            printf("%lld\n", ans % mod);
        }
    }
    return 0;
}