// Basic Algorithm->Iteration
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main()
{int a,b,c,n;
 int ans[105];
 while(cin>>n&&n)
 {
     int count=0;
     for(int k=1;k<=n;k*=10)
     {
         c=(n/k)/11;
         b=(n/k)%11;
         if((b+c)!=0&&b<10)
         {
             a=(n-b*k-11*c*k)/2;
             if(n==2*a+b*k+11*c*k)
             ans[count++]=a+b*k+10*c*k;
         }
         b--;
         if((b+c)!=0&&b>=0)
         {
             a=(n-b*k-11*c*k)/2;
             if(n==2*a+b*k+11*c*k)
             ans[count++]=a+b*k+10*c*k;
         }
     }
     if(count==0)
     cout<<"No solution."<<endl;
     else
     {
         sort(ans,ans+count);
         cout<<ans[0];
         for(int i=1;i<count;i++)
         {
             if(ans[i]!=ans[i-1])
             cout<<" "<<ans[i];
         }
         cout<<endl;
     }
 }
    return 0;
}