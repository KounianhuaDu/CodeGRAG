// Math and Computational Geometry->Greatest Common Divisor (GCD),Math and Computational Geometry->Number Theory,Math and Computational Geometry->Möbius Inversion Formula
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LDQ 1000000007
#define QAQ 0x3f3f3f3f
using namespace std;
int mu[100001];
void init()
{
    int i,i1;
    memset(mu,0,sizeof(mu));
    mu[1]=1;
    for(i=1;100000>=i;i++)
    {
        for(i1=i+i;100000>=i1;i1=i1+i)
        {
            mu[i1]=mu[i1]-mu[i];
        }
    }
}
long long quick(long long x,int n)
{
    long long t=x,ans=1;
    while(n!=0)
    {
        if(n%2==1)
        {
            ans=(ans*t)%LDQ;
        }
        t=(t*t)%LDQ;
        n=n/2;
    }
    return ans;
}
int main()
{
    int n,t,i,i1,i2,x,num[100001],minx,maxx;
    long long temp,sum;
    init();            
    scanf("%d",&t);
    for(i=1;t>=i;i++)
    {
        scanf("%d",&n);
        memset(num,0,sizeof(num));
        minx=QAQ;
        maxx=-QAQ;
        for(i1=1;n>=i1;i1++)
        {
            scanf("%d",&x);
            num[x]++;
            minx=min(minx,x);
            maxx=max(maxx,x);
        }
        for(i1=1;maxx>=i1;i1++)
        {
            num[i1]=num[i1]+num[i1-1];
        }
        sum=0;
        for(i1=2;minx>=i1;i1++)
        {
            temp=1;
            for(i2=1;maxx>=i2*i1;i2++)
            {
                temp=(temp*quick(i2,num[min(maxx,i1*i2+i1-1)]-num[i1*i2-1]))%LDQ;
            }
            sum=(sum-mu[i1]*temp+LDQ)%LDQ;
        }
        printf("Case #%d: %lld\n",i,sum);
    }
    return 0;
}