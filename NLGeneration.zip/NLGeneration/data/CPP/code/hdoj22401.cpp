// Basic Algorithm->Simulation,Data Structure->Functional Segment Tree,Data Structure->Link List
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mst(a,b) memset((a),(b),sizeof(a))
#define rush() int T;scanf("%d",&T);while(T--)
typedef long long  ll;
const int maxn = 500005;
const ll mod = 1e9+7;
const int INF = 0x3f3f3f;
const double eps = 1e-9;
int pos[maxn];
int pre[maxn];
int nex[maxn];
int num[maxn];
int main()
{
    int n,k;
    int x;
    rush()
    {
        scanf("%d%d",&n,&k);
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&x);
            pos[x]=i;
            pre[i]=i-1;
            nex[i]=i+1;
        }
        pre[0]=0,nex[n+1]=n+1;
        ll ans=0;
        for(int i=1;i<=n;i++)      
        {
            int x=pos[i];
            int l=0,r=0;
            for(int j=x;j<=n&&r<k;j=nex[j])
            {
                num[++r]=nex[j]-j;  
                                    
            }
            ll cnt=0;
            for(int j=x;j>0&&l<k;j=pre[j])
            {
                l++;
                if(k-l+1>r) continue;
                cnt+=(ll)(j-pre[j])*num[k-l+1];
            }
            ans+=cnt*i;            
            pre[nex[x]]=pre[x];    
            nex[pre[x]]=nex[x];    
        }
        printf("%I64d\n",ans);
    }
    return 0;
}