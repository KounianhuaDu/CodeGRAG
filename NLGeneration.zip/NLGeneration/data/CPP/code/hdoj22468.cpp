// Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
#define rep(i,a,b) for(int i=a;i<b;i++)
const LL mod=2147493647;
struct Martix{
	int n,m;
	LL mat[10][10];
	Martix(int _n=5,int _m=5):n(_n),m(_m){
		memset(mat,0,sizeof(mat));
		rep(i,0,n)mat[i][i]=1;
	}
	Martix operator*(Martix b){
		Martix res;
		res.n=n,res.m=b.m;
		for(int i=0;i<n;i++){
			for(int j=0;j<b.m;j++){
				res.mat[i][j]=0;
				for(int k=0;k<m;k++){
					res.mat[i][j]=(res.mat[i][j]+mat[i][k]*b.mat[k][j]%mod)%mod;
					
				}
			}
		}
		return res;
	}
	void show(){
		printf("*****\n");
		rep(i,0,n){
			rep(j,0,m){
				printf("%lld ",mat[i][j]);
			}printf("\n");
		}
	}
};
Martix pow_mod(Martix base,LL n){
	Martix ans=Martix(7,7);
	
	while(n){
		if(n&1)ans=ans*base;
		base=base*base;
		n>>=1;
	}
	return ans;
}
LL mat[10][10]={
{1,2,1,4,6,4,1},
{1,0,0,0,0,0,0},
{0,0,1,4,6,4,1},
{0,0,0,1,3,3,1},
{0,0,0,0,1,2,1},
{0,0,0,0,0,1,1},
{0,0,0,0,0,0,1}
};
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		LL n,a,b;
		scanf("%lld %lld %lld",&n,&a,&b);
		if(n==1){
			printf("%lld\n",a%mod);
		}else if(n==2){
			printf("%lld\n",b%mod);
		}else{
			Martix st=Martix(7,1);
			st.mat[0][0]=b;
			st.mat[1][0]=a;
			LL res=1;
			for(int i=6;i>=2;i--){
				st.mat[i][0]=res;
				res=res*2%mod;
			}
			Martix mid=Martix(7,7);
			rep(i,0,7)rep(j,0,7)mid.mat[i][j]=mat[i][j];
            mid=pow_mod(mid,n-2);
			
            st=mid*st;
			
           
			printf("%lld\n",st.mat[0][0]);
		}
	}
	return 0;
}