// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:1024000000,1024000000")
using namespace std;
int f[101][1002]= {0}; 
int n,w[101],W,v[101];
int sta[120],top,ans;
void print(int i,int wt) {
	if(i==1) {
		if(f[i][wt]) sta[top++]=1,ans+=w[1];
		return;
	}
	if(f[i][wt]>f[i-1][wt]) {
		print(i-1,wt-w[i]);
		sta[top++]=i,ans+=w[i];
	} else print(i-1,wt);
}
int main() {
	int T,kase=0;
	scanf("%d",&T);
	while(T--) {
		memset(f,0,sizeof(f));
		top=ans=0;
		scanf("%d%d",&W,&n);
		for(int i=1; i<=n; i++)
			scanf("%d%d",v+i,w+i);
		for(int i=1; i<=n; i++)
			for(int j=0; j<=W; j++)
				if(j<w[i])
					f[i][j]=f[i-1][j];
				else f[i][j]=max(f[i-1][j],f[i-1][j-w[i]]+v[i]);
		if(n)
			print(n,W);
		printf("Case #%d:\n%d %d\n",++kase,f[n][W],ans);
		if(0<top)
			printf("%d",sta[0]);
		for(int i=1; i<top; ++i)
			printf(" %d",sta[i]);
		if(top>0)
			puts("");
	}
	return 0;
}