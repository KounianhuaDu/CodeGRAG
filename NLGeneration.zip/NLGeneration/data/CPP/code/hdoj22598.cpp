// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#pragma comment(linker,"/STACK:1024000000,1024000000")
int n;
int num[2005];
int dp[2005][2005];
int max(int x, int y)
{
	return x > y ? x :y;
}
int dfs(int l, int r)
{
	if(dp[l][r]) return dp[l][r];
	if(l == r) return dp[l][r] = 1;
	if(l > r) return 0;
	dp[l][r] = max(dfs(l, r - 1), dfs(l + 1, r));
    int v = dfs(l + 1, r - 1);
	if(r - l == n) --v;
	if(num[l] == num[r]) v += 2;
    dp[l][r] = max(dp[l][r], v);
	return dp[l][r];
}
int main()
{
	
    while(scanf("%d", &n) != EOF)
    {
        if(!n) break;
        for(int i = 2 * n; i >= 0; --i)
        	for(int j = 2 * n; j >= 0; --j)
        		dp[i][j] = 0;
        for(int i  = 0; i < n; ++i)
        {
        	scanf("%d", &num[i]);
        	num[n + i] = num[i];
        }
        int s = 0;
        for(int i = 0; i < n; ++i)
        	s = max(s, dfs(i, i + n));
        printf("%d\n", s);
    }
    return 0;
}