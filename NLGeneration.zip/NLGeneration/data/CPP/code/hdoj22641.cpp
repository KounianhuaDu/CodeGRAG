// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
#define MEM(a, v)        memset (a, v, sizeof (a))    
#define max(x, y)        ((x) > (y) ? (x) : (y))
#define min(x, y)        ((x) < (y) ? (x) : (y))
#define INF     (0x3f3f3f3f)
#define MAXN	10009
#define L(x)	((x)<<1)
#define R(x)	(((x)<<1)|1)
#define M(x, y)	(((x)+(y)) >> 1)
#define DB    /##/
typedef __int64_t	LL;
int dp[MAXN], a[MAXN];
int LongestIncSubSeq(int a[], int n)
{
	int i, j, longest;
	MEM(dp, 0);
	for (i = 0; i < n; ++i)
	{
		dp[i] = 1;
		for (j = 0; j < i; ++j)
		{
			if (a[i] > a[j])
				dp[i] = max(dp[i], dp[j]+1);
		}
	}
	longest = 0;
	for (i = 0; i < n; ++i)
		longest = max(longest, dp[i]);
	return longest;
}
int main()
{
	int i, n;
	while (scanf("%d", &n) != EOF)
	{
		for(i = 0; i < n; ++i)
			scanf("%d", a+i);
		printf("%d\n", LongestIncSubSeq(a, n));
	}
	return 0;
}