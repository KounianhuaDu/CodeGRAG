// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
string s;
int fun(int ith,int num)
{
    int k,e;
    char c;
    for(c=s[ith++]; ith<s.size()&&c!=')'; c=s[ith++])
    {
        for(k=0; isdigit(c); c=s[ith++])
            k=k*10+c-'0';
        if(!k) k=1;
        if(c=='(')
        {
            while(k--)
                e=fun(ith,num+1);
            ith=e;
        }
        else
        {
            while(k--)
                putchar(c);
        }
    }
    if(c==')') return ith;
}
int main()
{
    int i,j,k,T;
    cin>>T;
    while(T--)
    {
        s.clear();
        cin>>s;
        fun(0,0);
        cout<<endl;
    }
    return 0;
}