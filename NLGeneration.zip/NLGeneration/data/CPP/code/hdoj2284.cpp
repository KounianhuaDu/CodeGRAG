// Data Structure->Trie,Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

char str[60060],key[60],s[60060],k1[10],k2[10],k3[10];
int vis[10010],ans[10010],k,flag;
int head,tail;
struct node
{
    node *fail;
    node *next[10];
    int cnt;
    node()
    {
        fail=NULL;
        cnt=0;
        for(int i=0;i<10;i++)
            next[i]=NULL;
    }
}*q[602000];
node *root;
void insert(char *s,int id)
{
    int temp,len,i;
    node *p=root;
    len=strlen(s);
    for(i=0;i<len;i++)
    {
        temp=s[i]-'0';
        if(p->next[temp]==NULL)
            p->next[temp]=new node();
        p=p->next[temp];
    }
    p->cnt=id;
}
void build_ac()
{
    root->fail=NULL;
    q[tail++]=root;
    while(head!=tail)
    {
        node *p=q[head++];
        node *temp=NULL;
        for(int i=0;i<10;i++)
        {
            if(p->next[i]!=NULL)
            {
                if(p==root)
                {
                    p->next[i]->fail=root;
                }
                else
                {
                    temp=p->fail;
                    while(temp!=NULL)
                    {
                        if(temp->next[i]!=NULL)
                        {
                            p->next[i]->fail=temp->next[i];
                            break;
                        }
                        temp=temp->fail;
                    }
                    if(temp==NULL)
                    {
                        p->next[i]->fail=root;
                    }
                }
                q[tail++]=p->next[i];
            }
        }
    }
}
void query()
{
    int len=strlen(str);
    node *p=root,*temp;
    for(int i=0;i<len;i++)
    {
        int x=str[i]-'0';
        while(p->next[x]==NULL&&p!=root)
        {
            p=p->fail;
        }
        p=p->next[x];
        if(p==NULL)
        {
            p=root;
        }
        temp=p;
        while(temp!=root&&temp->cnt!=0)
        {
            if(!vis[temp->cnt])
			{
				vis[temp->cnt]=1;
				ans[k++]=temp->cnt;
				flag=1;
			}
            temp=temp->fail;
        }
    }
}
int main()
{
	int n,m;
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		int i;
		head=tail=0;
		root=new node();
		k=0;
		flag=0;
		memset(vis,0,sizeof(vis));
		for(i=0;i<n;i++)
		{
			scanf("%s",s);
			strcat(str,s);
		}
		
		for(i=1;i<=m;i++)
		{
			int x;
			scanf("[Key No. %d] ",&x);
			scanf("%s%s%s%s",k1,k2,k3,key);
			insert(key,i);
		}
		build_ac();
		query();
		if(!flag)
		{
			printf("No key can be found !\n");
		}
		else
		{
			printf("Found key:");
			for(i=0;i<k;i++)
			{
				printf(" [Key No. %d]",ans[i]);
			}
			printf("\n");
		}
	}
}