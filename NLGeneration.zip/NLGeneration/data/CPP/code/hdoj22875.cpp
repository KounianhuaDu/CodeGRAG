// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
double a[6], n, en;
int dfs(int top)
{
    if(top == 0)
        return 0;
    else if(top == 1){
        if(fabs(a[1]-en) < 1e-6)
            return 1;
        else
            return 0;
    }
    for(int i = 1; i <= top; i++){
        for(int j = i + 1; j <= top; j++){
            double x = a[i];
            double y = a[j];
            a[j] = a[top];
            a[i] = x + y;
            if(dfs(top-1))
                return 1;
            a[i] = x - y;
            if(dfs(top-1))
                return 1;
            a[i] = y - x;
            if(dfs(top-1))
                return 1;
            a[i] = x * y;
            if(dfs(top-1))
                return 1;
            if(y != 0){
                a[i] = x / y;
                if(dfs(top-1))
                    return 1;
            }
            if(x != 0){
                a[i] = y / x;
                if(dfs(top-1))
                    return 1;
            }
            a[j] = y;
            a[i] = x;
        }
    }
    return 0;
}
int main()
{
    int N;
    cin >> N;
    while(N--){
        cin >> n >> en;
        for(int i = 1; i <= n; i++)
            cin >> a[i];
        if(dfs(n))
            cout << "Yes" << endl;
        else
            cout << "No" << endl;
    }
    return 0;
}