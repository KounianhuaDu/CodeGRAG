// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define outstars cout << "***********************" << endl;
#define clr(a,b) memset(a,b,sizeof(a))
#define lson l , mid  , rt << 1
#define rson mid + 1 , r , rt << 1|1
#define FOR(i , x , n) for(int i = (x) ; i < (n) ; i++)
#define FORR(i , x , n) for(int i = (x) ; i <= (n) ; i++)
#define REP(i , x , n) for(int i = (x) ; i > (n) ; i--)
#define REPP(i ,x , n) for(int i = (x) ; i >= (n) ; i--)
#define mid ((l + r) >> 1)
const int MAXN = 100000 + 100;
const int maxw = 10000000 + 20;
const int MAXNNODE = 10000 +10;
const long long LLMAX = 0x7fffffffffffffffLL;
const long long LLMIN = 0x8000000000000000LL;
const int INF = 0x7fffffff;
const int IMIN = 0x80000000;
#define eps 1e-8
#define mod 10007
typedef long long LL;
const double PI = acos(-1.0);
typedef double D;
void update(int L ,int R , int add , int multi , int l , int r , int rt);
struct Node
{
    int  l , r , add , multi;
    int a[4];
}tree[4 * MAXN];
void build(int l , int r , int rt)
{
    tree[rt].l = l;
    tree[rt].r = r;
    tree[rt].add = 0;
    tree[rt].multi = 1;
    FORR(i , 1 , 3)tree[rt].a[i] = 0;
    if(l == r)return;
    build(lson);
    build(rson);
}
void pushup(int rt)
{
    FORR(i , 1 , 3)tree[rt].a[i] = (tree[rt<< 1].a[i] + tree[rt << 1|1].a[i])% mod;
}
void pushdown(int rt)
{
    update(tree[rt << 1].l , tree[rt << 1].r , tree[rt].add , tree[rt].multi , tree[rt << 1].l , tree[rt << 1].r , rt << 1);
    update(tree[rt << 1|1].l , tree[rt << 1|1].r , tree[rt].add , tree[rt].multi , tree[rt << 1|1].l , tree[rt << 1|1].r , rt << 1|1);
    tree[rt].add = 0;
    tree[rt].multi = 1;
}
void update(int L ,int R , int add , int multi , int l , int r , int rt)
{
    if(L <= l&& R >= r)
    {
        if(multi != 1)
        {
            tree[rt].add = tree[rt].add * multi % mod;
            tree[rt].multi = tree[rt].multi * multi % mod;
            tree[rt].a[1] = tree[rt].a[1] * multi % mod ;
            tree[rt].a[2] = tree[rt].a[2] * multi % mod * multi % mod;
            tree[rt].a[3] = tree[rt].a[3] * multi % mod * multi % mod* multi % mod;
        }
        if(add)
        {
            tree[rt].add = (tree[rt].add + add) % mod;
            tree[rt].a[3] =  (tree[rt].a[3] + 3 * tree[rt].a[2] % mod * add % mod + 3 * tree[rt].a[1] % mod * add % mod *add % mod + (r - l + 1)% mod * add % mod *add % mod * add % mod)%mod;
            tree[rt].a[2] = (tree[rt].a[2] + 2 * tree[rt].a[1] % mod * add % mod + (r - l + 1) % mod * add %mod *add % mod) % mod;
            tree[rt].a[1] = (tree[rt].a[1] + (r - l + 1) % mod * add % mod)%mod;
        }
        return ;
    }
    pushdown(rt);
    if(L <= mid)update(L ,R , add , multi , lson);
    if(R > mid)update(L ,R , add , multi , rson);
    pushup(rt);
}
int query(int L , int R ,int c , int l , int r , int  rt)
{
    if(L <= l && R >= r)return tree[rt].a[c];
    pushdown(rt);
    int ans = 0;
    if(L <= mid)ans =(ans + query(L ,R , c ,lson))%mod;
    if(R > mid)ans = (ans + query(L , R ,c , rson)) % mod;
    return ans;
}
int main()
{
    
#ifdef Online_Judge
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif 
    int n , m , i, j , a , b , c , op;
    while(scanf("%d%d" , &n , &m) != EOF&&(m|| n))
    {
        build(1 , n , 1);
        FORR(i , 1 , m)
        {
            scanf("%d%d%d%d",&op,  &a , &b , &c);
            if(op == 1)update(a , b ,c , 1 , 1 ,n , 1);
            else if(op == 2)update(a , b ,0 , c , 1 , n , 1);
            else if(op == 3)update(a , b , c , 0 , 1 , n , 1);
            else printf("%d\n" , query(a , b , c , 1 , n , 1));
        }
    }
    return 0;
}