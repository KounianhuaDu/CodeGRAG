// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
struct FastIO
{
    static const int S = 1310720;
    int wpos;
    char wbuf[S];
    FastIO() : wpos(0) {}
    inline int xchar()
    {
        static char buf[S];
        static int len = 0, pos = 0;
        if (pos == len)
            pos = 0, len = fread(buf, 1, S, stdin);
        if (pos == len) return -1;
        return buf[pos ++];
    }
    inline int xuint()
    {
        int c = xchar(), x = 0;
        while (c <= 32) c = xchar();
        for (; '0' <= c && c <= '9'; c = xchar()) x = x * 10 + c - '0';
        return x;
    }
    inline int xint()
    {
        int s = 1, c = xchar(), x = 0;
        while (c <= 32) c = xchar();
        if (c == '-') s = -1, c = xchar();
        for (; '0' <= c && c <= '9'; c = xchar()) x = x * 10 + c - '0';
        return x * s;
    }
    inline void xstring(char *s)
    {
        int c = xchar();
        while (c <= 32) c = xchar();
        for (; c > 32; c = xchar()) * s++ = c;
        *s = 0;
    }
    inline void wchar(int x)
    {
        if (wpos == S) fwrite(wbuf, 1, S, stdout), wpos = 0;
        wbuf[wpos ++] = x;
    }
    inline void wint(LL x)
    {
        if (x < 0) wchar('-'), x = -x;
        char s[24];
        int n = 0;
        while (x || !n) s[n ++] = '0' + x % 10, x /= 10;
        while (n--) wchar(s[n]);
    }
    inline void wstring(const char *s)
    {
        while (*s) wchar(*s++);
    }
    ~FastIO()
    {
        if (wpos) fwrite(wbuf, 1, wpos, stdout), wpos = 0;
    }
} io;
const int maxn = 2e5+10;
struct City{
    int buy,sell,dis;
}a[maxn];
struct Queue{
    int num,val;
}q[maxn];
int main()
{
    int T,n,m;
    T = io.xint();
    while(T--){
        n = io.xint(), m = io.xint();
        a[0].dis=a[1].dis=0;
        for(int i=2; i<=n+1; i++) a[i].dis = io.xint();
        for(int i=1; i<=n+1; i++) a[i].buy = io.xint(), a[i].sell = io.xint();
        LL ans=0;
        int head=0,tail=0;
        int sum = 0;
        for(int i=1; i<=n+1; i++){
            int dis = a[i].dis-a[i-1].dis;
            sum -= dis;
            while(dis!=0){
                if(q[head+1].num<=dis){
                    dis-=q[head+1].num;
                    head++;
                }else{
                    q[head+1].num-=dis;
                    dis=0;
                }
            }
            
            
            for(int j=head+1; j<=tail; j++)
                if(q[j].val < a[i].sell)
                    q[j].val = a[i].sell;
             
             while(tail>head&&q[tail].val>a[i].buy){
                ans-=(LL)q[tail].val*q[tail].num;
                sum-=q[tail].num;
                tail--;
             }
             
             if(sum!=m){
                tail++;
                q[tail].num=m-sum;
                q[tail].val=a[i].buy;
                ans+=(LL)q[tail].num*q[tail].val;
                sum=m;
             }
        }
        
        while(head<tail){
            ans-=(LL)q[head+1].num*q[head+1].val;
            head++;
        }
        printf("%lld\n", ans);
    }
    return 0;
}