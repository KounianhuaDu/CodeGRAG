// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 105;
vector<int> e[maxn];
int ca = 1, n, m, k, vis[maxn], match[maxn];
bool Hungary(int x)
{
    for(int i = 0; i < e[x].size(); i++)
    {
        int to = e[x][i];
        if(!vis[to])
        {
            vis[to] = 1;
            if(!match[to] || Hungary(match[to]))
            {
                match[to] = x;
                return true;
            }
        }
    }
    return false;
}
void solve()
{
    int ans = 0, sum = 0;
    for(int i = 1; i <= n; i++)
    {
        memset(vis, 0, sizeof(vis));
        ans += Hungary(i);
    }
    for(int i = 1; i <= n; i++)
        for(int j = 0; j < e[i].size(); j++)
        {
            int temp = *(e[i].begin());
            e[i].erase(e[i].begin());
            int num = 0;
            memset(match, 0, sizeof(match));
            for(int k = 1; k <= n; k++)
            {
                memset(vis, 0, sizeof(vis));
                num += Hungary(k);
            }
            e[i].push_back(temp);
            if(ans > num) sum++;
        }
    printf("Board %d have %d important blanks for %d chessmen.\n", ca++, sum, ans);
}
int main(void)
{
    while(cin >> n >> m >> k)
    {
        memset(match, 0, sizeof(match));
        for(int i = 0; i < maxn; i++)
            e[i].clear();
        while(k--)
        {
            int x, y;
            scanf("%d%d", &x, &y);
            e[x].push_back(y);
        }
        solve();
    }
    return 0;
}