// Basic Algorithm->Divide and Conquer
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ri register int
using namespace std;
inline int read(){
	int ans=0,w=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')w=-1;ch=getchar();}
	while(isdigit(ch))ans=(ans<<3)+(ans<<1)+(ch^48),ch=getchar();
	return ans*w;
}
typedef long long ll;
const int N=(1<<17)+5,delta=20000;
const double pi=acos(-1.0);
struct Complex{
	double x,y;
	inline Complex operator+(const Complex&b){return (Complex){x+b.x,y+b.y};}
	inline Complex operator-(const Complex&b){return (Complex){x-b.x,y-b.y};}
	inline Complex operator*(const Complex&b){return (Complex){x*b.x-y*b.y,y*b.x+x*b.y};}
	inline Complex operator/(const double&b){return (Complex){x/b,y/b};}
}a[N],b[N],c[N];
int n,lim,tim,A[N],B[N],C[N],pos[N];
inline void fft(Complex *a,int type){
	for(ri i=0;i<lim;++i)if(i<pos[i])swap(a[i],a[pos[i]]);
	for(ri mid=1;mid<lim;mid<<=1){
		Complex wn=(Complex){cos(pi/mid),type*sin(pi/mid)};
		for(ri j=0,len=mid<<1;j<lim;j+=len){
			Complex w=(Complex){1,0};
			for(ri k=0;k<mid;++k,w=w*wn){
				Complex a0=a[j+k],a1=a[j+k+mid]*w;
				a[j+k]=a0+a1,a[j+k+mid]=a0-a1;
			}
		}
	}
	if(type==-1)for(ri i=0;i<lim;++i)a[i]=a[i]/lim;
}
inline void init(){
	lim=1<<17,tim=17;
	for(ri i=0;i<lim;++i)pos[i]=(pos[i>>1]>>1)|((i&1)<<(tim-1));
}
int main(){
	freopen("lx.in","r",stdin);
	n=read(),init();
	for(ri i=1,val;i<=n;++i)val=read()+delta,++A[val],++B[val*2],++C[val*3];
	for(ri i=0;i<lim;++i)a[i].x=A[i],b[i].x=B[i],c[i].x=C[i];
	fft(a,1),fft(b,1);
	for(ri i=0;i<lim;++i)c[i]=a[i]*(a[i]*a[i]-(Complex){3,0}*b[i]);
	fft(c,-1);
	for(ri i=0;i<lim;++i){
		ll cnt=((ll)(c[i].x+0.5)+2*C[i])/6;
		if(cnt)cout<<i-3*delta<<" : "<<cnt<<'\n';
	}
	return 0;
}