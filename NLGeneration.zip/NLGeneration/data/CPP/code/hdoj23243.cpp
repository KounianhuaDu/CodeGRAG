// Math and Computational Geometry->Greatest Common Divisor (GCD),Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ll long long
ll a[1010];
ll tot=0;
void prime(ll n)
{
    tot=0;
    memset(a,0,sizeof(a));
    for(ll i=2; i*i<=n; i++)
    {
        if(n%i==0)
        {
            a[tot++]=i;
            n/=i;
            while(n%i==0)
                n/=i;
        }
        if(n==1)
            break;
    }
    if(n>1)
        a[tot++]=n;
}
ll ola(ll n)
{
    ll sum=1;
    for(ll i=2; i*i<=n; i++)
    {
        if(n%i==0)
        {
            sum*=i-1;
            n/=i;
            while(n%i==0)
            {
                n/=i;
                sum*=i;
            }
        }
    }
    if(n>1)
        sum*=n-1;
    return sum;
}
ll fg(ll n)
{
    ll sum=0;
    for(ll i=1; i<(1<<tot); i++)
    {
        ll ans=1,flag=0;
        for(ll j=0; j<tot; j++)
        {
            if(i&(1<<j))
            {
                ans*=a[j];
                flag++;
            }
        }
        if(flag%2==1)
            sum+=n/ans;
        else
            sum-=n/ans;
    }
    return n-sum;
}
int main()
{
    int t,ca=1;
    ll a,b,c,d,k;
    ll n,m;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%lld%lld%lld%lld%lld",&a,&b,&c,&d,&k);
        if(k==0||k>b||k>d)
        {
            printf("Case %d: 0\n",ca++);
            continue;
        }
        n=b/k,m=d/k;
        if(n>m)
            swap(n,m);
        ll sum=1;
                 
        for(ll i=1; i<=n; i++)
        {
            prime(i);
            sum+=fg(m);
            sum-=ola(i);
        }
        printf("Case %d: %lld\n",ca++,sum);
    }
    return 0;
}