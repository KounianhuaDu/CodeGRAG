// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int dp[1005][1005];
char s[1005];
int mod=10007;
int main()
{
    int t,c=0;
    scanf("%d",&t);
    while(t--)
    {
        c++;
        memset(dp,0,sizeof(dp));
        scanf("%s",s);
        int n=strlen(s);
        for(int i=0;i<n;i++)
            dp[i][i]=1;
        for(int len=2;len<=n;len++)
        {
            for(int i=0;i+len<=n;i++)
            {
                int l=i;
                int r=i+len-1;
                dp[l][r]=dp[l][r-1]+dp[l+1][r];
                if(s[l]==s[r])
                    dp[l][r]++;
                else
                    dp[l][r]-=dp[l+1][r-1];
                dp[l][r]%=mod;
                if(dp[l][r]<0)
                    dp[l][r]+=mod;
            }
        }
        printf("Case %d: %d\n",c,dp[0][n-1]);
    }
return 0;
}