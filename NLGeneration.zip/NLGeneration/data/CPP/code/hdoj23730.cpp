// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
bool cmp(int x,int y)
{
    return x>y;
}
int aver;
int stick[21];
int visit[21];
int n;
int exist;
void dfs(int have,int num,int pos)
{
    int i,j;
    if(num==4)
    {
        exist=1;
        return ;
    }
    for(i=pos;i<n;i++)
    {
        if(i&&!visit[i-1]&&stick[i]==stick[i-1])
        continue;
        if(visit[i])
        continue;
        if(have+stick[i]==aver)
        {
            visit[i]=1;
            dfs(0,num+1,0);
            visit[i]=0;
        }
        else if(have+stick[i]<aver)
        {
            visit[i]=1;
            dfs(have+stick[i],num,i+1);
            visit[i]=0;
        }
        if(have==0)
        break;
    }
}
int main()
{
    int t;
    int sum;
    int i,j;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        sum=0;
        for(i=0;i<n;i++)
        {
            scanf("%d",&stick[i]);
            sum+=stick[i];
        }
        if(sum%4!=0)
        {
            printf("no\n");
            continue;
        }
        aver=sum/4;
        sort(stick,stick+n,cmp);
        if(stick[0]>aver)
        {
            printf("no\n");
            continue;
        }
        memset(visit,0,sizeof(visit));
        exist=0;
        dfs(0,0,0);
        if(exist)
        printf("yes\n");
        else
        printf("no\n");
    }
    return 0;
}