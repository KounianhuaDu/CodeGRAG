// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
struct node
{
    int from;
    int to;
    int next;
    int w;
    int f;
    int num;
}e[100*100*5];
int vis[2050];
int pre[2050];
int path[2050];
int dis[2050];
int head[2050];
char a[150][150];
int val[2050];
int n,cont,ss,tt;
void add(int from,int to,int w,int f)
{
    e[cont].to=to;
    e[cont].f=f;
    e[cont].w=w;
    e[cont].num=cont;
    e[cont].next=head[from];
    head[from]=cont++;
}
void getmap()
{
    ss=2*n+1;
    tt=ss+1;
    cont=0;
    memset(head,-1,sizeof(head));
    for(int i=1;i<=n;i++)
    {
        add(ss,i,0,1);
        add(i,ss,0,0);
        add(i+n,tt,0,1);
        add(tt,i+n,0,0);
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(a[i][j]=='1')
            {
                int u=i+1;
                int v=j+1+n;
                add(u,v,val[i+1]^val[j+1],1);
                add(v,u,-(val[i+1]^val[j+1]),0);
            }
        }
    }
}
int SPFA()
{
    queue<int >s;
    memset(vis,0,sizeof(vis));
    memset(pre,-1,sizeof(pre));
    memset(path,-1,sizeof(path));
    for(int i=0;i<=tt;i++)dis[i]=-0x3f3f3f3f;
    vis[ss]=1;
    dis[ss]=0;
    s.push(ss);
    while(!s.empty())
    {
        int u=s.front();
        s.pop();vis[u]=0;
        for(int i=head[u];i!=-1;i=e[i].next)
        {
            int v=e[i].to;
            int w=e[i].w;
            int f=e[i].f;
            if(f>0&&dis[v]<dis[u]+w)
            {
                dis[v]=dis[u]+w;
                pre[v]=u;
                path[v]=e[i].num;
                if(vis[v]==0)
                {
                    vis[v]=1;
                    s.push(v);
                }
            }
        }
    }
    if(dis[tt]!=0x3f3f3f3f)return 1;
    else return 0;
}
void Maxcost_Maxflow()
{
    int ans=0;
    int maxflow=0;
    while(SPFA()==1)
    {
        if(dis[tt]<0)break;
        int minn=INF;
        for(int i=tt;i!=ss;i=pre[i])
        {
            minn=min(minn,e[path[i]].f);
        }
        for(int i=tt;i!=ss;i=pre[i])
        {
            e[path[i]].f-=minn;
            e[path[i]^1].f+=minn;
        }
        ans+=dis[tt];
        maxflow+=minn*dis[tt];
    }
    printf("%d\n",ans);
}
int main()
{
    while(~scanf("%d",&n))
    {
        if(n==0)break;
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&val[i]);
        }
        for(int i=0;i<n;i++)
        {
            scanf("%s",a[i]);
        }
        getmap();
        Maxcost_Maxflow();
    }
    return 0;
}