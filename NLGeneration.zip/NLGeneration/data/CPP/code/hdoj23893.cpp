// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Min-Cost Max-Flow
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 1e6+10;
const int M = 1000;
int head[M], cnt;
struct node
{
    int from, to, cap, cost, next;
}p[N];
void add(int u,int v,int w,int z)
{
    p[cnt].from=u, p[cnt].to=v, p[cnt].cap=w, p[cnt].cost=z, p[cnt].next=head[u], head[u]=cnt++;
    p[cnt].from=v, p[cnt].to=u, p[cnt].cap=0, p[cnt].cost=-z, p[cnt].next=head[v], head[v]=cnt++;
    return ;
}
int d[M], pre[M], vis[M];
const int inf = 1<<30;
int min_cost_flow(int s,int t,int f)
{
    int res=0;
    while(f>0)
    {
        queue<int>q;
        q.push(s);
        for(int i=0;i<=t;i++) d[i]=inf;
        memset(pre,-1,sizeof(pre));
        memset(vis,0,sizeof(vis));
        vis[s]=1, d[s]=0;
        while(!q.empty())
        {
            int u=q.front();q.pop();
            for(int i=head[u];i!=-1;i=p[i].next)
            {
                int v=p[i].to;
                if(d[v]>d[u]+p[i].cost&&p[i].cap>0)
                {
                    d[v]=d[u]+p[i].cost;
                    pre[v]=i;
                    if(!vis[v])
                    {
                        q.push(v);
                        vis[v]=1;
                    }
                }
            }
            vis[u]=0;
        }
        if(d[t]==inf) return res;
        if(d[t]>=0) return res;
        int flow=f;
        for(int i=pre[t];i!=-1;i=pre[p[i].from])
        {
            flow=min(flow,p[i].cap);
        }
        res+=flow*d[t];
        for(int i=pre[t];i!=-1;i=pre[p[i].from])
        {
            p[i].cap-=flow, p[1^i].cap+=flow;
        }
        f-=flow;
    }
    return res;
}
int v[N];
int main()
{
    int n;
    while(scanf("%d", &n)!=EOF&&n!=0)
    {
        memset(head,-1,sizeof(head));
        cnt=0;
        int s=0, t=2*n+10;
        for(int i=1;i<=n;i++)
        {
            scanf("%d", &v[i]);
            add(s,i,1,0);
            add(n+i,t,1,0);
        }
        int x;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                scanf("%1d",&x);
                if(i==j) continue;
                if(x==1)
                    add(i,n+j,1,-(v[i]^v[j]));
            }
        }
        printf("%d\n",-min_cost_flow(s,t,n));
    }
    return 0;
}