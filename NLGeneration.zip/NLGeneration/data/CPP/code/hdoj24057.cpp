// Data Structure->Segment Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define eps 1e-5
#define oo 1000000007
#define pi acos(-1.0)
#define MAXN 100005
using namespace std;
int tree[21][MAXN],num[21][MAXN],sorted[MAXN];
void built(int l,int r,int t)
{
       if (l==r) return;
       int i,x,y,mid=(r+l)>>1;
       x=l;y=mid+1; 
       for (i=l;i<=r;i++)
       {
              num[t][i]=num[t][i-1]; 
              if (tree[t][i]<=sorted[mid]) tree[t+1][x++]=tree[t][i],num[t][i]++; 
                  else tree[t+1][y++]=tree[t][i];  
       }
       built(l,mid,t+1),built(mid+1,r,t+1); 
}
int query(int L,int R,int k,int l,int r,int t)
{
       if (L==R) return tree[t][L];
       int ltoL,LtoR,mid=(l+r)>>1;
       ltoL=num[t][L-1]-num[t][l-1]; 
       LtoR=num[t][R]-num[t][L-1];  
       if (LtoR>=k) return query(l+ltoL,l+ltoL+LtoR-1,k,l,mid,t+1); 
       
       int b=L-l-ltoL,bb=R-L+1-LtoR; 
       return query(mid+b+1,mid+b+bb,k-LtoR,mid+1,r,t+1);  
           
}
int main()
{
       int n,m,i;
       scanf("%d%d",&n,&m);
       for (i=1;i<=n;i++) scanf("%d",&tree[0][i]),sorted[i]=tree[0][i];
       memset(num,0,sizeof(num));
       sort(sorted+1,sorted+1+n);
       built(1,n,0);
       while (m--)
       {
               int l,r,k;
               scanf("%d%d%d",&l,&r,&k);
               printf("%d\n",query(l,r,k,1,n,0));
       }
       return 0;
}