// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=1000+100;
char a[MAXN];
int ans[MAXN];
int dmin[MAXN][20];
int minc(int i,int j)
{
    if(a[i]<=a[j])return i;
    return j;
}
void initMin(int n)
{
    for(int i=0; i<n; i++)dmin[i][0]=i;
    for(int j=1; (1<<j)<=n; j++)
        for(int i=0; i+(1<<j)-1<n; i++)
            dmin[i][j]=minc(dmin[i][j-1],dmin[i+(1<<(j-1))][j-1]);
}
int getMin(int L,int R)
{
    int k=0;
    while((1<<(k+1))<=R-L+1)k++;
    return minc(dmin[L][k] , dmin[R-(1<<k)+1][k]);
}
int main()
{
    int m;
    while(scanf("%s%d",a,&m)==2)
    {
        int n=strlen(a);
        int p=-1;
        initMin(n);
        for(int i=1; i<=n-m; i++)
        {
            p=getMin(p+1,m+i-1);
            ans[i]=a[p]-'0';
        }
        int i;
        for(i=1; i<=n-m; i++)if(ans[i]!=0)break;
        if(i>n-m)printf("0\n");
        else
        {
            for(; i<=n-m; i++)
            {
                printf("%d",ans[i]);
            }
            printf("\n");
        }
    }
    return 0;
}