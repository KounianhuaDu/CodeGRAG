// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
#define eps 1e-8
#define MAXN 500000+10
#define MAXM 50000000
#define Ri(a) scanf("%d", &a)
#define Rl(a) scanf("%lld", &a)
#define Rs(a) scanf("%s", a)
#define Pi(a) printf("%d\n", (a))
#define Pl(a) printf("%lld\n", (a))
#define Ps(a) printf("%s\n", (a))
#define W(a) while(a--)
#define CLR(a, b) memset(a, (b), sizeof(a))
#define MOD 1000000007
#define LL long long
using namespace std;
int num[1100];
LL a[1100][110];
LL b[100100];
int Find(LL *s, LL val, int l, int r)
{
    int ans;
    while(r >= l)
    {
        int mid = (l + r) >> 1;
        if(s[mid] >= val)
        {
            ans = mid;
            r = mid-1;
        }
        else
            l = mid+1;
    }
    return ans;
}
int main()
{
    int t, kcase = 1;
    Ri(t);
    W(t)
    {
        int n; LL k;
        Ri(n); Rl(k);
        int top = 0;
        for(int i = 1; i <= n; i++)
        {
            Ri(num[i]);
            for(int j = 1; j <= num[i]; j++)
                Rl(a[i][j]), b[++top] = a[i][j];
            sort(a[i]+1, a[i]+num[i]+1);
        }
        sort(b+1, b+top+1);
        LL ans = 0;
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= num[i]; j++)
            {
                LL temp = k - a[i][j] + 1;
                int p1, p2;
                if(a[i][num[i]] < temp)
                    p1 = 0;
                else
                    p1 = num[i] - Find(a[i], temp, 1, num[i]) + 1;
                if(b[top] < temp)
                    p2 = 0;
                else
                    p2 = top - Find(b, temp, 1, top) + 1;
                ans += p2 - p1;
            }
        }
        Pl(ans / 2);
    }
    return 0;
}