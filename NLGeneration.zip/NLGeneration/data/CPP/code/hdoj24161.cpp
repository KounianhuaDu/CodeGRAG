// Graph Algorithm->Prim's Algorithm,Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define fun(x1,x2,y1,y2) sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2))
#define INT_MAX 100000000
#define NUM 110
struct Seat
{
	double x,y;
}num[NUM];
double cost[NUM][NUM],sum;
bool judge[NUM];
double prim(int n)
{
	int i,j,pos;
	double Long[NUM],sum=0,min1;
	memset(judge,false,sizeof(judge));
	pos=1;
	judge[pos]=true;
	for(i=1;i<=n;i++)
	if(i!=pos) Long[i]=cost[pos][i];
	for(i=0;i<n-1;i++)
	{
		min1=INT_MAX;
		for(j=1;j<=n;j++)
		if(!judge[j]&&Long[j]<min1)
		{
			min1=Long[j];
			pos=j;
		}
		if(min1==INT_MAX) return -1;
		sum+=min1;
		judge[pos]=true;
		for(j=1;j<=n;j++)
		if(!judge[j]&&cost[pos][j]<Long[j])
		Long[j]=cost[pos][j];
	}
	return sum;
}
int main()
{
	int T,N,M,i,j;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&N);
		for(i=1;i<=N;i++)
		scanf("%lf %lf",&num[i].x,&num[i].y);
		for(i=1;i<=N;i++)
		 for(j=1;j<=N;j++)
		 if(i==j) cost[i][j]=0;
		 else cost[i][j]=INT_MAX;
		for(i=1;i<=N;i++)
		 for(j=1;j<=N;j++)
		 {
		   cost[i][j]=fun(num[i].x,num[j].x,num[i].y,num[j].y);
		   if(!(cost[i][j]>=10&&cost[i][j]<=1000))
		   {
		   	  if(i==j) cost[i][j]=0;
		   	  else cost[i][j]=INT_MAX;
		   }
	     }
        if(prim(N)==-1)
        printf("oh!\n");
        else
        printf("%.1lf\n",prim(N)*100);
	    
	}
	return 0;
}