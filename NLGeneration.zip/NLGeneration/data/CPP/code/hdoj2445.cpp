// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char maptt1[10][10];
int x[100];
int y[100];
int vx[10][10];
int vy[10][10];
int vz[10][10];
int cnt;
bool flag;
void dfs(int deep)
{
	if (flag)return;
	if (deep == cnt) { flag = true; return; }
		int i = deep;
		for (int j = 1; j <= 9; j++)
		{
			if (flag)return;
			int temp = 0;
			if (vx[x[i]][j] == 1)continue;
			if (vy[y[i]][j] == 1)continue;
			if (x[i] >= 0 && x[i] < 3)
			{
				if (y[i] >= 0 && y[i] < 3)
				{
					temp = 0;
					if(vz[0][j] == 1)continue;
				}
				else	if (y[i] >= 3 && y[i] < 6)
				{
					temp = 1;
					if (vz[1][j] == 1)continue;
				}
				else	if (y[i] >= 6 && y[i]< 9)
				{
					temp = 2;
					if (vz[2][j] == 1)continue;
				}
			}
			else	if (x[i] >= 3 && x[i] < 6)
			{
				if (y[i] >= 0 && y[i] < 3)
				{
					temp = 3;
					if (vz[3][j] == 1)continue;
				}
				else	if (y[i] >= 3 && y[i] < 6)
				{
					temp = 4;
					if (vz[4][j] == 1)continue;
				}
				else	if (y[i] >= 6 && y[i]< 9)
				{
					temp = 5;
					if (vz[5][j] == 1)continue;
				}
			}
			else	if (x[i] >= 6 && x[i] < 9)
			{
				if (y[i] >= 0 && y[i]< 3)
				{
					temp = 6;
					if (vz[6][j] == 1)continue;
				}
				else	if (y[i] >= 3 && y[i] < 6)
				{
					temp = 7;
					if (vz[7][j] == 1)continue;
				}
				else	if (y[i] >= 6 && y[i]< 9)
				{
					temp = 8;
					if (vz[8][j] == 1)continue;
				}
			}
			maptt1[x[i]][y[i]] = j+'0';
			vx[x[i]][j] = 1;
			vy[y[i]][j] = 1;
			vz[temp][j] = 1;
			dfs(deep + 1);
			vx[x[i]][j] = 0;
			vy[y[i]][j] = 0;
			vz[temp][j] = 0;
		}
}
int main()
{
	int l = 0;
	char str[10];
	while (scanf("%s", &str) != EOF)
	{
		maptt1[0][0] = str[0];
		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				if (i == 0 && j == 0)continue;
				scanf("%s", &str);
				maptt1[i][j] = str[0];
			}
		}
		cnt = 0;
		memset(vx, 0, sizeof(vx));
		memset(vy, 0, sizeof(vy));
		memset(vz, 0, sizeof(vz));
		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 9; j++)
			{
				if (maptt1[i][j] == '?') { x[cnt] = i; y[cnt++] = j; }
				else
				{
					int temp = maptt1[i][j] - '0';
					vx[i][temp] = 1;
					vy[j][temp] = 1;
					if (i >= 0 && i < 3)
					{
						if (j >= 0 && j < 3)
						{
							vz[0][temp] = 1;
						}
						else	if (j >= 3 && j < 6)
						{
							vz[1][temp] = 1;
						}
						else	if (j >= 6 &&  j< 9)
						{
							vz[2][temp] = 1;
						}
					}
					else	if (i >= 3 && i < 6)
					{
						if (j >= 0 && j < 3)
						{
							vz[3][temp] = 1;
						}
						else	if (j >= 3 && j < 6)
						{
							vz[4][temp] = 1;
						}
						else	if (j >= 6 && j< 9)
						{
							vz[5][temp] = 1;
						}
					}
					else	if (i >= 6 && i < 9)
					{
						if (j >= 0 && j < 3)
						{
							vz[6][temp] = 1;
						}
						else	if (j >= 3 && j < 6)
						{
							vz[7][temp] = 1;
						}
						else	if (j >= 6 && j< 9)
						{
							vz[8][temp] = 1;
						}
					}
				}
			}
		}
		flag = false;
		if (l)printf("\n");
		dfs(0);
		l++;
		for (int i = 0; i < 9; i++)
		{
			for (int j = 0; j < 8; j++)
			{
				printf("%c ", maptt1[i][j]);
			}
			printf("%c\n", maptt1[i][8]);
		}
	}
	return 0;
}