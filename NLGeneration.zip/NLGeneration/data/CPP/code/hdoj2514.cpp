// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define Max(a,b) ((a>b)?a:b)
#define Min(a,b) ((a<b)?a:b)
#define debug 0
#define M(a) memset(a,0,sizeof(a))
#define INF 1<<28
const int maxn = 100 + 5;
int n,num[maxn],dp[maxn];
struct R
{
	int c;
	int w;
}r[maxn];
void Do(){
	for(int i = 2;i <= n;i++)
		{
			int temp = INF;
			for(int j = 1;j <= i;j++)
				{
					int t = num[i] - num[j - 1];
			 		temp = Min(temp,(t + 10) * r[i].w + dp[j - 1]);
				}
			dp[i] = temp;
		}
	printf("%d\n",dp[n]);
}
int main(){
#if debug
	freopen("in.txt","r",stdin);
#endif 
	int T;
	scanf("%d",&T);
	while (T--)
	{
		M(num);
		scanf("%d",&n);
		for(int i = 1;i <= n;i++)
		{
			scanf("%d%d",&r[i].c,&r[i].w);
			num[i]=num[i - 1]+r[i].c;
		}
		dp[1] = (num[1] + 10) * r[1].w;
		Do();
	}
	return 0;
}