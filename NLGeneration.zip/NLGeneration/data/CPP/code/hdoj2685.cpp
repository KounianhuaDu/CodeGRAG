// Basic Algorithm->Arbitrary-Precision Arithmetic,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int Max(int a, int b)
{
	return (a>b)?a:b;
}
int main()
{
	int n,i,j;
	char s1[1001],s2[1001];
	scanf("%d",&n);
	for (i = 0;i < n;i ++) {
		scanf("%s %s",s1,s2);
		int a1[1010]={0},a2[1010]={0},len1,len2;
		len1 = strlen(s1);
		len2 = strlen(s2);
		for (j = len1 - 1;j >= 0; j --) {
			a1[j] = s1[len1-j-1] - '0';
		}
		for (j = len2 - 1;j >= 0; j --) {
			a2[j] = s2[len2-j-1] - '0';
		}
		int len = Max(len1,len2);
		for (j = 0;j < len; j ++) {
			a1[j] += a2[j];
			a1[j+1] += a1[j] / 10;
			a1[j] %= 10;
		}
		if (a1[len] != 0) {
			len ++;
		}
		printf("Case %d:\n",i+1);
		printf("%s + %s = ",s1,s2);
		for (j=len-1;j>=0;j--) {
			printf("%d",a1[j]);
		}
		printf("\n");
		if (i != n-1)
		printf("\n");
	}
	return 0;
}