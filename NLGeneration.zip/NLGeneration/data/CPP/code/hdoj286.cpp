// Data Structure->Stack,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define N 9
#define NMAX 362885
struct Point{
	char eightMap[N];
	int position;
	string path;
};
const int fac[]={1,1,2,6,24,120,720,5040,40320};
const int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
const char option[4]={'u','l','d','r'};
bool visited[NMAX];
string inversionPath[NMAX];
inline int cantor(Point p){
	int ans=0;
	for(int i=0;i<N;i++)
	{
		int cnt=0;
		for(int k=i+1;k<N;k++)
		{
			if(p.eightMap[k]<p.eightMap[i])
				cnt++;
		}
		ans+=fac[8-i]*cnt;
	}
	return ans;
}
bool bfs(){
	int row,col,cantorValue;
	memset(visited,false,sizeof(visited));
	Point startPoint;
	for (int i=1;i<N;i++)
		startPoint.eightMap[i-1]=i+'0';
	startPoint.eightMap[N-1]='x';
	startPoint.position=N-1;
	startPoint.path="";
	visited[0]=true;
	queue<Point> que;
	que.push(startPoint);
	while(!que.empty()){
		Point p=que.front();
		que.pop();
		for(int i=0;i<4;i++){
			row=p.position/3+dir[i][0];
			col=p.position%3+dir[i][1];
			if(row<0||col<0||row>=3||col>=3) continue;
			Point newPoint(p);
			newPoint.eightMap[newPoint.position]=newPoint.eightMap[col+row*3];
			newPoint.position=col+row*3;
			newPoint.eightMap[newPoint.position]='x';
			cantorValue=cantor(newPoint);
			if(visited[cantorValue]) continue;
			visited[cantorValue]=true;
			newPoint.path+=option[i];
			inversionPath[cantorValue]=newPoint.path;
			que.push(newPoint);
		}
	}
	return false;
}
int main(){
	
	Point startPoint;
	int startCantor;
	bfs();
	while(cin>>startPoint.eightMap[0])
	{
		if(startPoint.eightMap[0]=='x')
			startPoint.position=0;
		for(int i=1;i<9;i++)
		{
			cin>>startPoint.eightMap[i];
			if(startPoint.eightMap[i]=='x')
				startPoint.position=i;
		}
		startCantor=cantor(startPoint);
		if(visited[startCantor])
		{
			for (int i=inversionPath[startCantor].size()-1;i>=0;i--)
				cout<<inversionPath[startCantor][i];
			cout<<endl;
		}
		else
		{
			cout<<"unsolvable"<<endl;
		}
	}
	return 0;
}