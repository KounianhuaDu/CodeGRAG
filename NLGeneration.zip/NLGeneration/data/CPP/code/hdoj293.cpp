// Basic Algorithm->Breadth First Search (BFS),Data Structure->Hashing,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct Node {
    int s[9];
    int loc;
    int status;
};
queue<Node> q;
struct Path {
    int fa;
    char d;
};
Path path[500000];
string s, _ans;
int a[10], F[10];
int jud[500000];
int dir_jud[4][9] = {
    
    1, 1, 0, 1, 1, 0, 1, 1, 0,
    0, 1, 1, 0, 1, 1, 0, 1, 1,
    0, 0, 0, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 0, 0, 0
};
int dir[4] = {1, -1, -3, 3};
char zifu[10] = {"rlud"};
int Cantor(int a[]) {
    int ans = 0;
    for (int i = 0; i < 9; i++) {
        int t = 0;
        for (int j = 0; j < i; j++) {
            if(a[j] < a[i])
                t++;
        }
        ans += (a[i] - t - 1) * F[9 - i - 1];
    }
    return ans;
}
void read() {
    int j = 0;
    for (int i = 0; i < s.size(); i++) {
        if(s[i] >= '1' && s[i] <= '9') {
            a[j++] = s[i] - '0';
        } else if(s[i] == 'x') {
            a[j++] = 9;
        }
    }
}
int check(int a[]) {
    int ans = 0;
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < i; j++) {
            if(a[i] < a[j] && a[j] != 9)
                ans++;
        }
    }
    return ans;
}
void cal() {
    F[0] = 1;
    for (int i = 1; i <= 9; i++)
        F[i] = i * F[i - 1];
}
int bfs() {
    while(!q.empty()) {
        if (!q.front().status)
            return 1;
        for (int i = 0; i < 4; i++) {
            Node tt = q.front();
            if (dir_jud[i][tt.loc]) {
                swap(tt.s[tt.loc], tt.s[tt.loc + dir[i]]);
                tt.status = Cantor(tt.s);
                if (!jud[tt.status]) {
                    jud[tt.status] = 1;
                    path[tt.status].fa = q.front().status;
                    path[tt.status].d = zifu[i];
                    tt.loc += dir[i];
                    q.push(tt);
                }
            }
        }
        q.pop();
    }
    return 0;
}
int main() {
    while(getline(cin, s)) {
        q = queue<Node> ();
        memset(path, 0, sizeof(path));
        memset(jud, 0, sizeof(jud));
        read();
        cal();
        if(check(a) % 2) {
            puts("unsolvable");
            continue;
        }
        Node start;
        for(int i = 0; i < 9; i++) {
            start.s[i] = a[i];
            if(a[i] == 9)
                start.loc = i;
        }
        start.status = Cantor(start.s);
        q.push(start);
        path[start.status].fa = -1;
        jud[start.status] = 1;
        if(!bfs()) {
            puts("unsolvable");
            continue;
        }
        int i = 0;
        while (path[i].fa != -1) {
            _ans.push_back(path[i].d);
            i = path[i].fa;
        }
        reverse(_ans.begin(), _ans.end());
        cout << _ans << endl;
    }
    return 0;
}