// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int INF = 0x3f3f3f3f;
const int maxn = 102;
int G[maxn][maxn],path[maxn][maxn],cost[maxn];
int i,j,k,s,e,n;
void Floyd()
{
    for(k=1; k<=n; k++)
    {
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
            {
                int cur=G[i][k]+G[k][j]+cost[k];
                if(cur<G[i][j])G[i][j]=cur,path[i][j]=path[i][k];
                else if(cur==G[i][j]){
                    if(path[i][j]>path[i][k]){
                        path[i][j]=path[i][k];
                    }
                }
            }
        }
    }
}
int main()
{
    while(~scanf("%d",&n)&&n)
    {
        int data;
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
            {
                scanf("%d",&data);
                if(data==-1)G[i][j]=INF;
                else        G[i][j]=data;
                path[i][j]=j;
            }
        }
        for(int i=1; i<=n; i++)scanf("%d",&cost[i]);
        Floyd();
        while(~scanf("%d%d",&s,&e))
        {
            if(s==-1&&e==-1)break;
            printf("From %d to %d :\n",s,e);
            printf("Path: %d",s);
            int temp=s;
            while(temp!=e)
            {
                temp = path[temp][e];
                printf("-->%d",temp);
            }
            printf("\nTotal cost : %d\n\n",G[s][e]);
        }
    }
    return 0;
}