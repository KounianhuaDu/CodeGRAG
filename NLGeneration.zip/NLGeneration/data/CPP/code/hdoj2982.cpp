// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int INF=0x3f3f3f3f;
int n;
int g[110][110],b[110];
int fa[110][110];
int main()
{
    while(scanf("%d",&n)!=EOF)
    {
        memset(g,63,sizeof(g));
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                scanf("%d",&g[i][j]);
                if(g[i][j]==-1)
                    g[i][j]=INF;
            }
        }
        for(int i=1;i<=n;i++)
            scanf("%d",&b[i]);
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                fa[i][j]=j;
        for(int k=1;k<=n;k++)
        {
            for(int i=1;i<=n;i++)
            {
                for(int j=1;j<=n;j++)
                {
                    if(g[i][j]>g[i][k]+g[k][j]+b[k])
                    {
                        g[i][j]=g[i][k]+g[k][j]+b[k];
                        fa[i][j]=fa[i][k];
                    }
                    else if(g[i][j]==g[i][k]+g[k][j]+b[k])
                    {
                        fa[i][j]=min(fa[i][j],fa[i][k]);
                    }
                }
            }
        }
        int s,t;
        while(scanf("%d%d",&s,&t)!=EOF)
        {
            if(s==-1&&t==-1) break;
            printf("From %d to %d :\nPath: ",s,t);
            int next=fa[s][t];
            printf("%d",s);
            if(s!=t)
            {
                while(next!=t)
                {
                    printf("-->");
                    printf("%d",next);
                    next=fa[next][t];
                }
                printf("-->%d",t);
            }
            printf("\nTotal cost : %d\n\n",g[s][t]);
        }
    }
    return 0;
}