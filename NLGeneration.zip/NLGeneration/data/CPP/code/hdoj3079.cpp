// Math and Computational Geometry->Fast Fourier Transform (FFT)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 
 
 
 
 
 
 
 
#define maxn 900005
#define maxm 1000005
#define eps 1e-10
#define mod 1000000007
#define INF 999999999
#define PI (acos(-1.0))
#define lowbit(x) (x&(-x))
#define mp make_pair
#define ls o<<1
#define rs o<<1 | 1
#define lson o<<1, L, mid 
#define rson o<<1 | 1, mid+1, R
#pragma comment(linker, "/STACK:16777216")
typedef long long LL;
typedef unsigned long long ULL;
using namespace std;
LL qpow(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base;base=base*base;b/=2;}return res;}
LL powmod(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base%mod;base=base*base%mod;b/=2;}return res;}
void scanf(int &__x){__x=0;char __ch=getchar();while(__ch==' '||__ch=='\n')__ch=getchar();while(__ch>='0'&&__ch<='9')__x=__x*10+__ch-'0',__ch = getchar();}
LL gcd(LL _a, LL _b){if(!_b) return _a;else return gcd(_b, _a%_b);}
struct complex
{
	double r, i;
	complex(double r = 0, double i = 0) : r(r), i(i) {}
	complex operator + (const complex b) const {
		return complex(r + b.r, i + b.i);
	}
	complex operator - (const complex b) const {
		return complex(r - b.r, i - b.i);
	}
	complex operator * (const complex b) const {
		return complex(r * b.r - i * b.i, r * b.i + i * b.r);
	}
}x1[maxn], x2[maxn];
int sum[maxn];
char s1[maxn], s2[maxn];
void chang(complex y[], int len)
{
	for(int i = 1, j = len / 2; i < len-1; i++) {
		if(i < j) swap(y[i], y[j]);
		int k = len / 2;
		while(j >= k) {
			j -= k;
			k /= 2;
		}
		j += k;
	}
}
void fft(complex y[], int len, int on)
{
	chang(y, len);
	for(int i = 2; i <= len; i <<= 1) {
		complex wn(cos(-on * 2 * PI / i), sin(-on * 2 * PI / i));
		for(int j = 0; j < len; j += i) {
			complex w(1.0, 0.0);
			for(int k = j; k < j + i / 2; k++) {
				complex u = y[k];
				complex t = w * y[k + i / 2];
				y[k] = u + t;
				y[k + i / 2] = u - t;
				w = w * wn;
			}
		}
	}
	if(on == -1) for(int i = 0; i < len; i++) y[i].r /= len;
}
void work(void)
{
	int len1 = strlen(s1);
	int len2 = strlen(s2);
	int len = 1;
	while(len < 2 * len1 || len < 2 * len2) len <<= 1;
	for(int i = 0; i < len1; i++) x1[i] = complex(s1[len1-1-i] - '0', 0.0);
	for(int i = 0; i < len2; i++) x2[i] = complex(s2[len2-1-i] - '0', 0.0);
	for(int i = len1; i < len; i++) x1[i] = complex(0.0, 0.0);
	for(int i = len2; i < len; i++) x2[i] = complex(0.0, 0.0);
	fft(x1, len, 1);
	fft(x2, len, 1);
	for(int i = 0; i < len; i++) x1[i] = x1[i] * x2[i];
	fft(x1, len, -1);
	sum[len] = 0;
	for(int i = 0; i < len; i++) sum[i] = x1[i].r + 0.5;	
	for(int i = 0; i < len; i++) sum[i+1] += sum[i] / 10, sum[i] %= 10;
	while(!sum[len] && len) len--;
	for(int i = len; i >= 0; i--) printf("%d", sum[i]);
	printf("\n");
}
int main(void)
{
	while(scanf("%s%s", s1, s2)!=EOF) {
		work();
	}
	return 0;
}