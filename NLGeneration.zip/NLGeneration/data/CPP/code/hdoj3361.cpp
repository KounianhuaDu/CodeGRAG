// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
using namespace std;
#define max_n 1010
int dp[22][max_n];
int main()
{
	int c;
	cin >> c;
	while (c--)
	{
		int n, m;
		cin >> n >> m;
		for (int i = 0; i < n; i++)
		{
			for (int j = 1; j <=m; j++)  
			{
				cin >> dp[i][j];
			}
		}
		for (int j = 2; j <=m; j++)
		{
			int t = dp[0][j - 1];
			for (int k = 2; k <=j; k++)
			{
				if (j%k == 0)t = max(t, dp[0][j / k]);
			}
			dp[0][j] += t;
		}
		for (int i = 1; i < n; i++)
		{
			dp[i][1] += dp[i - 1][1];
			for (int j = 2; j <= m; j++)
			{
				int t = dp[i][j - 1];
				t = max(t, dp[i - 1][j]);
				for (int k = 2; k <= j; k++)
				{
					if (j%k == 0)t = max(t, dp[i][j / k]);
				}
				dp[i][j] += t;
			}
		}
		cout << dp[n - 1][m ] << endl;
	}
	return 0;
}