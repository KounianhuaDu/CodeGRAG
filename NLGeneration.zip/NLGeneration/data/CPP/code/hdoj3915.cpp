// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int mv[6][2] = {0, 2, 0, -2, 1, 1, -1, -1, -1, 1, 1, -1};
int mm[222][222];
int h, w, sh, sw;
int cnt, ans;
int check(int x, int y)
{
    return (x <= h && y <= 2 * w && x >= 1 && y >= 1);
}
void dfs(int x, int y)
{
    ans --;
    mm[x][y] = 0;
    for(int i = 0; i < 6; i++)
    {
        int nextx = x + mv[i][0];
        int nexty = y + mv[i][1];
        if(check(nextx, nexty) && mm[nextx][nexty])
            dfs(nextx, nexty);
    }
}
void destroy(int x, int y, int cl)
{
    cnt ++;
    mm[x][y] = 0;
    for(int i = 0; i < 6; i++)
    {
        int nextx = x + mv[i][0];
        int nexty = y + mv[i][1];
        if(check(nextx, nexty) && mm[nextx][nexty] == cl)
            destroy(nextx, nexty, cl);
    }
}
int main()
{
    char str[101];
    int i, j;
    while(~scanf("%d%d%d%d",&h, &w, &sh, &sw))
    {
        memset(mm, 0, sizeof(mm));
        for(i = 1; i <= h; i++)
        {
            scanf("%s",str);
            int len = strlen(str);
             for(j = 1 + !(i % 2); j <= 2 * len; j += 2)
                if(str[(j + 1) / 2 - 1] != 'E')
                    mm[i][j] = str[(j + 1) / 2 - 1] - 'a' + 1;
        }
        ans = 0;
        cnt = 0;
        sw = sw * 2 - (sh % 2);
        destroy(sh, sw, mm[sh][sw]);
        if(cnt < 3)
        {
            printf("0\n");
            continue;
        }
        for(i = 1; i <= h; i++)
            for(j = 1; j < 2 * w; j++)
                if(mm[i][j])ans ++;
        for(i = 1; i < 2 * w; i++)
            if(mm[1][i])
            dfs(1, i);
        printf("%d\n",ans + cnt);
    }
    return 0;
}