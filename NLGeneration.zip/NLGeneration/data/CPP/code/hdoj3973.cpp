// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1005;
struct point{
    double x,y;
};
struct segment{
    point s,e;
}a[maxn];
int i,j,k,n,tot;
int f[maxn],ans[maxn];
char cc;
double product(point &a, point &b, point &c){
   double x1,y1,x2,y2;
   x1 = a.x - c.x; y1 = a.y - c.y;
   x2 = b.x - c.x; y2 = b.y - c.y;
   return (x1*y2 - x2*y1);
}
bool intersect(segment &a, segment &b){
    if (
        product(a.s,a.e,b.s)*product(a.s,a.e,b.e)<=0 &&
        product(b.s,b.e,a.s)*product(b.s,b.e,a.e)<=0 ) return 1;
    return 0;
}
int Find(int x) {
     if (f[x]==x) return x;
     return f[x] = Find(f[x]);
}
void Merge(int x, int y){
    int fx = Find(x), fy = Find(y);
    if (fx!=fy) {
        f[fx] = fy;
        ans[fy] += ans[fx];
    }
}
int main(){
   int T;
   scanf("%d",&T);
   while (T--) {
       tot = 0;
       for (i=1; i<=1000; i++) ans[i] = 1;
       for (i=1; i<=1000; i++) f[i] = i;
       scanf("%d",&n);
       while (n--) {
          cin >> cc;
          if (cc=='P') {
              tot++;
              scanf("%lf %lf %lf %lf",&a[tot].s.x,&a[tot].s.y,&a[tot].e.x,&a[tot].e.y);
              for (i=1; i<=tot-1; i++)
                if (intersect(a[i],a[tot])) {
                        Merge(tot,i);
                  }
          }
          else {
             scanf("%d",&k);
             printf("%d\n",ans[Find(k)]);
          }
       }
       if (T) printf("\n");
   }
   return 0;
}