// Math and Computational Geometry->Chinese Remainder Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ll long long
ll n,m;
ll a[15],b[15];
ll e_gcd(ll a,ll b,ll &x,ll &y)
{
	if(b==0)
	{
		x=1;
		y=0;
		return a;
	}
	int ans=e_gcd(b,a%b,x,y);
	ll temp=x;
	x=y;
	y=temp-a/b*y;
	return ans;
}
ll lmes() {
    ll M = a[0], R = b[0], x, y;
    for (int i = 1; i < m; i++) {
        int gcd=e_gcd(M, a[i], x, y);
        if ((b[i] - R) % gcd) return 0; 
        x = (b[i] - R) / gcd*x % (a[i] / gcd);
        R += x*M;
        M = M / gcd*a[i];
	   R=(R%M+M)%M;
    }
    
    return !R ? n / M : n < R ? 0 : (n - R) / M + 1;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld%lld",&n,&m);
		for(int i=0;i<m;i++)
		{
			scanf("%lld",&a[i]);
		}
		for(int i=0;i<m;i++)
		{
			scanf("%lld",&b[i]);
		}
		ll sum=lmes();
		printf("%lld\n",sum);
	}
	return 0;
}