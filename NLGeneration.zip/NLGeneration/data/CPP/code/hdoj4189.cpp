// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int inf = 1<<25;
const int maxn = 1005;
int i,j,k,n,m,max_dis,tot,A,B,V;
int dis[maxn],a[maxn][maxn],pre[maxn];
bool vis[maxn];
void dijstra(int f){
    int s,tmp,d;
    for (i=1; i<=n; i++) {
        vis[i] = 0;
        dis[i] = a[1][i];
    }
    vis[1] = 1; s=1;
    for (j = 1; j<n; j++) {
        d = inf;
        for (i=1; i<=n; i++) if (!vis[i] && d>dis[i]) {
            s = i;
            d = dis[i];
        }
        vis[s] = 1;
        for (i=1; i<=n; i++) if (!vis[i] && dis[i]>dis[s]+a[s][i]) {
             dis[i] = dis[s] + a[s][i];
             if (f) pre[i] = s;
        }
    }
}
int main(){
    while (scanf("%d%d",&n,&m)!=EOF){
        for (i=1; i<=n; i++) {
            for (j=1; j<=n; j++) a[i][j] = inf;
            a[i][i]=0;
            pre[i] = 1;
        }
        for (i=1; i<=m; i++) {
            scanf("%d%d%d",&A,&B,&V);
            if (a[A][B]>V) a[A][B] = a[B][A] = V;
        }
        tot = 0;
        dijstra(1);
        max_dis = dis[n];
        for (k=n; k!=1; k=pre[k]) {
            int temp = a[pre[k]][k];
            a[k][pre[k]] = a[pre[k]][k] = inf;
            dijstra(0);
            max_dis = max(max_dis,dis[n]);
            a[k][pre[k]] = a[pre[k]][k] = temp;
        }
        printf("%d\n",max_dis);
    }
    return 0;
}