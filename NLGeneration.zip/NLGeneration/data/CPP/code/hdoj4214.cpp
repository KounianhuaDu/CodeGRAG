// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
using namespace std;
int n,m;
int pre[203];
struct data
{
    int s,e,sp;
}a[100003];
int cmp(data a,data b)
{
    return a.sp<b.sp;
}
void init()
{
    for(int i=0;i<=200;i++)pre[i]=i;
}
int Find(int x)
{
    if(x==pre[x])
        return x;
    return pre[x]=Find(pre[x]);
}
void Merge(int x,int y)
{
    int X=Find(x);
    int Y=Find(y);
    if(X!=Y)
        pre[X]=Y;
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        init();
        for(int i=0;i<m;i++)
        {
            scanf("%d%d%d",&a[i].s,&a[i].e,&a[i].sp);
        }
        sort(a,a+m,cmp);
        int Q;
        scanf("%d",&Q);
        while(Q--)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            int res=inf;
            for(int i=0;i<m;i++)
            {
                init();
                int flag=0;
                for(int j=i;j<m;j++)
                {
                    Merge(a[j].s,a[j].e);
                    if(Find(x)==Find(y))
                    {
                        res=min(res,a[j].sp-a[i].sp);
                        break;
                    }
                }
            }
            if(res==inf)
                printf("-1\n");
            else printf("%d\n",res);
        }
    }
}