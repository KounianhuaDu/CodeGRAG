// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct kiss
{
    int kk;
    bool operator < (const kiss &a)
    {
        return kk>a.kk;
    }
}tmep[27];
priority_queue<int,vector<int>,greater<int> > que;
int main()
{
    string str;
    
    while (getline(cin,str),str!="END")
    {
        
        
        for (int i=0; i<27; ++i)
        {
            tmep[i].kk=0;
        }
        while(!que.empty())
            que.pop();
        for (int i=0; i<str.length(); ++i)
        {
            if (str[i]=='_')
                tmep[26].kk++;
            else
                tmep[str[i]-'A'].kk++;
        }
        for (int i=0; i<27; ++i)
        {
            if (tmep[i].kk!=0)
            {
                que.push(tmep[i].kk);
            }
        }
        int ans=0,a,b;
        if (que.size()==1)
        {
            
            que.pop();
            
            printf("%d %d 8.0\n",str.length()*8,str.length());
        }
        else
        {
            
        
            while(que.size()!=1)
            {
                a=que.top();que.pop();
                b=que.top();que.pop();
                  que.push(a+b);
                  ans+=(a+b);
                }
            printf("%d %d %.1lf\n",str.length()*8,ans,str.length()*8.0/ans);
        }
        
    
    }
}