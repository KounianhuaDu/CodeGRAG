// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=2000;
struct Edge
{
    int to,next;
}edge[maxn*maxn];
int Adj[maxn],Size;
void init()
{
    Size=0;
    memset(Adj,-1,sizeof(Adj));
}
void Add_Edge(int u,int v)
{
    edge[Size].next=Adj[u];
    edge[Size].to=v;
    Adj[u]=Size++;
}
int n;
int linker[maxn];
bool used[maxn];
bool dfs(int u)
{
    for(int i=Adj[u];~i;i=edge[i].next)
    {
        int v=edge[i].to;
        if(!used[v])
        {
            used[v]=true;
            if(linker[v]==-1||dfs(linker[v]))
            {
                linker[v]=u;
                return true;
            }
        }
    }
    return false;
}
int hungary()
{
    int res=0;
    memset(linker,-1,sizeof(linker));
    for(int u=0;u<n;u++)
    {
        memset(used,false,sizeof(used));
        if(dfs(u)) res++;
    }
    return res;
}
int main()
{
    while(scanf("%d",&n)!=EOF)
    {
        init();
        for(int i=0;i<n;i++)
        {
            int u,v,m;
            scanf("%d:(%d)",&u,&m);
            for(int j=0;j<m;j++)
            {
                scanf("%d",&v);
                Add_Edge(u,v);
                Add_Edge(v,u);
            }
        }
        printf("%d\n",hungary()/2);
    }
    return 0;
}