// Graph Algorithm->Hungarian (KM) Algorithm,Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char s[1024];
char p[1024];
int Next[1024];
void CalNext() {
    Next[0] = 0;
    Next[1] = 0;
    int len = strlen(p);
    int k = 0;
    for(int i = 2;i <= len;i++) {
        while(p[i-1] != p[k] && k) {
            k = Next[k];
        }
        if(p[i-1] == p[k]) {
            k++;
        }
        
        Next[i] = k;
    }
    
}
int KMP() {
    int i = 0;
    int j = 0;
    int count = 0;
    int len1 = strlen(s);
    int len2 = strlen(p);
    while(i < len1) {
        if(s[i] == p[j]) {
            i++,j++;
            if(j == len2) {
                
                count++;
                j = 0;
            }
        } else {
            if(j == 0)
                i++;
            j = Next[j];
        }
    }
    return count;
}
int main()
{
   while(scanf("%s",s) != EOF) {
       if(strcmp(s,"#") == 0) {
           break;
       }
       scanf("%s",p);
       printf("%d\n",KMP());
       
   }
   
   return 0;
}