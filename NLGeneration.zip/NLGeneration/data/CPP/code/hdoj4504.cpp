// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
  
  
  
  
  
using namespace std;  
const int inf=999999;  
int n,m;  
int startt,endd;
int e[1003][1003];  
int value[1003][1003];
int book[1003];  
int dis[1003];  
int val[1003]; 
  
void dijstra()  
{  
    int u,v;   
    for(int i=1;i<=n;i++)  
    {   
        dis[i]=e[startt][i];  
    	val[i]=value[startt][i];
	}    
    dis[startt]=0;  
    val[startt]=0;
    int minn;  
    for(int i=1;i<=n-1;i++)  
    {  
        minn=inf;  
		u=0;
        for(int j=1;j<=n;j++)  
        {  
            if(book[j]==0&&dis[j]<minn)  
            {  
                minn=dis[j];  
                u=j;  
            }  
        }  
        book[u]=1; 
        if(u==0)return;   
        for(int j=1;j<=n;j++)  
        {  
            if(!book[j]&&dis[j]>dis[u]+e[u][j]){
				dis[j]=dis[u]+e[u][j]; 
				val[j]=val[u]+value[u][j]; 	
			} 
			else if(dis[j]==dis[u]+e[u][j]&&val[j]>val[u]+value[u][j]){
				val[j]=val[u]+value[u][j];
			}
        }  
    }     
}  
  
int main()  
{    
    while(scanf("%d%d",&n,&m)!=EOF&&n+m)  
    {  
        memset(book,0,sizeof(book));  
        memset(e,inf,sizeof(e));  
        memset(value,inf,sizeof(value));  
        for(int i=1;i<=m;i++)  
        {  
            int a,b,d,p;
			scanf("%d%d%d%d",&a,&b,&d,&p);
			if(d<e[a][b]){
				e[a][b]=d;
				e[b][a]=d;
				value[a][b]=p;
				value[b][a]=p; 				
			}
        }  
		scanf("%d%d",&startt,&endd);
		dijstra();
        printf("%d %d\n",dis[endd],val[endd]);   
    }  
    return 0;  
}