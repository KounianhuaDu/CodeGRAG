// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int STATE=1000000+10;
const int HASH = 30007;
const int MAXD=15;
int N,M;
int ex,ey;
int cur;
int mp[MAXD][MAXD];
int code[MAXD];
long long sum;
struct HASHMAP
{
    int size,head[HASH],next[STATE];
    long long state[STATE];
    long long f[STATE];
    void init()
    {
        memset(head,-1,sizeof(head));
        size=0;
    }
    void push(long long st, long long num)
    {
        long long h = st%HASH;
        int i;
        for(i=head[h]; i!=-1; i=next[i])
        {
            if(state[i]==st)
            {
                f[i]+=num;
                return ;
            }
        }
        next[size]=head[h];
        head[h]=size;
        f[size]=num;
        state[size]=st;
        size++;
    }
}hm[2];
void decode(int *code,long long st)
{
    for(int i=M; i>=0; i--)
    {
        code[i]=st&7;
        st>>=3;
    }
}
long long encode(int *code)
{
    int ch[MAXD];
    memset(ch,-1,sizeof(ch));
    ch[0]=0;
    int cnt=1;
    long long st=0;
    for(int i=0; i<=M; i++)
    {
        if( ch[code[i]]==-1 ) ch[code[i]]= cnt++;
        code[i]=ch[code[i]];
        st<<=3;
        st|=code[i];
    }
    return st;
}
void shift(int *code)
{
    for(int i=M; i>=1; i--)
        code[i]=code[i-1];
    code[0]=0;
}
void dpblock(int i,int j)
{
    for(int k=0; k<hm[cur].size; k++)
    {
        long long st=hm[cur].state[k];
        int code[MAXD];
        decode(code,st);
        int left=code[j-1] ,up=code[j];
        if(left==0&&up==0)
        {
            if(j==M)
                shift(code);
            hm[1-cur].push(encode(code),hm[cur].f[k]);
        }
    }
}
void dpblank(int i,int j)
{
    for(int k=0; k<hm[cur].size; k++)
    {
        long long st=hm[cur].state[k];
        long long num = hm[cur].f[k];
        int code[MAXD];
        decode(code,st);
        int left=code[j-1] ,up=code[j];
        if(left>0&&up>0)
        {
            if(left!=up)
            {
                code[j-1]=code[j]=0;
                for(int l=0; l<=M; l++)
                    if(code[l]==up)
                        code[l]=left;
                if(j==M)shift(code);
                hm[1-cur].push( encode(code),num );
            }
            else if(left==up)
            {
            	
                
                code[j-1]=code[j]=0;
				if(j==M)shift(code);
				hm[1-cur].push( encode(code),num );
            }
        }
        else if(left>0||up>0)
        {
            if(mp[i][j+1]==1)
            {
                code[j-1]=0;
                code[j]=left+up;
                if(j==M)shift(code);
                hm[1-cur].push( encode(code),num );
            }
            if(mp[i+1][j]==1)
            {
                code[j-1]=left+up;
                code[j]=0;
                if(j==M)shift(code);
                hm[1-cur].push( encode(code),num );
            }
        }
        else
        {
            if(mp[i][j+1]==1&&mp[i+1][j]==1)
            {
                int max_c=1;
                for(int l=0; l<=M; l++)
                    if(max_c<code[l])
                        max_c = code[l];
                code[j-1]=code[j]=max_c+1;
                hm[1-cur].push( encode(code),num );
            }
        }
    }
}
void init()
{
    memset(mp,0,sizeof(mp));
    for(int i=1; i<=N; i++)
    {
        for(int j=1; j<=M; j++)
        {
			scanf("%d",&mp[i][j]);
        }
    }
}
long long  solve()
{
    sum=0;
    cur=0;
    hm[cur].init();
    hm[cur].push(0,1);
    for(int i=1; i<=N; i++)
        for(int j=1; j<=M; j++)
        {
            hm[1-cur].init();
            if(mp[i][j])
                dpblank(i,j);
            else
                dpblock(i,j);
            cur=1-cur;
        }
    for(int i=0;i<hm[cur].size;i++)
      sum+=hm[cur].f[i];
    return sum;
}
int main()
{
	int cas;
	scanf("%d",&cas);
    for(int i=1;i<=cas;i++)
    {
    	scanf("%d%d",&N,&M);
        init();
        solve();
        printf("Case %d: There are %lld ways to eat the trees.\n",i,solve());
    }
    return 0;
}