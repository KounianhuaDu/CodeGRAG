// Data Structure->Stack,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int main()
{
	int i,j,k,m,n,t,c[1100];
	char a[110],b[110];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%s",&m,a);
		if(strcmp(a,"FIFO")==0)
		{
			i=j=0;
			while(m--)
			{
				scanf("%s",b);
				if(strcmp(b,"IN")==0)
				{
					scanf("%d",&n);
					c[i++]=n;
				}
				else
				{
					if(j>=i)
					printf("None\n");
					else
					printf("%d\n",c[j++]);
				}
			}
		}
		else
		{
			i=0;
			while(m--)
			{
				scanf("%s",b);
				if(strcmp(b,"IN")==0)
				{
					scanf("%d",&n);
					c[i++]=n;
				}
				else
				{
					if(i<1)
					printf("None\n");
					else
					{
						j++;
						printf("%d\n",c[--i]);
					}
				}
			}
		}
	}
}