// Data Structure->Segment Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

    
    
    #define MaxSize 200001
    
    int Tree[MaxSize*4];
    int max(int a,int b){
        if(a>b)
            return a;
        return b;
    }
    void Create(int p,int l,int r){
        if(l==r){
            scanf("%d",&Tree[p]);
            return;
        }
        int mid=(l+r)>>1;
        Create(p<<1,l,mid);
        Create(p<<1|1,mid+1,r);
        Tree[p]=max(Tree[p<<1],Tree[p<<1|1]);
    }
    void Add(int i,int add,int p,int l,int r){
        if(l==r){
            Tree[p]=add;
            return ;
        }
        int mid=(l+r)>>1;
        if(i<=mid)
            Add(i,add,p<<1,l,mid);
        else
            Add(i,add,p<<1|1,mid+1,r);
        Tree[p]=max(Tree[p<<1],Tree[p<<1|1]);
    }
    int Query(int p,int l,int r,int L,int R){
        if(R>=r&&L<=l)
            return Tree[p];
        int sum=-1;
        int mid=(l+r)>>1;
        if(L<=mid)
            sum=max(sum,Query(p<<1,l,mid,L,R));
        if(R>mid)
            sum=max(sum,Query(p<<1|1,mid+1,r,L,R));
        return sum;
    }
    int main()
    {
        int n,b,a,m,i;
        char c;
    
        while(scanf("%d%d",&n,&m)!=EOF){
            Create(1,1,n);
            for(i=1;i<=m;i++){
                scanf("%*c%c %d %d",&c,&a,&b);
                if(c=='Q')
                    printf("%d\n",Query(1,1,n,a,b));
                if(c=='U')
                    Add(a,b,1,1,n);
            }
        }
        return 0;
    }