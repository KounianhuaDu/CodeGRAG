// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 15;
char a[2][maxn][maxn];
bool used[2][maxn][maxn];
int n,m,t,ex,ey,ez;
int dx[]={0,0,-1,1};
int dy[]={1,-1,0,0};
bool flag;
void dfs(int x, int y, int z, int time){
      if (flag) return;
      if (a[z][x][y]=='P'){
         if (time<=t) flag=1;
         return;
      }
      if (time>=t) return; 
      for (int i=0;i<4;i++){
             int xx=x+dx[i];
             int yy=y+dy[i];
             if (xx<0 || xx>=n || yy<0 || yy>=m) continue; 
             if (used[z][xx][yy]) continue;  
             if  (a[z][xx][yy]=='*') continue; 
                 if  (a[z][xx][yy]=='#') {
                    if (a[1-z][xx][yy]=='*' || a[1-z][xx][yy]=='#') continue; 
                        used[z][xx][yy]=used[1-z][xx][yy]=1;
                        dfs(xx,yy,1-z,time+1);  
                        if (flag) return;
                        used[z][xx][yy]=used[1-z][xx][yy]=0;
                 }
                 else {
                    used[z][xx][yy]=1;
                    dfs(xx,yy,z,time+1);
                    used[z][xx][yy]=0;
                 }
                 if (flag) return;
      }
}
int main(){
    int c;
    std::ios::sync_with_stdio(false); 
    cin>>c;
    while (c--){
        cin>>n>>m>>t;
        for (int k=0;k<=1;k++)
            for (int i=0;i<n;i++)
                for (int j=0;j<m;j++)
                    cin>>a[k][i][j];
        flag=0;
        memset(used,0,sizeof(used)); 
        used[0][0][0]=1;
        dfs(0,0,0,0);
        if (flag) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}