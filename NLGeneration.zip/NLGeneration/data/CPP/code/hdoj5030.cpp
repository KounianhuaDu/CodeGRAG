// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int tree[50050],n;
int lowbit(int x)
{
    return x&(-x);
}
void update(int p,int x)
{
    while(p<=n)
    {
        tree[p]+=x;
        p+=lowbit(p);
    }
}
int sum(int p)
{
    int sum=0;
    while(p>0)
    {
        sum+=tree[p];
        p-=lowbit(p);
    }
    return sum;
}
int main()
{
    int t,cas=0;
    scanf("%d",&t);
    while(t--)
    {
        int i,j;
        memset(tree,0,sizeof(tree));
        scanf("%d",&n);
        for(i=1;i<=n;i++)
        {
            scanf("%d",&j);
            update(i,j);
        }
        printf("Case %d:\n",++cas);
        char a[10];
        while(scanf("%s",a)!=EOF)
        {
            if(a[0]=='E')
            {
                break;
            }
            if(a[0]=='A')
            {
                scanf("%d%d",&i,&j);
                update(i,j);
            }
            if(a[0]=='S')
            {
                scanf("%d%d",&i,&j);
                update(i,-j);
            }
            if(a[0]=='Q')
            {
                scanf("%d%d",&i,&j);
                printf("%d\n",sum(j)-sum(i-1));
            }
        }
    }
    return 0;
}