// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Strongly Connected Components,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define oo 1000000007
#define MAXN 8005
#define MAXM 20005
#define ll long long
using namespace std;  
struct node
{
       int x,y,next;
}line[MAXM<<1];
int n,last,Lnum,_next[MAXN<<1],num,way[MAXN<<1],color[MAXN<<1];
bool instack[MAXN<<1];
stack<int> mystack;
void addline(int x,int y)
{
       line[++Lnum].next=_next[x],_next[x]=Lnum,line[Lnum].x=x,line[Lnum].y=y;
}
bool dfs(int x)
{  
      if(color[x]==2) return false;  
      if(color[x]==1) return true;  
      color[x]=1,color[x^1]=2;  
      way[num++]=x;  
      for(int k=_next[x];k;k=line[k].next)
           if(!dfs(line[k].y)) return false;   
      return true;  
}  
  
bool find()
{  
      memset(color,0,sizeof(color));  
      for(int i=0;i<(n<<1);i++)
      {   
            if(color[i]) continue;  
            num=0;  
            if(!dfs(i))
            {
                   for(int j=0;j<num;j ++) color[way[j]]=color[way[j]^1]=0;    
                   if(!dfs(i^1))return false; 
            }
      }  
      return true;  
}  
int main()
{    
       int i,m;   
       while (~scanf("%d%d",&n,&m))
       {
              memset(_next,0,sizeof(_next));
              Lnum=0;
              while (m--)
              {
                     int x,y;
                     scanf("%d%d",&x,&y),x--,y--;
                     addline(x,y^1),addline(y,x^1);
              } 
              if (!find()) printf("NIE\n");
              else
              {     
                     for (i=0;i<(n<<1);i++)
                        if (color[i]==1) printf("%d\n",i+1);
              }
       }
       return 0;
}