// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
  
  
#define ll long long  
#define MAXN 100005  
using namespace std;  
int father[MAXN];  
ll d[MAXN];  
int getfather(int x)  
{  
        if (father[x]==x) return x;  
        int f=father[x];  
        father[x]=getfather(father[x]);  
        d[x]+=d[f];  
        return father[x];  
}  
int main()  
{  
        int n,m,i,x,y;  
        ll dis;    
        char c;   
        while (~scanf("%d%d",&n,&m) && n)  
        {    
                 for (i=1;i<=n;i++) father[i]=i,d[i]=0;  
                 while (m--)  
                 {  
                        do { c=getchar(); }while (c!='!' && c!='?');        
                        scanf("%d%d",&x,&y);  
                        if (c=='?')  
                        {  
                                if (getfather(x)!=getfather(y)) printf("UNKNOWN\n");  
                                                           else printf("%lld\n",d[y]-d[x]);   
                        }else  
                        {  
                                scanf("%lld",&dis);  
                                if (getfather(y)==getfather(x)) continue;  
                                d[father[y]]+=dis-d[y]; 
                                father[father[y]]=x;   
                        }  
                 }    
        }  
        return 0;  
}