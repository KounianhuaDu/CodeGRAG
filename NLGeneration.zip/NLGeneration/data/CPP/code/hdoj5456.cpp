// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define M 3000005  
int dp[M], s[M];
int main(){
    double q, temp;
    int n, m;
    while(scanf("%lf%d",&q, &n), n){
        memset(dp, 0 ,sizeof(dp));
        int tot = 0, i, j;
        for(i = 0; i < n; i ++){
             int flag; double sum, pa, pb, pc;
             scanf("%d", &m);
            pa = pb = pc = sum = 0;
            flag = 0;
            while(m --){
                char ch;
                
                scanf("%*c%c:%lf", &ch, &temp);
                switch(ch){
                    case 'A': pa+=temp;break;
                    case 'B': pb+=temp; break;
                    case 'C': pc+=temp;break;
                }
                if((ch!='A'&&ch!='B'&&ch!='C')||(pa>600||pb>600||pc>600)) flag = 1;
                sum += temp;
            }
            if(flag||sum>1000||sum>q) continue;
            else s[tot++] = (int)(sum*100);
        }
        memset(dp, 0, sizeof(dp));
        int Q = (int)(q*100);
       
        for(i = 0; i < tot; i ++){
            for(j = Q; j >= s[i]; j --){
                dp[j] = max(dp[j], dp[j-s[i]]+s[i]);
            }
        }
        printf("%.2lf\n", (dp[Q]+0.0)/100);
    }
    return 0;
}