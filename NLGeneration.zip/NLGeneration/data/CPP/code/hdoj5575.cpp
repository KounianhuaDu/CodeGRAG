// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
#define PI 3.14159265358979323
#define SCD(a) scanf("%d",&a)
#define SCDD(a,b) scanf("%d%d",&a,&b)
#define SCF(a) scanf("%lf",&a)
#define PTD(a) printf("%d\n",a)
#define PTS(a) printf("%s\n",a)
#define MST(a) memset(a, 0, sizeof(a))
using namespace std;
const int L = 101;
int n, m;
int maz[L][L], dis[L];
bool vis[L];
int ans;
void init()
{
    int i, j;
    ans = 0;
    for(i=1;i<=n;i++){
        vis[i] = false;
        for(j=1;j<=n;j++){
            maz[i][j] = inf;
        }
    }
}
void Prim()
{
    int i, j, pos, t;
    for(i=1;i<=n;i++)
        dis[i] = maz[1][i];
    vis[1] = true;
    dis[1] = 0;
    for(i=2;i<=n;i++){
        t = inf;
        for(j=2;j<=n;j++){
            if(!vis[j] && dis[j] < t){
                t = dis[j];
                pos = j;
            }
        }
        ans += t;
        vis[pos]  = true;
        for(j=2;j<=n;j++){
            if(!vis[j] && dis[j] > maz[pos][j]){
                dis[j] = maz[pos][j];
            }
        }
    }
}
int main()
{
    int i ,j ,a ,b ,t, com;
    while(SCD(n)!=EOF&&(n)){
        init();
        for(i=0;i<n*(n-1)/2;i++){
            SCDD(a, b);
            SCDD(t, com);
            if(com){
                maz[a][b] = maz[b][a] = 0;
            }else{
                maz[a][b] = maz[b][a] = t;
            }
        }
        Prim();
        PTD(ans);
    }
    return 0;
}