// Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main(void) {
	char *num=new char[1000000];
	int index = 0,carry=0,tempDig=0;
	int tempchangge;
	int N;
	while ((num[index] = getchar()) != '\n') {
		index++;
	}
	num[index] = '\0';
	while (num[0] != '0') {
		N = strlen(num) - 1;
		while (N != 0) {
			
			for (index = 1; index <= N; ++index) {
				carry = carry + num[index]-'0' + num[tempDig]-'0';
				num[tempDig] = carry % 10+'0';
				carry /= 10;
				if (carry) {
					tempchangge = carry;
					carry = num[tempDig]-'0';
					num[tempDig] = tempchangge+'0';
					tempDig++;
					num[tempDig] = carry+'0';
					carry = 0;
				}
				
			}
			N = tempDig;
			tempDig = 0;
		}
		cout << num[0] << endl;
		index = 0;
		while ((num[index] = getchar()) != '\n') {
			index++;
		}
		num[index] = '\0';
	}
	system("pause");
	return 0;
}