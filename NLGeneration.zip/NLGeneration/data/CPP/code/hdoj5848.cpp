// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 100000+10;
struct node {
    int left,right;
    int lazy,max1;
} e[N * 4];
void push_up(int p) {
    e[p].max1 = max(e[p*2].max1, e[p*2+1].max1);
}
void push_down(int p) {
    if (e[p].lazy != 0) {
        e[p*2].lazy += e[p].lazy;
        e[p*2].max1 += e[p].lazy;
        e[p*2+1].lazy += e[p].lazy;
        e[p*2+1].max1 += e[p].lazy;
        e[p].lazy = 0;
    }
}
void build(int p,int l,int r) {
    e[p].left = l;
    e[p].right = r;
    e[p].lazy = 0;
    if (l == r) {
        e[p].max1 = 0;
    }
    else {
        int mid = (l + r) / 2;
        build(p*2,l,mid);
        build(p*2+1,mid+1,r);
        push_up(p);
    }
}
void update(int p,int l,int r,int val) {
    if (l <= e[p].left && e[p].right <= r) {
        e[p].lazy += val;
        e[p].max1 += val;
    }
    else {
        push_down(p);
        int mid = (e[p].left+e[p].right) / 2;
        if (l <= mid) update(p*2,l,r,val);
        if (r > mid) update(p*2+1,l,r,val);
        push_up(p);
    }
}
int query(int p,int l,int r) {
    if (l <= e[p].left && e[p].right <= r) {
        return e[p].max1;
    }
    int mid = (e[p].left+e[p].right) / 2;
    push_down(p);
    int ans = 0;
    if (l <= mid) ans = max(ans, query(p*2,l,r));
    if (r > mid) ans = max(ans, query(p*2+1,l,r));
    return ans;
}
int n;
int main() {
    while (scanf("%d", &n) != EOF && n) {
        int a,b;
        build(1,1,n);
        for (int i = 1;i <= n;++i) {
            scanf("%d%d", &a, &b);
            update(1,a,b,1);
        }
        for (int i = 1;i <= n;++i) {
            int ans = query(1,i,i);
            if (i > 1)
                printf(" ");
            printf("%d", ans);
        }
        printf("\n");
    } 
    return 0;
}