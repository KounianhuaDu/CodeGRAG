// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
int n;
ll dp[41][41];
int DP() {  
    for(int i = 0; i <= 40; i++)
        dp[i][0] = 1;
    for(int i = 1; i <= 40; i++)
        for(int j = 1; j <= i; j++) {
            
            dp[i][j] = dp[i - 1][j] + dp[i][j - 1];
        }
}
int main() {
    int t = 0;
    DP();
    
    while(scanf("%d", &n) != EOF) {
        if(n == -1)
            break;
        t++;
        printf("%d %d %lld", t, n, 2 * dp[n][n]);
        cout << endl;
    }
    return 0;
}