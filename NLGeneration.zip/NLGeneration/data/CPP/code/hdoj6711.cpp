// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define LL __int64_t
#define eps 1e-8
const ll INF = 9999999999999;
using namespace std;
#define M 400000100
#define inf 0xfffffff
vector<int>G[1212];
int mp[1212][1212];
int marry[1212];
bool vis[1212];
int vmax, vmin, l, r, mid;
int dis[2][4] = {0, -1, 0, 1, 1, 0, -1, 0};
int n, m, k;
void clear() {
    memset(marry, -1, sizeof(marry));
    memset(vis, false, sizeof(vis));
    memset(mp, 0, sizeof(mp));
    for(int i = 0; i < 1212; i++)
        G[i].clear();
}
bool dfs(int x) {
    for(int i = 0; i < m; i++) {
        if(mp[x][i] && !vis[i]) {
            vis[i] = true;
            if(marry[i] == -1 || dfs(marry[i])) {
                marry[i] = x;
                return 1;
            }
        }
    }
    return 0;
}
int main(void) {
    while(scanf("%d", &n), n) {
        clear();
        scanf("%d", &m);
        for(int i = 0; i < n; i++)
            for(int j = 0; j < m; j++)
                cin >> mp[i][j];
        int ans = 0;
        for(int i = 0; i < n; i++) { 
            memset(vis, false, sizeof(vis));
            if(dfs(i))
                ans++;
        }
        cout << ans << endl;
    }
}