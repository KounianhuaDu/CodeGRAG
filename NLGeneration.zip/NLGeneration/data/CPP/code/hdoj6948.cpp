// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int digit[200],dp[200][30000],Sum;
int dfs(int pos,int sum,bool limit){
    if(pos == -1) return sum >= 0?1:0;
    if(sum < 0) return 0;
    if(!limit&&dp[pos][sum] != -1) return dp[pos][sum];
    int up = limit?digit[pos]:9;
    int ans = 0;
    for(int i = 0;i <= up;i++){
        ans += dfs(pos-1,sum-(i*1<<pos),limit&&i == digit[pos]);
    }
    if(!limit) dp[pos][sum] = ans;
    return ans;
}
int solve(int x){
    int pos = 0;
    while(x){
        digit[pos++] = x%10;
        x/=10;
    }
    return dfs(pos-1,Sum,true);
}
int Fun(int x){
    int sum = 0,len = 0;
    while(x){
        sum += (x%10)*(1<<len);
        x /= 10;
        len++;
    }
    return sum;
}
int main(){
    int t,A,B;
    memset(dp,-1,sizeof(dp));
    scanf("%d",&t);
    int Case = 1;
    while(t--){
        scanf("%d%d",&A,&B);
        Sum = Fun(A);
        printf("Case #%d: %d\n",Case++,solve(B));
    }
    return 0;
}