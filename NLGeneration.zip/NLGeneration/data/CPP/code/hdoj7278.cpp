// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int k,n,m,sx,sy,sz,ex,ey,ez;
char mp[35][35][35];
int dir[6][3] = {{1,0,0},{-1,0,0},{0,-1,0},{0,1,0},{0,0,1},{0,0,-1}};
bool vis[35][35][35];
struct node{
    int x,y,z,step;
};
bool check(int x,int y,int z){
    if(x < 0||y < 0||z < 0||x >= k||y >= n||z >= m||vis[x][y][z]||mp[x][y][z] == '#') return true;
    return false;
}
int bfs(){
    node a,next;
    queue<node>Q;
    a.x = sx,a.y = sy,a.z = sz,a.step = 0;
    vis[sx][sy][sz] = true;
    Q.push(a);
    while(!Q.empty()){
        a = Q.front();
        Q.pop();
        if(a.x == ex&&a.y == ey&&a.z == ez) return a.step;
        for(int i = 0;i < 6;i++){
            next = a;
            next.x = a.x+dir[i][0];
            next.y = a.y+dir[i][1];
            next.z = a.z+dir[i][2];
            if(check(next.x,next.y,next.z))
                continue;
            vis[next.x][next.y][next.z] = true;
            next.step = a.step + 1;
            Q.push(next);
        }
    }
    return 0;
}
int main(){
    while(~scanf("%d%d%d",&k,&n,&m),n+m+k){
        for(int i = 0;i < k;i++){
            for(int j = 0;j < n;j++){
                scanf("%s",mp[i][j]);
                for(int r = 0;r < m;r++){
                    if(mp[i][j][r] == 'S')
                        sx = i,sy = j,sz = r;
                    if(mp[i][j][r] == 'E')
                        ex = i,ey = j,ez = r;
                }
            }
        }
        memset(vis,false,sizeof(vis));
        int ans = bfs();
        if(ans != 0) printf("Escaped in %d minute(s).\n",ans);
        else printf("Trapped!\n");
    }
    return 0;
}