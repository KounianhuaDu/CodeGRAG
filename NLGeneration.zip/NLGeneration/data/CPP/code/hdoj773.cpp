// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define CLR(a, b) memset(a, (b), sizeof(a))
using namespace std;
typedef long long LL;
const int MAXN = 1e4 +10;
const int INF = 0x3f3f3f3f;
int T[15], N[15];
int dp[1<<15], last[1<<15];
char str[15][20];
int ans[1<<15];
void Solve(int s) {
    if(s == 0) return ;
    Solve(s ^ (1<<ans[s]));
    printf("%s\n", str[ans[s]]);
}
int main()
{
    int t; scanf("%d", &t);
    while(t--) {
        int n; scanf("%d", &n);
        for(int i = 0; i < n; i++) {
            scanf("%s%d%d", str[i], &T[i], &N[i]);
        }
        for(int i = 0; i < (1<<n); i++) {
            last[i] = 0;
            for(int j = 0; j < n; j++) {
                if(i & (1<<j)) {
                    last[i] += N[j];
                }
            }
        }
        dp[0] = 0;
        for(int i = 1; i < (1<<n); i++) {
            dp[i] = INF;
            for(int j = 0; j < n; j++) {
                if(i & (1<<j)) {
                    if(dp[i^(1<<j)] + max(0, last[i^(1<<j)] + N[j] - T[j]) < dp[i]) {
                        dp[i] = dp[i^(1<<j)] + max(0, last[i^(1<<j)] + N[j] - T[j]);
                        ans[i] = j;
                    }
                    else if(dp[i^(1<<j)] + max(0, last[i^(1<<j)] + N[j] - T[j]) == dp[i] && strcmp(str[ans[i]], str[j]) < 0) {
                        ans[i] = j;
                    }
                }
            }
        }
        printf("%d\n", dp[(1<<n)-1]);
        Solve((1<<n)-1);
    }
    return 0;
}