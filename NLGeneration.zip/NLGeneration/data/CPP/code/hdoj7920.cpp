// Data Structure->Stack
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define CLR(a, b) memset(a, (b), sizeof(a))
#define fi first
#define se second
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
const int MAXN = 1e4 +10;
const int INF = 0x3f3f3f3f;
char str[1010];
pii Stack[1010];
int da[1010], db[1010], dc[1010];
LL dp[1010];
int n, m;
int Solve(int d[]) {
    int ans = 0, top = 0;
    int l, r;
    for(int j = 1; j <= m; j++) {
        r = 0;
        while(top && Stack[top-1].fi >= d[j]) {
            if(r == 0) r = Stack[top-1].se;
            if(top == 1) {
                l = Stack[top-1].se;
            }
            else {
                l = Stack[top-1].se - Stack[top-2].se;
            }
            ans = max(ans, (r - Stack[top-1].se + l) * Stack[top-1].fi); top--;
        }
        Stack[top++] = pii(d[j], j);
    }
    r = 0;
    while(top) {
        if(r == 0) r = Stack[top-1].se;
        if(top == 1) {
            l = Stack[top-1].se;
        }
        else {
            l = Stack[top-1].se - Stack[top-2].se;
        }
        ans = max(ans, (r - Stack[top-1].se + l) * Stack[top-1].fi); top--;
    }
    return ans;
}
int main()
{
    while(scanf("%d%d", &n, &m) != EOF) {
        for(int j = 1; j <= m; j++) da[j] = db[j] = dc[j] = 0;
        int ans = 0;
        for(int i = 1; i <= n; i++) {
            scanf("%s", str+1);
            for(int j = 1; j <= m; j++) {
                if(str[j] == 'a') {
                    da[j]++; db[j] = dc[j] = 0;
                }
                else if(str[j] == 'b') {
                    db[j]++; da[j] = dc[j] = 0;
                }
                else if(str[j] == 'c') {
                    dc[j]++; da[j] = db[j] = 0;
                }
                else if(str[j] == 'w') {
                    da[j]++; db[j]++; dc[j] = 0;
                }
                else if(str[j] == 'x') {
                    db[j]++; dc[j]++; da[j] = 0;
                }
                else if(str[j] == 'y') {
                    da[j]++; dc[j]++; db[j] = 0;
                }
                else {
                    da[j]++; db[j]++; dc[j]++;
                }
            }
            ans = max(ans, Solve(da));
            ans = max(ans, Solve(db));
            ans = max(ans, Solve(dc));
        }
        printf("%d\n", ans);
    }
    return 0;
}