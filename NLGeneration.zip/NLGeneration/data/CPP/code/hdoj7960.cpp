// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define sca(x) scanf("%d",&x)
#define per(i,j,k) for(int i=j;i>=k;i--)
#define inf 0x3f3f3f3f
#define LL long long
#define N 1000005
#define inf 0x3f3f3f3f
const LL mod = 998244353;
set<int>ss;
int f[N],a[N];
int F(int x)
{
    return f[x]==x?x:f[x]=F(f[x]);
}
void U(int x,int y)
{
    int f1=F(x);
    int f2=F(y);
    if(f1!=f2)
        f[f1]=f2;
}
int main()
{
    int n,m;
    int cas=1;
    while(~scanf("%d%d",&n,&m))
    {
        if(n==0&&m==0)break;
        rep(i,0,1000000)f[i]=i;
        rep(i,0,100000)a[i]=i;
        char s[3];
        int x,y;
        int now=n+1;
        rep(i,1,m)
        {
            scanf("%s",s);
            if(s[0]=='M')
            {
                scanf("%d%d",&x,&y);
                U(a[x],a[y]);
            }
            else
            {
                scanf("%d",&x);
                a[x]=now++;
            }
        }
        rep(i,0,n-1)
        {
            ss.insert(F(a[i]));
        }
        printf("Case #%d: %d\n",cas++,ss.size());
        ss.clear();
    }
}