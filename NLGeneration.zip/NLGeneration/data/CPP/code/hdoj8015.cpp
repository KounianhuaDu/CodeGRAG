// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
struct tree{
    int v , next ;
}edge[110];
int head[110] , cnt ;
int dp1[110][210] , dp2[110][210] ;
int c[110] , n , m ;
void add(int u,int v) {
    edge[cnt].v = v ;
    edge[cnt].next = head[u] ;
    head[u] = cnt++ ;
    return ;
}
void dfs(int u) {
    int i , j , k , v ;
    dp1[u][0] = dp2[u][0] = c[u] ;
    if( head[u] == -1 )
        return ;
    for(i = head[u] ; i != -1 ; i = edge[i].next) {
        v = edge[i].v ;
        dfs(v) ;
    }
    for(i = head[u] ; i != -1 ; i = edge[i].next) {
        v = edge[i].v ;
        for(j = m ; j >= 0 ; j--) {
            for(k = 0 ; k <= j ; k++) {
                if( k+2 <= j ) {
                    dp1[u][j] = max(dp1[u][j],dp1[u][j-k-2]+dp1[v][k]) ;
                    dp2[u][j] = max(dp2[u][j],dp2[u][j-k-2]+dp1[v][k]) ;
                }
                if( k+1 <= j )
                dp2[u][j] = max(dp2[u][j],dp1[u][j-k-1]+dp2[v][k]) ;
            }
        }
    }
}
int Map[110][110] ;
queue <int> que ;
void bfs(int n) {
    while( !que.empty() ) que.pop() ;
    que.push(1) ;
    int i , u , v ;
    while( !que.empty() ) {
        u = que.front() ;
        que.pop() ;
        for(i = 1 ; i <= n ; i++){
            if( Map[u][i] == 1 ) {
                Map[u][i] = Map[i][u] = 0 ;
                add(u,i) ;
                que.push(i) ;
            }
        }
    }
}
int main() {
    int i , j , u , v ;
    while( scanf("%d %d", &n, &m) != EOF ) {
        memset(head,-1,sizeof(head)) ;
        memset(dp1,0,sizeof(dp1)) ;
        memset(dp2,0,sizeof(dp2)) ;
        memset(Map,0,sizeof(Map)) ;
        cnt = 0 ;
        for(i = 1 ; i <= n ; i++)
            scanf("%d", &c[i]) ;
        for(i = 1 ; i < n ; i++) {
            scanf("%d %d", &u, &v) ;
            Map[u][v] = Map[v][u] = 1 ;
        }
        bfs(n) ;
        dfs(1) ;
        int max1 = 0 ;
        for(i = 0 ; i <= m ; i++) {
            max1 = max(max1,dp2[1][i]) ;
        }
        printf("%d\n", max1) ;
    }
    return 0 ;
}