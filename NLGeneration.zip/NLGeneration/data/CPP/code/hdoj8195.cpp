// Data Structure->Stack,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int sign[100];
char s1[100],s2[100],in[100];
int main()
{
	int n,j,i,k,ans;
	while(scanf("%d",&n)!=EOF)
	{
		scanf("%s",s1);
		scanf("%s",s2);
		memset(sign,0,sizeof(sign));
		i=k=ans=-1;
		j=0;
		in[++i]=s1[++ans];
		sign[++k]=1;
		while(i<n&&j<n)
		{
			while(i>=0&&in[i]==s2[j])
			{
				sign[++k]=0;
				--i;
				++j;
			}
			sign[++k]=1;
			in[++i]=s1[++ans];
		}
		if(ans==n&&j==n)
		{
			printf("Yes.\n");
			for(i=0;i<k;i++)
			{
				if(sign[i])
				   printf("in\n");
				else
				   printf("out\n");
			}
			printf("FINISH\n");
		}
		else
		    printf("No.\nFINISH\n");
	}
	return 0;
}