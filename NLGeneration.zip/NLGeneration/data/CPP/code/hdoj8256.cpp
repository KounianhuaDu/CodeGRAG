// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 110
using namespace std;
char maptt1[N][N];
char vis[N][N];
int h,w;
int l,r,row;
int cnt=0;
int ans;
struct body{
	int x[30],y[30];
	int step;
}start;
bool jug(body &a)
{
	int i;
	for(i=0;i<cnt;i++)
	{
		if(maptt1[a.x[i]][a.y[i]]=='Q')
		return 1;
	}
	return 0;
}
bool check(body &a)
{
	for(int i=0;i<cnt;i++)
	{
		if(a.x[i]<0||a.y[i]<0||a.x[i]>=h||a.y[i]>=w)
		return 1;
		if(maptt1[a.x[i]][a.y[i]]=='O')
		return 1;
	}
	if(vis[a.x[0]][a.y[0]])
		return 1;
	return 0;
}
void bfs()
{
	memset(vis,0,sizeof(vis));
	queue<body>q;
	body now,next;
	now=start;
	next=now;
	q.push(now);
	int i,j;
	vis[now.x[0]][now.y[0]]=1;
	while(!q.empty())
	{
		now=q.front();
		q.pop();
		if(jug(now))
		{
			ans=now.step;
			return;
		}
		for(i=0;i<4;i++)
		{
			if(i==0)
			{
				for(j=0;j<cnt;j++)
				{
					next.x[j]=now.x[j]+1;
					next.y[j]=now.y[j];
				}
			}
			if(i==1)
			{
				for(j=0;j<cnt;j++)
				{
					next.x[j]=now.x[j]-1;
					next.y[j]=now.y[j];
				}
			}
			if(i==2)
			{
					for(j=0;j<cnt;j++)
				{
					next.x[j]=now.x[j];
					next.y[j]=now.y[j]-1;
				}
			}
			if(i==3)
			{
				for(j=0;j<cnt;j++)
				{
					next.x[j]=now.x[j];
					next.y[j]=now.y[j]+1;
				}
			}
			if(!check(next))
			{
				vis[next.x[0]][next.y[0]]=1;
				next.step=now.step+1;
				q.push(next);
			}	
		}
	}
}
int main()
{
	while(cin>>h>>w&&h&&w)
	{
		int i,j;
		cnt=0;
		for(i=0;i<h;i++)
		{
			scanf("%s",maptt1[i]);
			for(j=0;j<w;j++)
			if(maptt1[i][j]=='D')
			{
				start.x[cnt]=i;
				start.y[cnt++]=j;
			}
		}
		start.step=0;
		ans=0;
		bfs();
		if(ans)cout<<ans<<endl;
		else cout<<"Impossible"<<endl;
	}
	return 0;
}