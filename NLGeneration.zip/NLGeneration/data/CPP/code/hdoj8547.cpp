// Math and Computational Geometry->Greatest Common Divisor (GCD),Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=10000005;
int a[maxn];
int euler(int n)
{
    int m=(int)sqrt(n+0.5);
    int ans=n;
    for(int i=2;i<=m;i++)
        if(n%i==0)
    {
        ans=ans/i*(i-1);
        while(n%i==0) n/=i;
    }
    if(n>1) ans=ans/n*(n-1);
    return ans;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        int n,m;
        scanf("%d%d",&n,&m);
        int t=0;
        for(int i=1;i*i<=n;i++)
        {
            if(n%i==0)
            {
                if(i>=m) a[t++]=n/i;
                if(n/i>=m&&(n/i)!=i) a[t++]=i;
            }
        }
        int sum=0;
        for(int i=0;i<t;i++) sum+=euler(a[i]);
        printf("%d\n",sum);
    }
    return 0;
}