// Basic Algorithm->Recursion,Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int x,y;
    int ans;
    bool operator <(const node t)const
    {
        return ans > t.ans;
    }
};
const int maxn = 205;
char grid[maxn][maxn];
int n,m,ax,ay,rx,ry;
int dx[4]= {-1,0,0,1},dy[4]= {0,1,-1,0};
int vis[300][300];
void bfs(int x, int y)
{
    memset(vis,0,sizeof(vis));
    priority_queue<node>q;
    node f1, f2;
    f1.x=x;
    f1.y=y;
    f1.ans=0;
    q.push(f1);
    vis[x][y]=1;
    while(!q.empty())
    {
        f1=q.top();
        q.pop();
        if(grid[f1.x][f1.y]=='r')
        {
            printf("%d\n",f1.ans);
            return ;
        }
        for(int i=0; i<4; i++)
        {
            f2.x=f1.x+dx[i];
            f2.y=f1.y+dy[i];
            if(f2.x>=0&&f2.x<n&&f2.y>=0&&f2.y<m&&!vis[f2.x][f2.y]&&grid[f2.x][f2.y]!='#')
            {
                vis[f2.x][f2.y]=1;
                if(grid[f2.x][f2.y]=='x')
                {
                    f2.ans=f1.ans+2;
                }
                else
                {
                    f2.ans=f1.ans+1;
                }
                q.push(f2);
            }
        }
    }
    printf("Poor ANGEL has to stay in the prison all his life.\n");
}
int main()
{
    
    while(~scanf("%d%d",&n,&m))
    {
        int i,j;
        for(i=0; i<n; i++)
        {
            getchar();
            for(j=0; j<m; j++)
            {
                scanf("%c",&grid[i][j]);
                if(grid[i][j]=='a')
                {
                    ax=i;
                    ay=j;
                }
                if(grid[i][j]=='r')
                {
                    rx=i;
                    ry=j;
                }
            }
        }
        bfs(ax,ay);
    }
    return 0;
}