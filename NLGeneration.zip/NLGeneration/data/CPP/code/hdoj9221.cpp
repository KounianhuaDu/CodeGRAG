// Dynamic Programming->Bitmask Dynamic Programming (DP),Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 105
#define INF 0x3f3f3f3f
#define MOD 20090717
#define LL long long
using namespace std;
int have[1<<10];
int n, m, k;
void gethave()
{
    for(int i = 0; i < (1<<10); i++)
    {
        have[i] = 0;
        for(int j = 0; j < 10; j++)
        {
            if(i & (1<<j))
                have[i]++;
        }
    }
}
struct Trie
{
    int next[MAXN][30], fail[MAXN], State[MAXN];
    int L, root;
    int newnode()
    {
        for(int i = 0; i < 26; i++)
            next[L][i] = -1;
        State[L++] = 0;
        return L-1;
    }
    void init()
    {
        L = 0;
        root = newnode();
    }
    void Insert(char *s, int id)
    {
        int len = strlen(s);
        int now = root;
        for(int i = 0; i < len; i++)
        {
            if(next[now][s[i]-'a'] == -1)
                next[now][s[i]-'a'] = newnode();
            now = next[now][s[i]-'a'];
        }
        State[now] |= (1<<id);
    }
    void Build()
    {
        queue<int> Q;
        fail[root] = root;
        for(int i = 0; i < 26; i++)
        {
            if(next[root][i] == -1)
                next[root][i] = root;
            else
            {
                fail[next[root][i]] = root;
                Q.push(next[root][i]);
            }
        }
        while(!Q.empty())
        {
            int now = Q.front();
            Q.pop();
            State[now] |= State[fail[now]];
            for(int i = 0; i < 26; i++)
            {
                if(next[now][i] == -1)
                    next[now][i] = next[fail[now]][i];
                else
                {
                    fail[next[now][i]] = next[fail[now]][i];
                    Q.push(next[now][i]);
                }
            }
        }
    }
    
    LL dp[30][MAXN][1<<10];
    void solve()
    {
        memset(dp, 0, sizeof(dp));
        dp[0][0][0] = 1;
        for(int i = 0; i < n; i++)
        {
            for(int S = 0; S < L; S++)
            {
                for(int j = 0; j < (1<<m); j++)
                {
                    if(dp[i][S][j] > 0)
                    {
                        for(int l = 0; l < 26; l++)
                        {
                            int nextnode = next[S][l];
                            int nextState = j | State[nextnode];
                            dp[i+1][nextnode][nextState] += dp[i][S][j], 
                            dp[i+1][nextnode][nextState] %= MOD;
                        }
                    }
                }
            }
        }
        LL ans = 0; 
        for(int i = 0; i < (1<<m); i++)
        {
            if(have[i] < k) continue;
            for(int j = 0; j < L; j++)
                ans = (ans + dp[n][j][i]) % MOD;
        }
        printf("%lld\n", ans);
    }
};
Trie ac;
char str[15];
int main()
{
    gethave();
    while(scanf("%d%d%d", &n, &m, &k), n||m||k)
    {
        ac.init();
        for(int i = 0; i < m; i++)
            scanf("%s", str), ac.Insert(str, i);
        ac.Build(); ac.solve();
    }
    return 0;
}