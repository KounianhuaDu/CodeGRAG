// Basic Algorithm->Divide and Conquer,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

 using namespace std;
 int n;
 struct node
 {
     double x;
     double y;
 };
int cmp(node a,node b)
{
     if (a.x==b.x)
     return a.y<b.y;
     return a.x<b.x;
}
node point[10005];
int cmp2(int a,int  b)
 {
     return point[a].y<point[b].y;
 }
 double distance(double c1,double c2,double d1,double d2)
 {
    return sqrt((c1-d1)*(c1-d1)+(c2-d2)*(c2-d2));
 }
 double calculate(int left,int right)
 {
     int i,j,mid,tempnumber;
     double d,d1,d2;
     int temp[10005];
     if (left==right)
        return 999999;
     if (left+1==right)
        return  distance(point[left].x,point[left].y,point[right].x,point[right].y);
     mid=(left+right)>>1;
     d1=calculate(left,mid);
     d2=calculate(mid+1,right);
     d=d1<d2?d1:d2;
     i=mid;
     tempnumber=0;
     while(i>=0&&point[mid].x-point[i].x<d)
     {
        temp[tempnumber++]=i;
        i--;
     }
     i=mid+1;
     while(i<n&&point[i].x-point[mid].x<d)
     {
         temp[tempnumber++]=i;
         i++;
     }
     sort(temp,temp+tempnumber,cmp2);
     for (i=0;i<tempnumber;i++)
        for (j=i+1;j<tempnumber;j++)
     {
         if (point[temp[j]].y-point[temp[i]].y>d)
            break;
         else
         {
           d1=distance(point[temp[i]].x,point[temp[i]].y,point[temp[j]].x,point[temp[j]].y);
           d=d<d1?d:d1;  
         }
     }
     return d;
 }
int main()
{
     int i,j;
     scanf("%d",&n);
     for (i=0;i<n;i++)
     scanf("%lf%lf",&point[i].x,&point[i].y);
     sort(point,point+n,cmp);
     printf("%.4f\n",calculate(0,n-1));
     return 0;
}