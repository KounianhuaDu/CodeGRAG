// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int MOD = 200907;
struct Mat {
    long long g[3][3];
}ori, res;
long long n;
Mat multiply(Mat x, Mat y) {
    Mat temp;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            temp.g[i][j] = 0;
            for (int k = 0; k < 3; k++)
                temp.g[i][j] = (temp.g[i][j] + x.g[i][k] * y.g[k][j]) % MOD;
        }
    return temp;
}
void calc(long long n) {
    while (n) {
        if (n & 1)
            ori = multiply(ori, res);
        n >>= 1;
        res = multiply(res, res);
    }
}
int main() {
    while (scanf("%lld", &n) == 1 && n) {
        if (n == 1 || n == 2) {
            printf("%lld\n", n);
            continue;
        }
        memset(ori.g, 0, sizeof(ori.g));
        memset(res.g, 0, sizeof(res.g));
        ori.g[0][0] = 2;
        ori.g[0][1] = ori.g[0][2] = 1;
        res.g[0][0] = res.g[0][1] = res.g[2][0] = res.g[2][2] = 1;
        res.g[1][0] = 2;
        calc(n - 2);
        printf("%lld\n", ori.g[0][0]);
    }
    return 0;
}