// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int s[205],vis[205];
int n,a,b;
int flag=0,minx=0xffffff;
struct node
{
	int x,t;
};
void bfs(int x,int t)        
{
	node a;
	queue<node> q;
	a.x=x;
	a.t=t;
	q.push(a);
	while(!q.empty())
	{
		a=q.front();
		q.pop();
		x=a.x;
		t=a.t;
		vis[x]=0;
		if(x==b)
		{
			flag=1;
			minx=min(t,minx);
			break;
		}
		if(t>n-1)
		{
			flag=0;
			break;
		}
		if(x+s[x]<=n&&vis[x+s[x]]==0)
		{
			vis[x+s[x]]=1;
			a.t=t+1;        
			a.x=x+s[x];
			q.push(a);
		}
		if(x-s[x]>=1&&vis[x-s[x]]==0)
		{
			vis[x-s[x]]=1;
			a.t=t+1;
			a.x=x-s[x];
			q.push(a);
		}
	}
}
int main()
{
    
	while(~scanf("%d",&n)&&n)
	{
		
		scanf("%d %d",&a,&b);
		memset(vis,0,sizeof(vis));
		minx=0xffffff;
		flag=0;
		for(int i=1;i<=n;i++)
		scanf("%d",&s[i]);
		if(a<=0||a>n||b<=0||b>n)
		{
			printf("-1\n");
			continue;
		}
		vis[a]=1;
		bfs(a,0);
		if(flag==0) printf("-1\n");
		else printf("%d\n",minx);
	}
	return 0;
 }