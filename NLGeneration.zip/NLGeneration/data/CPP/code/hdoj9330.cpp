// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 2;
int n , MOD;
struct Matrix{
    int mat[N][N];
    Matrix operator*(const Matrix &m)const{
        Matrix tmp;
        for(int i = 0 ; i < N ; i++){
            for(int j = 0 ; j < N ; j++){
                tmp.mat[i][j] = 0;
                for(int k = 0 ; k < N ; k++)
                    tmp.mat[i][j] += mat[i][k]*m.mat[k][j]%MOD;
                tmp.mat[i][j] %= MOD;
            }
        }
        return tmp;
    }
};
int Pow(Matrix m){
    if(n <= 1) return n%MOD;
    Matrix ans;
    ans.mat[0][0] = ans.mat[1][1] = 1;
    ans.mat[0][1] = ans.mat[1][0] = 0;
    n--;
    while(n){
        if(n&1)
            ans = ans*m;
        n >>= 1;
        m = m*m;
    }
    return (ans.mat[0][0]%MOD+MOD)%MOD;    
}
int main(){
    Matrix m; 
    m.mat[0][0] = 3 ; m.mat[0][1] = -1;
    m.mat[1][0] = 1 ; m.mat[1][1] = 0;
    int cas;
    scanf("%d" , &cas);
    while(cas--){
         scanf("%d%d" , &n , &MOD);
         printf("%d\n" , Pow(m)); 
    }
    return 0;
}