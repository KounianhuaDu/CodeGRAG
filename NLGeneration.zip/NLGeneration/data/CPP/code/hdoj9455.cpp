// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef struct Edge
{
    int v,next;
}Edge;
Edge eg[6000001];
int head[61],tp;
int link[100001];
bool vis[100001];
bool vil[61];
bool can(int u)
{
    int v,i;
    for(i = head[u]; i != -1; i = eg[i].next)
    {
        v = eg[i].v;
        if(vis[v]) continue;
        vis[v] = 1;
        if(link[v] == -1 || can(link[v]))
        {
            link[v] = u;
            return true;
        }
    }
    return false;
}
int main()
{
    int t,n,i,l,r,j,cnt,f;
    scanf("%d",&t);
    while(t--)
    {
        tp = 0;
        memset(head,-1,sizeof(head));
        scanf("%d",&n);
        for(i = 1; i <= n; ++i)
        {
            scanf("%d %d",&l,&r);
            for(j = l; j <= r; ++j)
            {
                eg[tp].v = j;
                eg[tp].next = head[i];
                head[i] = tp++;
            }
        }
        memset(link,-1,sizeof(link));
        memset(vil,0,sizeof(vil));
        cnt = 0;
        for(i = n; i >= 1; --i)
        {
            memset(vis,0,sizeof(vis));
            if(can(i))
            {
                cnt++;
                vil[i] = 1;
            }
        }
        printf("%d\n",cnt);
        f = 0;
        for(i = 1; i <= n; ++i)
        {
            if(vil[i])
            {
                if(f) printf(" ");
                else f = 1;
                printf("%d",i);
            }
        }
        puts("");
    }
    return 0;
}