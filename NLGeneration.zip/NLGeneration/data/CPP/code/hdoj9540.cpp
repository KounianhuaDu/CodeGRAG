// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const long long maxn=1e7;
int possible[maxn];
set<pair<int,int>> save;
int main(){
    int t,n,m;
    scanf("%d",&t);
    while(t--){
        memset(possible, 0, sizeof(possible));
        save.clear();
        pair<int,int> k;
        scanf("%d%d",&n,&m);
        while(n--){
            int a,b;
            scanf("%d%d",&a,&b);
            k = make_pair(a, b);
            save.insert(k);
        }
        
        int god=0;
        for(set<pair<int,int>>::iterator i=save.begin();i!=save.end();i++){
            for(set<pair<int,int>>::iterator j=i;j!=save.end();j++){
                if(j==i){
                    continue;
                }
                unsigned dis=abs(i->first-j->first)+abs(i->second-j->second);
                if(possible[dis]==0){
                    possible[dis]=1;
                }else{
                    god=1;
                    goto here;
                }
            }
        }
    here:
        if(god){
            cout<<"YES"<<endl;
        }else{
            cout<<"NO"<<endl;
        }
    }
    return 0;
}