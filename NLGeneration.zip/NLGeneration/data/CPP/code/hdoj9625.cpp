// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define mem(a, b) memset(a, (b), sizeof(a))
#define Wi(a) while(a--)
#define Si(a) scanf("%d", &a)
#define Pi(a) printf("%d\n", (a))
#define INF 0x3f3f3f3f
using namespace std;
const int N = 500;
int maptt1[N][N], path[N][N], b[N];
int n;
void input()
{
	int i, j, k;
	for(i = 1; i <= n; i++)
	{
		for(j = 1; j <= n; j++)
		{
			Si(maptt1[i][j]);
			if(maptt1[i][j] == -1)  maptt1[i][j] = INF;
			path[i][j] = j;
		}
	}
	for(i = 1; i <= n; i++)  Si(b[i]);
}
void floyd()
{
	int i, j, k;
	for(k = 1; k <= n; k++)
	{
		for(i = 1; i <= n; i++)
		{
			for(j = 1; j <= n; j++)
			{
				if(maptt1[i][j] > maptt1[i][k] + maptt1[k][j] + b[k])
				{
					maptt1[i][j] = maptt1[i][k] + maptt1[k][j] + b[k];
					path[i][j] = path[i][k];
				}
				else if(maptt1[i][j] == maptt1[i][k] + maptt1[k][j] + b[k])
				{
					if(path[i][j] > path[i][k])
					{
						path[i][j] = path[i][k];
						maptt1[i][j] = maptt1[i][k] + maptt1[k][j] + b[k];
					}
				}
			}
		}
	}
}
void put_path(int u, int v)
{
	int now;
	if(u == v)
	{
		Pi(v);  return ;
	}
	now = path[u][v];
	printf("%d-->", u);
	put_path(now, v);
}
int main()
{
	while(Si(n)==1 && n)
	{
		input();
		floyd();
		int s, t;
		while(scanf("%d%d", &s, &t)==2)
		{
			if(s==-1 && t==-1)   break;
			printf("From %d to %d :\n", s, t);
			if(s == t)
			{
				printf("Path: %d\n", t);
				printf("Total cost : %d\n\n", maptt1[s][t]);
				continue;
			}
			printf("Path: ");
			put_path(s, t);
			printf("Total cost : %d\n\n", maptt1[s][t]);
		}
	}
	return 0;
}