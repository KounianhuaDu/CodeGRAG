// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Prim's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int re[25], n;     
bool vis[25], isp[25];      
void isprime() {    
    isp[0] = isp[1] = false;
    for (int i = 2; i < sqrt((double)25); ++i) {
        if (isp[i]) {
            for (int j = i; i * j < 25; ++j) {
                if (isp[i * j]) {
                    isp[i * j] = false;
                }
            }
        }
    }
}
void dfs(int cur) {                     
    int i;
    if (cur == n && isp[re[0] + re[n - 1]]) { 
        for (i = 0; i < n - 1; ++i) {   
            printf("%d ", re[i]);
        }
        printf("%d/n", re[i]);
    } else {
        for (int i = 2; i <= n; ++i) {
            if (!vis[i] && isp[i + re[cur - 1]]) { 
                re[cur] = i;
                vis[i] = true;    
                dfs(cur + 1);
                vis[i] = 0;       
            }
        }
    }
}
int main() {
    int icase = 1;
    memset(isp, true, sizeof(isp));
    memset(vis, false, sizeof(vis));
    re[0] = 1;
    isprime();
    while (scanf("%d", &n) != EOF) {
        printf("Case %d:/n", icase++);
        dfs(1);     
        printf("/n");
    }
    return 0;
}