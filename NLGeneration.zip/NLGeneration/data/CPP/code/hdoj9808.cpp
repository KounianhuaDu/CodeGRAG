// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define  INF  0x3f3f3f
using namespace std;
int maptt1[10001][10001];
int dist[10001];
int vis[10001];
int T,S,D,city;
int qi[10001];
int mo[10001];
void dijkstra()
{
	int next;
	for(int i=0;i<=1010;i++)
	{
		  dist[i]=maptt1[0][i];
	 }
	memset(vis,0,sizeof(vis));
	vis[0]=1;
	for(int i=0;i<=city;i++)
	{
	     int mindist=INF;
		for(int j=1;j<=city;j++)
		{
			if(vis[j]==0&&dist[j]<mindist)
			{
				mindist=dist[j];
				next=j;
			}
		}
		vis[next]=1;
		for(int j=1;j<=city;j++)
		{
			if(vis[j]==0&&dist[next]+maptt1[next][j]<dist[j])
			{
				dist[j]=dist[next]+maptt1[next][j];
			 }
		}
	}
}
int main()
{
	while(scanf("%d%d%d%",&T,&S,&D)!=EOF)
	{
	     for(int i=0;i<1001;i++)
	    	{
			for(int j=0;j<1001;j++)
			{
				if(i==j)
				{
					maptt1[i][j]=0;
				}
				else
				{
					maptt1[i][j]=INF;
				}
			}
		}
		 int u,v,w;
		 city=0;
		 while(T--)
		 {
		 	scanf("%d%d%d",&u,&v,&w);
		 	city=max(max(u,v),city);
		 	if(maptt1[u][v]>w)
		 	{
		 		maptt1[u][v]=maptt1[v][u]=w;
			 }
		 }
		 for(int i=0;i<S;i++)
		 {
		 	scanf("%d",&qi[i]);
		 	maptt1[0][qi[i]]=maptt1[qi[i]][0]=0;
		 }
		 int mindist1=INF;
		 for(int i=0;i<D;i++)
		 {
		 	 	scanf("%d",&mo[i]);
			     dijkstra();
			  if(mindist1>dist[mo[i]])
		 		mindist1=dist[mo[i]];
		 }
		 printf("%d\n",mindist1);
	}
	return 0;
}