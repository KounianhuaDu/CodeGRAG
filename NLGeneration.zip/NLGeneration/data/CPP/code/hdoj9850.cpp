// Math and Computational Geometry->Inverse Element
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define LL long long
LL mod, n, p[15], jc[15] = {1};
LL C(LL n, LL m)
{
	LL i, ans = 1;
	if(n<m)
		return 0;
	for(i=1;i<=m;i++)
		ans = ans*(n-i+1)%mod;
	return ans;
}
LL Sech(LL k)
{
	LL i, j, now, f, ans = 0;
	for(i=0;i<(1ll<<n);i++)
	{
		now = 0, f = 1;
		for(j=0;j<=n-1;j++)
		{
			if(i&(1ll<<j))
			{
				now += p[j+1]+1;
				f = -f;
			}
		}
		ans = (ans+f*C(n+k-now, n)%mod+mod)%mod;
	}
	return ans;
}
int main(void)
{
	LL a, b, i;
	mod = 2004;
	for(i=1;i<=10;i++)
		jc[i] = jc[i-1]*i;
	scanf("%lld%lld%lld", &n, &a, &b);
	mod = mod*jc[n];
	for(i=1;i<=n;i++)
		scanf("%lld", &p[i]);
	printf("%lld\n", (Sech(b)-Sech(a-1)+mod)%mod/jc[n]);
	return 0;
}