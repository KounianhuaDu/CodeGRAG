// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 505
#define maxm 1000005
#define eps 1e-10
#define mod 1000000007
#define INF 0x3f3f3f3f
#define PI (acos(-1.0))
#define lowbit(x) (x&(-x))
#define mp make_pair
#define ls o<<1
#define rs o<<1 | 1
#define lson o<<1, L, mid
#define rson o<<1 | 1, mid+1, R
typedef long long LL;
typedef unsigned long long ULL;
using namespace std;
LL qpow(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base;base=base*base;b/=2;}return res;}
LL powmod(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base%mod;base=base*base%mod;b/=2;}return res;}
struct Edge
{
	int v, c, next;
	Edge() {}
	Edge(int v, int c, int next) : v(v), c(c), next(next) {}
}E[maxm];
queue<int> q;
int H[maxn], cntE;
int dis[maxn];
int cur[maxn];
int pre[maxn];
int cnt[maxn];
int flow, s, t, nv;
int n, m, ans;
void addedges(int u, int v, int c)
{
	E[cntE] = Edge(v, c, H[u]);
	H[u] = cntE++;
	E[cntE] = Edge(u, 0, H[v]);
	H[v] = cntE++;
}
void bfs(void)
{
	memset(cnt, 0, sizeof cnt);
	memset(dis, -1, sizeof dis);
	cnt[0] = 1, dis[t] = 0;
	q.push(t);
	while(!q.empty()) {
		int u = q.front();
		q.pop();
		for(int e = H[u]; ~e; e = E[e].next) {
			int v = E[e].v;
			if(dis[v] == -1) {
				dis[v] = dis[u] + 1;
				cnt[dis[v]]++;
				q.push(v);
			}
		}
	}
}
int isap(void)
{
	memcpy(cur, H, sizeof cur);
	flow = 0;
	bfs();
	int u = pre[s] = s, f, e, minv, pos;
	while(dis[s] < nv) {
		if(u == t) {
			f = INF;
			for(int i = s; i != t; i = E[cur[i]].v) if(E[cur[i]].c < f) {
				f = E[cur[i]].c;
				pos = i;
			}
			for(int i = s; i != t; i = E[cur[i]].v) {
				E[cur[i]].c -= f;
				E[cur[i] ^ 1].c += f;
			}
			flow += f;
			u = pos;
		}
		for(e = H[u]; ~e; e = E[e].next) if(E[e].c && (dis[E[e].v] + 1 == dis[u])) break;
		if(~e) {
			cur[u] = e;
			pre[E[e].v] = u;
			u = E[e].v;
		}
		else {
			if(--cnt[dis[u]] == 0) break;
			for(e = H[u], minv = nv; ~e; e = E[e].next) if(E[e].c && minv > dis[E[e].v]) {
				minv = dis[E[e].v];
				cur[u] = e;
			}
			dis[u] = minv + 1;
			cnt[dis[u]]++;
			u = pre[u];
		}
	}
	return flow;
}
void init(void)
{
	ans = cntE = 0;
	memset(H, -1, sizeof H);
}
void read(void)
{
	int x, u, v;
	s = 0, t = n + 1, nv = t + 1;
	for(int i = 1; i <= n; i++) {
		scanf("%d", &x);
		if(x > 0) ans += x, addedges(s, i, x);
		else addedges(i, t, -x);
	}
	while(m--) {
		scanf("%d%d", &u, &v);
		addedges(u, v, INF);
	}
}
void work(void)
{
	printf("%d\n", ans - isap());
}
int main(void)
{
	while(scanf("%d%d", &n, &m)!=EOF) {
		init();
		read();
		work();
	}
	return 0;
}