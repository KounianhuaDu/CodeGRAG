// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node{
	int x, y;
	int t;
}s, u, v;
const int INF = 1e8;
const int maxn = 9; 
int G[maxn][maxn]; 
int path[maxn*maxn][maxn*maxn];
int dir[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
int N, M, L, var, ans;
bool vis[maxn][maxn], vis2[maxn*maxn];
void bfs(int x, int y, int from) {
	memset(vis, false, sizeof(vis)); 
	s.x = x; s.y = y; s.t = 0; 
	vis[s.x][s.y] = true; 
	queue<node> que; 
	que.push(s);  
	while(!que.empty()) {
		u = que.front(); que.pop();
		
		for(int i = 0; i < 4; i++) {
			v.x = u.x + dir[i][0];
			v.y = u.y + dir[i][1];
			if(v.x < 0 || v.y < 0 || v.x >= N || v.y >= M || G[v.x][v.y] == 0 || vis[v.x][v.y]) continue; 
			vis[v.x][v.y] = true;
			v.t = u.t+1;
			if(G[v.x][v.y] != 1 && v.t < 6){
				
				if(G[v.x][v.y] == 2) path[from][0] = v.t;
				else if(G[v.x][v.y] == 3) path[from][L+1] = v.t;
				else path[from][G[v.x][v.y] - 53] = v.t;
				
			}
			que.push(v); 
		}
	}
}
void dfs(int pos, int steps) {
	if(steps >= ans) return ;
	if(pos == L+1) {
		ans = min(ans, steps);
		return ;
	}
	for(int i = 1; i <= L+1; i++) {
		if(vis2[i]) continue; 
		vis2[i] = true;
		
		dfs(i, steps + path[pos][i]); 
		vis2[i] = false;
	}
}
int main() {
	int T; scanf("%d", &T);
	while(T--) {
		L = 0; var = 49; ans = INF;
		scanf("%d%d", &N, &M);
		for(int i = 0; i < N; i++)
			for(int j = 0; j < M; j++) {
				scanf("%d", &G[i][j]);
				if(G[i][j] == 4) {
					G[i][j] += (++var);
					L++;
				
				}
			}
		for(int i = 0; i <= L+1; i++) {
			for(int j = 0; j <= L+1; j++) {
				path[i][j] = INF;
			}
		}
		for(int i = 0; i < N; i++)
			for(int j = 0; j < M; j++) {
				if(G[i][j] > 50) bfs(i, j, G[i][j]-53);
				else if(G[i][j] == 3) bfs(i, j, L+1);
				else if(G[i][j] == 2) bfs(i, j, 0);
			}
		memset(vis2, false, sizeof(vis2));
		dfs(0, 0);
	
		if(ans == INF) printf("-1\n");
		else printf("%d\n", ans); 
	}
	return 0; 
}