// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define  INF 1000000001
int f[510][10000];
int w[510];
int c[510];
int min (int a,int b)
{
    return (a>b) ? b:a;
}
int main ()
{
    int t;
    scanf("%d",&t);
    while (t--)
    {
        
        int a,b;
        scanf("%d%d",&a,&b);
        int V = b - a;
        int type;
        scanf("%d",&type);
        int i,j;
        for(i = 0;i <= type;i++)
            f[i][0] = 0;
        for(i = 0;i <= V;i++)
            f[0][i] = INF;
        for(i = 1;i <= type;i++)
            scanf("%d%d",&w[i],&c[i]);
        for(i = 1;i <= type;i++)
        for(j = 1;j <= V;j++)
        {
            if(j < c[i])
            f[i][j] = f[i-1][j];
            else
            f[i][j] = min(f[i-1][j],f[i][j-c[i]]+w[i]);
        }
        if(f[type][V] != INF)
        printf("The minimum amount of money in the piggy-bank is %d.\n",f[type][V]);
        else printf("This is impossible.\n");
    }
    return 0;
}