// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char maptt1[1110][1110];
int shi[1110][1110];
int vis[1110][1110];
int ans;
int n,m;
void dfs(int x,int y)
{
	if(maptt1[x][y]=='*'||vis[x][y]||x<0||x>=n||y<0||y>=m)
	return;
	if(vis[x][y]==0)
	ans++;
	vis[x][y]=1;
	dfs(x+1,y);dfs(x-1,y);
	dfs(x,y+1);dfs(x,y-1);
	dfs(x+1,y+1);dfs(x+1,y-1);
	dfs(x-1,y+1);dfs(x-1,y-1);
}
int main()
{
	while(scanf("%d%d",&n,&m)&&n||m)
	{
		memset(shi,0,sizeof(shi));
		memset(maptt1,0,sizeof(maptt1));
		memset(vis,0,sizeof(vis));
		int i,j;
		int p=0;
		for(i=0;i<n;i++)
		{
			scanf("%s",maptt1[i]);
			for(j=0;j<m;j++)
			{
				if(maptt1[i][j]=='@')
				{
					shi[i][j]=1;
					p++;
				}
			}
		}
		int sum=0;
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
		{
			if(shi[i][j]==1)
			{	
				ans=0;
				dfs(i,j);
				if(p>0)
				{
				if(ans<=p&&ans>0)
				{
					sum++;
					p-=ans;
					ans=0;
				}	
				}
				else
				break;
			}
		}	
		if(p==0)
		break;
		}
		printf("%d\n",sum);
	}
	return 0;
}