// Graph Algorithm->Dijkstra's Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#pragma warning(disable : 4996)
const int MAXN = 2000;
const int INF = 999999;
int n, s, e;
int maps[MAXN][MAXN];
bool visited[MAXN];
int pre[MAXN];
int dist[MAXN];
int values[MAXN];
vector<int>path;
int cmp(int a, int b, int c) 
{ 
	int cur = 0, path1[1002] = {0}, path2[1002] = {0}, count1 = 0, count2 = 0; 
	path1[count1++] = c, path2[count2++] = c;
	for(cur = a; cur != pre[cur]; cur = pre[cur]) 
		path1[count1++] = cur; 
	for(cur = b; cur != pre[cur]; cur = pre[cur]) 
		path2[count2++] = cur; 
	count1--, count2--; 
	while(count1 != -1 || count2 != -1) 
	{ 
		if(path1[count1] > path2[count2]) 
			return b; 
		else if(path1[count1] < path2[count2]) 
			return a; 
		count1--, count2--; 
	} 
	if(count1 == -1) 
		return a; 
	else 
		return b; 
}
void Dijkstra() 
{
	int i, j;
	int minValue, minNode;
	dist[s] = 0;
	visited[s] = true;
	for (i = 1; i <= n; i++)
	{
		dist[i] = maps[s][i];
		if(dist[i] == -1)
		{
			pre[i] = 0;
		}
		else
		{
			pre[i] = s;
			
			dist[i] += values[i];
		}
		
	}
	for (i = 1; i <= n; i++)
	{
		minValue = INF;
		minNode = 0;
		for (j = 1; j <= n; j++)
		{
			if(!visited[j] && minValue > dist[j])
			{
				minNode = j;
				minValue = dist[j];
			}
		}
		
		if(minNode == 0)
		{
			break;
		}
		visited[minNode] = true;
		for (j = 1; j <= n; j++)
		{
			if(!visited[j] && maps[minNode][j] != INF && dist[j] > dist[minNode] + maps[minNode][j] + values[j])
			{
				dist[j] = dist[minNode] + maps[minNode][j] + values[j];
				pre[j] = minNode;
				
			}
			else if(!visited[j] && maps[minNode][j] != INF && dist[j] == dist[minNode] + maps[minNode][j] + values[j])
			{
				pre[j] = cmp(pre[j], minNode, j);
			}
		}
	}
}
void show()
{
	int x = e;
	while (pre[x] != x)
	{
		path.push_back(x);
		x = pre[x];
	}
	printf("From %d to %d :\n", s, e);
	printf("Path: ");
	printf("%d-->", s);
	for (int i = path.size() - 1; i >= 1; i--)
	{
		printf("%d-->", path[i]);
	}
	printf("%d\n", path[0]);
	path.clear();
	printf("Total cost : %d\n", dist[e] - values[e]);
	printf("\n");
}
int main()
{
	freopen("in.txt", "r", stdin);
	int x;
	while (scanf("%d", &n) != EOF)
	{
		if(n == 0)
		{
			break;
		}
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= n; j++)
			{
				scanf("%d", &x);
				if(x == -1 || x == 0)
				{
					maps[i][j] = INF;
				}
				else
				{
					maps[i][j] = x;
				}
			}
		}
		for (int i = 1; i <= n; i++)
		{
			scanf("%d", &values[i]);
		}
		while (scanf("%d %d", &s, &e) != EOF)
		{
			if(s == -1 && e == -1)
			{
				break;
			}
			if(s == e)
			{
				printf("From %d to %d :\n", s, e);
				printf("Path: %d\n", s);
				printf("Total cost : 0\n");
				printf("\n");
			}
			else
			{
				memset(visited, false, sizeof(visited));
				for (int i = 1; i <= n; i++)
				{
					pre[i] = i;
				}
				Dijkstra();
				show();
			}
		}
	}
	return 0;
}