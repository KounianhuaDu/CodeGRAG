// Data Structure->Binary Indexed Tree (BIT)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX=100000+10;
typedef long long LL;
LL c[MAX];
int N;
int lowbit(int x)
{
	return x&(-x);
}
LL query(int x)
{
	LL s=0;
	while(x>0)
	{
		s+=c[x];
		x-=lowbit(x);
	}
	return s;
}
void update(int x,int data)
{
	while(x<=N)
	{
		c[x]+=data;
		x+=lowbit(x);
	}
}
int main()
{
	
	
	while(scanf("%d",&N)&&N)
	{
		memset(c,0,sizeof(c));
		
		for(int i=1;i<=N;i++)
		{
			int a,b;
			scanf("%d%d",&a,&b);
			update(a,1);
			update(b+1,-1);
		}
		for(int i=1;i<=N;i++)
		{
			printf("%lld%c",query(i),i==N?'\n':' ');
		}
	}
	return 0;
}