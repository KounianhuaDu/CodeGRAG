// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
using namespace std;
#define max_n 100010
int dp[max_n][12];
int maxa(int a, int b, int c)
{
	int t = max(a, b);
	t = max(t, c);
	return t;
}
int main()
{
	int n;
	int location;
	int time;
	
	while (scanf("%d",&n)!=EOF)
	{
		int max_time = 0;
		if (n == 0)break;
		memset(dp, 0, sizeof(dp));
		for (int i = 0; i < n; i++)
		{
			scanf("%d%d", &location, &time);
			dp[time][location]++;
			if (max_time < time)
				max_time = time;
		}
		for (int i = max_time - 1; i >= 0; i--)
		{
			dp[i][0] += max(dp[i + 1][0], dp[i + 1][1]);
			for (int j = 1; j < 10; j++)
			{
				dp[i][j] += maxa(dp[i + 1][j], dp[i + 1][j - 1], dp[i + 1][j + 1]);
			}
			dp[i][10] += max(dp[i + 1][10], dp[i + 1][9]);
		}
		printf("%d\n", dp[0][5]);
	}
	
	return 0;
}