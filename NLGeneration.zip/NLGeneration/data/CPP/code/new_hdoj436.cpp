// Data Structure->Stack
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int main()
{
	char s1[110],s2[110];
	int n,m,i,j,k,flag[110];
	stack<char>s;
	while(~scanf("%d %s%s",&n,&s1,&s2))
	{
		while(!s.empty())
		s.pop();
		k=0;
	    j=0;
		memset(flag,-1,sizeof(flag));
		for(i=0;i<n;i++)
		{
			s.push(s1[i]);
			flag[k++]=1;
			while(!s.empty()&&s.top()==s2[j])
			{
				flag[k++]=0;
				s.pop();
				j++;
			}
		}
		if(j==n)
		{
			printf("Yes.\n");
			for(i=0;i<k;i++)
			{
				if(flag[i])
				printf("in\n");
				else
				printf("out\n");
			}
		}
		else
		printf("No.\n");
		printf("FINISH\n");
	}
	return 0;
 }