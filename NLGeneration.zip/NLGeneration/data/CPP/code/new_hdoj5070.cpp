// Graph Algorithm->Euler Circuit / Euler Path
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
typedef pair<int,int>pii;
const int maxn=1000010;
int num[maxn];
int degree[maxn];
int father[maxn];
int Find(int x){
    return x==father[x]?x:father[x]=Find(father[x]);
}
int main()
{
    int t,n,m;cin>>t;
    while(t--){
        scanf("%d%d",&n,&m);
        for(int i=1;i<=n;++i){
            scanf("%d",&num[i]);
            father[i]=i;degree[i]=0;
        }int ans=0;
        for(int i=1;i<=m;++i){
            int a,b;
            scanf("%d%d",&a,&b);
            degree[a]++;degree[b]++;
            a=Find(a);b=Find(b);
            if(a!=b)father[a]=b;
        }
        bool sign=true;
        int root=Find(1);
        for(int i=1;i<=n;++i){
            if(Find(i)!=root){
                sign=false;break;
            }
        }
        int cnt=0;
        for(int i=1;i<=n;++i){
            if(degree[i]&1)cnt++;
        }
        if(sign&&(cnt==0||cnt==2)){
            ans=0;
            if(cnt==2){
                for(int i=1;i<=n;++i){
                    if(degree[i]&1){
                        ans^=num[i];
                        if(((degree[i]-1)/2)&1){
                            ans^=num[i];
                        }
                    }
                    else {
                        if(((degree[i])/2)&1){
                            ans^=num[i];
                        }
                    }
                }
                printf("%d\n",ans);
            }
            else {
                int cntx=0;
                for(int i=1;i<=n;++i){
                    if((degree[i]/2)&1){
                        cntx^=num[i];
                    }
                }
                for(int i=1;i<=n;++i){
                    ans=max(ans,cntx^num[i]);
                }
                printf("%d\n",ans);
            }
        }
        else {
            printf("Impossible\n");
        }
    }
    return 0;
}