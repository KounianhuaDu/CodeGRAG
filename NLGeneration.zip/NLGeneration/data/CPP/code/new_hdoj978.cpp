// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  
  
  
using namespace std;
#define MAX_N 10010
#define max_n	10000000
const double  esp = 1e-8;
double a[MAX_N];
int n, k;
bool c(double x)
{
	int num = 0;
	for (int i = 0; i < n; i++)
	{
		num += int(a[i] / x);
	}
	return num >= k;
}
int main()
{
	while (scanf("%d%d",&n,&k)!=EOF)
	{
		double sum = 0;
		if (n == 0 && k == 0)break;
		for (int i = 0; i < n; i++)
		{
			scanf("%lf", &a[i]);
			sum += a[i];
		}
		double first = 0.00;
		double last = sum/k;
		double mid;
		while (first + esp<last)
		{
			mid = (first + last) / 2;
			if (c(mid))first = mid;
			else last = mid;
		}
		printf("%.2lf\n", first);
	}
	return 0;
}