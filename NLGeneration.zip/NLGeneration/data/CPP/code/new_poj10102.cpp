// Graph Algorithm->Kruskal's Algorithm
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,per[1005];double s;
struct lu
{
	int a,b;
	double len;
}x[1005];
int cmp(lu a,lu b)
{
	return a.len<b.len;
}
void init()
{
	for(int i=0;i<n;++i)
	{
		per[i]=i;
	}
}
int find(int x)
{
	int r=x;
	while(r!=per[r])
	{
		r=per[r];
	}
	int i=x,j;
	while(i!=r)
	{
		j=per[i];
		per[i]=r;
		i=j;
	}
	return r;
}
int join(int x,int y)
{
	int fx=find(x),fy=find(y);
	if(fx!=fy)
	{
		per[fy]=fx;
		return 1;
	}
	return 0;
}
void kruscal()
{
	init();
	int i,cnt=0;double sum=0;
	for(i=0;cnt<n-1;++i)
	{
		if(join(x[i].a,x[i].b))
		{
			sum+=x[i].len;
			++cnt;
		}
	}
	if(sum>s)
	{
		printf("Not enough cable\n");
		return;
	}
	printf("Need %.1lf miles of cable\n",sum);
}
int main()
{
	int i,j;double len;
	char a[25],b[25];
	while(~scanf("%lf",&s))
	{
		map<string,int> maptt1;
		scanf("%d",&n);
		for(i=0;i<n;++i)
		{
			getchar();
			scanf("%s",a);
			maptt1[a]=i;
		}
		scanf("%d",&m);
		for(i=0;i<m;++i)
		{
			getchar();
			scanf("%s%s%lf",a,b,&len);
			x[i].a=maptt1[a];x[i].b=maptt1[b];
			x[i].len=len;
		}
		sort(x,x+m,cmp);
		kruscal();
	}
	return 0;
}