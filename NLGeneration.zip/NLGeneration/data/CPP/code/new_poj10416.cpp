// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Divide and Conquer,Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL long long
const int INF = 0x3f3f3f3f;
const int maxn = 1e5 + 10;
int n, m, x, w;
int s[maxn], nt[maxn], e[maxn], val[maxn], cnt;
int sum[maxn], mx[maxn], dis[maxn], vis[maxn],tot;
int a[maxn],flag[maxn],sz;
map<int, int>mp;
int dfs(int k, int fa, int p)
{
	int ans = mx[k] = (sum[k] = 1) - 1;
	for (int i = s[k]; ~i; i = nt[i])
	{
		if (e[i] == fa || vis[e[i]]) continue;
		int temp = dfs(e[i], k, p);
		sum[k] += sum[e[i]];
		mx[k] = max(mx[k], sum[e[i]]);
		if (mx[temp] < mx[ans]) ans = temp;
	}
	mx[k] = max(mx[k], p - sum[k]);
	return mx[k] < mx[ans] ? k : ans;
}
void get(int k, int fa, int len)
{
	dis[tot++] = len;
	for (int i = s[k]; ~i; i = nt[i])
	{
		if (vis[e[i]] || e[i] == fa) continue;
		get(e[i], k, len + val[i]);
	}
}
void Find(int k)
{
	mp.clear(), mp[0] = 1;
	for (int i = s[k]; ~i; i = nt[i])
	{
		if (vis[e[i]]) continue;
		tot = 0;
		get(e[i], k, val[i]);
		for (int j = 0; j < sz; j++)
		{
			if (flag[j]) continue;
			for (int k = 0; k < tot; k++)
				if (mp.count(a[j] - dis[k])) { flag[j] = 1; break; }
		}
		for (int j = 0; j < tot; j++) mp[dis[j]] = 1;
	}
}
void solve(int k, int p)
{
	int y = dfs(k, k, p);
	Find(y), vis[y] = 1;
	for (int i = s[y]; ~i; i = nt[i])
	{
		if (vis[e[i]]) continue;
		if (sum[e[i]] < sum[y]) solve(e[i], sum[e[i]]);
		else solve(e[i], p - sum[y]);
	}
	vis[y] = 0;
}
int main()
{
	while (~scanf("%d", &n)&&n)
	{
		memset(s, -1, sizeof s);
		mx[cnt = 0] = INF;
		for (int i = 1; i <= n; i++)
		{
			while (scanf("%d", &x) && x)
			{
				scanf("%d", &w);
				nt[cnt] = s[x], s[x] = cnt, e[cnt] = i, val[cnt++] = w;
				nt[cnt] = s[i], s[i] = cnt, e[cnt] = x, val[cnt++] = w;
			}
		}
		sz = 0;
		while (scanf("%d", &a[sz]) && a[sz]) flag[sz++] = 0;
		solve(1, n);
		for (int i = 0; i < sz; i++)
		{
			if (flag[i]) printf("AYE\n");
			else printf("NAY\n");
		}
		printf(".\n");
	}
	return 0;
}