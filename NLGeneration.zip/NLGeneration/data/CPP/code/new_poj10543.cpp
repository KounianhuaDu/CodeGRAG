// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Graph Algorithm->Min-Cost Max-Flow
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define max(x,y) x>y?x:y
#define min(x,y) x<y?x:y
const int N=1100,INF=0x3f3f3f3f;
int pre[N],d[N],p[N],cnt,ans;
struct edge
{
    int u,v,w,c;
}e[N*N];
vector<int> g[N];
void add(int u,int v,int w,int c)
{
    e[cnt].u=u,e[cnt].v=v,e[cnt].w=w,e[cnt].c=c;
    g[u].push_back(cnt++);
    e[cnt].u=v,e[cnt].v=u,e[cnt].w=-w,e[cnt].c=0;
    g[v].push_back(cnt++);
}
void updata(int s,int t)
{
    int i,f=INF;
    for(i=t;i!=s;i=e[pre[i]].u)
        f=min(f,e[pre[i]].c);
    for(i=t;i!=s;i=e[pre[i]].u)
    {
       e[pre[i]].c-=f;
       e[pre[i]^1].c+=f;
       ans+=f*e[pre[i]].w;
    }
}
int spfa(int s,int t)
{
    int i,u,v,w;
    memset(p,0,sizeof(p));
    memset(pre,-1,sizeof(pre));
    for(i=0;i<N;i++)    d[i]=INF;
    queue<int> q;
    q.push(s),p[s]=1,d[s]=0;
    while(!q.empty())
    {
        p[u=q.front()]=0;
        q.pop();
        for(i=0;i<g[u].size();i++)
        {
            v=e[g[u][i]].v,w=e[g[u][i]].w;
            if(e[g[u][i]].c&&d[v]>d[u]+w)
            {
                d[v]=d[u]+w;
                pre[v]=g[u][i];
                if(!p[v])
                {
                    p[v]=1;
                    q.push(v);
                }
            }
        }
    }
    if(pre[t]==-1)
        return 0;
    return 1;
}
int main()
{
    int i,n,m,u,v,w;
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        for(i=0;i<N;i++)
            g[i].clear();
        ans=cnt=0;
        for(i=1;i<=m;i++)
        {
            scanf("%d%d%d",&u,&v,&w);
            add(u,v,w,1);
            add(v,u,w,1);
        }
        add(0,1,0,2);
        add(n,n+1,0,2);
        while(spfa(0,n+1))
            updata(0,n+1);
        printf("%d\n",ans);
    }
    return 0;
}