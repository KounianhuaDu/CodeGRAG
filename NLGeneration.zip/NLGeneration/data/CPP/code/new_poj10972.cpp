// Math and Computational Geometry->Convex Hull Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct Point{
    int x, y;
};
const int MAXN = 50010;
Point list[MAXN];
Point p[MAXN];
int stacktt1[MAXN], top;
int crossProduct(Point a, Point b){
	return a.x*b.y - a.y*b.x;
}
Point sub(Point a, Point b){
	Point p;
	p.x = a.x - b.x;
	p.y = a.y - b.y;
	return p;
}
int dist(Point a, Point b){
	return (a.x-b.x)*(a.x-b.x) + (a.y-b.y)*(a.y-b.y);
}
bool cmp(Point p1, Point p2){
    int temp  = crossProduct(sub(p1, list[0]), sub(p2, list[0]));
	if(temp>0) return true;
	else if(temp==0 && dist(p1, list[0])-dist(p2, list[0])<=0) return true;
	else return false;
}
void Graham(int n){
    Point p0 = list[0];
    int k = 0;
    for(int i=1;i<n;i++){
        if(p0.y>list[i].y || (p0.y==list[i].y && p0.x>list[i].x)){
            p0 = list[i];
            k = i;
        }
    }
    swap(list[k], list[0]);
    sort(list+1, list+n, cmp);
	stacktt1[0] = 0;
    if(n==1){top = 1; return;}
    stacktt1[1] = 1;
    if(n==2){top = 2; return;}
	top = 2;
	for(int i=2;i<n;i++){
        while(top>1 && crossProduct(sub(list[stacktt1[top-1]], list[stacktt1[top-2]]), sub(list[i], list[stacktt1[top-2]]))<=0){
			top--;
        }
        stacktt1[top++] = i;
	}
}
int rotating_calipers(int n){
    
	int ans = 0, cur = 1;
    p[n] = p[0];   
    for(int i=0;i<n;i++){
        while(crossProduct(sub(p[i], p[i+1]), sub(p[cur+1], p[cur]))<0)
			cur = (cur+1)%n;
        ans = max(ans, max(dist(p[i], p[cur]), dist(p[i+1], p[cur+1])));
    }
    return ans;
}
int main(){
	int n;
	while(~scanf("%d", &n)){
        for(int i=0;i<n;i++){
            scanf("%d %d", &list[i].x, &list[i].y);
        }
		Graham(n);
        for(int i=0;i<top;i++) p[i] = list[stacktt1[i]];
        printf("%d\n", rotating_calipers(top));
	}
	return 0;
}