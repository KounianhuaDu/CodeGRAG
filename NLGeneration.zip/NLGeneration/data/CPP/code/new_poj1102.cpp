// Data Structure->Segment Tree
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 10000+5
#define Pi  acos(-1.0)
struct node
{
    int l, r;
    double vx,vy;
    int lazy;
};
node tree[4*maxn];
int a[maxn];
int ang[maxn];
void build(int rt, int ll, int rr)
{
    tree[rt].l = ll, tree[rt].r = rr;
    tree[rt].vx = 0, tree[rt].lazy = 0;
    if(ll==rr){
        tree[rt].vy = a[ll];
        return;
    }
    int m = ll+(rr-ll)/2;
    int lc = 2*rt, rc = 2*rt+1;
    build(lc, ll, m);
    build(rc, m+1, rr);
    tree[rt].vx = tree[lc].vx+tree[rc].vx;
    tree[rt].vy = tree[lc].vy+tree[rc].vy;
}
void rotate(double &x,  double &y, int ang)
{
    double tx = x, ty = y;
    double a = (double)ang/180*Pi;
    x = tx*cos(a)-ty*sin(a);
    y = tx*sin(a)+ty*cos(a);
}
void seg_modify(int rt, int ll, int rr, int a)
{
    if(ll > rr) return;
    int l = tree[rt].l, r = tree[rt].r;
    int lazy = tree[rt].lazy;
    int lc = 2*rt, rc = 2*rt+1;
    if(ll == l && rr == r){
        tree[rt].lazy += a;
        rotate(tree[rt].vx, tree[rt].vy, a);
        return;
    }
    else if(lazy){
        tree[lc].lazy+= lazy; 
        tree[rc].lazy+= lazy;
        tree[rt].lazy = 0;
        rotate(tree[lc].vx, tree[lc].vy, lazy);
        rotate(tree[rc].vx, tree[rc].vy, lazy);
    }
    int m = l+(r-l)/2;
    if(rr <= m)
        seg_modify(lc, ll, rr, a);
    else if(ll >= m+1)
        seg_modify(rc, ll, rr, a);
    else{
        seg_modify(lc, ll, m, a);
        seg_modify(rc, m+1, rr, a);
    }
    tree[rt].vx = tree[lc].vx+tree[rc].vx;
    tree[rt].vy = tree[lc].vy+tree[rc].vy;
}
int main()
{
    int n, c;
    while(scanf("%d%d", &n, &c)!=EOF){
        for(int i = 1; i <= n; i++)
            scanf("%d", a+i);
        build(1, 1, n);
       for(int i = 0; i<= n+1; i++) ang[i] = 180;
        int s, a;
        for(int i = 0; i < c; i++){
            scanf("%d%d", &s, &a);
            seg_modify(1, s+1, n, a-ang[s+1]);
            ang[s+1]=a;
            printf("%.2lf %.2lf\n\n", tree[1].vx, tree[1].vy);
        }
        printf("\n");
    }
    return 0;
}