// Data Structure->Stack,Sorting->Topological Sort
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 30;
int n,m;
vector<int> list[maxn];		
bool vis[maxn]; 			
int ind[maxn];				
int cnt;					
char res[maxn];				
int TopSort(){
	stack<int> st;
	int d[maxn];
	int f = 1;
	for(int i = 0; i < n; i++){
		d[i] = ind[i];
		if(d[i] == 0 && vis[i]) st.push(i);
	}
	
	
	for(int i = 0; i < cnt; i++){
		if(st.empty()) return -1;
		if(st.size() > 1) f = 0;
		int u = st.top(); st.pop(); res[i] = u + 'A';
		for(int j = 0; j < list[u].size(); j++){
			if(--d[list[u][j]] == 0) st.push(list[u][j]);
		}
	}
	res[cnt] = '\0';
	if(f) return cnt;
	else return 0;
}
bool Input(){
	int flag = 0;
	int k = 0; 
	char u,v;
	cnt = 0; 
	
	cin>>n>>m;
	if(n == 0 && m == 0)
		return false;
		
	for(int i = 0; i < n; i++) {
		list[i].clear();
		ind[i] = 0;
		vis[i] = false;
	}
	
	for(int i = 0; i < m; i++){
		cin>>u;
		getchar();
		cin>>v;
		list[u-'A'].push_back(v-'A');
		ind[v-'A']++;
		
		if(!vis[u-'A']) {vis[u-'A'] = true; cnt++;}
		if(!vis[v-'A']) {vis[v-'A'] = true; cnt++;}
		
		if(flag != -1 && flag != n) {flag = TopSort(); k = i;}
	}
	
	if(flag == -1){
		printf("Inconsistency found after %d relations.\n",k+1);	
	}
	else if(flag < n){
		printf("Sorted sequence cannot be determined.\n");
	}
	else{
		printf("Sorted sequence determined after %d relations: %s.\n",k+1,res);
	}
		
	return true;
}
int main(){
	
	
	while(Input());
	return 0;
}