// Graph Algorithm->Bellman-Ford Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0xfffffff
#define MAXN 1010
struct Edge
{
    int u,v;
    double w;
};
Edge edge[MAXN];
int n,m;
double dist[MAXN];
bool flag=false;
void Bellman(int s)
{
    int i,j;
    memset(dist,0,sizeof(dist));
    dist[s]=1.0;
    for(i=1; i<=n; ++i)
        for(j=0; j<m; ++j)
        {
            Edge e=edge[j];
            if(e.w*dist[e.u]>dist[e.v])
            {
                dist[e.v]=e.w*dist[e.u];
                
            }
            if(dist[s]>1.0)
            {
                flag=true;
                return;
            }
        }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int i,j,cnt=0;
    while(cin>>n&&n)
    {
        string name[30];
        for(i=0; i<n; ++i)
            cin>>name[i];
        cin>>m;
        for(i=0; i<m; ++i)
        {
            string a,b;
            double c;
            cin>>a>>c>>b;
            for(j=0; j<n; ++j)
            {
                if(a==name[j])
                    edge[i].u=j;
                if(b==name[j])
                    edge[i].v=j;
            }
            edge[i].w=c;
        }
        for(i=0; i<n; ++i)
        {
            flag=false;
            Bellman(i);
            if(flag) break;
        }
        
        if(flag) cout<<"Case "<<++cnt<<": "<<"Yes"<<endl;
        else cout<<"Case "<<++cnt<<": "<<"No"<<endl;
    }
    return 0;
}