// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef pair<int, double> P;
const int INF = 0x3f3f3f3f;
const int maxn = 1e3 + 10;
bool vis[maxn];
string s1, s2;
int flag, n, num[maxn];
double temp, dis[maxn];
vector<P> G[maxn];
map<string, int> m;
bool spfa(int s) {
    for (int i = 1; i <= n; i++) dis[i] = 0, vis[i] = false, num[i] = 0;
    dis[s] = 1, vis[s] = true, num[s] = 1;
    queue<int> q; q.push(s);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        vis[u] = false;
        for (int i = 0; i < G[u].size(); i++) {
            int v = G[u][i].first;
            double val = G[u][i].second;
            if (dis[v] < dis[u] * val) {
                dis[v] = dis[u] * val;
                if (!vis[v]) {
                    vis[v] = true, num[v]++;
                    q.push(v);
                    if (num[v] > n) return true;
                }
            }
        }
    }
    return false;
}
int main() {
    while (~scanf("%d", &n) && n) {
        for (int i = 1; i <= n; i++) G[i].clear();
        m.clear();
        int cnt = 0;
        for (int i = 1; i <= n; i++) {
            cin >> s1;
            if (!m[s1]) m[s1] = ++cnt;
        }
        int t; scanf("%d", &t);
        while (t--) {
            cin >> s1 >> temp >> s2;
            int u = m[s1], v = m[s2];
            G[u].push_back(make_pair(v, temp));
            
        }
        bool ok = false;
        for (int i = 1; i <= n; i++) {
            if (spfa(i)) { ok = true; break; }
        }
        printf("Case %d: %s\n", ++flag, ok ? "Yes" : "No");
    }
    return 0;
}