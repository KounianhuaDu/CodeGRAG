// Basic Algorithm->Recurrence
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,dir[5003],f[5003];
int cal(int x)
{
	memset(f,0,sizeof(f));
	int ret=0;int sum=0;
	for(int i=1;i+x-1<=n;i++)
	{
		if((sum+dir[i])%2!=0)
		{
			ret++;
			f[i]=1;
			sum+=f[i];
		}
	
		if(i-(x-1)>=1)sum-=f[i-x+1]; 
	}
	
	
	for(int i=n-x+2;i<=n;i++)
	{
		if((sum+dir[i])%2==1){
			return -1;
		} 
		if(i-(x-1)>=1)sum-=f[i-x+1]; 
	} 
	return ret;
	
	
}
int main()
{
	while(cin>>n)
	{
		for(int i=1;i<=n;i++){
			char x;cin>>x;
			dir[i]=(x=='F'?0:1);
	 
		}
		int M=n;int K=1;
		for(int k=1;k<=n;k++)
		{
			int m=cal(k);
			if(m<M&&m>=0)
			{
				M=m;K=k; 
			}
		 } 
		 cout<<K<<" "<<M<<endl; 
	}
	
	
	return 0;
}