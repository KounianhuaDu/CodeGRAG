// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=20003;
int vis[N],dp[N];
int num[N];
vector<int>V[N];
void dfs1(int u)
{
    vis[u]=1;
    num[u]=1;
    for(int i=0;i<(int)V[u].size();i++)
    {
        int v=V[u][i];
        if(vis[v]) continue;
        dfs1(v);
        num[u]+=num[v];
    }
    return ;
}
void dfs2(int u,int n)
{
    vis[u]=1;
    dp[u]=n-num[u];
    for(int i=0;i<(int)V[u].size();i++)
    {
        int v=V[u][i];
        if(vis[v]) continue;
        dp[u]=max(dp[u],num[v]); 
        dfs2(v,n); 
    }
}
int main()
{
    
    int n,ncase;
    scanf("%d",&ncase);
    while(ncase--)
    {
        scanf("%d",&n);
        if(n==1) {printf("%d %d\n",1,0);continue;}
        int a,b;
        memset(num,0,sizeof(num));
        memset(vis,0,sizeof(vis));
        for(int i=1;i<n;i++)
        {
            scanf("%d%d",&a,&b);
            V[a].push_back(b);
            V[b].push_back(a);
        }
        dfs1(1);
        memset(vis,0,sizeof(vis));
        dfs2(1,n);
        int res=n+1,ans;
        for(int i=1;i<=n;i++)
        {
            
            if(res>dp[i])
            {
                ans=i;
                res=dp[i];
                if(res==1) break;
            }
        }
        printf("%d %d\n",ans,res);
        for(int i=0;i<=n;i++)
         V[i].clear();
    }
    return 0;
}