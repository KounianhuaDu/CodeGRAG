// Sorting->Quick Sort,Dynamic Programming->Priority Queue
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int num;
    int dis;
    friend bool operator < (node a, node b)
    {
        return a.num < b.num;
    }
}tem, now_oil, oil[11000];
priority_queue<struct node> q;
int comp(node a, node b)
{
    return a.dis > b.dis;
}
int main()
{
    int n;
    while(~scanf("%d", &n))
    {
        int ans = 0;
        for(int i = 0; i < n; i++)
        {
            scanf("%d%d", &oil[i].dis, &oil[i].num);
        }
        sort(oil, oil+n, comp);
        int l, p;
        scanf("%d%d", &l, &p);
        for(int i = 0; i <= n; i++)
        {
            if(ans == -1) break;
            if(i < n)
            {
                now_oil.dis = l - oil[i].dis;
                now_oil.num = oil[i].num;
            }
            else
                now_oil.dis = l;
            while(now_oil.dis > p)
            { 
                if(q.empty())
                {
                    ans = -1;
                    break;
                } 
                tem = q.top();
                q.pop();
                ans++;
                p += tem.num;
            }
            q.push(now_oil);
        }
        while(!q.empty()) q.pop();
        printf("%d\n", ans);
    }
    return 0;
}