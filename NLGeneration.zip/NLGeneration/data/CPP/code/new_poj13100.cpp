// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Hungarian (KM) Algorithm
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef pair<int,int>Pa;
map<Pa,int>M;
int vis[1505],pre[1505];
int ml[1505],mr[1505];
int flag[1505];
vector<int>V[1505];
int m,n,k;
int MaxMatch()
{
    int sum=0;
    memset(ml,-1,sizeof(ml));
    memset(mr,-1,sizeof(mr));
    memset(vis,0,sizeof(vis));
    for(int i=1; i<=n*m; i++)
    {
        if(!flag[i]&&ml[i]==-1)
        {                   
            queue<int>Q;
            Q.push(i);
            pre[i]=-1;
            int kas=0;
            while(!Q.empty()&&!kas)
            {
                int st=Q.front();
                Q.pop();
                for(int j=0; j<V[st].size()&&!kas; j++)
                {
                    int to=V[st][j];
                    if(vis[to]!=i&&!flag[to])
                    {
                        vis[to]=i;
                        Q.push(mr[to]);
                        if(mr[to]>=0)
                        {
                            pre[mr[to]]=st;
                        }
                        else
                        {
                            kas=1;
                            int d=st,e=to;
                            while(d!=-1)
                            {
                                int temp=ml[d];
                                ml[d]=e;
                                mr[e]=d;
                                e=temp;
                                d=pre[d];
                            }
                        }
                    }
                }
            }
            if(kas)sum++;
        }
    }
    return sum;
}
int main()
{
    while(~scanf("%d%d%d",&m,&n,&k))
    {
        memset(flag,0,sizeof(flag));
        M.clear();
        int x,y;
        for(int i=0; i<k; i++)
        {
            scanf("%d%d",&x,&y);
            M[make_pair(y,x)]=1;
        }
        int ans=1;
        for(int i=1; i<=m; i++)
        {
            for(int j=1; j<=n; j++)
            {
                if(!M[make_pair(i,j)])
                {
                    if(j<n)   
                    {
                        V[ans].push_back(ans+1);
                    }
                    if(j>1)
                    {
                        V[ans].push_back(ans-1);
                    }
                    if(i<m)
                    {
                        V[ans].push_back(ans+n);
                    }
                    if(i>1)
                    {
                        V[ans].push_back(ans-n);
                    }
                    ans++;
                }
                else
                {
                    flag[ans]=1;
                    ans++;
                }
            }
        }
        
        int he=MaxMatch();
        if(he+k==n*m)
        {
            printf("YES\n");
        }
        else
            printf("NO\n");
    }
}