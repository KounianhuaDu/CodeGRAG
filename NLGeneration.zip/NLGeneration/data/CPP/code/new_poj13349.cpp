// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 110
struct node
{
	int to;
	double rate;
};
int n,m;
bool in[MAXN];
vector<node> g[MAXN];
double dis[MAXN];
void init()
{
	for(int i=1;i<=n;i++)
		g[i].clear();
	node temp;
	int a1,b;
	double x;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%lf",&a1,&b,&x);
		temp.to=a1;
		temp.rate=x/100;
		g[b].push_back(temp);
		temp.to=b;
		g[a1].push_back(temp);
	}
}
void spfa(int s)
{
	queue<int> q;
	for(int i=1;i<=n;i++)
	{
		in[i]=false;
		dis[i]=0;
	}
	dis[s]=1;
	in[s]=true;
	q.push(s);
	while(!q.empty())
	{
		int tag=q.front();
		q.pop();
		in[tag]=false;
		for(int i=0;i<g[tag].size();i++)
		{
			int j=g[tag][i].to;
			if(dis[j]<dis[tag]*g[tag][i].rate)
			{
				dis[j]=dis[tag]*g[tag][i].rate;
				if(!in[j])
				{
					in[j]=true;
					q.push(j);
				}
			}
			
		}
		
	}
}
void solve()
{
	spfa(1);
	cout<<setprecision(6)<<setiosflags(ios::fixed)<<100*dis[n]<<" percent"<<endl;
	
}
int main()
{
	while(cin>>n && n)
	{
		cin>>m;
		init();
		solve();
	}
	return 0;
}