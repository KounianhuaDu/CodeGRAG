// Graph Algorithm->Bellman-Ford Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int INF=99999999;
const int MAXM=5500;
const int MAXN=510;
struct Edge
{
    int u,v,w;
}edge[MAXM];
int dis[MAXN],n,m,t,edgenum;
void Add_Edge(int u,int v,int w)
{
    edgenum++;
    edge[edgenum].u=u;
    edge[edgenum].v=v;
    edge[edgenum].w=w;
}
bool Bellmen_Ford()
{
    for (int i=1;i<=n;i++)
        dis[i]=INF;
    dis[1]=0;
    for (int k=1;k<=n-1;k++)
    {
        bool flag=false;
        for (int i=1;i<=edgenum;i++)
        {
            int u=edge[i].u;
            int v=edge[i].v;
            if (dis[v]>dis[u]+edge[i].w)
            {
                dis[v]=dis[u]+edge[i].w;
                flag=true;
            }
        }
        if (!flag) break;
    }
    for (int i=1;i<=edgenum;i++)
        if (dis[edge[i].v]>dis[edge[i].u]+edge[i].w)
            return true;
    return false;
}
int main()
{
    int F,i,u,v,w;
    scanf("%d",&F);
    while (F--)
    {
        scanf("%d%d%d",&n,&m,&t);
        edgenum=0;
        for (i=1;i<=m;i++)
        {
            scanf("%d%d%d",&u,&v,&w);
            Add_Edge(u,v,w);
            Add_Edge(v,u,w);
        }
        for (i=1;i<=t;i++)
        {
            scanf("%d%d%d",&u,&v,&w);
            Add_Edge(u,v,-w);
        }
        bool ans=Bellmen_Ford();
        if (ans) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}