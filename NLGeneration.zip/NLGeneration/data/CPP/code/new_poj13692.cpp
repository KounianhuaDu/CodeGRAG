// Graph Algorithm->Euler Circuit / Euler Path,Data Structure->Disjoint Set Union (DSU),Data Structure->Trie
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define M 500000
typedef struct stu
{
    int id,flag;        
    struct stu *next[26];
}node;
int num=1,f[M+5],d[M+5]; 
node* creat_node()      
{
    node *p=(node*)malloc(sizeof(node));
    p->id=p->flag=0;
    memset(p->next,0,sizeof(p->next));
    return p;
}
int trie_insert(node *p,char *s)  
{
    int i;
    while(*s!='\0'){
        i=*s-'a';
        if(p->next[i]==NULL)
            p->next[i]=creat_node();
        p=p->next[i];
        s++;
    }
    if(!p->flag){
        p->flag=1;
        p->id=num++;
    }
    return p->id;
}
int find(int x) 
{
    if(x!=f[x])
        f[x]=find(f[x]);
    return f[x];
}
void mix(int a,int b)  
{
    a=find(a);
    b=find(b);
    if(a!=b)
        f[a]=b;
}
int main()
{
    int i,j,n,m,flag=1;
    node *root=NULL;
    char s1[15],s2[15];
    root=creat_node();  
    for(i=1;i<=M;i++){  
        f[i]=i;
        d[i]=0;
    }
    while(scanf("%s%s",s1,s2)!=EOF){
        i=trie_insert(root,s1);
        j=trie_insert(root,s2);
        mix(i,j);
        d[i]++;
        d[j]++;
    }
    m=n=0;
    for(i=1;i<num&&flag;i++){
        if(d[i]%2)
            n++;  
        if(n>2)
            flag=0;  
        if(f[i]==i) 
            m++;  
        if(m>1)
            flag=0;
    }
    if(flag)
        printf("Possible\n");
    else
        printf("Impossible\n");
    return 0;
}