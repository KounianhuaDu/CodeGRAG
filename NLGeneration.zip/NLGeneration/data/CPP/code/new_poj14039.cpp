// Graph Algorithm->Floyd-Warshall Algorithm,Dynamic Programming->Bitmask Dynamic Programming (DP)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MM(x) memset(x,0,sizeof(x))
#define MMF(x) memset(x,0,sizeof(x))
using namespace std;
#define maxn 205
int n;
int E[maxn][maxn];
int cacu(const string& s){
    int ans = 0;
    int L = s.length();
    for(int i=0;i<L;i++){
        ans |= 1<<(s[i]-'a');
    }
    return ans;
}
void doit(int a,int b){
    int mask = 1;
    bool flag = false;
    for(int i=0;i<26;i++){
        if(mask & E[a][b] ) flag=true,putchar(i+'a');
        mask <<= 1;
    }
    if(flag) puts("");
    else puts("-");
}
void Floyd(){
    for(int k=1;k<=n;k++){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                E[i][j] |= E[i][k] & E[k][j];
            }
        }
    }
}
int main(){
    int T = 0;
    while(~scanf("%d",&n)&&n!=0){
        if(T++) puts("");
        MM(E);
        int a,b;
        while(~scanf("%d%d",&a,&b)&&a!=0){
            string s;
            cin>>s;
            E[a][b] = cacu(s);
        }
        Floyd();
        while(~scanf("%d%d",&a,&b)&&a!=0) doit(a,b);
    }
    return 0;
}