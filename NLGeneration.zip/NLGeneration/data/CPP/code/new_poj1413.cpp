// Basic Algorithm->Memorization
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int pn[2005][15][35];
int day[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
int isleap(int y)
{
    if(y%400==0||(y%100&&y%4==0))
        return 1;
    return 0;
}
int canmove(int y,int m,int d)
{
    if(m==13)
        m=1&&y++;
    if(m==2)
    {
        if(isleap(y))
            return d<=29;
        else
            return d<=28;
    }
    return d<=day[m];
}
int ans(int y,int m,int d)
{
    if(m==13)
        m=1&&y++;
    if(d>day[m])
    {
        if(m==2&&isleap(y))
        {
            if(d==30)
                d=1&&m++;
        }
        else
            d=1&&m++;
    }
    if(m==13)
        m=1&&y++;
    if(pn[y][m][d]!=-1)
        return pn[y][m][d];
    bool vis=1;
    if(canmove(y,m+1,d))
        vis&=ans(y,m+1,d);
    vis&=ans(y,m,d+1);
    if(vis)
        return pn[y][m][d]=0;
    return pn[y][m][d]=1;
}
int T;
int y,m,d;
int main()
{
    memset(pn,-1,sizeof pn);
    pn[2001][11][4]=0;
    pn[2001][11][3]=pn[2001][10][4]=1;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&y,&m,&d);
        if(ans(y,m,d))
            printf("YES\n");
        else
            printf("NO\n");
    }
    return 0;
}