// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 10000 + 5000;
const int INF  = 0x3f3f3f3f;
int head[MAXN],e;
long long dis[MAXN],ans;
bool vis[MAXN];
struct Edge{
    int v,nxt,w;
}E[MAXN<<1];
void init()
{
    e=0;
    memset(head,-1,sizeof head);
}
void add(int u,int v,int w)
{
    E[e].v=v;
    E[e].w=w;
    E[e].nxt = head[u];
    head[u]=e++;
}
int BFS(int s)
{
    int se = s;
    long long MAX = 0;
    ans  = 0;
    queue<int>Q;
    Q.push(s);
    memset(vis,false,sizeof vis);
    vis[s] = true;
    dis[s] = 0;
    while(!Q.empty())
    {
        int u = Q.front();Q.pop();
        for(int i=head[u];~i;i=E[i].nxt){
            int v = E[i].v;
            if(vis[v])continue;
            vis[v] = true;
            dis[v] = dis[u]+E[i].w;
            if(dis[v]>MAX){
                se = v;
                MAX = dis[v];
                ans = dis[v];
            }
            Q.push(v);
        }
    }
    return se;
}
int main()
{
    int u,v,w;
    init();
    while(scanf("%d%d%d",&u,&v,&w) != EOF){
        add(u,v,w);
        add(v,u,w);
    }
    BFS(BFS(1));
    printf("%lld\n",ans);
    return 0;
}