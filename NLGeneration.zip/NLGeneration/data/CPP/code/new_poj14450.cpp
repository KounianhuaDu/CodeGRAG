// Basic Algorithm->Discretization,Data Structure->Functional Segment Tree
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 1e5 + 5;
int T[maxn], L[maxn * 20], R[maxn * 20], sum[maxn * 20];
int sz[maxn], h[maxn];
int n, q, ql, qr, k, tot;
void build(int& rt, int l, int r) 
{
	rt = ++tot;
	sum[rt] = 0;
	if (l == r) return;
	int mid = (l + r) >> 1;
	build(L[rt], l, mid);
	build(R[rt], mid + 1, r);
}
void update(int& rt, int l, int r, int pre, int x)
{
	rt = ++tot;
	L[rt] = L[pre];
	R[rt] = R[pre];
	sum[rt] = sum[pre] + 1;
	if (l == r) return;
	int mid = (l + r) >> 1;
	if (x <= mid) update(L[rt], l, mid, L[pre], x);
	else update(R[rt], mid + 1, r, R[pre], x);
}
int query(int s, int e, int l, int r, int k)
{
	if (l == r) return l;
	int mid = (l + r) >> 1;
	int res = sum[L[e]] - sum[L[s]]; 
	if (k <= res) return query(L[s], L[e], l, mid, k);
	else return query(R[s], R[e], mid + 1, r, k - res);
}
int main()
{
	scanf("%d%d", &n, &q);
	for (int i = 1; i <= n; i++) scanf("%d", sz + i), h[i] = sz[i];
	sort(h + 1, h + 1 + n);
	int num = unique(h + 1, h + 1 + n) - h - 1;
	tot = 0;
	build(T[0], 1, num);
	for (int i = 1; i <= n; i++)
	{
		
		update(T[i], 1, num, T[i - 1], lower_bound(h + 1, h + 1 + num, sz[i]) - h);
	}
	while (q--)
	{
		scanf("%d%d%d", &ql, &qr, &k);
		int ans = query(T[ql - 1], T[qr], 1, num, k);
		printf("%d\n", h[ans]);
	}
	return 0;
}