// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100005
using namespace std;
int vis[maxn];
int step[maxn];
queue <int > q ;
int serch(int k,int n)
{
    int flag=0,a,mark=0;
    memset(vis,0,sizeof(vis));
    memset(step,0,sizeof(step));
    q.push(k);  
    vis[k]=1;   
    while(!q.empty())   
    {
        a=q.front();    
        q.pop();        
        for(int i=1; i<=3; i++)
        {
            if(i==1)
                flag=a+1;
            else if(i==2)
                flag=a-1;
            else
                flag=a*2;
            if(flag>100000||flag<0)
                continue;
            if(!vis[flag])
            {
                step[flag]=step[a]+1;
                vis[flag]=1;
                q.push(flag); 
                if(flag==n)
                    return step[flag];
            }
        }
    }
    return 0;
    
    
    
}
int main()
{
    int n,k;        
    while(~scanf("%d%d",&k,&n))
    {
        if(k>n) 
            printf("%d\n",k-n);
        else
            printf("%d\n",serch(k,n));
    }
    return 0;
}