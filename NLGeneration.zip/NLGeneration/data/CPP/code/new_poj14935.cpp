// Sorting->Quick Sort,Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

typedef long long LL;
using namespace std;
struct node
{
    int maxspf;
    int minspf;
    friend bool operator<(const node &a,const node &b)
    {
        return a.maxspf<b.maxspf;
    }
} cow[2505];
struct node1
{
    int num,sun;
    friend bool operator<(const node1 &a,const node1 &b)
    {
        return a.sun<b.sun;
    }
} a[2505];
int main()
{
    
    int C,L;
    while(cin>>C>>L)
    {
        for(int i=0; i<C; i++)
            cin>>cow[i].minspf>>cow[i].maxspf;
        for(int i=0; i<L; i++)
            cin>>a[i].sun>>a[i].num;
        sort(cow,cow+C);
        sort(a,a+L);
       
        int ans=0,j=0,i=0;
       
        for(int i=0; i<C; i++)
        {
            for(int j=0; j<L; j++)
            {
                if(cow[i].minspf<=a[j].sun&&cow[i].maxspf>=a[j].sun&&a[j].num>0)
                {
                    ans++;
                    a[j].num--;
                    break;
                }
                if(a[j].sun>cow[i].maxspf)
                    break;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}