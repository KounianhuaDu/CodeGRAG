// Dynamic Programming->Longest Common Subsequence (LCS),Data Structure->Suffix Array,Basic Algorithm->Binary Lifting
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 10000010
int t1[maxn],t2[maxn];
char s[maxn],str[maxn];
int c[maxn],sa[maxn];
int rak[maxn],height[maxn];
void SA(int n){
    int m=1000000,*x=t1,*y=t2;
    for(int i=1;i<=m;++i) c[i]=0;
    for(int i=1;i<=n;++i) c[x[i]=s[i]]++;
    for(int i=1;i<=m;++i) c[i]+=c[i-1];
    for(int i=n;i;--i) sa[c[x[i]]--]=i;
    for(int k=1;k<=n;k<<=1){
        int p=0;
        for(int i=n-k+1;i<=n;++i) y[++p]=i;
        for(int i=1;i<=n;++i) if(sa[i]>k) y[++p]=sa[i]-k;
        for(int i=1;i<=m;++i) c[i]=0;
        for(int i=1;i<=n;++i) c[x[y[i]]]++;
        for(int i=1;i<=m;++i) c[i]+=c[i-1];
        for(int i=n;i;--i) sa[c[x[y[i]]]--]=y[i];
        swap(x,y);
        p=1,x[sa[1]]=1;
        for(int i=2;i<=n;++i){
            x[sa[i]]=y[sa[i]]==y[sa[i-1]]&&y[sa[i]+k]==y[sa[i-1]+k]?p:++p;
        }
        m=p;
        if(p>=n) break;
    }
    int k=0;
    for(int i=1;i<=n;++i) rak[sa[i]]=i;
    for(int i=1;i<=n;++i){
        int j=sa[rak[i]-1];
        if(k) --k;
        while(s[i+k]==s[j+k])++k;
        height[rak[i]]=k;
    }
}
int main(){
    scanf("%s%s",s+1,str+1);
    int len1=strlen(s+1);
    int len2=strlen(str+1);
    s[len1+1]='$';
    for(int i=1;i<=len2;++i){
        s[i+len1+1]=str[i];
    }
    int n=strlen(s+1);
    SA(n);
    int ans=0;
    for(int i=1;i<=n;++i){
        if((sa[i]<len1)^(sa[i-1]<len1)){
            ans=max(ans,height[i]);
        }
    }
    printf("%d",ans);
    return 0;
}