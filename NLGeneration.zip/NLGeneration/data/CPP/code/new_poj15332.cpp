// Data Structure->Queue
#include <algorithm>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define loop(a,b,c) for(int a=b;a<=c;a++)
#define clr(a,b) memset(a,b,sizeof a)
#define x first
#define y second
#define maxn 1000005
using namespace std;
int num[maxn],mx[maxn],mi[maxn];
int main()
{
	
	int n,k,len1=0,len2=0;
	deque<int> q1,q2;
	scanf("%d %d",&n,&k);
	loop(i,1,n)
			scanf("%d",&num[i]);
	loop(i,1,n)
	{
			if(q1.empty()) q1.push_back(i);
			else{
				while(!q1.empty()&&(num[q1.back()]<num[i]||i-q1.back()+1>k)) q1.pop_back();
				while(!q1.empty()&&i-q1.front()+1>k) q1.pop_front();
				q1.push_back(i);
			}
			if(i>=k) mx[len1++]=num[q1.front()];
	}
	loop(j,1,n)
	{
			if(q2.empty()) q2.push_back(j);
			else{
				while(!q2.empty()&&(num[q2.back()]>num[j]||j-q2.back()+1>k)) q2.pop_back();
				while(!q2.empty()&&j-q2.front()+1>k) q2.pop_front();
				q2.push_back(j);
			}
			if(j>=k) mi[len2++]=num[q2.front()];
	}
	loop(j,0,len2-1) printf("%d ",mi[j]);
	printf("\n");
	loop(i,0,len1-1) printf("%d ",mx[i]);
}