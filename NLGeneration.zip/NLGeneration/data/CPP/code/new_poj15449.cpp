// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int M[100010];
int main()
{
    int A[110],C[110];
    int n,m;
    int i,j,k;
    while(scanf("%d %d",&n,&m),n|m){
       for(i=1;i<=n;i++)
          scanf("%d",&A[i]);
       for(i=1;i<=n;i++)
          scanf("%d",&C[i]);
       
       memset(M,0,sizeof(M));
       
       int temp;
       for(i=1;i<=n;i++)
	   {
            k=1;
          while(k<=C[i])
		  {
            C[i]-=k;
            temp=k*A[i];
            for(j=m;j>=temp;j--)
                M[j]=max(M[j],M[j-temp]+temp);
            k=k<<1;
          }
          if(C[i]>0) 
		  {
		    k=C[i];
            temp=k*A[i];
            for(j=m;j>=temp;j--)
                 M[j]=max(M[j],M[j-temp]+temp);
                  
          }
       }
      
      k=0;
     for(i=1;i<=m;i++)
        if(M[i]==i)
		   k++;
      printf("%d\n",k);
    }
    return 0;
}