// Math and Computational Geometry->Inclusion–Exclusion Principle
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
long long n,m;
long long num[60],cnt[60];
long long top,per;
long long f(long long ,long long);
void get(long long s,long long t,long long p){
	long long i;
	if(t==p)
	{
		long long j=m;
		for(i=0;i<t;i++)
			j/=cnt[i];
		per+=f(j,n);
	}
	else
	{
		for(i=s;i<top;i++)
		{
			cnt[t]=num[i];
			get(i+1,t+1,p);
		}
	}
}
long long f(long long s,long long t){
	long long i,j=1;
	for(i=1;i<=t;i++)
		j*=s;
	return j;
}
void read(){
	long long i,j,k;
	cin>>n>>m;
	long long ans=0;
	long long x=m;
	for(i=2;i*i<=x;i++)
		if(x%i==0)
		{
			while(x%i==0)
			{
				x/=i;
			}
			num[top++]=i;
		}
	if(x>1)
		num[top++]=x;
	ans=f(m,n);
	for(i=1;i<=top;i++)
	{
		per=0;
		get(0,0,i);
		if(i%2)
			ans-=per;
		else
			ans+=per;
	}
	cout<<ans<<endl;
}
int main(){
	read();
	return 0;
}