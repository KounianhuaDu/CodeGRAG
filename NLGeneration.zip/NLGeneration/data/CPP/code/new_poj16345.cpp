// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Blocking,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define lowbit(x) (x&(-x))
#define inf  0x7fffffff
#define linf 0x7fffffffffffffff
#define fill(x,y) memset(x,y,sizeof(x))
#define fup(i,x,y) for(int i=(x);i<=(y);i++)
#define fdn(i,x,y) for(int i=(x);i>=(y);i--)
#define sp(x) setprecision(x)
#define sd(n) scanf("%d",&n)
#define sdd(n,m) scanf("%d%d",&n,&m)
#define sddd(n,m,k) scanf("%d%d%d",&n,&m,&k)
#define sld(n) scanf("%lld",&n)
#define sldd(n,m) scanf("%lld%lld",&n,&m)
#define slddd(n,m,k) scanf("%lld%lld%lld",&n,&m,&k)
#define sf(n) scanf("%lf",&n)
#define sff(n,m) scanf("%lf%lf",&n,&m)
#define sfff(n,m,k) scanf("%lf%lf%lf",&n,&m,&k)
#define sc(n) scanf("%s",n)
#define pf(x) printf("%d\n",x)
#define pfl(x) printf("%lld\n",x)
#define pff(x) printf("%lf\n",x)
#define N 100005
#define M 4000009
#define pi acos(-1)
#define eps 1e-2
using namespace std;
typedef long long  ll;
typedef double db;
int n,m;
char c[45][15];
int vis[45*15],link[45*15], a[45][15];
vector<int> q[45*15];
int ok(int x)
{
    fup(i,0,q[x].size()-1)
    {
        int tp=q[x][i];
        if(!vis[tp])
        {
            vis[tp]=1;
            if(!link[tp]||ok(link[tp]))
            {
                link[tp]=x;
                return 1;
            }
        }
    }
    return 0;
}
int right(int x,int y)
{
    if(x<1||x>n||y<1||y>m||c[x][y]!='*') return 0;
    return 1;
}
void dfs(int x,int y)
{
    int go[4][2]={1,0,-1,0,0,-1,0,1};
    fup(i,0,3)
    {
        int xx=x+go[i][0];
        int yy=y+go[i][1];
        if(right(xx,yy)) q[a[x][y]].push_back(a[xx][yy]);
    }
}
int main()
{
    int t ;
    sd(t);
    while(t--)
    {
        sdd(n,m);
        fup(i,1,n)
            sc(c[i]+1);
        int cnt=0;
        fup(i,1,n)
            fup(j,1,m)
                if(c[i][j]=='*') a[i][j]=++cnt;
        fup(i,1,cnt)
            q[i].clear();
        fup(i,1,n)
            fup(j,1,m)
                if(c[i][j]=='*') dfs(i,j);
        int ans=0;
        fill(link,0);
        fup(i,1,cnt)
        {
            fill(vis,0);
            if(ok(i)) ans++;
        }
        pf(cnt-ans/2);
    }
    return 0;
}