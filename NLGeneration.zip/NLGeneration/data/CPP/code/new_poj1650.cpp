// Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

long long c[20],sum[20];
int n;
void catalan(){
    int i,j;
    memset(c, 0, sizeof(c));
    memset(sum, 0, sizeof(sum));
    c[0] = c[1] = sum[1] = 1;
    for(i = 2;i<20;i++){
        for(j = 0;j<i;j++)
            c[i] += c[j]*c[i-1-j];
        sum[i] = c[i]+sum[i-1];
    }
}
void solve(int x,int num){
    int i,j,t = 0,a,b;
    if(x == 1){
        printf("X");
        return;
    }
    for(i = 0;i<x;i++){
        t += c[i]*c[x-1-i];
        if(num <= t)
            break;
    }
    t = c[i]*(c[x-1-i])-(t-num);
    a = (t-1)/c[x-1-i]+1;
    b = (t-1)%c[x-1-i]+1;
    if(i){
        printf("(");
        solve(i,a);
        printf(")");
    }
    printf("X");
    if(i<x-1){
        printf("(");
        solve(x-1-i, b);
        printf(")");
    }
}
int main(){
    catalan();
    while (scanf("%d",&n) && n){
        int i;
        for(i = 1;i<20;i++){
            if(n<=sum[i])
                break;
        }
        solve(i,n-sum[i-1]);
        printf("\n");
    }
    return 0;
}