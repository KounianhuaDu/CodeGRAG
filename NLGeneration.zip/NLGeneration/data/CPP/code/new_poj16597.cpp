// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const long M=100005;
long a[M];
long sum[M];
void solve(long n, long s){
	if (sum[n]<s){
	 cout<<0<<endl;
	 return;
    }
    long res=n;
    for (long i=0; sum[i]+s<=sum[n]; i++){
    	long t=lower_bound(sum+i, sum+n, sum[i]+s)-sum;
    	res=min(res,t-i);
    }
    cout<<res<<endl;
	
}
void init(long n, long s)
{
	memset(a,0,sizeof(a));
	memset(sum, 0, sizeof(sum));	 
	for (long i=0; i<n; i++)
	scanf("%d", &a[i]);
	for (long i=0; i<n; i++)
	sum[i+1]=sum[i]+a[i];		
}
int main()
{
	int t;
	scanf("%d",&t);
	for (int i=1; i<=t; i++)
	{
		long s,n;
		scanf("%ld %ld", &n, &s);
		init(n,s);
		solve(n,s);	
	}
	return 0;
}