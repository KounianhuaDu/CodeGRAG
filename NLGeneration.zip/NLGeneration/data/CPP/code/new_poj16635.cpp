// Sorting->Quick Sort,Data Structure->Binary Indexed Tree (BIT)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX_N=1010;
int T,n,m,k,cases=0;
long long bits[MAX_N];
struct Way{
    int a,b;
    bool operator <(const Way tmp) const{
        if(b==tmp.b) return a>tmp.a;
        else return b>tmp.b;
    }
}way[MAX_N*MAX_N];
inline void update(int x)
{
    for(int i=x;i<MAX_N;i+=(i&(-i))){
        bits[i]++;
    }
}
inline long long sum(int x)
{
    long long res=0;
    for(int i=x-1;i>0;i-=(i&(-i))){
        res+=bits[i];
    }
    return res;
}
int main()
{
    
    scanf("%d",&T);
    while(T--){
        scanf("%d%d%d",&n,&m,&k);
        for(int i=0;i<k;i++){
            scanf("%d%d",&way[i].a,&way[i].b);
        }
        sort(way,way+k);
        memset(bits,0,sizeof(bits));
        long long ans=0;
        for(int i=0;i<k;i++){
            ans+=sum(way[i].a);
            update(way[i].a);
        }
        printf("Test case %d: %lld\n",++cases,ans);
    }
    return 0;
}