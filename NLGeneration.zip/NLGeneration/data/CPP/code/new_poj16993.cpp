// Sorting->Quick Sort,Basic Algorithm->Discretization
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 210000
using namespace std;
struct Chess{
	int x,y;
}a[maxn];
int b[maxn],c[maxn];
int sum[maxn];
int n;
bool cmp_x(Chess a,Chess b){
	if (a.x != b.x)return a.x<b.x;
	return a.y<b.y;
}
bool cmp_y(Chess a,Chess b){
	if (a.y != b.y)return a.y<b.y;
	return a.x<b.x;
}
int bit(int i){
	return i&(-i);
}
void add(int i,int x){
	while (i<=n){
		sum[i]+=x;
		i+=bit(i);
	}
}
int query(int l,int r){
	int right=0,left=0;
	l--;
	while (l>0){
		left+=sum[l];
		l-=bit(l);
	}
	while (r>0){
		right+=sum[r];
		r-=bit(r);
	}
	return right-left;
}
int main(){
	scanf("%d",&n);
	for (int i=0;i<n;i++)
		scanf("%d%d",&a[i].x,&a[i].y);
	sort(a,a+n,cmp_x);
	int cnt=1;
	for (int i=0;i<n;i++){
		bool flag=false;
		if (a[i].x != a[i+1].x)flag=true;
		a[i].x=cnt;
		if (flag)cnt++;
	}
	sort(a,a+n,cmp_y);
	cnt=1;
	for (int i=0;i<n;i++){
		bool flag=false;
		if (a[i].y != a[i+1].y)flag=true;
		a[i].y=cnt;
		if (flag)cnt++;
	}
	memset(c,0,sizeof(c));
	for (int i=0;i<n;i++)
		if (c[a[i].x]<a[i].y)
			c[a[i].x]=a[i].y;
	int result=0;
	memset(b,0,sizeof(b));
	for (int i=0;i<n-1;i++){
		if (b[a[i].x]==0 && a[i].y!=c[a[i].x]){
			add(a[i].x,1);
			b[a[i].x]=1;
		}
		if (a[i].y==a[i+1].y){
			if (a[i].x != a[i+1].x)
				result+=query(a[i].x+1,a[i+1].x-1);
		}
		if (b[a[i].x]==1&&a[i].y==c[a[i].x]){
			b[a[i].x]=0;
			add(a[i].x,-1);
		}
	}
	printf("%d",result+n);
	return 0;
}