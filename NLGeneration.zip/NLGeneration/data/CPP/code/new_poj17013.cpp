// Data Structure->Stack,Data Structure->Queue,Graph Algorithm->Tarjan's Algorithm,Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Graph Algorithm->Strongly Connected Components
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int inf=0x7f7f7f7f;
const int maxn=5e4+50;
const int N=5e5+50;
typedef long long ll;
typedef struct{
    ll u,v,next,w;
}Edge;
Edge e[N],e1[N];
typedef struct B{
    int l,r;
    ll sum,lazy1,lazy2;
    void update(ll value1,ll value2){
        sum=sum*value1;
        lazy2=lazy2*value1;
        sum=(sum+(r-l+1)*value2);
        lazy1=(lazy1*value1+value2);
    }
}Tree;
Tree tree[4];
int cnt,cnt1,head[N],head1[N];
inline void add(int u,int v,int w){
    e[cnt].u=u;
    e[cnt].v=v;
    e[cnt].w=w;
    
    e[cnt].next=head[u];
    head[u]=cnt++;
    
    
    
    
    
    
}
inline void add1(int u,int v,int w){
    e1[cnt1].u=u;
    e1[cnt1].v=v;
    e1[cnt1].w=w;
    e1[cnt1].next=head1[u];
    head1[u]=cnt1++;
}
inline int read()
{
    int x = 0;
    int f = 1;
    char c = getchar();
    while (c<'0' || c>'9')
    {    
        if (c == '-')
            f = -1;
        c = getchar();
    }
    while (c >= '0'&&c <= '9')
    {
        x = x * 10 + c - '0';
        c = getchar();
    }
    return x*f;
}
int k,res,n ,m,t,low[N],dfn[N],_time,vis[N],_scc[N],vis1[N],dis[N];
stack<int >s;
void tarjan(int u){
    low[u]=dfn[u]=_time++;
    s.push(u);
    vis[u]=1;
    for(int i=head[u];i!=-1;i=e[i].next){
        int v=e[i].v;
        if(!dfn[v]){
            tarjan(v);
            low[u]=min(low[v],low[u]);
        }
        else if(vis[v])low[u]=min(low[u],dfn[v]);
    }
    if(dfn[u]==low[u]){
        res++;
        do{
            t=s.top();
            s.pop();
            vis[t]=0;
            _scc[t]=res;
        }while(t!=u);
    }
}
void  spfa(int a,int b){
    memset(dis,inf,sizeof(dis));
    memset(vis1,0,sizeof(vis1));
    dis[a]=0;
    queue<int>q;
    q.push(a);
    vis1[a]=1;
    while(!q.empty()){
        int u=q.front();q.pop();
        vis1[u]=0;
        for(int i=head1[u];i!=-1;i=e1[i].next){
            int v=e1[i].v,w=e1[i].w;
            if(dis[v]>dis[u]+w){
                dis[v]=dis[u]+w;
                if(!vis1[v]){
                    q.push(v);
                    vis1[v]=1;
                }
            }
        }
    }
    if(dis[b]==inf)cout<<"Nao e possivel entregar a carta"<<endl;
    else cout<<dis[b]<<endl;
}
int main() {
    while(scanf("%d%d",&n,&m)!=EOF&&n!=0){
        cnt1=cnt=res=_time=0;
        int a,b,c;
        memset(head,-1,sizeof(head));
        memset(head1,-1,sizeof(head1));
        for(int i=0;i<=n;i++)
            vis[i]=_scc[i]=dfn[i]=low[i]=0;
       
        for(int i=0;i<m;i++){
            scanf("%d%d%d",&a,&b,&c);
            add(a,b,c);
        }
        while(!s.empty())s.pop();
        for(int i=1;i<=n;i++)
            if(!dfn[i])
                tarjan(i);
        
         
        for(int i=0;i<cnt;i++){
            int u=e[i].u,v=e[i].v,w=e[i].w;
            
            if(_scc[u]!=_scc[v])
                add1(_scc[u],_scc[v],w);
        }
        cin>>k;
        for(int i=0;i<k;i++){
            scanf("%d%d",&a,&b);
            
            
            
            if(_scc[a]==_scc[b])cout<<0<<endl;
            else spfa(_scc[a],_scc[b]);
        }
        cout<<endl;
    }  
}