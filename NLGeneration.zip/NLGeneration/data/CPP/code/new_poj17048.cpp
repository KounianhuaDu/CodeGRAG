// Sorting->Quick Sort,Basic Algorithm->Binary Search
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int inf=0x3f3f3f3f;
const double pi= acos(-1.0);
const double esp=1e-6;
const int maxn=10010;
double a[maxn];
int main()
{
    int T,n,F;
    scanf("%d",&T);
    while(T--){
        double low=0,high=0;
        scanf("%d %d",&n,&F);
        F+=1;
        for(int i=0;i<n;i++){
            scanf("%lf",&a[i]);
            a[i]=a[i]*a[i];
            high=max(high,a[i]);
        }
        double mid;
        int cnt;
        while(high-low>esp){
            cnt=0;
            mid=(low+high)/2;
            for(int i=0;i<n;i++)
                cnt+=(int)(a[i]/mid);
            if(cnt>=F){
                low=mid;
            }
            else
                high=mid;
        }
        printf("%.4f\n",mid*pi);
    }
    return 0;
}