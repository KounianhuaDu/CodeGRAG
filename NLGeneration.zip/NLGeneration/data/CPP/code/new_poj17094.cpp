// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=105;
int vis[15000];
int sta,pos;
struct proc
{
    int x,step;
};
bool isLeagal(int x)
{
    if(x==2&&x==3) return true;
    else if(x<=1||x%2==0) return false;
    else if(x>3)
    {
        for(int i=3;i*i<=x;i++)
        {
            if(x%i==0) return false;
        } 
        return true;
    }
}
int bfs(int s)
{
    proc vw,vn;
    queue<proc> q;
    vw.x=s;
    vw.step=0;
    vis[s]=0;
    q.push(vw);
    while(!q.empty())
    {
        vw=q.front();
        q.pop();
        if(vw.x==pos)
        {
            return vw.step;
        }
        int tmpx=vw.x%10;
        int tmpy=(vw.x/10)%10;
        for(int i=1;i<=9;i+=2)
        {
            vn.x=(vw.x/10)*10+i;
            if(vn.x!=vw.x&&!vis[vn.x]&&isLeagal(vn.x))
            {
                vis[vn.x]=1;
                vn.step=vw.step+1;
                q.push(vn);
            }
        } 
        for(int i=0;i<=9;i++)
        {
            vn.x=(vw.x/100)*100+i*10+tmpx;
            if(vn.x!=vw.x&&!vis[vn.x]&&isLeagal(vn.x))
            {
                vis[vn.x]=1;
                vn.step=vw.step+1;
                q.push(vn);
            }
        }
        for(int i=0;i<=9;i++)
        {
            vn.x=(vw.x/1000)*1000+i*100+tmpy*10+tmpx;
            if(vn.x!=vw.x&&!vis[vn.x]&&isLeagal(vn.x))
            {
                vis[vn.x]=1;
                vn.step=vw.step+1;
                q.push(vn);
            }
        }
        for(int i=1;i<=9;i++)
        {
            vn.x=(vw.x%1000)+i*1000;
            if(vn.x!=vw.x&&!vis[vn.x]&&isLeagal(vn.x))
            {
                vis[vn.x]=1;
                vn.step=vw.step+1;
                q.push(vn);
            }
        }
    }
    return -1;      
}
int main()
{
    int n;
    scanf("%d",&n);
    while(n--)
    {
        memset(vis,0,sizeof(vis));
        scanf("%d %d",&sta,&pos);
        int ans=bfs(sta);
        if(ans!=-1) printf("%d\n",ans);
        else printf("Impossible\n");
    }
    return 0;
}