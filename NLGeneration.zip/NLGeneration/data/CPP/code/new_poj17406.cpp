// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,k,s;
struct TT
{
    int len;
    int num[111111];
    int low[111111][33],equ[111111][33];
} t,p;
void init(TT &tmp)
{
    for(int i =1;i<=tmp.len;i++)
    {
        for(int j = 1;j<=s;j++)
        {
            tmp.low[i][j] = tmp.low[i-1][j] + (tmp.num[i] < j ? 1 : 0);
            tmp.equ[i][j] = tmp.equ[i-1][j] + (tmp.num[i] == j ? 1 : 0);
        }
    }
}
int fail[25555];
int check(TT &a,TT &b,int i,int j)
{
    if(a.low[i][a.num[i]] - a.low[i - j][a.num[i]] == b.low[j][b.num[j]]
       && a.equ[i][a.num[i]] - a.equ[i - j][a.num[i]] == b.equ[j][b.num[j]])
        return 1;
    return 0;
}
void get_fail()
{
    fail[1] = 0;
    int j = 0;
    for(int i = 2;i<=k;i++)
    {
        if(j >= 1 && !check(p,p,i,j+1) )
            j = fail[j];
        if(check(p,p,i,j+1)) j++;
        fail[i] = j;
    }
}
vector <int> ans;
void kmp()
{
    ans.clear();
    get_fail();
    int j = 0;
    for(int i = 1;i<=n;i++)
    {
        while(j >= 1 && !check(t,p,i,j+1)) j = fail[j];
        if(check(t,p,i,j+1)) j++;
        if(j == k)
        {
            ans.push_back(i-k+1);
            j = fail[j];
        }
    }
}
int main()
{
    while(~scanf("%d%d%d",&n,&k,&s))
    {
        for(int i = 1;i<=n;i++)
            scanf("%d",&t.num[i]);
        for(int i = 1;i<=k;i++)
            scanf("%d",&p.num[i]);
        t.len = n;
        p.len = k;
        init(t);
        init(p);
        kmp();
        printf("%d\n",ans.size());
        for(int i = 0;i<ans.size();i++)
            printf("%d\n",ans[i]);
    }
    return 0;
}