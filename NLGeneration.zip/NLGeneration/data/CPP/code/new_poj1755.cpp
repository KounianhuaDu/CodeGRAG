// Math and Computational Geometry->Chinese Remainder Theorem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MP make_pair
#define PB push_back
#define mst(a,b) memset((a),(b),sizeof(a))
#define TEST cout<<"*************************"<<endl
#define rep(s,n,up) for(int i = (s); i < (n); i+=(up))
#define per(n,e,down) for(int i = (n); i >= (e); i-=(down))
#define rep1(s,n,up) for(int j = (s); j < (n); j+=(up))
#define per1(n,e,down) for(int j = (n); j >= (e); j-=(down))
typedef long long LL;
typedef unsigned long long uLL;
typedef pair<int, int> Pii;
typedef vector<int> Vi;
typedef vector<Pii> Vii;
const int inf = 0x3f3f3f3f;
const LL INF = (1uLL << 63) - 1;
const double Pi = acos(-1.0);
const int maxn = (1 << 16) + 7;
const uLL Hashmod = 29050993;
const double esp=1e-6;
int main() {
#ifdef local
    freopen("input.txt", "r", stdin);
    
#endif
    
    
    LL divisor[8],remainder[8],tot_m=1,sum=0;
    rep(0,8,1)scanf("%lld",&divisor[i]);
    rep(0,8,1)scanf("%lld",&remainder[i]);
    LL min_sum=divisor[0]+remainder[0];
    rep(0,8,1){
        tot_m*=divisor[i];
        LL s=divisor[i]+remainder[i];
        if(s>min_sum)
            min_sum=s;
    }
    rep(0,8,1){
        LL m=1,temp_m=1;
        rep1(0,8,1){
            if(j!=i)
                m*=divisor[j];
        }
        temp_m=m;
        while(m%divisor[i]!=1)
            m+=temp_m;
        sum+=m*remainder[i];
    }
    sum%=tot_m;
    while(sum<min_sum)sum+=tot_m;
    printf("%lld\n",sum);
    return 0;
}