// Data Structure->Queue,Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Binary Search,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Maximum Flow Algorithm,Sorting->Quick Sort,Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define sc scanf
#define ls rt << 1
#define rs ls | 1
#define Min(x, y) x = min(x, y)
#define Max(x, y) x = max(x, y)
#define ALL(x) (x).begin(),(x).end()
#define SZ(x) ((int)(x).size())
#define MEM(x, b) memset(x, b, sizeof(x))
#define lowbit(x) ((x) & (-x))
#define P2(x) ((x) * (x))
typedef long long ll;
const int MOD = 1e9 + 7;
const int MAXN = 2e5 + 100;
const int INF = 0x3f3f3f3f;
inline ll fpow(ll a, ll b){ ll r = 1, t = a; while (b){ if (b & 1)r = (r*t) % MOD; b >>= 1; t = (t*t) % MOD; }return r; }
struct Edge
{
	int v, w, next;
}e[MAXN << 1];
int head[MAXN], lev[MAXN][25], n, m, cnt, T, X;
int dep[MAXN], val[MAXN], cur[MAXN], sp, tp;
bool vis[MAXN];
void init() {
	MEM(head, -1); MEM(vis, 0);
	cnt = 0;
}
void add(int from, int to, int w) {
	e[cnt].v = to; e[cnt].w = w;
	e[cnt].next = head[from]; head[from] = cnt++;
	e[cnt].v = from; e[cnt].w = 0;
	e[cnt].next = head[to]; head[to] = cnt++;
}
bool bfs() {
	queue <int> q; MEM(dep, 0);
	dep[sp] = 1, q.push(sp);
	while (!q.empty()) {
		int now = q.front();
		q.pop();
		for (int i = head[now]; i != -1; i = e[i].next) {
			int vi = e[i].v;
			if (!dep[vi] && e[i].w) {
				dep[vi] = dep[now] + 1;
				q.push(vi);
			}
		}
	}
	if (dep[tp]) return true;
	else return false;
}
int dfs(int x, int dist) {
	if (x == tp || dist == 0) return dist;
	int res = 0, r;
	for (int &i = cur[x]; i != -1; i = e[i].next) {
		int vi = e[i].v;
		if (dep[vi] == dep[x] + 1 && e[i].w) {
			r = dfs(vi, min(e[i].w, dist - res));
			if (r > 0) {
				e[i].w -= r;
				e[i ^ 1].w += r;
				res += r;
				if (res == dist) return dist;
			}
		}
	}
	if (!res) dep[x] = 0;
	return res;
}
int dinic() {
	int flow = 0, ans;
	while (bfs()) {
		for (int i = sp; i <= tp; i++) cur[i] = head[i];
		flow += dfs(sp, INF);
	}
	return flow;
}
bool check(int x) {
	for (int i = 1; i <= m - x + 1; i++) {
		init();
		for (int j = 1; j <= n; j++) add(sp, j, 1);   
		for (int j = 1; j <= m; j++) add(n + j, tp, val[j]); 
		for (int j = 1; j <= n; j++) {
			for (int k = i; k <= i + x - 1; k++)
				add(j, lev[j][k] + n, 1);  
		}
		int scnt = dinic();
		if (scnt == n) return true;    
	}
	return false;
}
int main()
{
	cin >> n >> m; sp = 0, tp = n + m + 1;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) sc("%d", &lev[i][j]); 
	}
	for (int i = 1; i <= m; i++) sc("%d", &val[i]); 
	int l = 1, r = m, mid;
	int ans = INF;
	while (l <= r) {
		mid = (l + r) >> 1;  
		if (check(mid)) Min(ans, mid), r = mid - 1;  
		else l = mid + 1; 
	}
	cout << ans << endl;
	return 0;
}