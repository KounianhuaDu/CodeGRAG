// Basic Algorithm->Enumerate
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const double epsi = 1e-10;
const double pi = acos(-1.0);
const int maxn = 50005;
struct point{
	double x,y;
	point(){};
	point(double x,double y) :x(x),y(y){};
	point operator - (const point &op2) const{
		return point(x-op2.x,y-op2.y);
	}
	double operator ^ (const point &op2)const{  
		return x*op2.y - y*op2.x;
	}
}p[maxn];
inline int sign(const double &x){  
	if(x>epsi) return 1;
	if(x < -epsi) return -1;
	return 0;
}
inline double sqr(const double &x){
	return x*x;
}
inline double mul(const point &p0,const point &p1,const point &p2){ 
	return (p1-p0) ^ (p2-p0); 
}
inline double dis2(const point &p0,const point &p1){
	return	sqr(p0.x-p1.x)+sqr(p0.y-p1.y);
}
inline double dis(const point &p0,const point &p1){
	return sqrt(dis2(p0,p1));
}
point s;
double r;
int n;
int main(){
	while(~scanf("%lf%lf%lf",&s.x,&s.y,&r) && r >= 0){
		scanf("%d",&n);
		int ans = -1e9;
		for(int i = 0;i < n;i ++)
			scanf("%lf%lf",&p[i].x,&p[i].y);
		for(int i=0;i < n;i ++){
			int tmp = 0;
			for(int j = 0; j < n; j++){
				if(sign(dis(p[j],s)-r)!=1) 
					if(sign(mul(s,p[i],p[j]))!=-1) tmp++;
			}
			ans = std::max(ans,tmp);
		}
		printf("%d\n",ans);
	}
	return 0;
}