// Sorting->Quick Sort,Basic Algorithm->Greedy Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define lson lo, mi, rt << 1
#define rson mi + 1, hi, rt << 1 | 1
using namespace std;
const int maxn = 1e5 + 10;
const int inf = 0x3f3f3f3f;
const double eps = 1e-8;
const double pi = acos(-1.0);
const double ee = exp(1.0);
struct COW
{
    int t, d;
} cow[maxn];
bool cmp(COW a, COW b)
{
    return a.t * b.d < a.d * b.t;
}
int main()
{
#ifdef LOCAL
    freopen("in.txt", "r", stdin);
#endif 
    int n;
    while (~scanf("%d", &n))
    {
        LL sumD = 0;
        for (int i = 0; i < n; i++)
        {
            scanf("%d%d", &cow[i].t, &cow[i].d);
            sumD = sumD + (LL)cow[i].d;
        }
        sort(cow, cow + n, cmp);
        LL ans = 0;
        for (int i = 0; i < n; i++)
        {
            sumD -= cow[i].d;
            ans = ans + 2 * sumD * (LL)cow[i].t;
        }
        printf("%lld\n", ans);
    }
    return 0;
}