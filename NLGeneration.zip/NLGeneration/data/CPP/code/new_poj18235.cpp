// Data Structure->Segment Tree
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAX_INF 9999999
#define MIN_INF -9999999
struct Node
{
   int l,r;
   int max1,min1;
}a[200005];
int max(int n,int m)
{
    return n>m?n:m;
}
int min(int n,int m)
{
    return n<m?n:m;
}
void Build(int n,int l,int r)
{
   a[n].l=l;  
   a[n].r=r;
   a[n].max1=MIN_INF;
   a[n].min1=MAX_INF;
   if(l==r)
   return;
   Build(2*n,l,(l+r)/2);
   Build(2*n+1,(l+r)/2+1,r);         
}
void Insert(int n,int v,int num)
{
   if(a[n].max1<num) a[n].max1=num;
   if(a[n].min1>num) a[n].min1=num;
   if(a[n].l==a[n].r)
   return;
   if(v<=(a[n].l+a[n].r)/2)
   Insert(n*2,v,num);
   else
   Insert(n*2+1,v,num);
}
int QMax(int n,int l,int r)
{
    if(a[n].l==l&&a[n].r==r)
    return a[n].max1;
    if(r<=(a[n].l+a[n].r)/2)
    return QMax(n*2,l,r);
    else
    if(l>=(a[n].l+a[n].r)/2+1)
    return QMax(n*2+1,l,r);
    else
    {
        return max(QMax(n*2,l,(a[n].l+a[n].r)/2),QMax(n*2+1,(a[n].l+a[n].r)/2+1,r));
    }
}
int QMin(int n,int l,int r)
{
    if(a[n].l==l&&a[n].r==r)
    return a[n].min1;
    if(r<=(a[n].l+a[n].r)/2)
    return QMin(n*2,l,r);
    else
    if(l>=(a[n].l+a[n].r)/2+1)
    return QMin(n*2+1,l,r);
    else
    {
        return min(QMin(n*2,l,(a[n].l+a[n].r)/2),QMin(n*2+1,(a[n].l+a[n].r)/2+1,r));
    }
}
void QMinus(int n,int l,int r)
{
    if(a[n].l==l&&a[n].r==r)
    {
        printf("%d\n",a[n].max1-a[n].min1);
    }
    else
    {
        if(r<=(a[n].l+a[n].r)/2)
        QMinus(n*2,l,r);
        else
        if(l>=(a[n].l+a[n].r)/2+1)
        QMinus(n*2+1,l,r);
        else
        {
            int m1=QMax(n*2,l,(a[n].l+a[n].r)/2);
            int m2=QMax(n*2+1,(a[n].l+a[n].r)/2+1,r);
            int m3=QMin(n*2,l,(a[n].l+a[n].r)/2);
            int m4=QMin(n*2+1,(a[n].l+a[n].r)/2+1,r);
            printf("%d\n",max(m1,m2)-min(m3,m4));
        }
    }
}
int main()
{
    int i,j,n,m,x,l,r;
    while(scanf("%d %d",&n,&m)!=EOF)
    {
        Build(1,1,n);
        for(i=1;i<=n;i++)
        {
            scanf("%d",&x);
            Insert(1,i,x);
        }
        for(i=0;i<m;i++)
        {
            scanf("%d %d",&l,&r);
            QMinus(1,l,r);
        }
    }
    return 0;
}