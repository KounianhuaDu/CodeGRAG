// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=3000000;
int n,k;
int ans=0;
bool vis[maxn];
int pace[maxn];
int head,pos;
queue <int> q;
int bfs()
{
    q.push(n);
    while(!q.empty())
    {
        head=q.front();
        q.pop();
        for(int i=0; i<3; ++i)
        {
            if(i==0) pos=head-1;
            else if(i==1) pos=head+1;
            else pos=head*2;
            if(pos<0||pos>100000) continue;
            if(vis[pos]==false)
            {
                q.push(pos);
                pace[pos]=pace[head]+1;
                
                vis[pos]=true;
            }
            if(pos==k) return pace[pos];
        }
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    while(cin>>n>>k)
    {
        memset(vis,false,sizeof(vis));
        if(n>=k) cout<<n-k<<endl;
        else cout<<bfs()<<endl;
    }
    return 0;
}