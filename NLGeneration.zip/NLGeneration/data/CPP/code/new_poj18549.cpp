// Data Structure->Stack
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 110;
char s[N];
bool slove(int p,int q,int r,int s1,int t)
{
    stack<int> Q;
    int len = strlen(s);
    for(int i = len-1; i >= 0; i--)
    {
        if(s[i] == 'p') Q.push(p);
        else if(s[i] == 'q') Q.push(q);
        else if(s[i] == 'r') Q.push(r);
        else if(s[i] == 's') Q.push(s1);
        else if(s[i] == 't') Q.push(t);
        else if(s[i] == 'N')
        {
            int x = Q.top();
            Q.pop();
            x = x==0?1:0;
            Q.push(x);
        }
        else
        {
            int x = Q.top();
            Q.pop();
            int y = Q.top();
            Q.pop();
            if(x && y)
                Q.push(1);
            else if(x && !y)
            {
                if(s[i] == 'A')
                    Q.push(1);
                else
                    Q.push(0);
            }
            else if(!x && y)
            {
                if(s[i] == 'K' || s[i] == 'E')
                    Q.push(0);
                else
                    Q.push(1);
            }
            else
            {
                if(s[i] == 'K' || s[i] == 'A')
                    Q.push(0);
                else
                    Q.push(1);
            }
        }
    }
    return Q.top();
}
int main()
{
    while(~scanf("%s",s))
    {
        if(strcmp(s,"0") == 0)
            break;
        int flag = 1;
        for(int p = 0; p < 2; p++)
            for(int q = 0; q < 2; q++)
                for(int r = 0; r < 2; r++)
                    for(int s1 = 0; s1 < 2; s1++)
                        for(int t = 0; t < 2; t++)
        {
            if(!slove(p,q,r,s1,t))
                flag = 0;
        }
        if(flag == 0)
            printf("not\n");
        else
            printf("tautology\n");
    }
    return 0;
}