// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

typedef long long ll;
using namespace std;
const int maxn = 500 + 10;
const int maxm = 10000 + 10;
const int INF = 10000000;
int E, F, N, W;
int p[maxn], w[maxn];
int dp[maxm+1];
void solve()
{
	for(int i=0; i<=W; i++ )
		dp[i] = INF;
	dp[0] = 0;
	for( int i=1; i<=N; i++ )
	{
		for( int j=w[i]; j<=W; j++ )
		{
			dp[j] = min(dp[j], dp[j-w[i]]+p[i]);
		}
	}
	if( dp[W]!=INF )
		printf("The minimum amount of money in the piggy-bank is %d.\n", dp[W]);
	else
		printf("This is impossible.\n");
}
int main(void)
{
	int t;
	cin>>t;
	while( t-- )
	{
		cin>>E>>F>>N;
		W = F - E;
		for( int i=1; i<=N; i++ )
			scanf("%d %d", &p[i], &w[i]);
		solve();
	}
	return 0;
}