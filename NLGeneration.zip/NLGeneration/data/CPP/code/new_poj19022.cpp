// Data Structure->Trie,Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn=2e6+5;
const int maxc=26;
char s[maxn],rs[maxn];
int l[maxn],r[maxn];
bool book[2][maxn];
int Next[maxn];
int extend[maxn];
void GetNext(char T[],int &m,int Next[]){
	int a=0,p=0;
	Next[0]=m;
	for(int i=1;i<m;i++){
		if(i>=p||i+Next[i-a]>=p){
			if(i>=p)
				p=i;
 
			while(p<m&&T[p]==T[p-i])
				p++;
 
			Next[i]=p-i;
			a=i;
		}else
			Next[i]=Next[i-a];
	}
}
 
void GetExtend(char S[],char T[],int extend[],int Next[],int flag,int l){
	int a=0,p=0;
	int n=strlen(S);
    int m=strlen(T);
	GetNext(T,m,Next);
	for(int i=0;i<n;i++){
		if(i>=p||i+Next[i-a]>=p){
			if(i>=p)
				p=i;
 
			while(p<n&&p-i<m&&S[p]==T[p-i])
				p++;
 
			extend[i]=p-i;
			a=i;
		}else
			extend[i]=Next[i-a];
	}
	for(int i=0;i<n;i++){
		if(i+extend[i]==n) book[flag][l+i]=true;
	}
}
int root=1;
int tot=0;
struct TRIE{
	int Next[maxn][maxc];
	int num[maxn];
	int val[maxn];
	int base;
	void init(){
		for(int i=0;i<=tot;i++) {
			memset(Next[i],0,sizeof(Next[i]));
			num[i]=0;
			val[i]=0;
		}
		tot=1;
	}
	void add(char s[],int now,int l){
		int len=strlen(s);
		for(int i=0;i<len;i++){
			int c=s[i]-base;
			val[now]+=book[0][l+i];
			if(!Next[now][c]){
			 Next[now][c]=++tot;
			} 
			now=Next[now][c];
		}
		num[now]++;
	}
	ll find(char s[],int len,int now,int l){
		ll ans=0;
		for(int i=0;i<len;i++){
			int c=s[i]-base;
			now=Next[now][c];
			if(!now) break;
			if((i<len-1&&book[1][l+i+1])||(i==len-1)) ans+=num[now];
		} 
		if(now) ans+=val[now];
		return ans; 
	}
}tr;
int main(){
    int n; 
    scanf("%d",&n);
    tr.init();
    tr.base='a';
    int sumlen=0;
	for(int i=1;i<=n;i++){
		int len;
		scanf("%d%s",&len,s+sumlen);
		int Len=sumlen+len;
		for(int j=0;j<len;j++){
			rs[sumlen+j]=s[sumlen+len-j-1];
		}
		l[i]=sumlen;
		r[i]=Len-1;
		sumlen=Len;
	    GetExtend(s+l[i],rs+l[i],extend,Next,0,l[i]);
	    GetExtend(rs+l[i],s+l[i],extend,Next,1,l[i]);
	    tr.add(s+l[i],1,l[i]);	
	}
	ll ans=0;
	for(int i=1;i<=n;i++) {
		ans+=tr.find(rs+l[i],r[i]-l[i]+1,1,l[i]);
	}
	printf("%lld\n",ans);
	return 0;
}