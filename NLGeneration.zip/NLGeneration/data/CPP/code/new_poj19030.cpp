// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Point Biconnected Component,Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Maxn 1010
using namespace std;
struct line{
    int fr,to,next;
    bool operator==(line &x)const{
        return (fr==x.fr&&to==x.to)||(fr==x.to&&to==x.fr);
    }
}p[Maxn*Maxn],st[Maxn*Maxn];
int adj[Maxn][Maxn],is[Maxn],color[Maxn];
int head[Maxn],dfn[Maxn],low[Maxn],vis[Maxn];
int tot,tmpdfn,top,cnt;
vector<int> bcc[Maxn];
void addedge(int a,int b){
    p[tot].fr=a;
    p[tot].to=b;
    p[tot].next=head[a];
    head[a]=tot++;
}
void dfs(int u,int fa){
    dfn[u]=low[u]=tmpdfn;
    vis[u]=1;
    for(int i=head[u];i!=-1;i=p[i].next){
        int v=p[i].to;
        if(vis[v]&&dfn[v]<dfn[u]&&v!=fa){
            low[u]=min(low[u],dfn[v]);
            st[top++]=p[i];
        }
        else if(!vis[v]){
            st[top++]=p[i];
            tmpdfn++;
            dfs(v,u);
            low[u]=min(low[u],low[v]);
            if(low[v]>=dfn[u]){
                cnt++;
                while(top--){
                    if(is[st[top].fr]!=cnt){
                        bcc[cnt].push_back(st[top].fr);
                        is[st[top].fr]=cnt;
                    }
                    if(is[st[top].to]!=cnt){
                        bcc[cnt].push_back(st[top].to);
                        is[st[top].to]=cnt;
                    }
                    if(st[top]==p[i]) break;
                }
            }
        }
    }
}
bool bipartite(int u,int cnt){
    for(int i=head[u];i!=-1;i=p[i].next){
        int v=p[i].to;
        if(is[v]!=cnt) continue;
        if(color[u]==color[v]) return false;
        if(!color[v]){
            color[v]=3-color[u];
            if(!bipartite(v,cnt)) return false;
        }
    }
    return true;
}
void solve(int n){
    cnt=0;
    for(int i=1;i<=n;i++) bcc[i].clear();
    memset(vis,0,sizeof vis);
    memset(is,0,sizeof is);
    for(int i=1;i<=n;i++){
        tmpdfn=1,top=0;
        if(!vis[i]) dfs(i,-1);
    }
    memset(vis,0,sizeof vis);
    for(int i=1;i<=cnt;i++){
        memset(color,0,sizeof color);
        for(int j=0;j<bcc[i].size();j++)
            is[bcc[i][j]]=i;
        color[bcc[i][0]]=1;
        if(!bipartite(bcc[i][0],i))
            for(int j=0;j<bcc[i].size();j++)
                vis[bcc[i][j]]=1;
    }
}
int main()
{
    int n,m,a,b;
    while(cin>>n>>m,n){
        memset(adj,0,sizeof adj);
        memset(head,-1,sizeof head);
        tot=0;
        for(int i=0;i<m;i++){
            scanf("%d%d",&a,&b);
            adj[a][b]=adj[b][a]=1;
        }
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(i!=j&&!adj[i][j])
                    addedge(i,j);
        solve(n);
        int ans=n;
        for(int i=1;i<=n;i++)
            if(vis[i]) ans--;
        printf("%d\n",ans);
    }
	return 0;
}