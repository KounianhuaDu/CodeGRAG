// Sorting->Quick Sort,Data Structure->Splay Tree,Basic Algorithm->Binary Search
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define debug 0
#define M(a, b) memset(a, b, sizeof(a))
#define ls ch[x][0]
#define rs ch[x][1]
const int maxn = (1e6 + 10);
struct Splay{
    int pre[maxn], ch[maxn][2], k[maxn], v[maxn];
    int root, rt;
    Splay() {
        root = rt = 0;
        M(pre, 0);
        M(ch, 0);
        M(k, 0);
        M(v, 0);
    }
    void newNode(int &x, int _k, int c, int f) {
        x = ++rt;
        v[x] =  c;
        k[x] = _k;
        pre[x] = f;
    }
    void Rotate(int x, int d) {
        int y = pre[x];
        ch[y][!d] = ch[x][d];
        pre[ch[y][!d]] = y;
        pre[x] = pre[y];
        ch[x][d] = y;
        if (pre[y]) ch[pre[y]][ch[pre[y]][1] == y] = x;
        pre[y] = x;
    }
    void splay(int x, int to) {
        while (pre[x] != to) {
            if (pre[pre[x]] == to) Rotate(x, ch[pre[x]][0] == x);
            else {
                int y = pre[x], z = pre[y];
                int f = (ch[z][1] == y);
                if (ch[y][f] == x)
                    Rotate(y, !f), Rotate(x, !f);
                else
                    Rotate(x, f), Rotate(x, !f);
            }
        }
        if (!to) root = x;
    }
    void insert_node(int _k, int v) {
        int x = root; 
        int r = root;
        while (x) {
            r = x;
            if (k[x] < _k) x = rs;
            else x = ls;
        }
        newNode(ch[r][k[r] < _k] , _k, v, r);
        splay(ch[r][k[r] < _k], root);
        ch[0][0] = ch[0][1] = 0;
    }
    int query(int d) {
        d -= 2;
        int x = root;
        while (ch[x][!d]) x = ch[x][!d];
        if (x == root) root = ch[x][d];
        ch[pre[x]][!d] = ch[x][d];
        pre[ch[x][d]] = pre[x];
        return v[x];
    }
}sp;
int main() {
#ifndef ONLINE_JUDGE
    freopen("in.txt", "r", stdin);
#endif 
    int op, k, v;
    while (cin >> op, op) {
        if (op == 1) {
            cin >> k >> v;
            sp.insert_node(v, k);
        }
        else {
            cout << sp.query(op) << endl;
        }
    }
    return 0;
}