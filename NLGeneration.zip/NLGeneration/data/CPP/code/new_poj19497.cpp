// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Gap Optimization (SAP)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std ;
const int N=500 ;
const int M=100000 ;
const int inf=1<<30 ;
struct node
{
	int u ,v,c,next;
}edge[M] ;
struct node1
{
	int n,m ;
	double x,y;
}e[M] ;
int head[N],dis[N],gap[N],cur[N],pre[N] ;
int top , s,t,sum,n,nv;
double d ;
double Dis(int i,int j)  
{  
    return sqrt(1.0*(e[i].x-e[j].x)*(e[i].x-e[j].x)+(e[i].y-e[j].y)*(e[i].y-e[j].y));  
}  
void add(int u ,int v,int c)     
{    
    edge[top].u=u;    
    edge[top].v=v;    
    edge[top].c=c;    
    edge[top].next=head[u];    
    head[u]=top++;    
    edge[top].u=v;    
    edge[top].v=u;    
    edge[top].c=0;    
    edge[top].next=head[v];    
    head[v]=top++;    
}    
  
int sap()    
{    
    memset(dis,0,sizeof(dis));    
    memset(gap,0,sizeof(gap));    
    int u,v,minflow=inf,flow=0;    
    for(int i = 0 ; i <=nv ; i++)  cur[i]=head[i] ;    
    u=pre[s]=s;    
    gap[s]=nv;    
    while(dis[s] <= nv )    
    {    
            loop :    
               for(int &j=cur[u] ; j!=-1 ; j=edge[j].next)                   
               {    
                     v=edge[j].v ;    
                     if(edge[j].c > 0 && dis[u] == dis[v] +1 )    
                     {    
                              minflow = min(minflow ,edge[j].c) ;    
                              pre[v]=u;    
                              u=v ;    
                          if(v==t)    
                          {      
                                for( u =pre[v] ; v!=s ;v=u,u=pre[u])    
                                      {    
                                            edge[cur[u]].c -= minflow ;     
                                            edge[cur[u]^1].c += minflow ;    
                                      }     
                                flow += minflow ;    
                                minflow = inf ;    
                          }    
                         goto loop ;    
                     }    
               }    
           int mindis=nv ;    
           for(int i = head[u] ; i!=-1 ; i=edge[i].next)    
           {    
                  v=edge[i].v ;    
                  if(edge[i].c > 0 && dis[v] < mindis)    
                  {    
                       mindis = dis[v] ;    
                       cur[u]=i ;           
                 }    
           }    
          if(--gap[dis[u]]==0) break ;    
          gap[ dis[u] = mindis +1 ]++  ;    
          u=pre[u] ;    
    }    
    return flow ;    
}    
  
void make(int mid)
{
	memset(head,-1,sizeof(head)) ;
	top = 0 ;
	s=0,t=2*n+1 ,nv=t+1 ;
	for(int i = 1 ; i <= n ; i++)
	 {
	 	  add(s,i,e[i].n) ;  
	 	 if(i==mid)  
		    add(i,i+n,inf) ; 
	 	 else add(i,i+n,e[i].m) ;
	 } 
	for(int i = 1 ; i <= n ;i++ )
	  for(int j = i+1; j <= n ; j++)
	   {
	   	   if( Dis(i,j) <= d ) 
	   	   	 {
	   	   	   add(i+n,j,inf) ,add(j+n,i,inf)	;
	   	    }
	   }
	  
} 
int main()
{
	int tt ,f[200];
	scanf("%d",&tt) ;
	while(tt--)
	{
		  scanf("%d%lf",&n,&d) ;
		  sum = 0;
		  for(int i = 1 ; i <= n ; i++)
		  {
		  	  scanf("%lf%lf%d%d",&e[i].x,&e[i].y,&e[i].n,&e[i].m) ;
		  	  sum += e[i].n ;
		  }
		  int k = 0 ;
		  for(int i = 1 ; i <= n ; i++)
		  {
		  	    make(i) ;
		  	    add(i+n,t,inf) ;  
		  	  if(sap()==sum)   
		  	  {
		  	  	   f[k++]=i-1 ;
		  	  }
		  }
		 if(k==0)
		    printf("-1\n") ;
		  else
		  {
		  	    printf("%d",f[0]) ;
		  	    for(int  i = 1 ; i < k ; i++)
		  	       printf(" %d",f[i]) ;
		  	     puts("") ;  
		  }  
		
	}
	return 0 ;
}