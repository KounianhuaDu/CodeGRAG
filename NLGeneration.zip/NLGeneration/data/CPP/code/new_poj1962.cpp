// Math and Computational Geometry->Inverse Element
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const LL MD=10007;
LL mulit(LL a,LL b,LL m)
{
    LL ans=0;
    while(b)
    {
        if(b&1) ans=(ans+a)%m;
        a=(a<<1)%m;
        b>>=1;
    }
    return ans;
}
LL quick_mod(LL a,LL b,LL m)
{
    LL ans=1;
    while(b)
    {
        if(b&1) {
            ans=mulit(ans,a,m);
        }
        a=mulit(a,a,m);
        b>>=1;
    }
    return ans;
}
LL comp(LL a,LL b,LL m)
{
    if(a<b) return 0;
    if(a==b) return 1;
    if(b>a-b) b=a-b;
    LL ans=1,ca=1,cb=1;
    for(int i=0;i<b;i++)
    {
        ca=ca*(a-i)%m;
        cb=cb*(b-i)%m;
    }
    ans=ca*quick_mod(cb,m-2,m)%m;
    return ans;
}
LL lucas(LL a,LL b,LL m)
{
    LL ans=1;
    while(a&&b)
    {
        ans=(ans*comp(a%m,b%m,m)%m);
        a/=m;
        b/=m;
    }
    return ans;
}
int main()
{
    LL n;
    while(scanf("%lld",&n)==1)
    {
        if(n==2) printf("2\n");
        else {
            LL k=lucas(1l*2*(n-1),1l*n-1,MD);
            k*=2;
            k%=MD;
            printf("%lld\n",k*quick_mod(n,MD-2,MD)%MD);
        }
    }
    return 0;
}