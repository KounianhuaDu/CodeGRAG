// Sorting->Quick Sort,Data Structure->Disjoint Set Union (DSU),Basic Algorithm->Binary Search
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
#define PI acos(-1.0)
#define N 10000001
#define MOD 123
#define E 1e-6
using namespace std;
struct Node
{
    int x;
    int y;
    int minn;
}a[N],b[N];
int father[N];
int ans;
int n,m;
int read()
{
    int x=0,f=1;
    char ch=getchar();
    for(;!isdigit(ch);ch=getchar())
        if(ch=='-')
            f=-1;
    for(;isdigit(ch);ch=getchar())
        x=(x*2)+(x*8)+ch-'0';
    return x*f;
}
int Find(int x)
{
    if(father[x]==x)
        return x;
    else
    return father[x]=Find(father[x]);
}
bool cmp(Node a,Node b)
{
    return a.minn>b.minn;
}
bool check(int pos)
{
    for(int i=1;i<=n+1;i++)
       father[i]=i;
    for(int i=1;i<=pos;i++)
       b[i]=a[i];
    sort(b+1,b+pos+1,cmp);
    int lmin=b[1].x,lmax=b[1].x,rmin=b[1].y,rmax=b[1].y;
    for(int i=2;i<=pos;i++)
    {
        if(b[i].minn<b[i-1].minn)
        {
            if(Find(lmax)>rmin)
                return true;
            for(int j=lmin;j<=rmax;j++)
            {
                j=Find(j);
                father[j]=Find(rmax+1);
            }
            lmax=lmin=b[i].x;
            rmax=rmin=b[i].y;
        }
        else if(b[i].minn==b[i-1].minn)
        {
             lmax=max(lmax,b[i].x);
             lmin=min(lmin,b[i].x);
             rmax=max(rmax,b[i].y);
             rmin=min(rmin,b[i].y);
             if(lmax>rmin)
                return true;
        }
    }
    if(Find(lmax)>rmin)
        return true;
    else
        return false;
}
int main()
{
    n=read();
    m=read();
    for(int i=1;i<=m;i++)
    {
        a[i].x=read();
        a[i].y=read();
        a[i].minn=read();
    }
    int l=1,r=m,mid;
    while(r-l>1)
    {
        int mid=(l+r)/2;
        if(check(mid))
        {
            ans=mid;
            r=mid;
        }
        else
            l=mid;
    }
    printf("%d\n",ans);
    return 0;
}