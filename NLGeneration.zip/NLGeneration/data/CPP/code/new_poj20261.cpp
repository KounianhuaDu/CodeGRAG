// Sorting->Quick Sort,Dynamic Programming->Priority Queue,Basic Algorithm->Binary Search
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 100100
#define x first
#define y second
#define ll long long
#define P pair<int, int>
#define INF 1e9
struct node
{
    int a, b, c;
};
int n, p, k;
vector<node> ve;
vector<P> vec[maxn/100 + 10];
int d[maxn/100 + 10];
void build(int m)   
{
    for (int i = 0; i < p; ++i)
    {
        if (ve[i].c < m)
        {
            vec[ve[i].a].push_back(P(0, ve[i].b));
            vec[ve[i].b].push_back(P(0, ve[i].a));
        }
        else
        {
            vec[ve[i].a].push_back(P(1, ve[i].b));
            vec[ve[i].b].push_back(P(1, ve[i].a));
        }
    }
}
int dij()  
{
    fill(d, d + n + 1, maxn); 
    priority_queue<P, vector<P>, greater<P> > que;
    que.push(P(0, 1));
    d[1] = 0;
    while(!que.empty())
    {
        P pa = que.top();
        que.pop();
        if (d[pa.y] < pa.x) continue;
        for (int i = 0; i < vec[pa.y].size(); ++i)
        {
            P t = vec[pa.y][i];
            if (d[t.y] > d[pa.y] + t.x)
            {
                d[t.y] = d[pa.y] + t.x;
                que.push(P(d[t.y], t.y));
            }
        }
    }
    return d[n];
}
int main()
{
    scanf("%d%d%d", &n, &p, &k);
    for (int i = 0; i < p; ++i)
    {
        node num;
        scanf("%d%d%d", &num.a, &num.b, &num.c);
        ve.push_back(num);
    }
    ll lb = 0, rb = (ll)0x7fffffff + 10;
    while(rb - lb > 1)
    {
        for (int i = 0; i <= n; ++i)
            vec[i].clear();
        ll mid = (lb + rb) / 2;
        build(mid);
        if (dij() > k)  
        {
            lb = mid;
        }
        else
        {
            rb = mid;
        }
    }
    if (lb > (ll)0x7fffffff) lb = -1;
    printf("%lld\n", lb);
    return 0;
}