// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Graph Algorithm->Min-Cost Max-Flow
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL long long
const int INF = 0x3f3f3f3f;
#define MAXN 100100
#define MAXM 1000100
int vis[MAXN],d[MAXN],pre[MAXN],aa[MAXN];
struct Edge
{
    int u, v, c, cost, next;
} edge[MAXM];
int s[MAXN], cnt;
void init()
{
    cnt = 0;
    memset(s, -1, sizeof(s));
}
void add(int u, int v, int c, int cost)
{
    edge[cnt].u = u;
    edge[cnt].v = v;
    edge[cnt].cost = cost;
    edge[cnt].c = c;
    edge[cnt].next = s[u];
    s[u] = cnt++;
    edge[cnt].u = v;
    edge[cnt].v = u;
    edge[cnt].cost = -cost;
    edge[cnt].c = 0;
    edge[cnt].next = s[v];
    s[v] = cnt++;
}
bool spfa(int ss, int ee,int &flow,int &cost)
{
    queue<int> q;
    memset(d, INF, sizeof d);
    memset(vis, 0, sizeof vis);
    d[ss] = 0, vis[ss] = 1, pre[ss] = 0, aa[ss] = INF;
    q.push(ss);
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        vis[u] = 0;
        for (int i = s[u]; ~i; i = edge[i].next)
        {
            int v = edge[i].v;
            if (edge[i].c>0&& d[v]>d[u] + edge[i].cost)
            {
                d[v] = d[u] + edge[i].cost;
                pre[v] = i;
               aa[v] = min(aa[u], edge[i].c);
                if (!vis[v])
                {
                    vis[v] = 1;
                    q.push(v);
                }
            }
        }
    }
    if (d[ee] == INF) return 0;
    flow += aa[ee];
    cost += d[ee]*aa[ee];
    int u = ee;
    while (u != ss)
    {
        edge[pre[u]].c -= aa[ee];
        edge[pre[u] ^ 1].c += aa[ee];
        u = edge[pre[u]].u;
    }
    return 1;
}
int MCMF(int ss, int ee)
{
    int cost = 0, flow=0;
    while (spfa(ss, ee, flow, cost));
    return cost;
}
int a[300],b[300];
int main()
{
    int T,m,n,k,u,v,c;
    for(scanf("%d",&T);T--;)
    {
        init();
        scanf("%d%d",&n,&k);
        add(100001,100002,k,0);
        add(100003,100004,k,0);
        for(int i=0;i<n;i++)
        {
            scanf("%d%d%d",&a[i],&b[i],&c);
            add(a[i],b[i],1,-c);
            add(100002,a[i],1,0);
            add(b[i],100003,1,0);
        }
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
        {
            if(b[i]<a[j])
                add(b[i],a[j],1,0);
        }
        printf("%d\n",-MCMF(100001,100004));
    }
    return 0;
}