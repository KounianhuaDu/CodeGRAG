// Data Structure->Stack,Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
vector <int> E[150]; 
int mat[150][150]; 
int low[105], dfn[105], s[105], top, clk;
bool instack[105], vis[105]; 
void Tarjan(int u, int fa){
    low[u] = dfn[u] = ++clk;
    s[top++] = u;
    instack[u] = 1;
    for(int i = 0; i < E[u].size(); i++){
        int v = E[u][i];
        if(v == fa && mat[u][v] > 1){
            if(mat[u][v] % 2 == 0) vis[u] = 1;
            continue;
        }
        if(!dfn[v]){
            Tarjan(v, u);
            low[u] = min(low[u], low[v]);
        }
        else if(v != fa && instack[v]){
            low[u] = min(low[u], dfn[v]);
        }
    }
    if(low[u] == dfn[u]){
        int cnt = 1;
        top--;
        while(s[top] != u){
            vis[s[top]] = 1;
            top--;
            cnt++;
        }
        if(cnt&&(cnt&1)) vis[s[top+1]] = false;
    }
}
int getsg(int u, int fa){
    int ret = 0;
    for(int i = 0; i < E[u].size(); i++){
        int v = E[u][i];
        if(!vis[v] && v != fa){
            ret ^= (1 + getsg(v, u));
        }
    }
    return ret;
}
int main()
{
    int k, n, m;
    while(scanf("%d", &k) != EOF)
    {
        int ret = 0;
        while(k--){
            scanf("%d%d", &n, &m);
            for(int i = 1; i <= n; i++) E[i].clear();
            memset(mat, 0, sizeof(mat));
            memset(low, 0, sizeof(low));
            memset(dfn, 0, sizeof(dfn));
            memset(instack, 0, sizeof(instack));
            memset(vis, 0, sizeof(vis));
            top = clk = 0;
            while(m--){
                int u, v;
                scanf("%d%d", &u, &v);
                mat[u][v]++, mat[v][u]++;
                E[u].push_back(v), E[v].push_back(u);
            }
            Tarjan(1, -1);
            ret ^= getsg(1, -1);
        }
        puts(ret?"Sally":"Harry");
    }
    return 0;
}