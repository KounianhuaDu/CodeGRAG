// Basic Algorithm->Recursion,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Lowest Common Ancestor (LCA),Basic Algorithm->Binary Lifting
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

const int maxn=5e4+5;
const int mod=20190414;
const int inf=1e9;
const long long onf=1e18;
#define me(a,b) memset(a,b,sizeof(a))
#define lowbit(x) x&(-x)
#define mid l+(r-l)/2
#define lson l,mid,rt<<1
#define rson mid+1,r,rt<<1|1
#define PI 3.14159265358979323846
int dir[4][2]= {0,-1,-1,0,0,1,1,0};
int dx[]= {-2,-2,-1,-1,1,1,2,2};
int dy[]= {-1,1,-2,2,-2,2,-1,1};
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
int val[maxn],head[maxn<<1],cnt;
int Max[maxn][33],Min[maxn][33],up[maxn][33],down[maxn][33],father[maxn][33];
int depth[maxn];
int n;
struct node{
    int v,next;
}tree[maxn<<1];
void init() {
    cnt=0;
    me(head,-1);
}
void add_edge(int u,int v){
    tree[cnt].v=v;
    tree[cnt].next=head[u];
    head[u]=cnt++;
}
void BFS(int root){
    queue<int>q;
    father[root][0]=root;
    depth[root]=0;
    q.push(root);
    while(!q.empty()){
        int fa=q.front();
        q.pop();
        for(int i=1;(1<<i)<=n;i++){
            father[fa][i]=father[father[fa][i-1]][i-1];
            Max[fa][i]=max(Max[fa][i-1],Max[father[fa][i-1]][i-1]);
            Min[fa][i]=min(Min[fa][i-1],Min[father[fa][i-1]][i-1]);
            down[fa][i]=max(max(0,Max[fa][i-1]-Min[father[fa][i-1]][i-1]),max(down[fa][i-1],down[father[fa][i-1]][i-1]));
            up[fa][i]=max(max(0,Max[father[fa][i-1]][i-1]-Min[fa][i-1]),max(up[father[fa][i-1]][i-1],up[fa][i-1]));
        }
        for(int i=head[fa];i!=-1;i=tree[i].next){
            int v=tree[i].v;
            if(v==father[fa][0])
                continue ;
            father[v][0]=fa;
            depth[v]=depth[fa]+1;
            Max[v][0]=max(val[fa],val[v]);
            Min[v][0]=min(val[fa],val[v]);
            down[v][0]=max(0,val[v]-val[fa]);
            up[v][0]=max(0,val[fa]-val[v]);
            q.push(v);
        }
    }
}
int LCA(int u,int v){
    if(depth[u]>depth[v])
        swap(u,v);
    for(int ret=depth[v]-depth[u],i=0;ret;ret>>=1,i++){
        if(ret&1)
            v=father[v][i];
    }
    if(u==v)
        return v;
    for(int i=log2(n);i>=0;i--){
        if(father[u][i]==father[v][i])
            continue ;
        v=father[v][i];
        u=father[u][i];
    }
    return father[u][0];
}
int get_up(int u,int ret,int &min_val){
    int ans=0;
    min_val=inf;
    for(int i=log2(n);i>=0;i--){
        if(ret&(1<<i)){
            ans=max(ans,Max[u][i]-min_val);
            min_val=min(min_val,Min[u][i]);
            ans=max(ans,up[u][i]);
            u=father[u][i];
        }
    }
    return ans;
}
int get_down(int v,int ret,int &max_val){
    int ans=0;
    max_val=0;
    for(int i=log2(n);i>=0;i--){
        if(ret&(1<<i)){
            ans=max(ans,max_val-Min[v][i]);
            max_val=max(max_val,Max[v][i]);
            ans=max(ans,down[v][i]);
            v=father[v][i];
        }
    }
    return ans;
}
int main()
{
    init();
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&val[i]);
    for(int i=1;i<n;i++){
        int u,v;
        scanf("%d%d",&u,&v);
        add_edge(u,v),add_edge(v,u);
    }
    BFS(1);
    int q;
    scanf("%d",&q);
    while(q--){
        int u,v;
        scanf("%d%d",&u,&v);
        int t_father=LCA(u,v);
        int Max,Min;
        int temp2=get_up(u,depth[u]-depth[t_father],Min);
        int temp1=get_down(v,depth[v]-depth[t_father],Max);
        int ans=max(max(temp1,temp2),max(0,Max-Min));
        printf("%d\n",ans);
    }
    return 0;
}