// Dynamic Programming->Manacher's Algorithm
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;
typedef long long LL;
const int inf=0x3f3f3f3f;
const double pi= acos(-1.0);
const double esp=1e-6;
const int maxn=1000010;
char str[maxn];
char s[maxn*2];
int p[maxn*2];
int len;
void Manacher()
{
    int i;
    s[0]='$';
    s[1]='#';
    for(i=0;i<len; i++) {
        s[i*2+2]=str[i];
        s[i*2+3]='#';
    }
    len=i*2+2;
    s[len]='\0';
    int MaxL,id=0;
    MaxL=0;
    memset(p,0,sizeof(p));
    for(int i=0; i<len; i++) {
        if(p[id]+id>i)
            p[i]=min(p[2*id-i],p[id]+id-i);
        else
            p[i]=1;
        while(s[i+p[i]]==s[i-p[i]])
            p[i]++;
        if(p[i]+i>p[id]+id) {
            id=i;
        }
        if(p[i]>MaxL)
            MaxL=p[i];
    }
    printf("%d\n",MaxL-1);
}
int main()
{
    int icase=1;
    while(~scanf("%s",&str)) {
        if(strcmp(str,"END")==0)
            break;
        len=strlen(str);
        printf("Case %d: ",icase++);
        Manacher();
    }
    return 0;
}