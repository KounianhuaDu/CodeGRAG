// Data Structure->Queue,Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=505;
const int inf=0x3f3f3f3f;
int n,m,idx;
int head[maxn],d[maxn];
bool vis[maxn];
struct edge
{
    int v,val;
    int nxt;
}edges[maxn*maxn];
void init()
{
    memset(head,-1,sizeof head);
    memset(vis,false,sizeof vis);
    memset(d,0x3f,sizeof d);
    idx=0;
}
void add(int u,int v,int val)
{
    edges[idx].v=v;
    edges[idx].val=val;
    edges[idx].nxt=head[u];
    head[u]=idx++;
    edges[idx].v=u;
    edges[idx].val=val;
    edges[idx].nxt=head[v];
    head[v]=idx++;
}
void spfa()
{
    queue<int> que;
    que.push(1);
    vis[1]=true;
    d[1]=0;
    while(!que.empty())
    {
        int tmp=que.front();
        que.pop();
        vis[tmp]=false;
        for(int u=head[tmp];u!=-1;u=edges[u].nxt)
        {
            int v=edges[u].v;
            if(d[tmp]+edges[u].val<d[v])
            {
                d[v]=d[tmp]+edges[u].val;
                if(!vis[v])
                {
                    vis[v]=true;
                    que.push(v);
                }
            }
        }
    }
}
int main()
{
    int u,v,cost,test=0;
    while(scanf("%d %d",&n,&m),n||m)
    {
        init();
        while(m--)
        {
            scanf("%d %d %d",&u,&v,&cost);
            add(u,v,cost);
        }
        spfa();
        double tim=0.0;
        int domino=1;
        for(int i=2;i<=n;i++)
        {
            if(tim<d[i])
            {
                tim=(double)d[i];
                domino=i;
            }
        }
        int le=domino;
        double tt=tim;
        bool flag=true;
        for(u=head[domino];u!=-1;u=edges[u].nxt)
        {
            if(d[u]+edges[u].val!=d[domino])
            {
                v=edges[u].v;
                double tmp=(double)(edges[u].val-(d[domino]-d[v]))/2.0;
                if(tt<tmp+tim)
                {
                    tt=tim+tmp;
                    le=v;
                    flag=false;
                }
            }
        }
        if(le>domino) swap(le,domino);
        printf("System #%d\n",++test);
        if(flag) printf("The last domino falls after %.1lf seconds, at key domino %d.\n\n",tim,domino);
        else printf("The last domino falls after %.1lf seconds, between key dominoes %d and %d.\n\n",tt,le,domino);
    }
    return 0;
}