// Graph Algorithm->Maximum Flow Algorithm,Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 3100;
const int MAXM = 20010;
const int INF = 0x3f3f3f3f;
struct Edge
{
	int  to, cap, next;
};
Edge edge[MAXM];
int level[MAXN];
int head[MAXN];
int first[MAXN];
int pigs[MAXN];
int src, des, cnt;
inline void addedge(int from, int to, int cap)
{
	edge[cnt].to = to;
	edge[cnt].cap = cap;
	edge[cnt].next = head[from];
	head[from] = cnt++;
	edge[cnt].to = from;
	edge[cnt].cap = 0;
	edge[cnt].next = head[to];
	head[to] = cnt++;
}
int bfs()
{
	queue<int> q;
	while (!q.empty())
		q.pop();
	memset(level, -1, sizeof level);
	level[src] = 0;
	q.push(src);
	while (!q.empty())
	{
		int u = q.front();
		q.pop();
		for (int i = head[u]; i != -1; i = edge[i].next)
		{
			int v = edge[i].to;
			if (edge[i].cap > 0 && level[v] == -1)
			{
				level[v] = level[u] + 1;
				q.push(v);
			}
		}
	}
	return level[des] != -1;
}
int dfs(int u, int f)
{
	if (u == des) return f;
	int tem;
	for (int i = head[u]; i != -1; i = edge[i].next)
	{
		int v = edge[i].to;
		if (edge[i].cap > 0 && level[v] == level[u] + 1)
		{
			tem = dfs(v, min(f, edge[i].cap));
			if (tem > 0)
			{
				edge[i].cap -= tem;
				edge[i ^ 1].cap += tem;
				return tem;
			}
		}
	}
	level[u] = -1;
	return 0;
}
int Dinic()
{
	int ans = 0, tem;
	while (bfs())
	{
		while (tem = dfs(src, INF))
		{
			ans += tem;
		}
	}
	return ans;
}
int main()
{
	int n, m;
	src = 0;
	des = 305;
	while (~::scanf("%d%d", &m, &n))
	{
		memset(head, -1, sizeof head);
		memset(first, -1, sizeof first);
		cnt = 0;
		int keys, keynum, buy;
		for (int i = 1; i <= m; i++)
		{
			scanf("%d", &pigs[i]);
		}
		for (int i = 1; i <= n; i++)
		{
			scanf("%d", &keys);
			int mine = 0;
			for (int j = 1; j <= keys; j++)
			{
				scanf("%d", &keynum);
				if (first[keynum] == -1)
				{
					first[keynum] = i;
					mine += pigs[keynum];
				}
				else
				{
					addedge(first[keynum], i, INF);
				}
			}
			if (mine)
				addedge(src, i, mine);
			scanf("%d", &buy);
			addedge(i, des, buy);
		}
		printf("%d\n", Dinic());
	}
	return 0;
}