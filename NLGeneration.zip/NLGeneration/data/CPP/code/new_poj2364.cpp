// Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int maptt1[30][30];
int visit[500];
int step[4][2]={-1,0,1,0,0,1,0,-1};
int sum=1,max1=1;
int m,n;
void dfs(int x,int y)
{
	int i;
	for(i=0 ;i<4 ; i++)
	{
		int a=x+step[i][0];
		int b=y+step[i][1];
		if(a >=1&&b >=1&&a <=m&&b<=n&& !visit[maptt1[a][b]])
		{
			sum++;
			visit[maptt1[a][b]]=1;
			dfs(a,b);
			if(sum>max1)
				max1=sum;
			sum--;
			visit[maptt1[a][b]]=0;	
		} 
	}
	return; 
}
int main()
{
	char p;
	while(scanf("%d%d",&m,&n)!=EOF)
	{
		memset(visit,0,sizeof(visit));
		memset(maptt1,0,sizeof(maptt1));
		getchar();
		for(int i=1;i<=m;i++)
			{
			 for(int j=1;j<=n;j++)
				{
				 scanf("%c",&p);
				 maptt1[i][j]=p-'A';
			    }
			    getchar();
			}
		visit[maptt1[1][1]]=1;
		dfs(1,1);
		printf("%d\n",max1);
	} 
	return 0;
}