// Basic Algorithm->Divide and Conquer,Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

          
typedef struct __data {
   char *data;
   int point;
   int len;
} da;
da *charTimes(da *a,da *b){              
	char *aChar=(a->data);
	char *bChar=(b->data);
	
	int aLen=a->len;
	int bLen=b->len;
	int ansLen=aLen+bLen;
	int ansPoint=a->point+b->point;
	
	da *ans=(da *)calloc(1,sizeof(da));
	char *ansChar=(char *)calloc(ansLen,sizeof(char));
	char *temp=(char *)malloc((bLen+1)*aLen*sizeof(char));
	
	int i,j;
	int sum;
	
	for (i=0;i<aLen;i++){      
		 sum=0;
	   for (j=0;j<bLen;j++){
	   	 sum+=(bChar[j]-'0')*(aChar[i]-'0');
	     temp[i*(bLen+1)+j]=sum%10+'0';
	     sum=sum/10;
	   }
	   temp[i*(bLen+1)+j]=sum%10+'0';
	}
	
	sum=0;                        
	for (i=0;i<ansLen;i++){       
		 if (i-aLen+1>0){
		 	  j=i-aLen+1;
		 }
		 else j=0;
		 for (;((i-j)>=0)&&(j<=bLen);j++){
	     sum=sum+(temp[(i-j)*(bLen+1)+j]-'0');
	   }
	   ansChar[i]=sum%10+'0';
	   sum=sum/10;
	}
  free(temp);
  
  ans->data=ansChar;
  ans->point=ansPoint;
  ans->len=ansLen;
  return ans;
}
da *power_cal(da *a,int power){   
	da *ans;
	da *temp,*temp2;
	if (power==1){
		 da *ans=(da *)calloc(1,sizeof(da));
	   char *ansChar=(char *)calloc(a->len,sizeof(char));
	   ans->len=a->len;
	   ans->point=a->point;
	   ans->data=ansChar;
	   memcpy(ansChar,a->data,(a->len)*sizeof(char));
	   return ans;
	}
	else if (power==2){
	   return charTimes(a,a);
	}
	if (power%2==1){
		 temp=power_cal(a,power/2);
		 temp2=power_cal(temp,2);
		 ans=charTimes(temp2,a);
		 free(temp->data);
     free(temp);	
     free(temp2->data);
     free(temp2);		 
  }
  else {
  	 temp=power_cal(a,power/2);
		 ans=power_cal(temp,2);
		 free(temp->data);
     free(temp);		 
  }	
	return ans;
}
int printData(da *a){          
	char *aChar=a->data;
	int i;
	int len=a->len;
	int subfix=0;
	int prefix=0;
	char *buffer;
	
	buffer=(char *)malloc((len+2)*sizeof(char));
	
	memcpy(buffer,aChar,a->point);
	buffer[a->point]='.';
	memcpy(&(buffer[a->point+1]),&(aChar[a->point]),len-(a->point));
	buffer[len+1]='\0';
	
	for (i=0;i<=len;i++){
	  if (buffer[i]!='0'){
	    break;
	  }
	}
	subfix=i;
	if (buffer[subfix]=='.'){     
		subfix++;
	}
	
	for (i=len;i>=0;i--){
	  if (buffer[i]!='0'){
	    break;
	  }
	}
	prefix=i;
	
	for (i=prefix;i>=subfix;i--){
    printf("%c",buffer[i]);
  }
  
  free(buffer);
  printf("\n");
}
int main(){
   char readTemp[20];
   int power;
   int aLen;
   int i;
   char *aChar;
   da *ans;
   da *a;
   
   while(scanf("%s %d",readTemp,&power)!=EOF){          
     aLen=strlen(readTemp);
     
     a=(da *)calloc(1,sizeof(da));
	   aChar=(char *)calloc(aLen,sizeof(char));
     
     a->point=0;                          
     for (i=0;i<aLen;i++){
     	  if (readTemp[aLen-i-1]=='.'){   	     
     	     a->point=i;
     	     i--;
     	     aLen=aLen-1;
     	  }
     	  else {
           aChar[i]=readTemp[aLen-i-1];
        }
     }
     
     a->data=aChar;
     a->len=aLen;
     
     ans=power_cal(a,power);
     
     printData(ans);
     
     free(ans->data);
     free(a->data);
     free(ans);
     free(a);
   }
   return 0;
}