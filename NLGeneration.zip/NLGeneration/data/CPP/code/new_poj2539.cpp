// Basic Algorithm->Enumerate
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 10 
using namespace std;
int a[N],tem[N],t[N];
int main()
{
	for(int i=1;i<=9;i++)
	scanf("%d",&a[i]);
	for(t[1]=0;t[1]<=3;t[1]++)
	for(t[2]=0;t[2]<=3;t[2]++)
	for(t[3]=0;t[3]<=3;t[3]++)
	for(t[4]=0;t[4]<=3;t[4]++)
	for(t[5]=0;t[5]<=3;t[5]++)
	for(t[6]=0;t[6]<=3;t[6]++)
	for(t[7]=0;t[7]<=3;t[7]++)
	for(t[8]=0;t[8]<=3;t[8]++)
	for(t[9]=0;t[9]<=3;t[9]++)	
	{
		tem[1]=(a[1]+t[1]+t[2]+t[4])%4;
		tem[2]=(a[2]+t[1]+t[2]+t[3]+t[5])%4;
		tem[3]=(a[3]+t[2]+t[3]+t[6])%4;
		tem[4]=(a[4]+t[1]+t[4]+t[5]+t[7])%4;
		tem[5]=(a[5]+t[1]+t[3]+t[5]+t[7]+t[9])%4;
		tem[6]=(a[6]+t[3]+t[5]+t[6]+t[9])%4;
		tem[7]=(a[7]+t[4]+t[7]+t[8])%4;
		tem[8]=(a[8]+t[5]+t[7]+t[8]+t[9])%4;
		tem[9]=(a[9]+t[6]+t[8]+t[9])%4;
		if(tem[1]+tem[2]+tem[3]+tem[4]+tem[5]+tem[6]+tem[7]+tem[8]+tem[9]==0)
		{
			for(int i=0;i<t[1];i++)	printf("1 ");
			for(int i=0;i<t[2];i++)	printf("2 ");
			for(int i=0;i<t[3];i++)	printf("3 ");
			for(int i=0;i<t[4];i++)	printf("4 ");
			for(int i=0;i<t[5];i++)	printf("5 ");
			for(int i=0;i<t[6];i++)	printf("6 ");
			for(int i=0;i<t[7];i++)	printf("7 ");
			for(int i=0;i<t[8];i++)	printf("8 ");
			for(int i=0;i<t[9];i++)	printf("9 ");	
			break;
		}
	}
    
	return 0;
}