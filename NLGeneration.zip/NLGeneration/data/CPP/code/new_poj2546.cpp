// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define M 30000
#define N 100005
using namespace std;
int A[N][30],B[M][30],a[N],b[M],arr[N];
void get_next(int *next,int m)
{
	int i,j=1,k=0;
	next[1]=0;
	while(j<=m)
	{
		int si=0,sj=0,ei=0,ej=0;
		for(i=1;i<b[j];i++)
			si+=B[j][i]-B[j-k][i];
		ei=B[j][i]-B[j-k][i];
		for(i=1;i<b[k];i++)
			sj+=B[k][i];
		ej=B[k][i];
		if(k==0||si==sj&&ei==ej)
		{
			j++;k++;
			next[j]=k;
		}
		else
			k=next[k];
	}
}
int kmp(int m,int n)
{
	int *next=new int[m+5];
	get_next(next,m);
	int i=1,j=1,k,ans=0;
	while(i<=n)
	{
		int si=0,sj=0,ei=0,ej=0;
		for(k=1;k<a[i];k++)
			si+=A[i][k]-A[i-j][k];
		ei=A[i][k]-A[i-j][k];
		for(k=1;k<b[j];k++)
			sj+=B[j][k];
		ej=B[j][k];
		if(j==0||si==sj&&ei==ej)
			i++,j++;
		else
			j=next[j];
		if(j>m)
		{
			arr[ans++]=i-j+1;
			j=next[j];
		}
	}
	return ans;
}
int main()
{
	int i,n,k,s,ans;
	
	
	while(~scanf("%d%d%d",&n,&k,&s))
	{
		memset(A,0,sizeof(A));
		memset(B,0,sizeof(B));
		for(i=1;i<=n;i++)
		{
			scanf("%d",a+i);
			A[1][a[1]]=1;
			if(i>1)
				memcpy(A[i],A[i-1],sizeof(A[0]));
			A[i][a[i]]++;
		}
		for(i=1;i<=k;i++)
		{
			scanf("%d",b+i);
			B[1][b[1]]=1;
			if(i>1)
				memcpy(B[i],B[i-1],sizeof(B[0]));
			B[i][b[i]]++;
		}
		printf("%d\n",ans=kmp(k,n));
		for(i=0;i<ans;i++)
			printf("%d\n",arr[i]);
	}
	return 0;
}