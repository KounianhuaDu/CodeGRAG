// Graph Algorithm->Floyd-Warshall Algorithm
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 64;
const int d1[8][2] = {1, 2, 1, -2, 2, 1, 2, -1, -1, 2, -1, -2, -2, 1, -2, -1};
const int d2[8][2] = {1, 1, 1, -1, 1, 0, 0, 1, 0, -1, -1, -1, -1, 0, -1, 1};
const int INF = 0x3f3f3f3f;
int g1[N][N], g2[N][N];
char str[505];
int king, knight[N], kn;
int main() {
    memset(g1, INF, sizeof(g1));
    memset(g2, INF, sizeof(g2));
    for (int i = 0; i < 64; i++) {
	g1[i][i] = 0;
	g2[i][i] = 0;
    }
    for (int i = 0; i < 8; i++) {
	for (int j = 0; j < 8; j++) {
	    for (int k = 0; k < 8; k++) {
		int x1 = i + d1[k][0];
		int y1 = j + d1[k][1];
		int x2 = i + d2[k][0];
		int y2 = j + d2[k][1];
		if (x1 >= 0 && x1 < 8 && y1 >= 0 && y1 < 8)
		    g1[i * 8 + j][x1 * 8 + y1] = 1;
		if (x2 >= 0 && x2 < 8 && y2 >= 0 && y2 < 8)
		    g2[i * 8 + j][x2 * 8 + y2] = 1;
	    }
	}
    }
    for (int k = 0; k < 64; k++) {
	for (int i = 0; i < 64; i++) {
	    for (int j = 0; j < 64; j++) {
		g1[i][j] = min(g1[i][j], g1[i][k] + g1[k][j]);
		g2[i][j] = min(g2[i][j], g2[i][k] + g2[k][j]);
	    }
	}
    }
    while (~scanf("%s", str)) {
	int len = strlen(str);
	king = (str[0] - 'A') * 8 + (str[1] - '0' - 1);
	kn = 0;
	for (int i = 2; i < len; i += 2)
	    knight[kn++] = (str[i] - 'A') * 8 + (str[i + 1] - '0' - 1);
	int ans = INF;
	for (int i = 0; i < 64; i++) {
	    for (int j = 0; j < 64; j++) {
		int sum = g2[king][j];
		for (int k = 0; k < kn; k++)
		    sum += g1[knight[k]][i];
		int tot = INF;
		for (int k = 0; k < kn; k++) {
		    if (sum - g1[knight[k]][i] + g1[knight[k]][j] + g1[j][i] < tot)
			tot = sum - g1[knight[k]][i] + g1[knight[k]][j] + g1[j][i];
		}
		ans = min(ans, tot);
	    }
	}
	printf("%d\n", ans);
    }
    return 0;
}