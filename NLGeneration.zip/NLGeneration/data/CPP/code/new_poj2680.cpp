// Dynamic Programming->Dynamic Programming (DP) on Intervals
#include<bits/stdc++.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 400000
int n,ans;
char op[105];
int num[105],ma[105][105],mi[105][105];
vector<int> lt;
int mmax(int s,int k,int t,char z)
{
    if(z=='t')
        return ma[s][k-1]+ma[k][t];
    else
        return max(ma[s][k-1]*ma[k][t],mi[s][k-1]*mi[k][t]);
}
int mmin(int s,int k,int t,char z)
{
    if(z=='t')
        return mi[s][k-1]+mi[k][t];
    else
        return min(ma[s][k-1]*ma[k][t],mi[s][k-1]*mi[k][t]);
}
int main()
{
    scanf("%d\n",&n);
    for(int i=0;i<n;i++){
        scanf("%c %d%*c",&op[i],&num[i]);
        op[i+n]=op[i];
        num[i+n]=num[i];    
    }
    for(int i=0;i<2*n;i++){
        for(int j=0;j<2*n;j++){
            ma[i][j]=-INF;
            mi[i][j]=INF;
        }
    }
    for(int i=0;i<(n<<1);i++){
        ma[i][i]=mi[i][i]=num[i];
    }
        #ifdef TEST
    for(int i=0;i<2*n;i++){
        for(int j=0;j<2*n;j++){
            cout<<ma[i][j]<<' ';
        }
        cout<<endl;
    }
    #endif 
    for(int d=1;d<=n;d++){
        for(int s=0;s<2*n-d+1;s++){
            int t=s+d-1;
            for(int k=s+1;k<=t;k++){
                ma[s][t]=max(ma[s][t],mmax(s,k,t,op[k]));
                mi[s][t]=min(mi[s][t],mmin(s,k,t,op[k]));
            }
        }
    }
    #ifdef TEST
    for(int i=0;i<2*n;i++){
        for(int j=0;j<2*n;j++){
            cout<<ma[i][j]<<' ';
        }
        cout<<endl;
    }
    #endif 
    ans=-INF;
    lt.clear();
    for(int i=0;i<n;i++){
        if(ma[i][i+n-1]>ans){
            ans=ma[i][i+n-1];
            lt.clear();
            lt.push_back(i+1);
        }
        else if(ma[i][i+n-1]==ans){
            lt.push_back(i+1);
        }
    }
    printf("%d\n",ans);
    printf("%d",lt[0]);
    for(int i=1;i<lt.size();i++){
        printf(" %d",lt[i]);
    }
    printf("\n");
    return 0;
}