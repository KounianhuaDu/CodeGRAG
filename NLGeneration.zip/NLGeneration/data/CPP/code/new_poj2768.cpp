// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 100005;
char s1[7],s2[7];
int ans;
bool flag[10][10][10][10][10][10][10];
struct node
{
    char s[7];
    char pos[7];
    int step,cur;
    bool left;
}ss,now;
struct que
{
    struct node t[N];
    int head,tail;
    void init()
    {
        head = tail = 0;
    }
    bool empty()
    {
        return head == tail;
    }
    struct node top()
    {
        return t[head];
    }
    void pop()
    {
        head ++ ;
        if(head >= N)
            head %= N;
    }
    void push(struct node a)
    {
        t[tail] = a;
        tail ++;
        if(tail >= N)
            tail %= N;
    }
}q;
int getstate()
{
    if(ss.pos[0]=='1'&&ss.pos[1]=='0'&&ss.pos[2]=='0'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='0')
        return 0;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='0'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='0')
        return 1;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='0')
        return 2;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='1'&&ss.pos[4]=='0'&&ss.pos[5]=='0')
        return 3;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='1'&&ss.pos[4]=='1'&&ss.pos[5]=='0')
        return 4;
    if(ss.pos[0]=='1'&&ss.pos[1]=='0'&&ss.pos[2]=='0'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='1')
        return 5;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='0'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='1')
        return 6;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='0'&&ss.pos[4]=='0'&&ss.pos[5]=='1')
        return 7;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='1'&&ss.pos[4]=='0'&&ss.pos[5]=='1')
        return 8;
    if(ss.pos[0]=='1'&&ss.pos[1]=='1'&&ss.pos[2]=='1'&&ss.pos[3]=='1'&&ss.pos[4]=='1'&&ss.pos[5]=='1')
        return 9;
    return -1;
}
int getans()
{
    int ret = 0;
    int i;
    for(i = 0;i < 6;i ++)
    {
        if(now.pos[i] == '1')
            ret += abs(now.s[i] - s2[i]);
        else
        {
            if(now.s[i] != s2[i])
                return 100000;
        }
    }
    return ret + now.step;
}
int bfs()
{
    q.init();
    memset(flag,0,sizeof(flag));
    strcpy(ss.s,s1);
    ans = 10000;
    strcpy(ss.pos,"100000");
    ss.cur = ss.step = 0;
    ss.left = false;
    flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][0] = 1;
    q.push(ss);
    while(!q.empty())
    {
        now = q.top();
        if(now.step > ans)
            break;
        
        
        int ttt = getans();
        if(ans > ttt)
            ans = ttt;
        q.pop();
        if(now.cur)
        {
            ss = now;
            ss.step ++;
            int tp;
            if(ss.left == false)
            {
                ss.pos[ss.cur] = '0';
                ss.cur --;
                ss.left = true;
                ss.pos[ss.cur] = '1';
                tp = getstate();
                if(!flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp])
                {
                    flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp] = 1;
                    q.push(ss);
                }
            }
            ss = now;
            ss.step ++;
            tp = getstate();
            char c = ss.s[0];
            ss.s[0] = ss.s[ss.cur];
            ss.s[ss.cur] = c;
            if(!flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp])
            {
                flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp] = 1;
                q.push(ss);
            }
        }
        if(now.cur < 5)
        {
            ss = now;
            ss.step ++;
            ss.cur ++;
            ss.pos[ss.cur] = '1';
            int tp = getstate();
            if(!flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp])
            {
                flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp] = 1;
                q.push(ss);
            }
            ss = now;
            ss.step ++;
            ss.pos[5] = '1';
            char c = ss.s[5];
            ss.s[5] = ss.s[ss.cur];
            ss.s[ss.cur] = c;
            tp = getstate();
            if(!flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp])
            {
                flag[ss.s[0] - '0'][ss.s[1] - '0'][ss.s[2] - '0'][ss.s[3] - '0'][ss.s[4] - '0'][ss.s[5] - '0'][tp] = 1;
                q.push(ss);
            }
        }
    }
    return ans;
}
int main()
{
    
    while(scanf("%s%s",s1,s2) != EOF)
    {
        printf("%d\n",bfs());
    }
    return 0;
}