// Basic Algorithm->Arbitrary-Precision Arithmetic,Basic Algorithm->Recurrence
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define rep(i,a) for(int i = 0;i < a;i ++)
using namespace std;
const int N = 500010;
struct BigDouble
{
	int num[333];
	int len;
	BigDouble(char s[],int len){
		this->len = len;
		
		int L = strlen(s);
		for(int i = 0;i <= L - i - 1;i ++)
			swap(s[i],s[L - i - 1]);
		for(int i = 0;s[i] != '\0';i ++)
		num[i] = s[i] - '0';
	}
	BigDouble(){
		len = 1;
		memset(num,0,sizeof(num));
	}
	void setOne(){
		memset(num,0,sizeof(num));
		num[0] = 1;
		len = 1;
	}
	friend BigDouble operator*(BigDouble a,BigDouble b)
	{
		BigDouble res;
		for(int i = 0;i < a.len;i ++)
		{
			for(int j = 0;j < b.len;j ++)
			{
				res.num[i + j] += a.num[i] * b.num[j];
				res.num[i + j + 1] += res.num[i + j]/10;
				res.num[i + j]%= 10;
			}
		}
		for(int i = 300;i >= 0;i --){
			if(res.num[i] != 0){
				res.len = i + 1;
				break;
			}
		}
		return res;
	}
	void print()
	{
		int s = len - 1;
		for(;s >= 0;s --)printf("%d",num[s]);
			puts("");
	}
};
int main(){
	char num[333];
	int n;
	while(cin >> num >> n)
	{
		bool point = false;
		int local = 0;
		for(int i = 0;num[i] != '\0';i ++)
		{
			if(num[i] == '.'){
				point = true;
				local = i;
				break;
			}
		}
		int l = strlen(num);
		for(int i = l- 1;i > local;i --)
			if(num[i] == '0')l--;
		else break;
		if(point){
		for(int i = local;i < l;i ++)
			num[i] = num[i + 1];
		l--;num[l] = '\0';
		local = l - local;
		local *= n;
		}
		
		
		
		BigDouble res;
		res.num[0] = 1;
		BigDouble tmp(num,l);
		
		for(int i = 1;i <= n;i ++)
			res = res*tmp;
		int s = res.len - 1;
		
		if(point){
			local = res.len - local;
			if(local < 0)printf(".");
			while(local < 0){
			    printf("0");local++;
			}
		}
		
		for(int j = 1;s >= 0;s --,j ++)
		{
			printf("%d",res.num[s]);
			if(j == local && s)printf(".");
		}
		puts("");
	}
	
	return 0;
}