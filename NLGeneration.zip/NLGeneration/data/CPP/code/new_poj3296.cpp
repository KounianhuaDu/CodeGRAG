// Data Structure->Stack,Graph Algorithm->Tarjan's Algorithm,Graph Algorithm->Strongly Connected Components
#include<set>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define debug cout<<"aaa"<<endl
#define d(a) cout<<a<<endl
#define mem(a,b) memset(a,b,sizeof(a))
#define LL long long
#define lson l,mid,root<<1
#define rson mid+1,r,root<<1|1
#define MIN_INT (-2147483647-1)
#define MAX_INT 2147483647
#define MAX_LL 9223372036854775807i64
#define MIN_LL (-9223372036854775807i64-1)
using namespace std;
const int N = 100 + 5;
const int mod = 1000000000 + 7;
const double eps = 1e-8;
int head[N],len;
int dfn[N],low[N],dfs_num;
int color[N],col_num;
int stacktt1[N],vis[N],top;
int outd[N],ind[N];
int ans1,ans2; 
struct EdgeNode{
	int from,to,next;
}edge[N*N];
void add(int i,int j){
	edge[len].from=i;
	edge[len].to=j;
	edge[len].next=head[i];
	head[i]=len++;
} 
void init(int n){
	mem(outd,0),mem(ind,0),mem(vis,0),mem(dfn,0),mem(low,0),mem(head,-1),len=ans1=ans2=top=col_num=dfs_num=0;
}
void tarjan(int x){
	dfn[x]=++dfs_num;
	low[x]=dfs_num;
	vis[x]=1;
	stacktt1[++top]=x;
	for(int i=head[x];i!=-1;i=edge[i].next){
		int temp=edge[i].to;
		if(!dfn[temp]){
			tarjan(temp);
			low[x]=min(low[x],low[temp]);
		}
		else if(vis[temp]){
			low[x]=min(dfn[temp],low[x]);
		}
	} 
	if(dfn[x]==low[x]){
		vis[x]=0;
		
		color[x]=++col_num; 
		while(stacktt1[top]!=x){
			color[stacktt1[top]]=col_num;
			vis[stacktt1[top]]=0;
			top--; 
		}
		top--;
	}
}
void solve(int n){
	for(int i=1;i<=n;i++){
		if(!dfn[i]){
			tarjan(i);
		}
	}
	
	for(int i=0;i<len;i++){
		if(color[edge[i].from]!=color[edge[i].to]){
			ind[color[edge[i].to]]++;
			outd[color[edge[i].from]]++;
		}
	}
	for(int i=1;i<=col_num;i++){
		
		if(ind[i]==0){
			ans1++;
		}
		if(outd[i]==0){
			ans2++;
		}
	} 
}
int main(){
	int n,m,u,v;
	while(~scanf("%d",&n)){
		init(n);
		for(int i=1;i<=n;i++){
			while(scanf("%d",&v)&&v){
				add(i,v);	
			}
		}
		solve(n);
		if(col_num==1){
			puts("1");
			puts("0");
			continue;
		}
		printf("%d\n",ans1);
		printf("%d\n",max(ans1,ans2));
	}
	return 0;
}