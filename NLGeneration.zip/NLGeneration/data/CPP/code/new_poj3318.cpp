// Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 33
int m,id[maxn],ans;
char pre[maxn],post[maxn];
int C(int a,int b)
{
    int ans=1;
    for(int i=1;i<=a-b;i++)
        ans=ans*(b+i)/i;
    return ans;
}
void count(int a,int b,int c,int d)
{
    if(a>b)return ;
    int cnt=0;
    a++;
    int k=id[pre[a]-'a'];
    while(c<d)
    {
        cnt++;
        int l=k-c;
        count(a,a+l,c,k);
        c=k+1,a=a+l+1;
        k=id[pre[a]-'a'];
    }
    ans*=C(m,cnt);
}
int main()
{
    while(~scanf("%d",&m),m)
    {
        scanf("%s%s",pre,post);
        int len=strlen(pre);
        for(int i=0;i<len;i++)
            id[post[i]-'a']=i;
        ans=1;
        count(0,len-1,0,len-1);
        printf("%d\n",ans);
    }
    return 0;
}