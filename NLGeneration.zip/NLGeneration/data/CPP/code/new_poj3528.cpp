// Graph Algorithm->Kruskal's Algorithm,Data Structure->Disjoint Set Union (DSU)
/* POJ1258 Agri-Net */
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 100;
int f[N + 1], fcnt;
void UFInit(int n)
{
    for(int i = 1; i <=n; i++)
        f[i] = i;
    fcnt = n;
}
int Find(int a) {
    return a == f[a] ? a : f[a] = Find(f[a]);
}
bool Union(int a, int b)
{
    a = Find(a);
    b = Find(b);
    if (a != b) {
        f[a] = b;
        fcnt--;
        return true;
    } else
        return false;
}
struct Edge {
    int src, dest, cost;
} edges[N * N];
bool cmp(Edge a, Edge b)
{
    return a.cost < b.cost;
}
int main()
{
    int n, cost, cnt2;
    while(~scanf("%d", &n)) {
        UFInit(n);
        cnt2 = 0;
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++) {
                scanf("%d", &cost);
                if(j > i) {
                    edges[cnt2].src = i;
                    edges[cnt2].dest = j;
                    edges[cnt2++].cost = cost;
                }
            }
        sort(edges, edges + cnt2, cmp);
        int ans = 0;
        for(int i = 0; i < cnt2; i++) {
            if(Union(edges[i].src, edges[i].dest)) {
                ans += edges[i].cost;
                if(fcnt == 1)
                    break;
            }
        }
        printf("%d\n", ans);
    }
    return 0;
}