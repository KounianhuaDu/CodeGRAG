// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem

#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=100000+9;
int f[N],w[N],c[N],num[N],V,n;
void ZeroOnePack(int C,int W)
{
    for(int v=V;v>=C;v--)
        f[v]=max(f[v],f[v-C]+W);
}
void CompletePack(int C,int W)
{
    for(int v=C;v<=V;v++)
        f[v]=max(f[v],f[v-C]+W);
}
int MultiplePack()
{
    memset(f,0,sizeof(f));
    for(int i=1;i<=n;i++){
        if(num[i]*c[i]>V)
            CompletePack(c[i],w[i]);
        else{
            int k=1;
            while(k<num[i]){
                ZeroOnePack(k*c[i],k*w[i]);
                num[i]-=k;
                k<<=1;
            }
            ZeroOnePack(num[i]*c[i],num[i]*w[i]);
        }
    }
    return f[V];
}
int main()
{
    
    while(~scanf("%d%d",&V,&n)){
        for(int i=1;i<=n;i++){
            scanf("%d%d",&num[i],&c[i]);
            w[i]=c[i];
        }
        printf("%d\n",MultiplePack());
    }
    return 0;
}