// Basic Algorithm->Greedy Algorithm
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define NUM 1001
using namespace std;
    
struct QU_jian
{
    double l;
    double r;
    bool operator<(const QU_jian& t)const{
        return this->l<t.l;
    }
}N[NUM];
int main()
{
    int n,d;
    double island_x,island_y;
    int k = 1;
    while(cin>>n>>d&&n&&d){
        int radar_min_num = 1;
        for (int i = 0;i<n;i++){
            cin>>island_x>>island_y;
            if(island_y<=d && d>0 && island_y>=0){
                N[i].r=island_x+(double)sqrt(d*d - island_y*island_y);
                N[i].l=island_x-(double)sqrt(d*d - island_y*island_y);
            }
            else{
                radar_min_num = -1;
            }
        }
            
        sort(N, N+n);
            
        double temp = N[0].r;
        for( int i = 1;(i<n && radar_min_num != -1);i++){
            if(temp<N[i].l){
                temp = N[i].r;
                radar_min_num++;
            }
            else{
                if(N[i].r<temp)
                    temp = N[i].r;
            }
        }
            
        cout <<"Case "<<k++<<": "<<radar_min_num<<endl;
    }
    return 0;
}