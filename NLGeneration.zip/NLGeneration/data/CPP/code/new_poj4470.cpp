// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N 50000
using namespace std;
int _map[55][55];
int vis[55][55][4]; 
int dirx[4] = {0,-1,0,1}; 
int diry[4] = {1,0,-1,0};
int m, n, b1, b2, e1, e2;
char normal_dir[6]; 
struct node
{
    int x; 
    int y;
    int dir; 
    int time; 
};
bool can_go(int x, int y) 
{
    if(x<1 || y<1 || x>m-1 || y>n-1) 
        return false;
    if(_map[x][y] || _map[x+1][y] || _map[x][y+1] || _map[x+1][y+1]) 
        return false;
    return true;
}
int normaldir(char ch) 
{
    if(ch == 'e') return 0;
    if(ch == 'n') return 1;
    if(ch == 'w') return 2;
    if(ch == 's') return 3;
}
int bfs()
{
    queue<node> q; 
    node start;
    start.x = b1, start.y = b2, start.dir = normaldir(normal_dir[0]), start.time = 0;
    q.push(start); 
    vis[start.x][start.y][start.dir] = 1;
    while(!q.empty()) 
    {
        node cur;
        cur = q.front(); 
        if(cur.x == e1 && cur.y == e2) return cur.time; 
        q.pop(); 
        int x = cur.x, y = cur.y;
        for(int i = 1; i <= 3; i ++){ 
            x += dirx[cur.dir];
            y += diry[cur.dir];
            if(!can_go(x, y)) break; 
            if(!vis[x][y][cur.dir]){
                node next;
                next.x = x;
                next.y = y;
                next.dir = cur.dir;
                next.time = cur.time + 1;
                vis[next.x][next.y][next.dir] = 1;
                q.push(next); 
            }
        }
        for(int i = 0; i < 4; i ++){ 
            if(max(cur.dir, i) - min(cur.dir, i) == 2) 
                continue;
            if(vis[cur.x][cur.y][i])
                continue;
            node next;
            next.x = cur.x;
            next.y = cur.y;
            next.dir = i;
            next.time = cur.time + 1;
            vis[next.x][next.y][next.dir] = 1;
            q.push(next); 
        }
    }
    return -1; 
}
int main()
{
    while(scanf("%d%d", &m, &n) && m && n)
    {
        memset(_map, 0, sizeof(_map));
        memset(vis, 0, sizeof(vis));
        for(int i = 1; i <= m;i ++)
            for(int j = 1; j <= n; j ++)
            scanf("%d", &_map[i][j]);
        scanf("%d%d%d%d%s", &b1, &b2, &e1, &e2, normal_dir);
        printf("%d\n",bfs());
    }
    return 0;
}