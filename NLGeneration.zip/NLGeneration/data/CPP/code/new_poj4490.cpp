// Basic Algorithm->Simulated Annealing (SA)
#include <iostream>  
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
  
  
  
  
  
  
  
  
  
  
#define maxn 50005
#define maxm 40005
#define eps 1e-10
#define mod 1000000007
#define INF 999999999
#define lowbit(x) (x&(-x))
#define mp mark_pair
#define ls o<<1
#define rs o<<1 | 1
#define lson o<<1, L, mid  
#define rson o<<1 | 1, mid+1, R  
typedef long long LL;
using namespace std;
LL qpow(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base;base=base*base;b/=2;}return res;}
LL powmod(LL a, LL b){LL res=1,base=a;while(b){if(b%2)res=res*base%mod;base=base*base%mod;b/=2;}return res;}
void scanf(int &__x){__x=0;char __ch=getchar();while(__ch==' '||__ch=='\n')__ch=getchar();while(__ch>='0'&&__ch<='9')__x=__x*10+__ch-'0',__ch = getchar();}
LL gcd(LL _a, LL _b){if(!_b) return _a;else return gcd(_b, _a%_b);}
int dir[8][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
struct node
{
	double x, y;
}p[maxn];
double a, b;
int n;
void read(void)
{
	scanf("%lf%lf%d", &a, &b, &n);
	for(int i = 1; i <= n; i++) scanf("%lf%lf", &p[i].x, &p[i].y);
}
bool check(double x, double y)
{
	if(x < 0 || y < 0) return false;
	if(x > a || y > b) return false;
	return true;
}
double calculate(double x, double y)
{
	double mi = INF;
	for(int i = 1; i <= n; i++) {
		double t1 = x - p[i].x;
		double t2 = y - p[i].y;
		double t = t1 * t1 + t2 * t2;
		t = sqrt(t);
		mi = min(t, mi);
	}
	return mi;
}
void work(void)
{
	double step = max(a, b), next = 0.99;
	double x = a/2, y = b/2, dis, xx, yy;
	dis = calculate(x, y);
	while(step > eps) {
		for(int i = 0; i < 8; i++) {
			xx = x + step * dir[i][0];
			yy = y + step * dir[i][1];
			if(check(xx, yy)) {
				double t = calculate(xx, yy);
				if(dis < t) dis = t, x = xx, y = yy;
			}
		}
		step *= next;
	}
	printf("The safest point is (%.1f, %.1f).\n", x, y);
}
int main(void)
{
	int _;
	while(scanf("%d", &_)!=EOF) {
		while(_--) {
			read();
			work();
		}
	}
	return 0;
}