// Data Structure->Segment Tree
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn=500010;
const int inf=0x3f3f3f3f;
ll num[maxn*4];
int A1[maxn],A[maxn];
void update(int pos,int le,int ri,int node){
    if(le==ri){
        num[node]++;
        return ;
    }
    int t=(le+ri)>>1;
    if(pos<=t) update(pos,le,t,node<<1);
    else update(pos,t+1,ri,node<<1|1);
    num[node]=num[node<<1]+num[node<<1|1];
}
ll query(int l,int r,int le,int ri,int node){
    if(l<=le&&ri<=r){
        return num[node];
    }
    int t=(le+ri)>>1;
    ll ans=0;
    if(l<=t) ans+=query(l,r,le,t,node<<1);
    if(r>t) ans+=query(l,r,t+1,ri,node<<1|1);
    return ans;
}
int main(){
    int n;
    while(scanf("%d",&n)!=-1){
        if(n==0) break;
        memset(num,0,sizeof(num));
        for(int i=1;i<=n;i++){
            scanf("%d",&A1[i]);
            A[i]=A1[i];
        }
        sort(A+1,A+1+n);
        ll ans=0;
        for(int i=1;i<=n;i++){
            int t=lower_bound(A+1,A+1+n,A1[i])-A;
            ans+=query(t,n,1,n,1);
            update(t,1,n,1);
        }
        printf("%lld\n",ans);
    }
    return 0;
}