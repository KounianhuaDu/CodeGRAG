// Data Structure->Segment Tree
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
using namespace std;
const int maxn=5555;
int sum[maxn<<2];
int a[maxn];
void PushUP(int rt)
{
    sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}
void build(int l,int r,int rt)
{
    int m;
    sum[rt]=0;
    if(l==r)
        return ;
    m=(l+r)>>1;
    build(lson);
    build(rson);
}
int query(int L,int R,int l,int r,int rt)
{
    int m;
    if(L<=l&&R>=r)
    {
        return sum[rt];
    }
    int ans=0;
    m=(l+r)>>1;
    if(L<=m)
        ans+=query(L,R,lson);
    if(R>m)
        ans+=query(L,R,rson);
    return ans;
}
void update(int pos,int l,int r,int rt)
{
    int m;
    if(l==r&&l==pos)
    {
        sum[rt]++;
        return ;
    }
    m=(l+r)>>1;
    if(pos<=m)
        update(pos,lson);
    else
        update(pos,rson);
    PushUP(rt);
}
int main()
{
    int i,n,sum;
    while(~scanf("%d",&n))
    {
        sum=0;
        build(0,n-1,1);
        for(i=0; i<n; i++)
        {
            scanf("%d",&a[i]);
            sum+=query(a[i],n-1,0,n-1,1);}}}