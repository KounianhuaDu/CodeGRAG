// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
using namespace std;
const int N=1005;
bool had[N*5];
string a[12];
queue<string>str;
int MOD(string s,int n)
{
    int k=0;
    for(int i=0;i<s.size();++i)
    {
        k=(k*10+s[i]-'0')%n;
    }
    return k;
}
int main()
{
    
    int n,m;
    while(cin>>n>>m)
    {
        while(!str.empty())
        str.pop();
        memset(had,false,sizeof(had));
        for(int i=0;i<m;++i)
        {
            cin>>a[i];
        }
        if(n==0)
        {
            printf("0\n");
            continue;
        }
        sort(a,a+m);
        string ans="0";
        int i;
        for(i=0;i<m;++i)
        {
            if(a[i]!="0")
            {
                int l=MOD(a[i],n);
                if(l==0)
                {
                    ans=a[i];
                    break;
                }
                if(!had[l])
                {
                    had[l]=true;
                    str.push(a[i]);
                }
            }
        }
        if(i>=m)
        while(!str.empty())
        {
            string x=str.front();
            str.pop();
            int j;
            for(j=0;j<m;++j)
            {
                string k=x+a[j];
                int l=MOD(k,n);
                if(had[l]==false)
                {
                    had[l]=true;
                    if(l==0)
                    {
                        ans=k;
                        break;
                    }
                    str.push(k);
                }
            }
            if(j<m)
            break;
        }
        cout<<ans<<endl;
    }
    return 0;
}