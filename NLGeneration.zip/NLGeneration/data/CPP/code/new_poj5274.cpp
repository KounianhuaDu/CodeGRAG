// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 999999999
int n,m;
int mat[1005][1005];
int d[1005];
int vis[1005]; 
int N;
int main(){
    scanf("%d",&N);
    int cases=0; 
    while(N--){
        cases++;
        scanf("%d%d",&n,&m);
        
        memset(mat,-1,sizeof(mat));
        memset(d,-1,sizeof(d)); 
        memset(vis,0,sizeof(vis));
        int a,b,w;
        for(int i=0;i<m;i++){
            scanf("%d%d%d",&a,&b,&w);
            mat[a][b]=mat[b][a]=w;
        }
        
        
        d[1]=INF;
        vis[1]=true;
        for(int i=2;i<=n;i++){
            if(mat[1][i]!=-1){
                d[i]=mat[1][i];
            }
        }
        for(int i=0;i<n-2;i++){
            int minF=-INF;
            int v=0;
            
            for(int j=1;j<=n;j++){
                if(vis[j]==0&&d[j]!=-1){
                    if(d[j]>minF){
                        minF=d[j];
                        v=j;
                    }
                }
            }
            
            vis[v]=1;
            for(int j=1;j<=n;j++){
                if(vis[j]==0&&mat[v][j]!=-1&&d[j]<min(d[v],mat[v][j])){
                    d[j]=min(d[v],mat[v][j]);
                }
            }
        }
        
        printf("Scenario #%d:\n",cases);
        printf("%d\n\n",d[n]);
    }
    return 0;
}