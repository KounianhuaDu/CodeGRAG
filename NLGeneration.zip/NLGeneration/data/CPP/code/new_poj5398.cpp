// Basic Algorithm->Depth First Search (DFS),Dynamic Programming->Tree-Based Dynamic Programming,Basic Algorithm->Recursion
#include <stdio.h>  
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
  
  
  
  
using namespace std ;  
#define MAX 1510  
vector<vector<int>> tree(MAX) ;  
int f[MAX] , n , dp[MAX][2];  
  
void DFS(int root)  
{  
    dp[root][0]=0;  
    dp[root][1]=1;  
    int len = tree[root].size();  
    for(int i = 0 ; i < len ; i ++)  
    {  
        DFS(tree[root][i]) ;  
        dp[root][1] += min(dp[tree[root][i]][1],dp[tree[root][i]][0]) ;  
        dp[root][0] += dp[tree[root][i]][1] ;  
    }  
}  
int main()  
{  
    int edge , fa , son ;  
    while(scanf("%d",&n)!=EOF)  
    {  
        memset(f , -1 , sizeof(f)) ;  
        for(int i = 1 ; i <= n ; i ++)  
        {  
            scanf("%d:(%d)", &fa , &edge);  
            tree[fa].clear();  
            while(edge --)  
            {  
                scanf("%d",&son) ;  
                tree[fa].push_back(son) ;  
                f[son] = fa ;  
            }  
        }  
        int a = 1 ;  
        while(f[a]!= -1) a=f[a];  
        DFS(a);  
        printf("%d\n" , min(dp[a][0],dp[a][1])) ;  
    }  
    return 0 ;  
}