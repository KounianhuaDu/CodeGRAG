// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define N 1010
#define M 1000010
#define min(a,b) ((a) < (b) ? (a) : (b))
struct Edge{
    int from, to, next, flag;
}E[M];
int head[N], pre[N], lowlink[N];
int tot, n, m, dfs_clock;
void AddEdge(int u, int v) {
    E[tot].from = u;
    E[tot].to = v;
    E[tot].flag = 0;
    E[tot].next = head[u];
    head[u] = tot++;
}
void init() {
    memset(head, -1, sizeof(head));
    tot = 0;
    int u, v;
    for (int i = 0; i < m; i++) {
        scanf("%d%d", &u, &v);
        AddEdge(u, v);
        AddEdge(v, u);
    }
}
void dfs(int u, int fa) {
    pre[u] = lowlink[u] = ++dfs_clock;
    int v;
    for (int i = head[u]; i != -1; i = E[i].next) {
        v = E[i].to;
        if (E[i].flag) continue;
        E[i].flag = 1;
        E[i ^ 1].flag = -1;
        if (!pre[v]) {
            dfs(v, u);
            lowlink[u] = min(lowlink[u], lowlink[v]);
            if (lowlink[v] > pre[u])
                E[i ^ 1].flag = 1;
        }
        else if (v != fa) 
            lowlink[u] = min(lowlink[u], pre[v]);
    }
}
int cas = 1;
void solve() {
    memset(pre, 0, sizeof(pre));
    dfs_clock = 0;
    for (int i = 1; i <= n; i++)
        if (!pre[i])
            dfs(i, -1);
    printf("%d\n\n", cas++);
    int u, v;
    for (int i = 0; i < tot; i++) {
        u = E[i].from;
        v = E[i].to;
        if (E[i].flag == 1)
            printf("%d %d\n", u, v);
    }
    printf("#\n");
}
int main() {
    while (scanf("%d%d", &n, &m) != EOF && n + m) {
        init();
        solve();
    }
    return 0;
}