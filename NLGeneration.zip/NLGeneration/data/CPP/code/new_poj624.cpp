// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

  using namespace std;
#define Abigail inline void
typedef long long LL;
const int N=5000;
int ri(){
  char c=getchar();
  int x=0,y=1;
  for (;c<'0'||c>'9';c=getchar()) if (c=='-') y=-1;
  for (;c<='9'&&c>='0';c=getchar()) x=x*10+c-'0';
  return x*y;
}
int rc(){
  char c=getchar();
  while (c<'a'||c>'z') c=getchar();
  return c=='o'?1:0;
}
int n,ord[N*2+9],x[N+9],y[N+9],a[N+9];
int fa[N*2+9],d[N*2+9],ans;
int lower(int k){
  int l=1,r=n<<1,mid=l+r>>1;
  for (;l<r;mid=l+r>>1)
    k<=ord[mid]?r=mid:l=mid+1;
  return l;
}
int get(int u){
  if (u==fa[u]) return u;
  int rot=get(fa[u]);d[u]^=d[fa[u]];
  return fa[u]=rot;
}
Abigail into(){
  ri();n=ri();
  for (int i=1;i<=n;++i){
  	x[i]=ri()-1;y[i]=ri();a[i]=rc();
  	ord[i*2-1]=x[i];ord[i*2]=y[i];
  }
}
Abigail work(){
  sort(ord+1,ord+1+2*n);
  for (int i=0;i<=n;++i)
    x[i]=lower(x[i]),y[i]=lower(y[i]);
  for (int i=1;i<=n<<1;++i) fa[i]=i;
  int u,v;
  ans=n;
  for (int i=1;i<=n;++i){
  	u=get(x[i]);v=get(y[i]);
  	if (u==v&&d[x[i]]^d[y[i]]^a[i]){ans=i-1;return;}
  	fa[v]=u,d[v]=d[x[i]]^d[y[i]]^a[i];
  }
}
Abigail outo(){
  printf("%d\n",ans);
}
int main(){
  into();
  work();
  outo();
  return 0;
}