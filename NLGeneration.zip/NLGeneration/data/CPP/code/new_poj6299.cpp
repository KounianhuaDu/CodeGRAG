// Data Structure->Disjoint Set Union (DSU)
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 30005;
int father[maxn];
int sum[maxn];
void init() {
    for(int i = 0 ; i < maxn ; i++) {
        father[i] = i;
        sum[i] = 1;
    }
}
int find(int x) {
    return father[x] == x ? x : find(father[x]);
}
int check(int x,int y) {
    return find(x) == find(y);
}
void unionn(int x,int y) {
    int p1 = find(x),p2 = find(y);
    if(p1==p2) return;
    father[p1] = p2;
    sum[p2] += sum[p1];
}
int k;
int tmp[30005];
int main() {
    int a,b;
    while(cin >> a >> b) {
        int ans = 1;
        if (a == 0 && b == 0) return 0;
        else if (a != 0 && b == 0) cout << 1 << endl;
        else {
            init();
            while(b--) {
                int t,fi,se;
                cin >> t;
                cin >> fi;
                t--;
                while(t--) {
                    cin >> se;
                    unionn(fi,se);
                }
            }
            cout << sum[find(0)] << endl;
        }
    }
    return 0;
}