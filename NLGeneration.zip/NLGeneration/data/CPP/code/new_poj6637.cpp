// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#ifdef WIN
typedef __int64_t LL;
#define iform "%I64d"
#define oform "%I64d\n"
#define oform1 "%I64d"
#else
typedef long long LL;
#define iform "%lld"
#define oform "%lld\n"
#define oform1 "%lld"
#endif
#define S64I(a) scanf(iform, &(a))
#define P64I(a) printf(oform, (a))
#define S64I1(a) scanf(iform1, &(a))
#define P64I1(a) printf(oform1, (a))
#define FOR(i, s, t) for(int (i)=(s); (i)<(t); (i)++)
const int INF = 0x3f3f3f3f;
const double eps = 10e-9;
const double PI = (4.0*atan(1.0));
const int maxn = 1000 + 20;
int n;
int vis[maxn];
int num;
int limtDept;
bool dfs() {
    if(num > limtDept) return false;
    if(vis[num] == n) return true;
    if(vis[num]<<(limtDept-num) < n) return false;
    for(int i=0; i<=num; i++) {
        num++;
        vis[num] = vis[num-1] + vis[i];
        if(vis[num] <= 2000 && dfs()) return true;
        vis[num] = vis[num-1] - vis[i];
        if(vis[num] > 0 && dfs()) return true;
        num--;
    }
    return false;
}
int main() {
    while(scanf("%d", &n) != EOF && n) {
        memset(vis, 0, sizeof(vis));
        limtDept = 0;
        while(limtDept <= 20) {
            vis[num=0] = 1;
            if(dfs()) break;
            limtDept++;
        }
        printf("%d\n", limtDept);
    }
    return 0;
}