// Data Structure->Trie
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

struct trie{
        trie *next[10];
        int v;
        trie(){
                v=1;
                for(int i=0;i<10;i++) next[i]=NULL;
        }
}*root;
void create_trie(char *str){
        int len=strlen(str);
        trie *p=root,*q;
        for(int i=0;i<len;i++){
                int id=str[i]-'0';
                if(p->next[id]==NULL){
                        q=new trie;
                        p->next[id]=q;
                        p=p->next[id];
                }
                else{
                        p->next[id]->v++;
                        p=p->next[id];
                }
        }
        p->v=-1;
}
int find_trie(char *s){
        int len=strlen(s);
        trie *q=root;
        for(int i=0;i<len;i++){
                int id=s[i]-'0';
                q=q->next[id];
                if(q==NULL) return 0;
                if(q->v==-1) return -1;
        }
        return -1;
}
void delete_trie(trie* q){
        if(q==NULL) return ;
        for(int i=0;i<10;i++) delete_trie(q->next[i]);
        delete q;
}
int main()
{
        int t,n,i;
        char s[15];
        scanf("%d",&t);
        while(t--){
                scanf("%d",&n);
                root=new trie;
                int flag=0;
                for(i=0;i<n;i++){
                        scanf("%s",s);
                        if(flag) continue;
                        if(find_trie(s)==-1) flag=1;
                        if(flag) continue;
                        create_trie(s);
                }
                if(flag) puts("NO");
                else puts("YES");
                delete_trie(root);
        }
}