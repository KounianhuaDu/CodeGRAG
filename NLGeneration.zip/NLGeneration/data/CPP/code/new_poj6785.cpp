// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct rect
{
    int lx,ly,rx,ry,col;
}r[16];
int n,ans,deg[16];
int m[16][16];
int vis[16];
void build()
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(r[i].ry==r[j].ly&&!(r[i].lx>=r[j].rx||r[i].rx<=r[j].lx))
            {
                m[i][j]=1;
                deg[j]++;
            }
        }
    }
}
void dfs(int dep,int cnt,int color)
{
    if(cnt>=ans) return;
    if(dep==n)
    {
        ans=cnt;
        return;
    }
    for(int i=0;i<n;i++)
    {
        if(!deg[i]&&!vis[i])
        {
            vis[i]=1;
            for(int j=0;j<n;j++)
            {
                if(m[i][j]) deg[j]--;
            }
            if(r[i].col==color) dfs(dep+1,cnt,color);
            else dfs(dep+1,cnt+1,r[i].col);
            for(int j=0;j<n;j++)
            {
                if(m[i][j]) deg[j]++;
            }
            vis[i]=0;
        }
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        for(int i=0;i<n;i++)
        {
            scanf("%d %d %d %d %d",&r[i].ly,&r[i].lx,&r[i].ry,&r[i].rx,&r[i].col);
        }
        ans=20;
        memset(m,0,sizeof(m));
        memset(deg,0,sizeof(deg));
        memset(vis,0,sizeof(vis));
        build();
        dfs(0,0,0);
        printf("%d\n",ans);
    }
    return 0;
}