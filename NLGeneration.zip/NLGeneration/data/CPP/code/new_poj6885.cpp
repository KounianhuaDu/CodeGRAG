// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include <stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define _LL __int64_t
#define eps 1e-8
using namespace std;
const int INF = 0x3f3f3f3f;
char s[12][22];
int n;
int a[12][12];
int vis[12];
int ans; 
int cal(char s1[], char s2[])
{
    int len1 = strlen(s1);
    int len2 = strlen(s2);
    int i,j,t;
    int flag;
    if(strcmp(s1,s2) == 0) return 0;
    for(int k = 1; k <= len2; k++)
    {
        t = len2 - k;
        i = len1 - t;
        j = 0;
        flag = 1;
        while(i < len1 && j < t)
        {
            if(s1[i] == s2[j])
            {
                i++;
                j++;
            }
            else
            {
                flag = 0;
                break;
            }
        }
        if(flag == 1)
            return k;
    }
}
void solve()
{
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            if(i == j) continue;
            a[i][j] = cal(s[i],s[j]);
        }
    }
}
void dfs(int x, int step, int sum)
{
    if(step > ans) 
        return;
    if(sum == n)
    {
        ans = min(ans,step);
        return;
    }
    for(int i = 0; i < n; i++)
    {
        if(!vis[i])
        {
            vis[i] = 1;
            dfs(i,step + a[x][i], sum+1);
            vis[i] = 0;
        }
    }
}
int main()
{
    int test;
    scanf("%d",&test);
    while(test--)
    {
        scanf("%d",&n);
        ans = 0;
        for(int i = 0; i < n; i++)
        {
            scanf("%s",s[i]);
            ans += strlen(s[i]);
        }
        solve(); 
        memset(vis,0,sizeof(vis));
        for(int i = 0; i < n; i++)
        {
            vis[i] = 1;
            dfs(i,strlen(s[i]),1);
            vis[i] = 0;
        }
       printf("%d\n",ans);
    }
    return 0;
}