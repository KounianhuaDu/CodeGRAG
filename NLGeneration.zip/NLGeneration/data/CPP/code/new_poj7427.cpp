// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Data Structure->Hashing,Basic Algorithm->Recursion
#include<stdio.h>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define MAX 70000
int queuett1[MAX];
int step[MAX];  
int a[16];
int n,m;
void find(int x)  
{
     int i=16,k=0;
     while (i--)
     {
           a[k]=x%2;
           x=x/2;
           k++;
     }
}
int check()  
{
    int s=a[0],temp=1,i;
    for (i=1;i<16;i++)
    {
        temp*=2;
        s+=a[i]*temp;
    }
    return s;       
}
void bfs()
{
     int qe=0,qs=0,i,u; 
     queuett1[qe++]=n;  
     step[n]=0; 
     while (qs<qe)
     {
           int temp=queuett1[qs++];
           if (temp==0||temp==65535)
           {
              m=step[temp];
              break;                           
           }
           find(temp);
           for (i=0;i<16;i++)  
           {
               int s,x,z,y;
               s=i-4;
               x=i+4;
               z=i-1;
               y=i+1;
               a[i]=(a[i]+1)%2;
               if (s>=0&&s<16)   
                  a[s]=(a[s]+1)%2;
               if (x>=0&&x<16)
                  a[x]=(a[x]+1)%2;
               if ((y>=0&&y<16)&&i%4!=3)  
                  a[y]=(a[y]+1)%2;
               if ((z>=0&&z<16)&&i%4!=0)  
                  a[z]=(a[z]+1)%2;
               
               u=check();
               
               if (step[u]==-1||(step[u]>step[temp]+1))  
               {
                  queuett1[qe++]=u;
                  step[u]=step[temp]+1;
               }
	      
               a[i]=(a[i]+1)%2;
               if (s>=0&&s<16)
                  a[s]=(a[s]+1)%2;
               if (x>=0&&x<16)
                  a[x]=(a[x]+1)%2;
               if ((y>=0&&y<16)&&i%4!=3)
                  a[y]=(a[y]+1)%2;
               if (z>=0&&z<16&&i%4!=0)
                  a[z]=(a[z]+1)%2;
               
               
               
           }
     }
}
int main()
{
    
    
    int i,j,s=1;
    char c;
    n=0;  
    
    memset(step,-1,sizeof(step));
    for (i=0;i<4;i++)
    {
        for (j=0;j<4;j++)
        {
            if (i!=0||j!=0)
               s*=2;
            c=getchar();
            if (c=='b')
            {
               n+=s*1;      
            }    
            else
            {
               n+=s*0; 
            }
            
        }    
        getchar();
    }
    
    m=-1;
    
    bfs();
    if (m!=-1)
       printf("%d\n",m);
    else
       printf("Impossible\n"); 
    
    
    return 0;    
}