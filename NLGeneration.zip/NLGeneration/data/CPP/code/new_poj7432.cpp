// Data Structure->Queue
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment (linker,"/STACK:102400000,102400000")
#define maxn 1005
#define MAXN 2005
#define mod 1000000009
#define INF 0x3f3f3f3f
#define pi acos(-1.0)
#define eps 1e-6
typedef long long ll;
using namespace std;
struct node
{
    int x;
    int step;
};
queue<node>Q;
int visit[70000];  
int main()
{
    int id;
    char ch;
    id=0;
    memset(visit,0,sizeof(visit));
    for (int i=0;i<4;i++)
    {
        for (int j=0;j<4;j++)
        {
            scanf("%c",&ch);
            if (ch=='b')
                id=id^(1<<(4*i+j));
        }
        getchar();
    }
    if (id==0||id==65535)
    {
        printf("0\n");
        return 0;
    }
    while (!Q.empty())
        Q.pop();
    node st,now;
    st.x=id;
    visit[id]=1;
    st.step=0;
    Q.push(st);
    while (!Q.empty())
    {
        st=Q.front();
        Q.pop();
        if (st.x==0||st.x==65535)
        {
            printf("%d\n",st.step);
            return 0;
        }
        for (int i=0;i<4;i++)
            for (int j=0;j<4;j++)
        {
            now.x=st.x^(1<<(4*i+j));
            if (i>0)
                now.x=now.x^(1<<(4*(i-1)+j));
            if (i<3)
                now.x=now.x^(1<<(4*(i+1)+j));
            if (j>0)
                now.x=now.x^(1<<(4*i+j-1));
            if (j<3)
                now.x=now.x^(1<<(4*i+j+1));
            if (!visit[now.x])
            {
                now.step=st.step+1;
                Q.push(now);
                visit[now.x]=1;
            }
        }
    }
    printf("Impossible\n");
    return 0;
}