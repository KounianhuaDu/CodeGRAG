// Dynamic Programming->Bitmask Dynamic Programming (DP),Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Bitwise Operation,Basic Algorithm->Recursion
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int size = 4;
const int dir_num = 4;
struct info {
    int value;  
    int step;   
};
int dir[dir_num][2] = {
        {-1, 0}, {0, 1},
        {1, 0}, {0, -1},
    };
int pos[size*size]; 
bool vis[1<<(size*size)];   
bool Judge(int x, int y) {
    if(x>=0 && x<size
        && y>=0 && y<size)
        return true;
    else return false;
}
void Initialize() {
    for(int i=0; i<size; ++i) {
        for(int j=0; j<size; ++j) {
            
            int value = 1 << (i*size + j);
            for(int k=0; k<dir_num; ++k) {
                int next_x = i+dir[k][0];
                int next_y = j+dir[k][1];
                if(Judge(next_x, next_y))
                    
                    value += 1 << (next_x*size + next_y);
            }
            pos[i*size+j] = value;
        }
    }
}
int BFS(int value) {
    queue<info> q;
    info s = {value, 0};
    q.push(s);
    vis[s.value] = true;
    while(!q.empty()) {
        info f = q.front();
        q.pop();
        
        if(f.value==0 || f.value==(1<<(size*size))-1)
            return f.step;
        
        for(int i=0; i<size*size; ++i) {
            
            info next = {f.value^pos[i], f.step+1};
            if(!vis[next.value]) {
                q.push(next);
                vis[next.value] = true;
            }
        }
    }
    return -1;  
}
int main(int argc, char const *argv[]) {
    Initialize();
    char str[5];
    int value = 0;
    for(int i=0; i<size; ++i) {
        scanf("%s", str);
        
        for(int j=0; j<size; ++j) {
            if(str[j] == 'w')
                value += 1 << (i*size + j);
        }
    }
    int ans = BFS(value);
    if(ans >= 0) printf("%d\n", ans);
    else printf("Impossible\n");
    return 0;
}