// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 10010;
const int INF = 0x7fffffff;
int dp[N];
int n;
int id[4]={1,5,10,25};
int v[4],ans[4];
struct thing{
	int kk[100];
	int nk;
}thi[4];
void ZeroOnePack(int w,int vi){
	for(int i=n;i>=vi;--i){
		if(dp[i-vi]==-INF) continue;
		dp[i] = max(dp[i],dp[i-vi] + w);
	}
}
void CompletePack(int vi){
	for(int i=vi;i<=n;++i){
		dp[i] = max(dp[i], dp[i-vi]+1);
	}
}
int main()
{
	
	int flag=0;
	while(scanf("%d%d%d%d%d",&n,&v[0],&v[1],&v[2],&v[3])==5){
		flag = 0;
		if(n!=0) flag=1;
		if(n==0) for(int i=0;i<4;++i)
			if(v[i]){ flag=1; break;}
		if(!flag) break;
		for(int i=0;i<4;++i){
			ans[i] = 0; thi[i].nk=0;
		}
		for(int i=1;i<=n;++i) dp[i] = -INF;
		dp[0]=0;
		for(int i=0;i<4;++i){
			int m=v[i],k=1;
			while(k<m){
				ZeroOnePack(k,k*id[i]);
				thi[i].kk[thi[i].nk++] = k;
				m -= k;
				k = 2*k;
			}
			ZeroOnePack(m,m*id[i]);
			thi[i].kk[thi[i].nk++] = m;
		}
		if(dp[n]==-INF){
			printf("Charlie cannot buy coffee.\n");
			continue;
		}
		int nnn = n;
		
		for(int i=3;i>=0;--i){
			for(int j=thi[i].nk-1;j>=0;--j){
				int temp = id[i]*thi[i].kk[j];
				if(n <  temp) continue;
				if(dp[n] == dp[n - temp] + thi[i].kk[j]){
					ans[i]+=thi[i].kk[j];
					n -= temp;
				}
			}
		}
		printf("Throw in %d cents, %d nickels, %d dimes, and %d quarters.\n",ans[0],ans[1],ans[2],ans[3]);
	}
	
	return 0;
}