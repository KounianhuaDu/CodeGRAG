// Sorting->Quick Sort,Data Structure->Queue,Data Structure->Segment Tree
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define Maxn 16010
int f[Maxn],n,wn,sv[Maxn];
struct work{int l,p,s;}w[Maxn];
bool cmp(work a,work b){return a.s<b.s;}
int main(){
    
    int i,j,jb,je,k,ans,tmp,tj;
    while(scanf("%d%d",&n,&wn)!=EOF){
        n++;
        for(i=1;i<=wn;++i){
            scanf("%d%d%d",&w[i].l,&w[i].p,&w[i].s);
            w[i].s+=1;
        }
        sort(w+1,w+wn+1,cmp);
        memset(f,0,sizeof(f));
        for(i=1;i<=wn;++i){
            tmp=0;
            for(j=n;j>=1;--j){
                sv[j]=f[j]+tmp;
                tmp+=w[i].p;
            }
            jb=w[i].s;
            je=min(w[i].s+w[i].l-1,n);
            tmp=0;
            for(j=w[i].s-1;j>1&&j>je-w[i].l;--j){
                if (sv[j]>tmp) {tmp=sv[j];k=j;}
            }
            tj=j+1;
            for(j=je;j>=jb;--j){
                if (tj>1){
                    tj--;
                    if (sv[tj]>tmp) {tmp=sv[tj];k=tj;}
                }
                f[j]=max(f[j],f[k]+(j-k)*w[i].p);
            }
            for(j=jb;j<=n;++j) if (f[j-1]>f[j]) f[j]=f[j-1];
        }
        ans=f[n];
        printf("%d\n",ans);
    }
    return 0;
}