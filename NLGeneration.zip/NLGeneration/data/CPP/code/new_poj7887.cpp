// Data Structure->Segment Tree,Basic Algorithm->Discretization,Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
#define MAXN 5002
#define memset0(a) memset(a,0,sizeof(a))
#define EPS 1e-8
struct Ln
{
    int l, r, y, f;
    bool operator<(Ln &b)const
    {
        return y < b.y;
    }
}lns[MAXN * 2];
int N;
int hashx[MAXN * 2], L[MAXN * 10], R[MAXN * 10], c[MAXN * 10], len[MAXN * 10], len2[MAXN * 10];
char blank[MAXN * 10];
void build(int i, int l, int r)
{
    L[i] = l, R[i] = r;
    if (l + 1 != r) {
        build(i * 2, l, (l + r) / 2);
        build(i * 2 + 1, (l + r) / 2, r);
    }
}
void modify(int i, Ln &a)
{
    if (a.l == hashx[L[i]] && a.r == hashx[R[i]])
        c[i] += a.f;
    else if (a.l >= hashx[L[i * 2 + 1]])
        modify(i * 2 + 1, a);
    else if (a.r <= hashx[R[i * 2]])
        modify(i * 2, a);
    else {
        Ln b = a;
        b.r = hashx[R[i * 2]];
        modify(i * 2, b);
        b = a;
        b.l = hashx[L[i * 2 + 1]];
        modify(i * 2 + 1, b);
    }
    if (c[i]) {
        len[i] = hashx[R[i]] - hashx[L[i]];
        blank[i] = 3;
        len2[i] = 1;
    }
    else {
        len[i] = len[i * 2] + len[i * 2 + 1];
        len2[i] = len2[i * 2] + len2[i * 2 + 1] - ((blank[i * 2] & 1) && (blank[i * 2 + 1] & 2));
        blank[i] = (blank[i * 2] & 2) + (blank[i * 2 + 1] & 1);
    }
}
int fun()
{
    for (int p = 1; p <= N; p++) {
        int x1, y1, x2, y2;
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        lns[p].l = x1, lns[p].r = x2, lns[p].y = y1, lns[p].f = 1;
        lns[N + p].l = x1, lns[N + p].r = x2, lns[N + p].y = y2, lns[N + p].f = -1;
        hashx[p] = x1, hashx[N + p] = x2;
    }
    sort(lns + 1, lns + 2 * N + 1);
    sort(hashx + 1, hashx + 2 * N + 1);
    build(1, 1, unique(hashx + 1, hashx + 2 * N + 1) - hashx - 1);
    int peri = 0, lastlen = 0;
    for (int p = 1; p <= 2 * N; p++) {
        modify(1, lns[p]);
        peri += abs(len[1] - lastlen) + len2[1] * 2 * (lns[p + 1].y - lns[p].y);
        lastlen = len[1];
    }
    return peri;
}
int main(void)
{
    
    
    while (~scanf("%d", &N)) {
        printf("%d\n", fun());
    }
}