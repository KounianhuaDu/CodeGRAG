// Data Structure->Disjoint Set Union (DSU)
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1 | 1
using namespace std;
const int maxn=1000005,inf=1<<29;
int n,m,t,flag;
int fa[maxn],vis[maxn],in[maxn];
int Find(int x)
{
    if(fa[x]==x) return x;
    return fa[x]=Find(fa[x]);
}
void Merge(int x,int y)
{
    x=Find(x);
    y=Find(y);
    if(x!=y) fa[y]=x;
}
bool same(int x,int y)
{
    return Find(x)==Find(y);
}
int main()
{
    int Case=1;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        
        for(int i=0;i<=2*n;i++) fa[i]=i;
        flag=0;
        while(m--)
        {
            int x,y;
            scanf("%d%d",&x,&y);
            if(same(x,y)) flag=1;
            Merge(x,n+y);
            Merge(n+x,y);
        }
        printf("Scenario #%d:\n",Case++);
        if(flag) printf("Suspicious bugs found!\n\n");
        else printf("No suspicious bugs found!\n\n");
    }
   
    return 0;
}