// Basic Algorithm->Depth First Search (DFS),Dynamic Programming->Tree-Based Dynamic Programming,Basic Algorithm->Recursion
/*ргргрг*/
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 1000050;
const int INF = 0x3f3f3f3f;
const ll mod = 1000000007;
const double eps = 1e-8;
int n, x, no, tp1, tp2, ban;
bool vis[maxn];
int head[maxn];
ll w[maxn], dp[maxn][2], ans;
struct node
{
    int to;
    int nxt;
}e[maxn << 1];
void add(int a, int b)
{
    e[no].to = b;
    e[no].nxt = head[a];
    head[a] = no++;
}
void sea_ring(int u, int fa)
{
    vis[u] = 1;
    for(int i = head[u];i != -1;i = e[i].nxt)
    {
        int v = e[i].to;
        if(v == fa) continue;
        if(vis[v])
        {
            ban = i;
            tp1 = u, tp2 = v;
        }
        else sea_ring(v, u);
    }
}
void dfs(int u, int fa)
{
    dp[u][0] = 0, dp[u][1] = w[u];
    for(int i = head[u];i != -1;i = e[i].nxt)
    {
        int v = e[i].to;
        if(v == fa) continue;
        if(i == ban || i == (ban ^ 1)) continue;
        dfs(v, u);
        dp[u][0] += max(dp[v][0], dp[v][1]);
        dp[u][1] += dp[v][0];
    }
}
int main()
{
    scanf("%d", &n);
    no = 0;
    memset(head, -1, sizeof(head));
    for(int i = 1;i <= n;i++)
    {
        scanf("%lld%d", &w[i], &x);
        add(i, x);
        add(x, i);
    }
    ans = 0;
    memset(vis, 0, sizeof(vis));
    for(int i = 1;i <= n;i++)
    {
        if(vis[i]) continue;
        sea_ring(i, -1);
        dfs(tp1, -1);
        ll tmp = dp[tp1][0];
        dfs(tp2, -1);
        ans += max(tmp, dp[tp2][0]);
    }
    printf("%lld\n", ans);
    return 0;
}