// Dynamic Programming->Longest Decreasing Subsequence (LDS)
#include <map>  
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
  
  
  
  
  
  
  
  
  
  
  
  
using namespace std;
int dp[40010];
int arr[40010];
int main()
{
	int icase = 1;
	while (~scanf("%d", &arr[0]), arr[0] != -1)
	{
		int res = 0, ans = 0;
		while(scanf("%d", &arr[++res]), arr[res] != -1);
		for (int i = 0; i < res; ++i)
		{
			dp[i] = 1;
		}
		for (int i = 0; i < res; ++i)
		{
			for (int j = 0; j < i; ++j)
			{
				if (arr[i] <= arr[j] && dp[i] < dp[j] + 1)
				{
					dp[i] = dp[j] + 1;
				}
			}
			ans = max(ans, dp[i]);
		}
		printf("Test #%d:\n", icase++);
		printf("  maximum possible interceptions: %d\n\n", ans);
	}
	return 0;
}