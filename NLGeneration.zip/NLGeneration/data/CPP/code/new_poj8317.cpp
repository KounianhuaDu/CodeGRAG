// Data Structure->Queue,Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Minimum Cut Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion
#include<cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int u,v,flow,next;
}edge[100010];
int n,N,m,Head[110],d[110],s,t,tot,INF=1e9,link[60][60],_u[10010],_v[10010];
char str[110];
queue<int> qu;
void add(int u,int v,int f)
{
    edge[tot].u=u;
    edge[tot].v=v;
    edge[tot].flow=f;
    edge[tot].next=Head[u];
    Head[u]=tot++;
}
void init()
{
    memset(Head,-1,sizeof(Head));
    tot=0;
    int i,j,k,u,v;
    for(i=1;i<=m;i++)
    {
        u=_u[i];
        v=_v[i];
        add(u*2^1,v*2,1);
        add(v*2,u*2^1,0);
        add(v*2^1,u*2,1);
        add(u*2,v*2^1,0);
    }
    for(i=1;i<n;i++)
       if(i!=t/2)
       {
           add(i*2,i*2^1,1);
           add(i*2^1,i*2,0);
       }
    add(s*2,s*2^1,INF);
    add(s*2^1,s*2,0);
    add(t^1,t,INF);
    add(t,t^1,0);
}
int bfs()
{
    int i,j,u,v;
    memset(d,-1,sizeof(d));
    while(!qu.empty())
      qu.pop();
    qu.push(s);
    d[s]=0;
    while(!qu.empty())
    {
        u=qu.front();
        qu.pop();
        for(i=Head[u];i!=-1;i=edge[i].next)
        {
            v=edge[i].v;
            if(edge[i].flow>0 && d[v]==-1)
            {
                d[v]=d[u]+1;
                if(v==t)
                  return 1;
                qu.push(v);
            }
        }
    }
    return 0;
}
int dfs(int u,int f)
{
    if(u==t || f==0)
      return f;
    int ans=0,i,j,k,v;
    for(i=Head[u];i!=-1;i=edge[i].next)
    {
        v=edge[i].v;
        if(edge[i].flow>0 && d[v]==d[u]+1)
        {
            k=dfs(v,min(edge[i].flow,f));
            edge[i].flow-=k;
            edge[i^1].flow+=k;
            f-=k;
            ans+=k;
            if(f==0)
              break;
        }
    }
    d[u]=-1;
    return ans;
}
int dinic()
{
    tot=0;
    init();
    int ans=0;
    while(bfs())
    {
        ans+=dfs(0,INF);
        
    }
    return ans;
}
int main()
{
    int i,j,k,u,v,minn;
    while(~scanf("%d%d",&n,&m))
    {
        memset(link,0,sizeof(link));
        for(i=1;i<=m;i++)
        {
            scanf("%s",str);
            sscanf(str,"(%d,%d)",&u,&v);
            link[u][v]=link[v][u]=1;
            _u[i]=u;_v[i]=v;
        }
        minn=INF;
        for(i=1;i<n;i++)
           if(!link[0][i])
           {
               s=0;t=i*2^1;
               k=dinic();
               
               minn=min(minn,k);
           }
        if(minn==INF)
          printf("%d\n",n);
        else
          printf("%d\n",minn);
    }
}