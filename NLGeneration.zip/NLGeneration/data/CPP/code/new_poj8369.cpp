// Data Structure->Queue,Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion
#include <cstdio>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define eps 1e-8
#define op operator
#define MOD  10009
#define MAXN  41000
#define INF   99999999
#define MEM(a,x)    memset(a,x,sizeof a)
#define ll long long
using namespace std;
int q[60];
int in[60][20],out[60][20];
struct Edge
{
    int from,to,cap,flow;
    bool operator <(const Edge e) const
    {
        if(e.from!=from)  return from<e.from;
        else return to<e.to;
    }
    Edge() {}
    Edge(int from,int to,int cap,int flow):from(from),to(to),cap(cap),flow(flow) {}
};
struct Dinic
{
    vector<Edge> edges;
    vector<int> G[MAXN];
    bool vis[MAXN];
    int d[MAXN];   
    int cur[MAXN]; 
    int n,m,s,t,maxflow;   
    void init(int n)
    {
        this->n=n;
        for(int i=0;i<=n;i++)
            G[i].clear();
        edges.clear();
    }
    void addedge(int from,int to,int cap)
    {
        edges.push_back(Edge(from,to,cap,0));
        edges.push_back(Edge(to,from,0,0));
        m=edges.size();
        G[from].push_back(m-2);
        G[to].push_back(m-1);
    }
    bool bfs()
    {
        MEM(vis,0);
        MEM(d,-1);
        queue<int> q;
        q.push(s);
        d[s]=maxflow=0;
        vis[s]=1;
        while(!q.empty())
        {
            int u=q.front(); q.pop();
            int sz=G[u].size();
            for(int i=0;i<sz;i++)
            {
                Edge e=edges[G[u][i]];
                if(!vis[e.to]&&e.cap>e.flow)
                {
                    d[e.to]=d[u]+1;
                    vis[e.to]=1;
                    q.push(e.to);
                }
            }
        }
        return vis[t];
    }
    int dfs(int u,int a)
    {
        if(u==t||a==0)  return a;
        int sz=G[u].size();
        int flow=0,f;
        for(int &i=cur[u];i<sz;i++)
        {
            Edge &e=edges[G[u][i]];
            if(d[u]+1==d[e.to]&&(f=dfs(e.to,min(a,e.cap-e.flow)))>0)
            {
                e.flow+=f;
                edges[G[u][i]^1].flow-=f;
                flow+=f;
                a-=f;
                if(a==0)  break;
            }
        }
        return flow;
    }
    int Maxflow(int s,int t)
    {
        this->s=s; this->t=t;
        int flow=0;
        while(bfs())
        {
            MEM(cur,0);
            flow+=dfs(s,INF);
        }
        return flow;
    }
}Dic;
vector<int> cut;
vector<Edge> ans;
int main()
{
    int p,n;
    while(scanf("%d%d",&p,&n)!=EOF)
    {
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&q[i]);
            for(int j=1;j<=p;j++)
                scanf("%d",&in[i][j]);
            for(int j=1;j<=p;j++)
                scanf("%d",&out[i][j]);
        }
        int s=0,t=2*n+1;
        Dic.init(t);
        for(int i=1;i<=n;i++)
        {
            int flag=1;
            for(int j=1;j<=p;j++)
            {
                if(in[i][j]==1)
                {
                    flag=0;
                    break;
                }
            }
            if(flag)
                Dic.addedge(s,i,INF);
        }
        for(int i=1;i<=n;i++)
        {
            int flag=1;
            for(int j=1;j<=p;j++)
            {
                if(out[i][j]==0)
                {
                    flag=0;
                    break;
                }
            }
            if(flag)
                Dic.addedge(i+n,t,INF);
        }
        for(int i=1;i<=n;i++)
            Dic.addedge(i,i+n,q[i]);
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(i==j)
                    continue;
                int flag=1;
                for(int k=1;k<=p;k++)
                {
                    if(out[i][k]==0&&in[j][k]==1)
                    {
                        flag=0;
                        break;
                    }
                    if(out[i][k]==1&&in[j][k]==0)
                    {
                        flag=0;
                        break;
                    }
                }
                if(flag)
                    Dic.addedge(i+n,j,INF);
            }
        }
        int mx=Dic.Maxflow(s,t);
        ans.clear();
        int cnt=0;
        for(int i=0;i<Dic.edges.size();i++)
        {
            if(Dic.edges[i].from==0||Dic.edges[i].to==0)
                continue;
            if(Dic.edges[i].to==t||Dic.edges[i].from==t)
                continue;
            if((Dic.edges[i].from+n==Dic.edges[i].to)||(Dic.edges[i].from-n==Dic.edges[i].to))
                continue;
            if(Dic.edges[i].flow<0)
            {
                cnt++;
            }
        }
        printf("%d %d\n",mx,cnt);
        for(int i=0;i<Dic.edges.size();i++)
        {
            if(Dic.edges[i].from==0||Dic.edges[i].to==0)
                continue;
            if(Dic.edges[i].to==t||Dic.edges[i].from==t)
                continue;
            if((Dic.edges[i].from+n==Dic.edges[i].to)||(Dic.edges[i].from-n==Dic.edges[i].to))
                continue;
            if(Dic.edges[i].flow<0)
            {
                printf("%d %d %d\n",Dic.edges[i].to-n,Dic.edges[i].from,-Dic.edges[i].flow);
            }
        }
    }
    return 0;
}