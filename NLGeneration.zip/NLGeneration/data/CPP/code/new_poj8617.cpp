// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 815
#define INF 1e8
using namespace std;
bool dp[801][801];
int a[44];
int n,sum,p;
int main()
{
   while(scanf("%d",&n)!=EOF)
   {
        sum=0;
        for(int i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
            sum+=a[i];
        }
        memset(dp,0,sizeof(dp));
        dp[0][0]=1;
        p=sum/2;
        for(int i=0;i<n;i++)
        {
            for(int j=p;j>=0;j--)
            {
                for(int k=j;k>=0;k--)
                {
                    if((j>=a[i]&&dp[k][j-a[i]])||(k>=a[i]&&dp[k-a[i]][j]))
                        dp[k][j]=1;
                }
            }
        }
        int ans=-1;
        for(int i=p;i>=1;i--)
        {
            for(int j=i;j>=1;j--)
            {
                if(dp[j][i])
                {
                    int c=sum-i-j;
                    if(i + j > c && i + c > j && j + c > i)
                    {
                        double px=(i+j+c)*1.0/2;
                        int temp=(int)(sqrt(px*(px-i)*(px-j)*(px-c))*100);
                        if(ans<temp)
                            ans=temp;
                    }
                }
            }
        }
        if(ans)
        printf("%d\n",ans);
        else
        printf("-1\n");
   }
   return 0;
}