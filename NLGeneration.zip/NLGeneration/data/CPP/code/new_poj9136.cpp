// Data Structure->Binary Indexed Tree (BIT)
#include<iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n;
struct e{
	int v,x;
};
e a[20001];
long long cnt[20001],sum[20001];
int lowbit(int x){
	return x&(x^(x-1));
}
void modify(long long a[],int s,int t){
	while(s<=20000)
	{
		a[s]+=t;
		s+=lowbit(s);
	}
}
long long getsum(long long a[],int s){
	long long ans=0;
	while(s>0)
	{
		ans+=a[s];
		s-=lowbit(s);
	}
	return ans;
}
int cmp(const void *a,const void *b){
	return (*(e *)a).v-(*(e*)b).v;
}
void read(){
	int i,j,k;
	long long total=0,ans=0;
	cin>>n;
	for(i=1;i<=n;i++)
		cin>>a[i].v>>a[i].x;
	qsort(a+1,n,sizeof(e),cmp);
	modify(cnt,a[1].x,1);
	modify(sum,a[1].x,a[1].x);
	total+=a[1].x;
	for(i=2;i<=n;i++)
	{
		modify(cnt,a[i].x,1);
		modify(sum,a[i].x,a[i].x);
		long long s,t;
		s=getsum(cnt,a[i].x);
		t=getsum(sum,a[i].x);
		total+=a[i].x;
		ans+=a[i].v*(s*a[i].x-t+total-t-a[i].x*(i-s));
	}
	cout<<ans<<endl;
}
int main(){
	read();
	return 0;
}