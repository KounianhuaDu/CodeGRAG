// Data Structure->Trie
#include <iostream>
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char s[1100][30];
struct node
{
    int flag;
    node *next[30];
};
node *newnode()
{
    int i;
    node *p;
    p=new node;
    for(i=0;i<26;i++)
    {
        p->next[i]=NULL;
    }
    p->flag=0;
    return p;
}
void insert1(node *root, char *s)
{
    int i, len=strlen(s), x;
    node *p=root;
    for(i=0;i<len;i++)
    {
        x=s[i]-'a';
        if(p->next[x]==NULL)
            p->next[x]=newnode();
        p=p->next[x];
        p->flag++;
    }
}
int seach(node *root, char *s)
{
    int i, len=strlen(s), x, pos=len;
    node *p=root;
    for(i=0;i<len-1;i++)
    {
        x=s[i]-'a';
        p=p->next[x];
        if(p->flag==1)
        {
            pos=i+1;
            break;
        }
    }
    return pos;
}
int main()
{
    node *root;
    root =newnode();
    int cnt=0, i, j, k;
    while(scanf("%s",s[cnt])!=EOF)
    {
        insert1(root,s[cnt]);
        cnt++;
    }
    for(i=0;i<cnt;i++)
    {
        printf("%s ",s[i]);
        k=seach(root,s[i]);
        for(j=0;j<k;j++)
        {
            printf("%c",s[i][j]);
        }
        printf("\n");
    }
    return 0;
}