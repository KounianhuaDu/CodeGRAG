// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxt=1100;
const int maxn=32;
double dp[maxt][2];
double p[maxt][maxn];
int T,M,N;
double DP(int t,int f){
    if(t<=0) return f;
    if(dp[t][f]>-1.0) return dp[t][f];
    double a[maxn][maxn],ans=0;
    a[0][0]=1;
    for(int i=1;i<=M;i++){
        for(int j=0;j<=i;j++){
            a[i][j]=0;
            if(j-1>=0) a[i][j]+=a[i-1][j-1]*p[t][i];
            if(i-1>=j) a[i][j]+=a[i-1][j]*(1-p[t][i]);
        }
    }
    for(int i=1;i<N;i++) ans+=DP(t-1,f)*a[M][i];
    for(int i=N;i<=M;i++) ans+=DP(t-1,1)*a[M][i];
    return dp[t][f]=ans;
}
void input(){
    for(int i=1;i<=T;i++){
        dp[i][0]=dp[i][1]=-2.0;
        for(int j=1;j<=M;j++){
            scanf("%lf",&p[i][j]);
        }
    }
}
void solve(){
    printf("%.3f\n",DP(T,0));
}
int main(){
    while(scanf("%d%d%d",&M,&T,&N)!=EOF && (T||M||N) ){
        input();
        solve();
    }
    return 0;
}