// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 200005
#define inf 0x3f3f3f3f
#define INF 0x7fffffff
typedef long long  ll;
typedef unsigned long long ull;
#define ms(x) memset(x,0,sizeof(x))
const long long int mod = 1e9 + 7;
#define eps 1e-7
typedef pair<int,int>pii;
inline int read()
{
	int x = 0, k = 1; char c = getchar();
	while (c < '0' || c > '9') { if (c == '-')k = -1; c = getchar(); }
	while (c >= '0' && c <= '9')x = (x << 3) + (x << 1) + (c ^ 48), c = getchar();
	return x * k;
}
int quickpow(int a,int b)
{
    int ans=1;
    while(b){
        if(b&1)ans=ans*a;
        b>>=1;
        a=a*a;
    }
    return ans;
}
int a[500][500],d[500][500],pos[500][500];
vector<int>path;
void outpath(int x,int y)
{
    if(pos[x][y]==0)return;
    outpath(x,pos[x][y]);
    path.push_back(pos[x][y]);
    outpath(pos[x][y],y);
}
int main()
{
    
   int n,m;
   n=read();m=read();
   int i,j;
   memset(a,0x3f,sizeof(a));
   for(i=1;i<=n;i++)a[i][i]=0;
   for(i=1;i<=m;i++){
    int x,y,z;
    x=read();y=read();z=read();
    a[x][y]=a[y][x]=min(a[x][y],z);
   }
   memcpy(d,a,sizeof(a));
   int ans=inf;
   for(int k=1;k<=n;k++){
    for(i=1;i<k;i++){
        for(j=i+1;j<k;j++){
           if((ll)d[i][j]+a[j][k]+a[k][i]<ans){
            ans=d[i][j]+a[j][k]+a[k][i];
            path.clear();
            path.push_back(i);
            outpath(i,j);
            path.push_back(j);path.push_back(k);
           }
        }
    }
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            if(d[i][j]>d[i][k]+d[k][j]){
                d[i][j]=d[i][k]+d[k][j];
                pos[i][j]=k;
            }
        }
    }
   }
   if(ans==inf){
    cout<<"No solution."<<endl;
   }
   else {
    for(i=0;i<path.size();i++){
        cout<<path[i]<<' ';
    }
    cout<<endl;
   }
}