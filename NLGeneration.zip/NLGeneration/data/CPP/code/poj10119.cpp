// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int inf=1e9+7;
template<typename T>inline void read(T &x)
{
	x=0;
	T f=1, ch=getchar();
	while (!isdigit(ch) && ch^'-') ch=getchar();
	if (ch=='-') f=-1, ch=getchar();
	while (isdigit(ch)) x=(x<<1)+(x<<3)+(ch^48), ch=getchar();
	x*=f;
}
int a[10][10],w[10][10];
double f[20][10][10][10][10];
double ans,sum;
inline double add(int x1,int y1,int x2,int y2)
{
	double ww=w[x2][y2]-w[x1-1][y2]-w[x2][y1-1]+w[x1-1][y1-1]-sum;
	return ww*ww;
}
int main()
{
	int n;read(n);
	sum=0;
	for (int i=1; i<=8; ++i)
		for (int j=1; j<=8; ++j)
			read(a[i][j]),sum+=a[i][j];
	sum=sum/n;
	for (int i=1; i<=8; ++i)
		for (int j=1; j<=8; ++j)
			w[i][j]=w[i-1][j]+w[i][j-1]-w[i-1][j-1]+a[i][j];
	for (int i=0; i<=n; ++i)
		for (int x1=1; x1<=8; ++x1)
			for (int y1=1; y1<=8; ++y1)
				for (int x2=x1; x2<=8; ++x2)
					for (int y2=y1; y2<=8; ++y2)
						f[i][x1][y1][x2][y2]=inf;
	f[0][1][1][8][8]=0;
	for (int i=1; i<n; ++i)
		for (int x1=1; x1<=8; ++x1)
			for (int y1=1; y1<=8; ++y1)
				for (int x2=x1; x2<=8; ++x2)
					for (int y2=y1; y2<=8; ++y2)
						for (int j=1; j<=8; ++j)
						{
							if (x1-j>0)
								f[i][x1][y1][x2][y2]=min(f[i-1][x1-j][y1][x2][y2]+add(x1-j,y1,x1-1,y2),f[i][x1][y1][x2][y2]);
							if (y1-j>0)
								f[i][x1][y1][x2][y2]=min(f[i-1][x1][y1-j][x2][y2]+add(x1,y1-j,x2,y1-1),f[i][x1][y1][x2][y2]);
							if (x2+j<=8)
								f[i][x1][y1][x2][y2]=min(f[i-1][x1][y1][x2+j][y2]+add(x2+1,y1,x2+j,y2),f[i][x1][y1][x2][y2]);
							if (y2+j<=8)
								f[i][x1][y1][x2][y2]=min(f[i-1][x1][y1][x2][y2+j]+add(x1,y2+1,x2,y2+j),f[i][x1][y1][x2][y2]);
						}
	ans=inf;
	for (int x1=1; x1<=8; ++x1)
		for (int y1=1; y1<=8; ++y1)
			for (int x2=x1; x2<=8; ++x2)
				for (int y2=y1; y2<=8; ++y2)
					if (f[n-1][x1][y1][x2][y2]+add(x1,y1,x2,y2)<ans)
						ans=f[n-1][x1][y1][x2][y2]+add(x1,y1,x2,y2);
	ans=ans/n;
	ans=sqrt(ans);
	printf("%.3f\n",ans);
	return 0;
}