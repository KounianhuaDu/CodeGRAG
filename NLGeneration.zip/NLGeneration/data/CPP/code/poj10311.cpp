// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define F(i,j,n) for(int i=j;i<=n;i++)
#define D(i,j,n) for(int i=j;i>=n;i--)
#define LL long long
#define pa pair<int,int>
#define MAXN 255
using namespace std;
int n,b,t,m,x,y,mx,mn,a[MAXN][MAXN],f[MAXN][MAXN][15],g[MAXN][MAXN][15];
int read()
{
	int ret=0,flag=1;char ch=getchar();
	while (ch<'0'||ch>'9'){if (ch=='-') flag=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){ret=ret*10+ch-'0';ch=getchar();}
	return ret*flag;
}
int main()
{
	n=read();b=read();m=read();
	t=int(log2(b));
	b-=(1<<t);
	F(i,1,n) F(j,1,n) f[i][j][0]=g[i][j][0]=a[i][j]=read();
	F(k,1,t) F(i,1,n-(1<<k)+1) F(j,1,n-(1<<k)+1)
	{
		f[i][j][k]=min(min(f[i][j][k-1],f[i+(1<<(k-1))][j][k-1]),min(f[i][j+(1<<(k-1))][k-1],f[i+(1<<(k-1))][j+(1<<(k-1))][k-1]));
		g[i][j][k]=max(max(g[i][j][k-1],g[i+(1<<(k-1))][j][k-1]),max(g[i][j+(1<<(k-1))][k-1],g[i+(1<<(k-1))][j+(1<<(k-1))][k-1]));
	}
	F(i,1,m)
	{
		x=read();y=read();
		mn=min(min(f[x][y][t],f[x+b][y][t]),min(f[x][y+b][t],f[x+b][y+b][t]));
		mx=max(max(g[x][y][t],g[x+b][y][t]),max(g[x][y+b][t],g[x+b][y+b][t]));
		printf("%d\n",mx-mn);
	}
	return 0;
}