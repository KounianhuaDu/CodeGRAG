// Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 32768;
int mypow[182];
int num[N];
void ini()
{
    for(int i=0;i<=181;++i)
        mypow[i] = i*i;
    for(int a=0;a<=181;++a)
    {
        for(int b=a;b<=181;++b)
        {
           if(mypow[b]+mypow[a]>=N)
            break;
           for(int c=b;c<=181;++c)
           {
               if(mypow[a]+mypow[b]+mypow[c]>=N)
                break;
               for(int e=c;e<=181;++e)
               {
                  int tmp = mypow[a]+mypow[b]+mypow[c]+mypow[e];
                  if(tmp>=N)
                    break;
                   num[tmp]++;
               }
           }
        }
    }
}
int main(void)
{
    int n;
    memset(num,0,sizeof(num));
    ini();
    while(scanf("%d",&n),n)
    {
        printf("%d\n",num[n]);
    }
    return 0;
}