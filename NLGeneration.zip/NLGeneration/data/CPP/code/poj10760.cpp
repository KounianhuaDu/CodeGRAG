// Math and Computational Geometry->Gaussian Elimination
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define eps 1e-6
#define pi acos(-1.0)
#define inf 107374182
#define inf64 1152921504606846976
#define lc l,m,tr<<1
#define rc m + 1,r,tr<<1|1
#define iabs(x)  ((x) > 0 ? (x) : -(x))
#define clear1(A, X, SIZE) memset(A, X, sizeof(A[0]) * (SIZE))
#define clearall(A, X) memset(A, X, sizeof(A))
#define memcopy1(A , X, SIZE) memcpy(A , X ,sizeof(X[0])*(SIZE))
#define memcopyall(A, X) memcpy(A , X ,sizeof(X))
#define max( x, y )  ( ((x) > (y)) ? (x) : (y) )
#define min( x, y )  ( ((x) < (y)) ? (x) : (y) )
using namespace std;
struct node
{
    long long num[75];
    node()
    {
        clearall(num,0);
    }
    void clen()
    {
        clearall(num,0);
    }
};
struct node matrix[75];
int n,m,len;
bool free_x[75];
long long X[75],p;
void Debug(void)
{
    puts("");
    int i, j;
    for (i = 0; i < m; i++)
    {
        for (j = 0; j < n + 1; j++)
        {
            cout << matrix[i].num[j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}
int Guass()
{
    int i,j,k,col;
    clearall(X,0);
    clearall(free_x,1);
    
    for (k = 0,col = 0; k < m && col < n; ++k, ++col) 
    {
        int max_r = k;
        for (i = k + 1; i < m; ++i)
        {
            if (iabs(matrix[i].num[col]) > iabs(matrix[max_r].num[col])) max_r = i;
        }
        if (max_r != k) 
        {
            for (i = k; i < n + 1; ++i) swap(matrix[k].num[i],matrix[max_r].num[i]);
        }
        
        for (i = k + 1; i < m; ++i) 
        {
            if (matrix[i].num[col]!=0)
            {
                long long x1=matrix[i].num[col],x2=matrix[k].num[col];
                for (j = col; j < n + 1; ++j)
                {
                    matrix[i].num[j] = matrix[i].num[j] *x2- x1*matrix[k].num[j];
                    matrix[i].num[j] = (matrix[i].num[j]%p+p)+p;
                }
            }
        }
    }
    
    
    
    
    
    
    
    
    
    for (i = k - 1; i >= 0; --i)
    {
        long long tmp = matrix[i].num[n];
        for (j = i + 1; j < n; ++j)
        {
            tmp =((tmp- matrix[i].num[j]*X[j])%p+p)%p;
        }
        while(tmp%matrix[i].num[i])tmp+=p;
        X[i] = ((tmp/matrix[i].num[i])%p+p)%p;
    }
    return 0;
}
char s[75];
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        clearall(matrix,0);
        scanf("%lld%s",&p,s);
        n=strlen(s);
        m=n;
        for(int i=0;i<n;i++)
        {
            if(s[i]!='*')
            matrix[i].num[n]=(s[i]-'a'+1)%p;
            matrix[i].num[0]=1;
            for(int j=1;j<n;j++)
            {
                matrix[i].num[j]=(matrix[i].num[j-1]*(i+1))%p;
            }
        }
        Guass();
        for(int i=0;i<n;i++)
        {
            if(i!=0)printf(" ");
            printf("%lld",X[i]);
        }
        
        puts("");
    }
    return 0;
}