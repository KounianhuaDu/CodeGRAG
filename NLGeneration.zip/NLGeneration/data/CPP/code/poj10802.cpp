// Basic Algorithm->Simulation,Math and Computational Geometry->Smallest-circle Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN=50;
const double eps=1e-8;
int n;
struct Point
{
	double x,y,z;
}myPoint[MAXN],op;
double GetDis(const Point &a,const Point &b)
{
	return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y)+(a.z-b.z)*(a.z-b.z));
}
double Solve()
{
	double ret,delta=100.0;
	double maxDis,tempDis;
	int i,id;
	while(delta>eps)
	{
		id=0;
		maxDis=GetDis(op,myPoint[id]);
		for(i=1;i<n;i++)
		{
			tempDis=GetDis(op,myPoint[i]);
			if(tempDis>maxDis)
			{
				maxDis=tempDis;
				id=i;
			}
		}
		ret=maxDis;
		op.x+=(myPoint[id].x-op.x)/maxDis*delta;
		op.y+=(myPoint[id].y-op.y)/maxDis*delta;
		op.z+=(myPoint[id].z-op.z)/maxDis*delta;
		delta*=0.98;
	}
	return ret;
}
int main()
{
	int i;
	while(scanf("%d",&n)!=EOF)
	{
		if(0==n)break;
		for(i=0;i<n;i++)
			scanf("%lf%lf%lf",&myPoint[i].x,&myPoint[i].y,&myPoint[i].z);
		op.x=op.y=op.z=0.0;
		printf("%.5lf\n",Solve());
	}
	return 0;
}