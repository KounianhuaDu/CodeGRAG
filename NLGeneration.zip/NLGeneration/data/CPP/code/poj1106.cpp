// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct Data
{
	int x, y, sum, num;
	int xiang;
};
int dx[] = {0, 0, 1, -1};
int dy[] = {1, -1, 0, 0};
int dd[] = {0, 2, 3, 1};
bool visit[80][80];
char maptt1[80][80];
int n, m;
int mmin = 100000;
queue<Data>q;
int bfs(int x, int y, int a, int b)
{
	if (x == a && y == b)
		return 0;
	Data data, c;
	data.x = x;
	data.y = y;
	data.sum = 0;
	data.num = 0;
	visit[x][y] = 1;
	q.push(data);
	while (!q.empty())
	{
		data = q.front();
		q.pop();
		for (int i = 0; i < 4; i++)
		{
			c.x = data.x + dx[i];
		    c.y = data.y + dy[i];
			c.xiang = dd[i];
			if (c.x == a && c.y == b)
			{
				if (data.sum != 0 && c.xiang != data.xiang)
					c.num = data.num + 1;
				else
					c.num = data.num;
				if (mmin > c.num + 1)
					mmin = c.num + 1;
			}
			if (c.x >= 0 && c.y >= 0 && c.x <= n + 1 && c.y <= m + 1 && maptt1[c.x][c.y] != 'X' && !visit[c.x][c.y])
			{
				if (data.sum != 0 && c.xiang != data.xiang)
					c.num = data.num + 1;
				else 
					c.num = data.num;
				c.sum = data.sum + 1;
				visit[c.x][c.y] = 1;
				q.push(c);
			}
		}
	}			
	if (mmin != 100000)
		return mmin;
	else
		return -1;
}
int main()
{
	int cun = 1;
	while (scanf("%d%d", &m, &n) != EOF && n != 0 && m != 0)
	{
		getchar();
		memset(maptt1, 0, sizeof(maptt1));
		memset(visit, 0, sizeof(visit));
		while (!q.empty())
			q.pop();
		int i, j;
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= m; j++)
				maptt1[i][j] = getchar();
			getchar();
		}
        printf("Board #%d:\n", cun++);
		int x_st, y_st, x_end, y_end;
		int cot = 1;
		while (scanf("%d%d%d%d", &y_st, &x_st, &y_end, &x_end) == 4 && x_st != 0 && y_st != 0)
		{
			mmin = 100000;
			memset(visit, 0, sizeof(visit));
            while (!q.empty())
				q.pop();
			if ((x_st - y_st == 1 || x_st - y_st == -1) && x_end == y_end || (x_end - y_end == 1 || y_end - x_end == -1) && x_st == y_st)
			{
				printf("Pair %d: 1 segments.\n", cot++);
				continue;
			}
			int k = bfs(x_st, y_st, x_end, y_end);
			if (k == -1)
				printf("Pair %d: impossible.\n", cot++);
			else 
				printf("Pair %d: %d segments.\n", cot++, k);
		}
		printf("\n");
	}
	return 0;
}