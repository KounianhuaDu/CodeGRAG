// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define min(a,b) (a<b?a:b)
using namespace std;
const int mm=11111;
const int mn=5555;
bool vis[mm];
int t[mm],p[mm];
int h[mn],dfn[mn],low[mn];
int i,j,n,m,e,tsp,ans;
inline void addedge(int u,int v)
{
    vis[e]=0,t[e]=v,p[e]=h[u],h[u]=e++;
    vis[e]=0,t[e]=u,p[e]=h[v],h[v]=e++;
}
void dfs(int u)
{
    dfn[u]=low[u]=++tsp;
    for(int i=h[u],v;i>=0;i=p[i])
    {
        if(vis[i])continue;
        vis[i]=vis[i^1]=1;
        if(!dfn[v=t[i]])
            dfs(v),low[u]=min(low[u],low[v]);
        else low[u]=min(low[u],dfn[v]);
    }
}
void tarjan()
{
    int i;
    for(tsp=i=0;i<=n;++i)dfn[i]=0;
    dfs(1);
}
int main()
{
    while(scanf("%d%d",&n,&m)!=-1)
    {
        for(i=e=0;i<=n;++i)h[i]=-1;
        while(m--)scanf("%d%d",&i,&j),addedge(i,j);
        tarjan();
        for(i=1;i<=n;++i)dfn[i]=0;
        for(i=1;i<=n;++i)
            for(j=h[i];j>=0;j=p[j])
                if(low[i]!=low[t[j]])++dfn[low[i]];
        ans=0;
        for(i=1;i<=n;++i)ans+=(dfn[i]==1);
        printf("%d\n",(ans+1)>>1);
    }
    return 0;
}