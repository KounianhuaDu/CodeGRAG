// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int data[70],sum,visited[70];
int n,ansnum,len;
long Count=0;
bool dfs(int cur,int remainlen,int num)
{
    int i;
    
    Count++;
    if (num==ansnum)   return true;
    if (remainlen==0) return (dfs(0,len,num+1));
        for (i=cur;i<n;i++)
        {
            if (visited[i]==1) continue;
            if (remainlen-data[i]<0) continue;
            if (i>0&&(data[i]==data[i-1]&&visited[i-1]==0)) continue;
            visited[i]=1;
            if (dfs(i,remainlen-data[i],num)) return true;
            visited[i]=0;
            if (cur==0&&remainlen==len) return false;
            if (remainlen==data[i]) return false;
        }
    return false;
}
bool cmp(int a,int b)
{
    return a>b;
}
int main()
{
    int i;
    bool k;
    while (cin>>n&&n)
    {
        sum=0;
        Count=0;
        for (i=0; i<n; i++)
        {
            cin>>data[i];
            sum=sum+data[i];
        }
        sort(data,data+n,cmp);
        for (len=data[0]; len<=sum; len++)
        {
            if (sum%len==0)
            {
                memset(visited,0,sizeof(visited));
                ansnum=sum/len;
                k=dfs(0,len,0);
                if (k==true)
                {
                    cout<<len<<endl;
                    break;
                }
            }
        }
    }
    return 0;
}