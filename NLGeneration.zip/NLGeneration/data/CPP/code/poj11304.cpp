// Graph Algorithm->Hungarian (KM) Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define M 55
#define N 1000
using namespace std;
vector<int>v[N];
char g[M][M];
int vis[N];
int linker[N];
int aR[M][M], aC[M][M]; 
int n, m;
bool dfs(int u){
   int len=v[u].size();
   for(int i=0; i<len; ++i){
       int vu=v[u][i];
       if(!vis[vu]) {
              vis[vu]=1; 
           if(!linker[vu] || dfs(linker[vu])){
               linker[vu]=u;
               return true;
           }
       }
   }
   return false;
}
int main(){
   while(scanf("%d%d", &n, &m)!=EOF){
          int cntR=1, cntC=1;
       for(int i=1; i<=n; ++i)
          scanf("%s", g[i]+1);
       for(int i=1; i<=n; ++i)
          for(int j=1; j<=m; ++j)
             if(g[i][j]=='*'){
                aR[i][j]=cntR;
                if(j+1>m || g[i][j+1]!='*')
                   ++cntR; 
             }
       for(int j=1; j<=m; ++j)
          for(int i=1; i<=n; ++i)
             if(g[i][j]=='*'){
                 aC[i][j]=cntC;
                 if(i+1>n || g[i+1][j]!='*')
                   ++cntC;
             }
       for(int i=1; i<=n; ++i)
          for(int j=1; j<=m; ++j)
            if(g[i][j]=='*')
               v[aR[i][j]].push_back(aC[i][j]);  
       
       int ans=0;
       memset(linker, 0, sizeof(linker));
       for(int i=1; i<cntR; ++i){
           memset(vis, 0, sizeof(vis));
           if(dfs(i))  ++ans;
       } 
       printf("%d\n", ans); 
       for(int i=1; i<cntR; ++i)
          v[i].clear();
   }
   return 0;
}