// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,fi[210],w[1000001],ne[1000001],v[1000001],cnt,tot,len[101][101],ans[101][101],sum[101],la[210],siz[210],dis[210];
bool b[210];
struct node{
	int x,y,v;
}a[101],c[101];
void add(int u,int vv,int val)
{
	w[++cnt]=vv;ne[cnt]=fi[u];fi[u]=cnt;v[cnt]=val;
}
int findd()
{
	queue<int> q;
	for(int i=1;i<tot;i++) dis[i]=1000000000;
	q.push(tot);b[tot]=1;siz[tot]++;
	while(!q.empty())
	{
		int k=q.front();q.pop();b[k]=0;
		for(int i=fi[k];i;i=ne[i])
		  if(dis[w[i]]>dis[k]+v[i])
		  {
		  	dis[w[i]]=dis[k]+v[i];la[w[i]]=k;
		  	if(!b[w[i]])
		  	{
		  		q.push(w[i]);b[w[i]]=1;
		  		if(++siz[w[i]]>tot) return w[i];
			}
		  }
	}
	return -1;
}
int main()
{
	scanf("%d%d",&n,&m);tot=n+m+1;
	for(int i=1;i<=n;i++) scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].v);
	for(int i=1;i<=m;i++) scanf("%d%d%d",&c[i].x,&c[i].y,&c[i].v);
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	  {
	  	len[i][j]=abs(a[i].x-c[j].x)+abs(a[i].y-c[j].y)+1;add(i,j+n,len[i][j]);
	  }
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	  {
	  	int val;scanf("%d",&val);sum[j]+=val;ans[i][j]=val;
	  	if(val) add(j+n,i,-len[i][j]);
	  }
	for(int i=1;i<=m;i++)
	{
		if(sum[i]<c[i].v) add(i+n,tot,0);
		if(sum[i]>0) add(tot,i+n,0);
	}
	int sta=findd(),id=sta;
    if(sta==-1)
	{
		printf("OPTIMAL\n");return 0;
	}
    printf("SUBOPTIMAL\n");
    memset(b,0,sizeof(b));
    while(!b[sta])
    {
    	b[sta]=1;sta=la[sta];
	}
	id=sta;
	do{
		int fro=la[sta],to=sta;
		if(fro<=n && to<tot && to>n) ans[fro][to-n]++;
		else if(fro>n && to<=n && fro<tot) ans[to][fro-n]--;
		sta=la[sta];
	}while(sta!=id);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++) printf("%d ",ans[i][j]);printf("\n");
	}
	return 0;
}