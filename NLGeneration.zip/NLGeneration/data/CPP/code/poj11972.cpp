// Basic Algorithm->Recursion,Graph Algorithm->Tarjan's Algorithm,Graph Algorithm->Strongly Connected Components,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAX_N 10010
#define MAX_M 50010
using namespace std;
vector <int> vec[MAX_N];
int dfn[MAX_N], low[MAX_N], stap[MAX_N], belong[MAX_N];
int n, m, bcnt, dindex = 0, stop = 0;
int rd[MAX_N], rd0cnt;
bool instack[MAX_N];
int x[MAX_M], y[MAX_M];
void tarjan(int v) {
	int u, l = vec[v].size();
	dfn[v] = low[v] = ++dindex;
	instack[v] = true;
	stap[++stop] = v;
	for (int i = 0; i < l; i++) {
		u = vec[v][i];
		if (!dfn[u]) {
			tarjan(u);
			if (low[u] < low[v])
				low[v] = low[u];
		}
		else if (instack[u] && dfn[u] < low[v])
			low[v] = dfn[u];
	}
	if (dfn[v] == low[v]) {
		bcnt++;
		do {
			u = stap[stop--];
			instack[u] = false;
			belong[u] = bcnt;
		}
		while (u != v);
	}
}
int main() {
	while (cin >> n >> m) {
		for (int i = 1; i <= m; i++) {
			cin >> x[i] >> y[i];
			vec[y[i]].push_back(x[i]);
		}
		stop = bcnt = dindex = 0;
		memset(dfn, 0, sizeof(dfn));
		for (int i = 1; i <= n; i++)
			if (!dfn[i]) tarjan(i);
		memset(rd, 0, sizeof(rd));
		for (int i = 1; i <= m; i++)
			if (belong[x[i]] != belong[y[i]])
				rd[belong[x[i]]]++;
		int cnt = 0;
		for (int i = 1; i <= bcnt; i++)
			if (rd[i] == 0) cnt++;
		if (cnt > 1) cout << 0 << endl;
		else {
			cnt = 0;
			for (int i = 1; i <= n; i++)
				if (rd[belong[i]] == 0) cnt++;
			cout << cnt << endl;
		}
	}
}