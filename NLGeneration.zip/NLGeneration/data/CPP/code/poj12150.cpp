// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define L(rt) (rt<<1)
#define R(rt)  (rt<<1|1)
using namespace std;
const ll INF = 100000000000000LL;
const int maxn = 100005;
int n, m;
ll sum, ans;
ll val[maxn], dp[maxn];
vector<int>G[maxn];
ll ABS(ll x){
    return x > 0 ? x : -x;
}
void dfs(int u, int pre){
    dp[u] = val[u];
    for(int i = 0; i < (int)G[u].size(); i++)
    {
        int v = G[u][i];
        if(v == pre) continue;
        dfs(v, u);
        dp[u] += dp[v];
    }
    ans = min(ans, ABS(sum - 2 * dp[u]));
}
int main()
{
    int a, b, c = 0;
    while(scanf("%d%d", &n, &m), n || m)
    {
        for(int i = 0; i <= n; i++) G[i].clear();
        sum = 0;
        for(int i = 1; i <= n; i++)
        {
            scanf("%I64d", &val[i]);
            sum += val[i];
        }
        while(m--)
        {
            scanf("%d%d", &a, &b);
            G[a].push_back(b);
            G[b].push_back(a);
        }
        ans = INF;
        dfs(1, -1);
        printf("Case %d: %I64d\n", ++c, ans);
    }
    return 0;
}