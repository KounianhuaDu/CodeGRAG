// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=305;
int e[maxn][maxn];
int match[maxn];
bool vis[maxn];
int n;
bool dfs(int u){
    for(int i=1;i<maxn;i++){
        if(e[u][i]==1&&!vis[i]){
            vis[i]=1;
            if(match[i]==-1||dfs(match[i])){
                match[i]=u;
                return 1;
            }
        }
    }
    return 0;
}
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    int n;
    while(cin>>n){
        memset(match,-1,sizeof(match));
        memset(vis,0,sizeof(vis));
        memset(e,0,sizeof(e));
        int k;
        for(int i=0;i<n;i++){
            cin>>k;
            int a,b;
            while(k--){
                cin>>a>>b;
                e[i+1][(a-1)*12+b]=1;
            }
        }
        int ans=0;
        for(int i=1;i<=n;i++){
            memset(vis,0,sizeof(vis));
            if(dfs(i)) ans++;
        }
        cout<<ans<<endl;
    }
    return 0;
}