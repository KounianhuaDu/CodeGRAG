// Data Structure->Stack,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 300
char temp[maxn];
int value[128];
int stacki;
string c,s;
void adjust()
{
    s.clear();
    stacki=0;
    for(int i=0;i!=c.size();i++)
        if(c[i]=='(')
            temp[stacki++]=-1;
        else if(c[i]==')')
        {
            while(temp[stacki-1]!=-1)
                s.push_back(temp[--stacki]);
            stacki--;
        }
        else if(c[i]=='{')
        {
            for(;c[i]!='}';i++)
                s.push_back(c[i]);
            s.push_back(c[i]);
        }
        else
        {
            while(stacki!=0&&temp[stacki-1]!=-1&&value[temp[stacki-1]]>=value[c[i]])
                s.push_back(temp[--stacki]);
            temp[stacki++]=c[i];
        }
    while(stacki!=0)
        s.push_back(temp[--stacki]);
}
set<char>solve()
{
    set<char>stacktt1[maxn];
    set<char>temp;
    stacki=0;
    for(int i=0;i!=s.size();i++)
        if(s[i]=='{')
        {
            i++;
            stacktt1[stacki].clear();
            for(;s[i]!='}';i++)
                stacktt1[stacki].insert(s[i]);
            stacki++;
        }
        else if(s[i]=='+')
        {
            --stacki;
            temp.clear();
            set_union(stacktt1[stacki-1].begin(),stacktt1[stacki-1].end(),
                        stacktt1[stacki].begin(),stacktt1[stacki].end(),
                        inserter(temp,temp.begin()));
            stacktt1[stacki-1]=temp;
        }
        else if(s[i]=='-')
        {
            --stacki;
            temp.clear();
            set_difference(stacktt1[stacki-1].begin(),stacktt1[stacki-1].end(),
                        stacktt1[stacki].begin(),stacktt1[stacki].end(),
                        inserter(temp,temp.begin()));
            stacktt1[stacki-1]=temp;
        }
        else
        {
            --stacki;
            temp.clear();
            set_intersection(stacktt1[stacki-1].begin(),stacktt1[stacki-1].end(),
                        stacktt1[stacki].begin(),stacktt1[stacki].end(),
                        inserter(temp,temp.begin()));
            stacktt1[stacki-1]=temp;
        }
    return stacktt1[0];
}
int main()
{
    value['+']=value['-']=0;
    value['*']=1;
    while(cin>>c)
    {
        adjust();
        set<char>ans=solve();
        printf("{");
        for(set<char>::iterator i=ans.begin();i!=ans.end();i++)
            printf("%c",*i);
        printf("}\n");
    }
    return 0;
}