// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m;
int v[15];
int d[15][15][1<<13];
long long num[15][15][1<<13];
int g[15][15];
int mi[15];
int base[20000][15];
inline int get(int k,int i,int j)
{
    if(g[k][j])return v[k]*v[i]*v[j];
    return 0;
}
int main()
{
    int temp=1;
    for(int i=0;i<=13;i++)
    {
        mi[i]=temp;
        temp *=2;
    }
    memset(base,0,sizeof(base));
    for(int value=0;value<mi[13];value++)
    {
        temp = value;
        int p=0;
        while(temp>0)
        {
            base[value][p++]=temp%2;
            temp/=2;
        }
    }
    int t;
    while(scanf("%d",&t)==1&&t)
    {
        while(t--)
        {
            scanf("%d%d",&n,&m);
            for(int i=0;i<n;i++)
                scanf("%d",&v[i]);
            memset(g,0,sizeof(g));
            for(int i=0;i<m;i++)
            {
                int a,b;
                scanf("%d%d",&a,&b);
                a--;b--;
                g[a][b]=g[b][a]=1;
            }
            if(n==1)
            {
                printf("%d 1\n",v[0]);
                continue;
            }
            memset(d,-1,sizeof(d));
            memset(num,0,sizeof(num));
            for(int i=0;i<n;i++)
                for(int j=0;j<n;j++)if(i!=j && g[i][j] )
                {
                    d[i][j][mi[i]+mi[j]]=v[i]+v[j]+v[i]*v[j];
                    num[i][j][mi[i]+mi[j]]=1;
                }
            for(int S=0;S<mi[n];S++)
            {
                for(int i=0;i<n;i++)if(base[S][i]==1)
                {
                    for(int j=0;j<n;j++)if(i!=j && base[S][j]==1 &&g[i][j])
                    {
                        if(d[i][j][S]==-1)continue;
                        for(int k=0;k<n;k++)if(base[S][k]==0 && g[k][i])
                        {
                            if( d[k][i][S+mi[k]] < d[i][j][S]+v[k]+v[k]*v[i]+get(k,i,j) )
                            {
                                d[k][i][S+mi[k]]=d[i][j][S]+v[k]+v[k]*v[i]+get(k,i,j);
                                num[k][i][S+mi[k]] = num[i][j][S];
                            }
                            else if( d[k][i][S+mi[k]] == d[i][j][S]+v[k]+v[k]*v[i]+get(k,i,j) )
                            {
                                num[k][i][S+mi[k]] += num[i][j][S];
                            }
                        }
                    }
                }
            }
            long long sum = 0;
            int max_sum=0;
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<n;j++)if(i!=j && g[i][j])
                {
                    if(max_sum < d[i][j][(1<<n)-1])
                    {
                        max_sum=d[i][j][(1<<n)-1];
                        sum = num[i][j][(1<<n)-1];
                    }
                    else if(max_sum == d[i][j][(1<<n)-1])
                    {
                        sum += num[i][j][(1<<n)-1];
                    }
                }
            }
            printf("%d %I64d\n",max_sum,sum/2);
        }
    }
    return 0;
}