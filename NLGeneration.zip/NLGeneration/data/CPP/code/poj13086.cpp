// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=100000+10;
int n;
struct dian
{
    int x,y;
    dian(){}
    dian(int x,int y):x(x),y(y){}
}di[maxn];
struct TwoSAT
{
    int n;
    vector<int> G[maxn*5];
    int S[maxn*5],c;
    bool mark[maxn*2];
    bool dfs(int x)
    {
        if(mark[x^1]) return false;
        if(mark[x]) return true;
        mark[x]=true;
        S[c++]=x;
        for(int i=0;i<G[x].size();i++)
            if(!dfs(G[x][i])) return false;
        return true;
    }
    void init(int n)
    {
        this->n=n;
        for(int i=0;i<n*2;i++) G[i].clear();
        memset(mark,0,sizeof(mark));
    }
    void add_clause(int x,int xval,int y,int yval)
    {
        x=x*2+xval;
        y=y*2+yval;
        G[x].push_back(y);
    }
    bool solve()
    {
        for(int i=0;i<2*n;i+=2)
        if(!mark[i] && !mark[i+1])
        {
            c=0;
            if(!dfs(i))
            {
                while(c>0) mark[S[--c]]=false;
                if(!dfs(i+1)) return false;
            }
        }
        return true;
    }
}TT;
bool ss(int mid)
{
    TT.init(n);
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if(abs(di[i].x-di[j].x)<mid)
            {
                if(di[i].y==di[j].y)
                {
                    TT.add_clause(i,0,j,1);
                    TT.add_clause(i,1,j,0);
                    TT.add_clause(j,0,i,1);
                    TT.add_clause(j,1,i,0);
                }
                else if(abs(di[i].y-di[j].y)<mid)
                {
                    if(di[i].y>di[j].y)
                    {
                        TT.add_clause(i,1,i,0);
                        TT.add_clause(j,0,j,1);
                        TT.add_clause(i,0,j,1);
                        TT.add_clause(j,1,i,0);
                    }
                    if(di[i].y<di[j].y)
                    {
                         TT.add_clause(j,1,j,0);
                         TT.add_clause(i,0,i,1);
                        TT.add_clause(i,1,j,0);
                        TT.add_clause(j,0,i,1);
                    }
                }
                else if(abs(di[i].y-di[j].y)<2*mid)
                {
                        if(di[i].y>di[j].y)
                        {
                            TT.add_clause(i,1,j,1);
                            TT.add_clause(j,0,i,0);
                        }
                        if(di[i].y<di[j].y)
                        {
                            TT.add_clause(j,1,i,1);
                            TT.add_clause(i,0,j,0);
                        }
                }
            }
        }
    }
    return TT.solve();
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d",&n);
        {
            for(int i=0;i<n;i++)
            {
                int x,y;
                scanf("%d%d",&x,&y);
                di[i]=dian(x,y);
            }
        }
        int L=0,R=20000+1;
        while(R>L)
        {
            int mid = L+(R-L+1)/2;
            if(ss(mid)) L=mid;
            else R=mid-1;
        }
        printf("%d\n",L);
    }
}