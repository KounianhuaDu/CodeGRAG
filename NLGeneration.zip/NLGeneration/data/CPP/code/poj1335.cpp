// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

const int MAXN=1000+10;
using namespace std;
long long num[20][5][5][2];
int n;
long long dfs(int a,int b,int c,int d,int e)
{
	if(a==n){
		if(d && b>=3) return 1;
		else return 0;
	}
	if(num[a][b][c][d]!=-1) return num[a][b][c][d];
	long long ans=0;
	for(int i=1; i<=4; i++){
		int x=0;
		if(c==1 && i==4) x=1;
		else if(c==4 && i==1) x=1;
		int y;
		if((1<<(i-1))&e) y=b;
		else y=b+1;
		if(y>3) y=3;
		ans+=dfs(a+1, y, i, d||x, e|(1<<(i-1)));
	}
	num[a][b][c][d]=ans;
	return ans;
}
int main()
{
	
	while(cin>>n, n!=-1)
	{
		memset(num,-1,sizeof(num));
		long long res=dfs(0,0,0,0,0);
		cout<<n<<": "<<res<<endl;
	}
	return 0;
}