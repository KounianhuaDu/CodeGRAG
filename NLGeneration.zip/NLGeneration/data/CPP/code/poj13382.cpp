// Graph Algorithm->Kruskal's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Maxn 110
using namespace std;
struct line{
    int u,v;
    double w;
    line(){}
    line(int uu,int vv,double ww):u(uu),v(vv),w(ww){}
    bool operator<(const line &a)const{
        return w<a.w;
    }
}edge[Maxn*Maxn];
double x[Maxn],y[Maxn],z[Maxn],r[Maxn];
int fa[Maxn];
double dis(int a,int b){
    return sqrt((x[a]-x[b])*(x[a]-x[b])+(y[a]-y[b])*(y[a]-y[b])+(z[a]-z[b])*(z[a]-z[b]));
}
void init(int n){
    for(int i=0;i<n;i++)
        fa[i]=i;
}
int findset(int x){
    return x==fa[x]?x:(fa[x]=findset(fa[x]));
}
void unionset(int a,int b){
    fa[a]=b;
}
double kruskal(int n,int tot){
    int cnt=0;
    double ans=0;
    for(int i=0;i<tot;i++){
        int a=findset(edge[i].u),b=findset(edge[i].v);
        if(a!=b){
            ans+=edge[i].w;
            unionset(a,b);
            if(++cnt==n-1) return ans;
        }
    }
}
int main()
{
    int n;
    while(scanf("%d",&n),n){
        for(int i=0;i<n;i++)
            scanf("%lf%lf%lf%lf",x+i,y+i,z+i,r+i);
        int tot=0;
        for(int i=0;i<n;i++)
            for(int j=i+1;j<n;j++){
                double tp=dis(i,j)-r[i]-r[j];
                edge[tot++]=line(i,j,tp<0?0:tp);
            }
        sort(edge,edge+tot);
        init(n);
        double ans=kruskal(n,tot);
        printf("%.3f\n",n==1?0:ans);
    }
	return 0;
}