// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Max = 105;
int main()
{
    int n, m, i, j, k, minute;
    int maptt1[Max][Max];
	
    while(cin >> n && n != 0)
	{
        for(i = 1; i <= n; i ++)
            for(j = 1; j <= n; j ++)
                maptt1[i][j] = 999; 
			for(i = 1; i <= n; i ++)
			{
				cin >> m;
				while(m --)
				{
					cin >> j >> minute;
					maptt1[i][j] = minute;
				}
			}
			
			
			
			for(k = 1; k <= n; k ++)   
				for(i = 1; i <= n; i ++)
					for(j = 1; j <= n; j ++)
						if(maptt1[i][k] + maptt1[k][j] < maptt1[i][j])
							maptt1[i][j] = maptt1[i][k] + maptt1[k][j];
						
						
						
						int sum, stockbroker, time = 9999;
						for(i = 1; i <= n; i ++)
						{
							sum = 0;
							for(j = 1; j <= n; j ++)    
								if(i != j && maptt1[i][j] > sum)
									sum = maptt1[i][j];
								if(sum < time)
								{
									stockbroker = i;
									time = sum;
								}
						}
						cout << stockbroker << ' ' << time << endl;
	}
	return 0;
}