// Math and Computational Geometry->Pigeonhole Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAX_SIZE 10005
int nums[MAX_SIZE];
int sums[MAX_SIZE];
vector< int > count_vector[MAX_SIZE];
int main()
{
    sums[0] = 0;
    int ans_len = -1, ans_start, ans_end;
    int limit_num;
    
    cin >> limit_num;
    
    for( int i = 1; i <= limit_num; ++i ){
        
        cin >> nums[i];
        sums[i]     = nums[i] + sums[i - 1];
        sums[i - 1] = sums[i - 1] % limit_num;
        
    }
    
    sums[limit_num] = sums[limit_num] % limit_num;
    
    for( int i = 1; i <= limit_num; ++i ){
        if( sums[i] == 0 ){
            
            ans_len = i;
            ans_start = 1;
            ans_end = i;
            
            break;
        }
    }
    
    if( ans_len == -1 ){
        for( int i = 1; i <= limit_num; ++i ){
            
            int index = sums[i];
            count_vector[index].push_back( i );
            
            if( count_vector[index].size() > 1 ){
                ans_start = count_vector[index][0] + 1;
                ans_end   = count_vector[index][1];
                ans_len   = ans_end - ans_start + 1;
            }
        }
    }
    
    cout << ans_len << '\n';
    for( int i = ans_start; i <= ans_end; ++i ){
        cout << nums[i] << '\n';
    }
    
    return 0;
}