// Basic Algorithm->Recursion,Basic Algorithm->Simulation,Sorting->Topological Sort,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define CLEAR(xxx) memset(xxx,0,sizeof(xxx))
using namespace std;
const int maxn=100000+5,inf=1e9;
int n,m,e,tot,L[maxn],R[maxn],s[maxn],c[maxn];
int to[maxn<<2],Next[maxn<<2],last[maxn];
inline int lowbit(int x) {return x&-x;}
inline void _read(int &x){
	char ch=getchar(); bool mark=false;
	for(;!isdigit(ch);ch=getchar())if(ch=='-')mark=true;
	for(x=0;isdigit(ch);ch=getchar())x=x*10+ch-'0';
	if(mark)x=-x;
} 
void Add(int x,int d){
	for(;x<=n;x+=lowbit(x)) c[x]+=d;
}
int Sum(int x){
	int ans;
	for(ans=0;x>0;x-=lowbit(x)) ans+=c[x];
	return ans;
}
void add_edge(int From,int To){
	Next[++e]=last[From];
	last[From]=e;
	to[e]=To;
}
void DFS(int v,int fa){
	L[v]=++tot;   
	for(int i=last[v];i;i=Next[i]){
		if(to[i]==fa) continue;
		DFS(to[i],v);
	}
	R[v]=tot;      
}
int main(){
	int i,x,y,p;
	_read(n); 
	for(i=1;i<n;i++){
		_read(x); _read(y);
		add_edge(x,y);
		add_edge(y,x);
	}
	DFS(1,0);
	for(i=1;i<=n;i++){    
		s[i]=1;
		Add(i,1);
	}
	_read(m);
	while(m--){
		char ch;
		cin>>ch;
		_read(p);
		if(ch=='C'){
			p=L[p];
			if(s[p]==1)Add(p,-1);
			else Add(p,1);
			s[p]=1-s[p];
		}
		else {
			printf("%d\n",Sum(R[p])-Sum(L[p]-1));
		}
	}
	return 0;
}