// Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 100;
int n, g[N + 1][N + 1], din[N + 1], ans[N + 1];
void toposort()
{
    for(int i = 1; i <=n; i++) {
        int j;
        for(j = 1; j <= n; j++) {
            if(din[j] == 0)
                break;
        }
        din[j] = -1;
        ans[i] = j;
        
        for(int k = 1; k <= n; k++) {
            if(g[j][k])
                din[k]--;
        }
    }
}
int main()
{
    ios::sync_with_stdio(false);
    while(cin >> n) {
        memset(g, 0, sizeof(g));        
        memset(din, 0, sizeof(din));    
        
        for(int i = 1; i <= n; i++) {
            int a;
            while(cin >> a && a) {
                g[i][a] = 1;    
                din[a]++;       
            }
        }
        
        toposort();
        
        for(int i = 1; i < n; i++)
            cout << ans[i] << " ";
        cout << ans[n] << endl;
    }
    return 0;
}