// Data Structure->Queue,Dynamic Programming->Monotone Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int N=1000005,inf=0x3f3f3f3f;
int n,l,a,b,s,e,head,tail,c[N],f[N],q[N];
int main(){
    scanf("%d%d%d%d",&n,&l,&a,&b);
    for(int i=1;i<=n;i++){
        scanf("%d%d",&s,&e);
        c[s+1]++;
        c[e]--;
    }
    for(int i=1;i<=l;i++){
        c[i]+=c[i-1];
    }
    head=1,tail=0;
    for(int i=2;i<=l;i+=2){
        while(head<=tail&&q[head]<i-2*b){
            head++;
        }
        if(i-2*a>=0){
            while(head<=tail&&f[i-2*a]<=f[q[tail]]){
                tail--;
            }
            q[++tail]=i-2*a;
        }
        if(c[i]){
            f[i]=inf;
        }else{
            if(head<=tail){
                if(f[q[head]]!=inf){
                    f[i]=f[q[head]]+1;
                }else{
                    f[i]=inf;
                }
            }else{
                f[i]=inf;
            }
        }
    }
    printf("%d\n",f[l]==inf?-1:f[l]);
    return 0;
}