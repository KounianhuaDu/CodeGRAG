// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

    
    int pon[110][110];
    int cur = 0,color[110][110];
    void dfs(int i,int j)
    {
       color[i][j] = cur;
       if(pon[i-1][j-1] && !color[i-1][j-1]&& j>1&& i>1)
         dfs(i-1,j-1);
       if(pon[i-1][j] && !color[i-1][j]&& i>1)
         dfs(i-1,j);
       if(pon[i-1][j+1] && !color[i-1][j+1]&& i>1)
         dfs(i-1,j+1);
       if(pon[i][j-1] && !color[i][j-1]&& j>1)
         dfs(i,j-1);
       if(pon[i][j+1] && !color[i][j+1])
         dfs(i,j+1);
       if(pon[i+1][j-1]&& !color[i+1][j-1]&& j>1)
         dfs(i+1,j-1);
       if(pon[i+1][j] && !color[i+1][j])
         dfs(i+1,j);
       if(pon[i+1][j+1] && !color[i+1][j+1])
         dfs(i+1,j+1);
    }
    int main()
    {
       int n = 0,m = 0;
       int i = 0,j = 0;
       char c = 0;
       scanf("%d%d",&n,&m);
       getchar();
       for(i = 1;i<=n;i++)
       {
         for(j = 1;j<=m;j++)
         {
             scanf("%c",&c);
             if(c == 'W')
               pon[i][j] = 1;
             else
               pon[i][j] = 0;
             color[i][j] = 0;
         }
         getchar();
       }
        for(i = 1;i<=n;i++)
         for(j = 1;j<=m;j++)
         {
            if(!color[i][j] && pon[i][j])
            {
              ++cur;
              dfs(i,j);
            }
         }
        printf("%d",cur);
       return 0;
    }