// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x3f3f3f3f
#define ll long long
#define fo freopen("in.txt","r",stdin)
#define fc fclose(stdin)
#define fu0(i,n) for(i=0;i<n;i++)
#define fu1(i,n) for(i=1;i<=n;i++)
#define fd0(i,n) for(i=n-1;i>=0;i--)
#define fd1(i,n) for(i=n;i>0;i--)
#define mst(a,b) memset(a,b,sizeof(a))
#define sd(n) scanf("%d",&n)
#define sdd(n,m) scanf("%d %d",&n,&m)
#define ss(s) scanf("%s",s)
#define sddd(n,m,k) scanf("%d %d %d",&n,&m,&k)
#define pans(ans) printf("%d\n",ans)
#define all(a) a.begin(),a.end()
#define sc(c) scanf("%c",&c)
const int maxn=200005;
const double eps=1e-8;
const double PI = acos(-1.0);
char g[105][105];
    int n,m;
void dfs(int a,int b)
{
    g[a][b]='.';
    for(int i=-1;i<=1;i++)
    {
        for(int j=-1;j<=1;j++)
        {
            int dx=a+i;
            int dy=b+j;
            if(dx>=0&&dx<n&&dy>=0&&dy<m&&g[dx][dy]=='W')
            {
                dfs(dx,dy);
            }
        }
    }
    return ;
}
int main()
{
    while(~sdd(n,m))
    {
        for(int i=0;i<n;i++)
        {
               ss(g[i]);
        }
       int res=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                if(g[i][j]=='W')
                {
                    dfs(i,j);
                    res++;
                }
            }
        }
        pans(res);
    }
    return 0;
}