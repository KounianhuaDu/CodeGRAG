// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 10005
using namespace std;
pair<int, int> a[maxn];
int main(){
    int n,l,p;
    int i,j,k;
    scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d%d",&a[i].first,&a[i].second);
        }
        scanf("%d%d",&l,&p);
        a[n].first=l;
        a[n].second=0;
        for(i=0;i<n;i++){
            a[i].first=l-a[i].first;
        }
        n++;
        sort(a,a+n);
        priority_queue<int> q;
        int ans=0,pos=0,tank=p,distance;
        for(i=0;i<n;i++){
            distance=a[i].first-pos;
            
            while(tank-distance<0){
                if(q.empty()){
                    printf("-1\n");
                    return 0;
                }
                tank+=q.top();
                q.pop();
                ans++;
            }
            tank-=distance;
            pos=a[i].first;
            q.push(a[i].second);
        }
        printf("%d\n",ans);
    return 0;
}