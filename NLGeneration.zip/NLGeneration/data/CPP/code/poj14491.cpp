// Dynamic Programming->Bitmask Dynamic Programming (DP)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define LL __int64_t
#define inf 1999999999
#define N 1010
#define mod 1000000007
int dp[N];
bool judge(int x,int k)
{
    int res=0;
    while(x)
    {
        res+=(x&1);
        x>>=1;
    }
    return res<=k;
}
int main()
{
    int i,j,m,n,k,num,x;
    while(scanf("%d%d%d",&n,&m,&k)!=-1)
    {
        memset(dp,0,sizeof(dp));
        for(i=1;i<=n;i++)
        {
            scanf("%d",&num);
            while(num--)
            {
                scanf("%d",&x);
                dp[i]|=1<<(x-1);
            }
        }
        int ans=0;
        for(i=0;i<(1<<m);i++)
        {
            if(judge(i,k)==0)
                continue;
            int tmp=0;
            for(j=1;j<=n;j++)
            {
                if((dp[j]&i)==dp[j])
                    tmp++;
            }
            ans=max(ans,tmp);
        }
        printf("%d\n",ans);
    }
    return 0;
}