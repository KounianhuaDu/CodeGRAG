// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ll long long
#define N 110000
#define mem(a,t) memset(a,t,sizeof(a))
const int inf=1000005;
int cnt,n;
struct node
{
    int v,next;
}e[N*20];
int head[N];
ll num[N];
ll ans,sum;
void add(int u,int v)
{
    e[cnt].v=v;
    e[cnt].next=head[u];
    head[u]=cnt++;
}
void dfs(int u,int len,int fa)
{
    int i,v;
    for(i=head[u];i!=-1;i=e[i].next)
    {
        v=e[i].v;
        if(v!=fa)
        {
            dfs(v,len+1,u);
            num[u]+=num[v];
        }
    }
    ll t=sum-2*num[u];
    if(t<0)
        t*=-1;
    if(t<ans)
        ans=t;
}
int main()
{
    
    int i,u,v,m,cas=1;
    while(scanf("%d%d",&n,&m),n||m)
    {
        for(i=1,sum=0;i<=n;i++)
        {
            scanf("%lld",&num[i]);
            sum+=num[i];
        }
        cnt=0;
        mem(head,-1);
        for(i=0;i<m;i++)
        {
            scanf("%d%d",&u,&v);
            add(u,v);
            add(v,u);
        }
        ans=sum;
        dfs(1,0,-1);
        printf("Case %d: %lld\n",cas++,ans);
    }
    return 0;
}