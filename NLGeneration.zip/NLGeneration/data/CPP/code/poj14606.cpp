// Basic Algorithm->Greedy Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAX 30
using namespace std;
const int dx[] = {0,-1,1,-2,2,-2,2,-1,1};
const int dy[] = {0,-2,-2,-1,-1,1,1,2,2};
int cases;
pair<int,int> ans[MAX];
bool v[MAX][MAX],judge[MAX][MAX];
int m,n;
bool finished;
inline void Initialize();
void DFS(int x,int y,int step);
int main()
{
	cin >> cases;
	for(int i = 1;i <= cases; ++i) {
		scanf("%d%d",&m,&n);
		Initialize();
		printf("Scenario #%d:\n",i);
		ans[1] = make_pair(1,1);
		v[1][1] = true;
		DFS(1,1,1);
		if(!finished)	puts("impossible");
		putchar('\n');
	}
	return 0;
}
inline void Initialize()
{
	finished = false;
	memset(v,false,sizeof(v));
	memset(judge,false,sizeof(judge));
	for(int i = 1;i <= m; ++i)
		for(int j = 1;j <= n; ++j)
			judge[i][j] = true;
}
void DFS(int x,int y,int step)
{
	if(finished)	return ;
	if(step == m * n) {
		for(int i = 1;i <= step; ++i)
			printf("%c%d",ans[i].second + 'A' - 1,ans[i].first);
		putchar('\n');
		finished = true;
		return ;
	}
	for(int i = 1;i <= 8; ++i) {
		int fx = x + dx[i];
		int fy = y + dy[i];
		if(judge[fx][fy] && !v[fx][fy]) {
			ans[step + 1] = make_pair(fx,fy);
			v[fx][fy] = true;
			DFS(fx,fy,step + 1);
			v[fx][fy] = false;
		}
	}
}