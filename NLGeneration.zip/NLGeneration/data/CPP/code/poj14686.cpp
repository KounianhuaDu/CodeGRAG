// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 1e6+10;
int a[N],n,m;
bool judge(int k)
{
    int cnt = a[0], num = 1;
    for(int i = 1; i < n; i ++)
    {
        if(a[i] - cnt >= k)
        {
            cnt = a[i];
            num ++;
        }
        if(num >= m) return true;
    }
    return false;
}
void solve()
{
    int l = 1, r = a[n-1] - a[0];
    while(l < r)
    {
        int mid = (l+r) >> 1;
        if(judge(mid)) l = mid + 1;
        else r = mid;
    }
    printf("%d\n",r-1);
}
int main()
{
    int i;
    while(~scanf("%d%d",&n,&m))
    {
        for(i = 0; i < n; i ++)
            scanf("%d",&a[i]);
        sort(a, a+n);
        solve();
    }
    return 0;
}