// Data Structure->Segment Tree,Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 200005;
const int INF = 0x3f3f3f3f;
struct Point {
    int x, y;
    bool operator < (const Point &a) const { return x < a.x; }
}p[N];
int n, tree1[N << 2], tree2[N << 2], numh[N], numl[N], res1;
vector<int> a, b, res2;
map<int, int> mp;
void pushdown(int k) {
    tree1[k * 2] += tree1[k];
    tree1[k * 2 + 1] += tree1[k];
    tree2[k * 2] += tree2[k];
    tree2[k * 2 + 1] += tree2[k];
    tree1[k] = tree2[k] = 0;
}
void build(int k, int left, int right) {
    tree1[k] = tree2[k] = 0;
    if (left == right) {
        tree1[k] = numh[left];
        tree2[k] = numl[left];
        return;
    }
    int mid = (left + right) / 2;
    build(k * 2, left, mid);
    build(k * 2 + 1, mid + 1, right);
}
void modify(int k, int left, int right, int l, int r, int flag, int v) {
    if (l <= left && right <= r) {
        if (flag == 1) tree1[k] += v;
        else tree2[k] += v;
        return;
    }
    pushdown(k);
    int mid = (left + right) / 2;
    if (l <= mid)
        modify(k * 2, left, mid, l, r, flag, v);
    if (r > mid)
        modify(k * 2 + 1, mid + 1, right, l, r, flag, v);
}
void query(int k, int left, int right, int pos, int& temp1, int& temp2) {
    if (left == right) {
        temp1 = tree1[k];
        temp2 = tree2[k];
        return;
    }
    pushdown(k);
    int mid = (left + right) / 2;
    if (pos <= mid)
        query(k * 2, left, mid, pos, temp1, temp2);
    else
        query(k * 2 + 1, mid + 1, right, pos, temp1, temp2);
}
int main() {
    while (scanf("%d", &n) == 1 && n) {
        a.clear(), b.clear(), mp.clear(), res2.clear();
        for (int i = 0; i < n; i++) {
            scanf("%d%d", &p[i].x, &p[i].y);
            a.push_back(p[i].y);
        }
        sort(p, p + n);
        sort(a.begin(), a.end());
        b.push_back(a[0]);
        int m = 0;
        numl[m] = 0;
        mp[a[0]] = 0;
        for (int i = 0; i < n; i++) {
            if (b[m] != a[i]) {
                numh[m] = n - i;
                numl[++m] = i;
                b.push_back(a[i]);
                mp[b[m]] = m;
            }
        }
        numh[m] = 0;
        build(1, 0, m);
        res1 = 0;
        for (int cur1 = 0; cur1 < n;) {
            int cur2 = cur1;
            while (cur2 < n && p[cur1].x == p[cur2].x) {
                if (p[cur2].y != b[0])
                    modify(1, 0, m, mp[b[0]], mp[p[cur2].y] - 1, 1, -1);
                if (p[cur2].y != b[m])
                    modify(1, 0, m, mp[p[cur2].y] + 1, mp[b[m]], 2, -1);
                cur2++;
            }
            int maxx = 0, minn = INF;
            for (int i = cur1; i < cur2; i++) {
                int temp1, temp2;
                query(1, 0, m, mp[p[i].y], temp1, temp2);
                minn = min(minn, temp1);
                maxx = max(maxx, temp2);
            }
            if (minn == res1)
                res2.push_back(maxx);
            else if (minn > res1) {
                res1 = minn;
                res2.clear();
                res2.push_back(maxx);
            }
            for (int i = cur1; i < cur2; i++) {
                if (p[i].y != b[0])
                    modify(1, 0, m, mp[b[0]], mp[p[i].y] - 1, 2, 1);
                if (p[i].y != b[m])
                    modify(1, 0, m, mp[p[i].y] + 1, mp[b[m]], 1, 1);
            }
            cur1 = cur2;
        }
        sort(res2.begin(), res2.end());
        res2.erase(unique(res2.begin(), res2.end()), res2.end());
        printf("Stan: %d; Ollie:", res1);
        int sz = res2.size();
        for (int i = 0; i < sz; i++)
            printf(" %d", res2[i]);
        printf(";\n");
    }
    return 0;
}