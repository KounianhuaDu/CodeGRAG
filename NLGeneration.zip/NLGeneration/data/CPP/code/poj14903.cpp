// Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int phi[1000100],prime[1000100];
void s()
{
    prime[0]=prime[1]=0;
     for(int i=2;i*i<=1000000;i++)
     {
        if(prime[i])
         {
            for(int j=i*i;j<=1000000;j+=i)
             {
                 prime[j]=0;
             }
         }
     }
}
void oula()
{
    for(int i=1;i<=1000000;i++)
     {
         phi[i]=i;
     }
    for(int i=2;i<=1000000;i++)
     {
        if(prime[i])
         {
            for(int j=i;j<=1000000;j+=i)
             {
                 phi[j]=phi[j]/i*(i-1);    
             }
         }
     }
}
int main()
{
    int m;
    __int64_t num;
    memset(prime,1,sizeof(prime));
    s();
    oula();
    while(cin>>m&&m!=0)
    {
        num=0;
        for(int i=2;i<=m;i++)
            num+=phi[i];
        cout<<num<<endl;
    }
    return 0;
}