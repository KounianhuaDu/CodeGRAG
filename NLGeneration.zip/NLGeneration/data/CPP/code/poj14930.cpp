// Math and Computational Geometry->Euler's Totient Function
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ll long long
#define mem(a) memset(a,0,sizeof(a))
const double eps=1e-8;
const int maxn=300010;
const int inf=0x3f3f3f3f;
ll eular(ll n)
{
    ll ans=n;
    for(int i=2;i*i<= n;i++)
    {
        if(n%i == 0)
        {
            ans-=ans/i;
            while(n%i == 0)
                n/=i;
        }
    }
    if(n > 1)
        ans-= ans/n;
    return ans;
}
ll num[maxn];
int main()
{
    ll a;
    ll res=0;
    ll i;
    ll t=0;
    while(cin>>a)
    {
        res=0;
        t=0;
        for(i=1;i*i <= a ;i++)
        {
            if(i*i == a)
                num[t++]=i;
            else if(a%i==0)
            {
                num[t++]=i;
                num[t++]=a/i;
            }
        }
        if(t==2)
        {
            cout<<a*2-1<<endl;
            continue;
        }
        for(i=0;i<t;i++)
            res+=num[i]*eular(a/num[i]);
        cout<<res<<endl;
    }
    return 0;
}