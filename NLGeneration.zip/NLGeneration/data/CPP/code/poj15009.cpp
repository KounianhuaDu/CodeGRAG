// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int ans[100][2];
int vis[100][100];
int fx[] = { -1, 1, -2, 2, -2, 2, -1, 1 },
fy[] = { -2, -2, -1, -1, 1, 1, 2, 2 };
int n,m;
int ok;
int kase;
void dfs(int x,int y,int cur)
{
    if(ok==1)
    return ;
    if(cur==n*m)
    {
        ok=1;
        printf("Scenario #%d:\n",++kase);
        for(int i=1;i<cur;i++)
        {
            printf("%c%d",ans[i][1]+'A'-1,ans[i][0]);
        }
        printf("%c%d\n",y+'A'-1,x);
        return ;
    }
    ans[cur][0]=x;
    ans[cur][1]=y;
    vis[x][y]=1;
    for(int i=0;i<8;i++)
    {
        int xx=x+fx[i];
        int yy=y+fy[i];
        if(xx>=1&&xx<=n&&yy>=1&&yy<=m&&vis[xx][yy]==0)
        {
            vis[xx][yy]=1;
            dfs(xx,yy,cur+1);
            vis[xx][yy]=0;
        }
    }
    return ;
}
int main()
{
    kase=0;
    int t;
    scanf("%d",&t);
    while(t--)
    {
        ok=0;
        memset(vis,0,sizeof(vis));
        scanf("%d%d",&n,&m);
        dfs(1,1,1);
        if(ok==0)
        {
            printf("Scenario #%d:\nimpossible\n",++kase);
        }
        printf("\n");
    }
}