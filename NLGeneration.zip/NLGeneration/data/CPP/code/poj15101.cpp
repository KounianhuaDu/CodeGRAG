// Math and Computational Geometry->Gaussian Elimination
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int nMax=305;
const int MOD=7;
int freex[nMax],x[nMax],a[nMax][nMax],N,M;
char week[7][10]={"MON","TUE","WED","THU","FRI","SAT","SUN"};
int getday(char s[])
{
    for(int i=0;i<7;i++)
        if(strcmp(week[i],s)==0)
            return i;
}
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
int lcm(int a,int b)
{
    return a/gcd(a,b)*b;
}
void exgcd(int a,int b,int &x,int &y)
{
     b?(exgcd(b,a%b,y,x),y-=x*(a/b)):(x=1,y=0);
}
int guass(int n,int m)
{
    memset(x,0,sizeof(x));
    
    memset(freex,0,sizeof(freex));
    int row=0,col=0;
    for(;row<n&&col<m;col++)
    {
        int maxr=row;
        for(int i=row+1;i<n;i++)
            if(abs(a[i][col])>abs(a[maxr][col]))maxr=i;
        if(maxr!=row) for(int i=0;i<=m;i++) swap(a[maxr][i],a[row][i]);
        if(a[row][col]==0) continue;
        for(int i=row+1;i<n;i++)
            if(a[i][col]!=0)
            {
                int g=lcm(abs(a[row][col]),abs(a[i][col]));
                int ga=g/abs(a[row][col]),gb=g/abs(a[i][col]);
                if(a[row][col]*a[i][col]<0) ga=-ga;
                for(int j=col;j<=m;j++)
                {
                    a[i][j]=(a[i][j]*gb-a[row][j]*ga)%MOD;
                    if(a[i][j]<0) a[i][j]+=MOD;
                }
            }
        row++;
    }
    
    for(int i=row;i<n;i++) if(a[i][m]!=0) return -1;
    
    if(row<m) return m-row;
    
    for(int i=m-1;i>=0;i--)
    {
        int tmp=0,tx,ty;
        for(int j=i+1;j<m;j++)tmp+=x[j]*a[i][j];
        tmp=(a[i][m]-tmp)%MOD;
        if(tmp<MOD) tmp+=MOD;
        exgcd(a[i][i],MOD,tx,ty),tx%=MOD;
        x[i]=tx*tmp/gcd(a[i][i],MOD);
    }
    return 0;
}
int main()
{
    while(scanf("%d%d",&N,&M) &&N)
    {
        memset(a,0,sizeof(a));
        for(int i=0;i<M;i++)
        {
           int k,d[2],t;
           scanf("%d",&k);
           char s[10];
           for(int j=0;j<2;j++)
           {
               scanf("%s",s);d[j]=getday(s);
           }
           a[i][N]=(d[1]-d[0]+8)%7;
           for(int j=0;j<k;j++)
           {
               scanf("%d",&t);
               a[i][t-1]++;a[i][t-1]%=MOD;
           }
        }
        int ans=guass(M,N);
        if(ans==-1) printf("Inconsistent data.\n");
        else if(ans>0) printf("Multiple solutions.\n");
        else
        {
            for(int i=0;i<N;i++)
            {
                x[i]=(x[i]%MOD+MOD)%MOD;
                if(x[i]<3) x[i]+=MOD;
                printf("%d%c",x[i],i==N-1?'\n':' ');
            }
        }
    }
    return 0;
}