// Data Structure->Segment Tree,Basic Algorithm->Discretization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct node
{
    int l,r;
    int v;
}t[80005];
int c,n,a[10005],b[10005],d[20010],num,ans;
bool vis[20010];
int p[10000005];
void pushdown(int rt)
{
    if(t[rt].v)
    {
        t[rt<<1].v=t[rt].v;
        t[rt<<1|1].v=t[rt].v;
        t[rt].v=0;
    }
}
void create(int ll,int rr,int rt)
{
    if(ll>rr)return;
    t[rt].l=ll;
    t[rt].r=rr;
    t[rt].v=0;
    if(ll==rr)return;
    int m=(ll+rr)/2;
    create(ll,m,rt<<1);
    create(m+1,rr,rt<<1|1);
}
void update(int ll,int rr,int rt,int va)
{
    if(t[rt].l>t[rt].r||ll>rr)return;
    if(t[rt].l==ll&&t[rt].r==rr)
    {
        t[rt].v=va;
        return;
    }
    else
    {
        if(t[rt].v)pushdown(rt);
        int m=(t[rt].l+t[rt].r)/2;
        if(rr<=m)update(ll,rr,rt<<1,va);
        else if(ll>m)update(ll,rr,rt<<1|1,va);
        else
        {
            update(ll,m,rt<<1,va);
            update(m+1,rr,rt<<1|1,va);
        }
    }
}
void query(int rt)
{
    if(t[rt].l>t[rt].r)return;
    if(t[rt].v)
    {
        if(vis[t[rt].v]==0)
        {
            ans++;
            vis[t[rt].v]=1;
        }
    }
    else
    {
        if(t[rt].l==t[rt].r)return;
        query(rt<<1);
        query(rt<<1|1);
    }
}
int main()
{
    scanf("%d",&c);
    while(c--)
    {
        scanf("%d",&n);
        for(int i=0;i<n;i++)
        {
            scanf("%d%d",&a[i],&b[i]);
            d[i<<1]=a[i];
            d[i<<1|1]=b[i];
        }
        sort(d,d+(n<<1));
        memset(p,0,sizeof(p));
        num=0;
        int nn=(n<<1);
        for(int i=0;i<nn;i++)
        {
            if(p[d[i]]==0)p[d[i]]=++num;
        }
        for(int i=0;i<n;i++)
        {
            a[i]=p[a[i]];
            b[i]=p[b[i]];
        }
        create(1,num,1);
        for(int i=0;i<n;i++)
        {
            update(a[i],b[i],1,i+1);
        }
        memset(vis,0,sizeof(vis));
        ans=0;
        query(1);
        cout<<ans<<endl;
    }
    return 0;
}