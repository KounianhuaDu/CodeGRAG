// Basic Algorithm->Recursion,Dynamic Programming->Priority Queue,Data Structure->Queue,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int f[55],ans[55];
vector<int> vec[55];
bool cmp(const int &a,const int &b)
{
	return a<b;
}
void dfs(int x)
{
	printf("(");
	printf("%d",x);
	int l=vec[x].size();
	sort(vec[x].begin(),vec[x].end(),cmp);
	for(int i=0;i<l;i++)
	{
		printf(" ");
		dfs(vec[x][i]);
	}
	printf(")");
	vec[x].clear();
}
int main()
{
	int i,n=0;
	char c;
	string line;
	memset(ans,0,sizeof(ans));
	while(getline(cin,line))
	{
		stringstream ss(line);
		for(n=0;ss>>f[n];n++)
			ans[f[n]]++;
		n--;
			priority_queue<int,vector<int>,greater<int> > leafs;
			for(i=1;i<=n+1;i++)
				if(!ans[i]) leafs.push(i);
			for(i=0;i<=n;i++)
			{
				int k=leafs.top();
				leafs.pop();
				vec[f[i]].push_back(k);
				if(--ans[f[i]]==0) leafs.push(f[i]);
			}
			if(n!=-1) dfs(f[n]);
			else printf("(1)");
			printf("\n");
			memset(ans,0,sizeof(ans));
	}
}