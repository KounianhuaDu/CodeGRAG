// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 110, INF = 0x3f3f3f3f;
int v[N];
int dp[N*250][N];
int work(int n, int m, int r)
{
    memset(dp, -1, sizeof dp);
    dp[0][0] = 0;
    for(int i = 1; i <= n; i++)
        for(int j = m; j >= v[i]; j--)
            for(int k = r; k >= 1; k--)
                if(dp[j-v[i]][k-1] != -1)
                    dp[j][k] = max(dp[j][k], dp[j-v[i]][k-1] + v[i]);
    for(int i = m; i >= 0; i--)
    {
        if(n & 1)
        {
            if(dp[i][r-1] != -1 || dp[i][r] != -1) return i;
        }
        else
        {
            if(dp[i][r-1] != -1) return i;
        }
    }
}
int main()
{
    int n;
    while(~ scanf("%d", &n))
    {
        int sum = 0;
        for(int i = 1; i <= n; i++) scanf("%d", &v[i]), sum += v[i];
        int res = work(n, sum/2, n/2+1);
        printf("%d %d\n", min(res, sum-res), max(res, sum-res));
    }
    return 0;
}