// Graph Algorithm->Floyd-Warshall Algorithm,Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m,num;
int _map[1000][1000];
int link[1000],mark[1000];
void print()
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            printf("%d ",_map[i][j]);
        }
        printf("\n");
    }
}
void floyd()
{
    for(int k=0;k<n;k++)
    {
        for(int j=0;j<n;j++)
        {
            for(int i=0;i<n;i++)
            {
                if(_map[j][k]&&_map[k][i])
                {
                    _map[j][i]=1;
                }
            }
        }
    }
}
void init()
{
    for(int i=0;i<n;i++)
    {
        link[i]=-1;
        mark[i]=0;
        for(int j=0;j<n;j++)
        {
            _map[i][j]=0;
        }
    }
    num=0;
}
int dfs(int k)
{
    for(int i=0;i<n;i++)
    {
        if(_map[k][i]&&!mark[i])
        {
            mark[i]=1;
            if(link[i]==-1||dfs(link[i]))
            {
                link[i]=k;
                return 1;
            }
        }
    }
    return 0;
}
void hungery()
{
    for(int i=0;i<n;i++)
    {
        memset(mark,0,sizeof(mark));
        if(dfs(i))
        {
            num++;
        }
    }
    num=n-num;
}
int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        if(!n&&!m)
        {
            break;
        }
        init();
        for(int i=0;i<m;i++)
        {
            int a,b;
            scanf("%d%d",&a,&b);
            _map[a-1][b-1]=1;
        }
        floyd();
        hungery();
        printf("%d\n",num);
    }
    return 0;
}