// Math and Computational Geometry->Convex Hull Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double INF = 1e50;
const int N = 61111;
struct Point
{
    int x, y;
} ;
Point p[N], stk[N];
Point minp;
int top;
double cross ( Point &o,  Point &a,  Point &b )
{
    return ( a.x - o.x ) * ( b.y - o.y ) - ( a.y - o.y ) * ( b.x - o.x );
}
double dist ( Point &A,  Point & B )
{
    return hypot ( A.x - B.x, A.y - B.y );
}
bool cmp ( Point A, Point B )
{
    double k = cross ( minp, A, B );
    if ( k < 0 ) return 0;
    if ( k > 0 ) return 1;
    return dist ( minp, A ) < dist ( minp, B );
}
void Gramham ( int n )
{
    int i;
    for ( i = 1; i < n; i++ )
    {
        if ( p[i].y < p[0].y || ( p[i].y == p[0].y && p[i].x < p[0].x ) )
        {
            swap ( p[i], p[0] );
        }
    }
    minp = p[0];
    p[n] = p[0];
    sort ( p + 1, p + n, cmp );
    stk[0] = p[0];
    stk[1] = p[1];
    top = 1;
    for ( i = 2; i < n; i++ )
    {
        while ( top >= 1 && cross ( stk[top - 1], stk[top ], p[i] ) <= 0 ) --top;
        stk[++top] = p[i];
    }
}
double mmin, mmax;
int c;
void update ( Point a, Point b )
{
    if ( a.x > b.x )
    {
        swap ( a, b );
    }
    if ( a.x <= c && b.x >= c )
    {
        if ( a.x == c && b.x == c )
        {
            mmax = max ( mmax, ( double ) max ( a.y, b.y ) );
            mmin = min ( mmin, ( double ) min ( a.y, b.y ) );
        }
        else
        {
            double k = ( ( double ) c - a.x ) / ( ( double ) b.x - a.x ) * ( b.y - a.y ) + a.y;
            mmax = max ( mmax, k );
            mmin = min ( mmin, k );
        }
    }
}
int main()
{
    int n,  i;
    while ( ~scanf ( "%d%d", &n, &c ) )
    {
        for ( i = 0; i < n; i++ )
        {
            scanf ( "%d", &p[i].x );
        }
        for ( i = 0; i < n; i++ )
        {
            scanf ( "%d", &p[i].y );
        }
        if ( n == 1 )
        {
            printf ( "%.3f %.3f\n", ( double ) p[0].y, ( double ) p[0].y );
            continue;
        }
        Gramham ( n );
        stk[++top] = stk[0];
        mmin = INF, mmax = -INF;
        for ( i = 1; i <= top; i++ )
        {
            update ( stk[i - 1], stk[i] );
        }
        printf ( "%.3f %.3f\n", mmin, mmax );
    }
    return 0;
}