// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 1111
#define INF 0x3f3f3f3f
struct Edge
{
    int to,next;
}edge[maxn*maxn];
int head[maxn],tot,n=1,vis[maxn],dis[maxn];
struct node
{
    double x,y;
}s,e,p[maxn];
void add(int u,int v)
{
    edge[tot].to=v;
    edge[tot].next=head[u];
    head[u]=tot++;
}
double get_dis(node a,node b)
{
    return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
int bfs()
{
    queue<int>que;
    que.push(0);
    dis[0]=0,vis[0]=1;
    for(int i=1;i<=n;i++)
        dis[i]=INF,vis[i]=0;
    while(!que.empty())
    {
        int u=que.front();que.pop();
        for(int i=head[u];~i;i=edge[i].next)
        {
            int v=edge[i].to;
            if(!vis[v])
            {
                que.push(v);
                vis[v]=1;
                dis[v]=dis[u]+1;
            }
        }
    }
    return dis[n];
}
int main()
{
    memset(head,-1,sizeof(head));
    tot=0;
    double v,m,d;
    scanf("%lf%lf%lf%lf%lf%lf",&v,&m,&s.x,&s.y,&e.x,&e.y);
    d=v*m*60;
    p[0]=s;
    while(~scanf("%lf%lf",&p[n].x,&p[n].y))n++;
    p[n]=e;
    for(int i=0;i<=n;i++)
        for(int j=i+1;j<=n;j++)
            if(get_dis(p[i],p[j])<=d)
                add(i,j),add(j,i);
    int ans=bfs();
    if(ans==INF)printf("No.\n");
    else printf("Yes, visiting %d other holes.\n",ans-1);
    return 0;
}