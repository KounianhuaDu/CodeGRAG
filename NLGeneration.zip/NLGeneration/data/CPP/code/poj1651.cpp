// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxR=32;
char a[maxR][maxR];
int r,s;
int ans=1;
int vis[200];
void dfs(int i,int j,int len)
{
	ans=max(ans,len+1);
	if(i+1<r&&vis[a[i+1][j]]==0){
		vis[a[i+1][j]]=1;
		dfs(i+1,j,len+1);
		vis[a[i+1][j]]=0;
	}
	if(i-1>=0&&vis[a[i-1][j]]==0){
		vis[a[i-1][j]]=1;
		dfs(i-1,j,len+1);
		vis[a[i-1][j]]=0;
	}
	if(j+1<s&&vis[a[i][j+1]]==0){
		vis[a[i][j+1]]=1;
		dfs(i,j+1,len+1);
		vis[a[i][j+1]]=0;
	}
	if(j-1>=0&&vis[a[i][j-1]]==0){
		vis[a[i][j-1]]=1;
		dfs(i,j-1,len+1);
		vis[a[i][j-1]]=0;
	}	
}
int main()
{
	scanf("%d%d",&r,&s);
	for(int i=0;i<r;++i)
		scanf("%s",&a[i]);
	memset(vis,0,sizeof(vis));
	vis[a[0][0]]=1;
	dfs(0,0,0); 
	printf("%d\n",ans);
}