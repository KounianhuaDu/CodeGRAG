// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int inf=0x3f3f3f3f;
int dp[3001][3001];
vector <int> v[3001];
vector <int> w[3001];
int num[3001];
int n,m,k,a,b;
inline void add(int a,int b,int c)
{
    v[a].push_back(b);
    w[a].push_back(c);
}
inline void dfs(int k)
{
    for (int i=0;i<v[k].size();++i)
    {
        dfs(v[k][i]);
        num[k]+=num[v[k][i]];
        for (int j=num[k];j>0;--j)
            for (int l=num[v[k][i]];l>=1;--l)
                dp[k][j]=max(dp[k][j],dp[k][j-l]+dp[v[k][i]][l]-w[k][i]);
    }
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        for (int i=1;i<=n;++i) v[n].clear();
        for (int i=1;i<=n-m;i++)
        {
            scanf("%d",&k);
            num[i]=0;
            for(int j=0;j<k;j++)
            {
                scanf("%d%d",&a,&b);
                add(i,a,b);
            }
        }
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
                dp[i][j]=-inf;
        }
        for(int i=n-m+1;i<=n;i++)
        {
            num[i]=1;
            scanf("%d",&dp[i][1]);
        }
        dfs(1);
        for(int i=m;i>=0;i--)
        {
            if(dp[1][i]>=0)
            {
                printf("%d\n",i);
                break;
            }
        }
    }
}