// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
typedef pair<int,int>P;
const int INF=0x3f3f3f3f,maxn=1005;
int n,a[maxn];
int main()
{
    while(~scanf("%d",&n),n)
    {
        int sum=0;
        for(int i=1;i<=n;i++)
        {
            double temp;
            scanf("%lf",&temp);
            a[i]=(int)(temp*100+0.5);
            sum+=a[i];
        }
        sort(a+1,a+n+1);
        int res=sum%n,ans=0;
        for(int i=n;i>=1;i--)
            if(a[i]*n>sum)
            {
                if(res)
                {
                    if((a[i]-1)*n>sum)ans+=a[i]-(sum/n+1),res--;
                    else break;
                }
                else ans+=a[i]-sum/n;
            }
            else break;
        printf("$%d.%02d\n",ans/100,ans%100);
    }
    return 0;
}