// Basic Algorithm->Bitwise Operation,Dynamic Programming->Bitmask Dynamic Programming (DP)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[15];
int maptt1[55][55];
double dp[(1<<10)][55];
void init()
{
    memset(maptt1,-1,sizeof(maptt1));
    for(int i=0;i<(1<<10);i++)
    {
        for(int j=0;j<45;j++)
        {
            dp[i][j]=0x3f3f3f3f*1.0;
        }
    }
}
int main()
{
    int n,m,p,aa,bb;
    while(~scanf("%d%d%d%d%d",&n,&m,&p,&aa,&bb))
    {
        if(n==0&&m==0&&p==0&&aa==0&&bb==0)break;
        init();
        for(int i=0;i<n;i++)
        {
            scanf("%d",&a[i]);
        }
        for(int i=0;i<p;i++)
        {
            int x,y,w;
            scanf("%d%d%d",&x,&y,&w);
            maptt1[x][y]=w;
            maptt1[y][x]=w;
        }
        dp[0][aa]=0;
        int end1=(1<<n);
        for(int i=0;i<end1;i++)
        {
            for(int j=0;j<n;j++)
            {
                if((i&(1<<j))!=0)
                {
                    int q=i-(1<<j);
                    for(int u=1;u<=m;u++)
                    {
                        for(int v=1;v<=m;v++)
                        {
                            if(maptt1[u][v]>-1)
                            {
                                double tmp=maptt1[u][v]*1.0/a[j]*1.0;
                                dp[i][v]=min(dp[i][v],dp[q][u]+tmp);
                            }
                        }
                    }
                }
            }
        }
        double ans=0x3f3f3f3f*1.0;
        for(int i=0;i<end1;i++)
        {
            ans=min(ans,dp[i][bb]);
        }
        if(ans==0x3f3f3f3f*1.0)printf("Impossible\n");
        else
        printf("%f\n",ans);
    }
}