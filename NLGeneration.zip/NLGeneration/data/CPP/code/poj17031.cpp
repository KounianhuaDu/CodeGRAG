// Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
char s[27000000];
int vis[300];
int vi[27000000];
int a[300];
int main()
{
    int n,nc;
    scanf("%d%d",&n,&nc);
    
    scanf("%s",s);
    int len=strlen(s);
    for(int i=0;i<len;i++)
    {
        vis[s[i]]=1;
    }
    int t=0;
    int sum=0;
    for(int i=0;i<300;i++)
    {
        if(vis[i]==1)
            a[i]=t++;
    }
    
    
    int x;
    for(int i=0;i<=len-n;i++)
    {
        x=0;
        for(int j=i;j<i+n;j++)
        {
            x=x*nc+a[s[j]];
        }
        if(vi[x]==0)
        {
            sum++;
            vi[x]=1;
        }
    }
    cout<<sum<<endl;
    return 0;
}