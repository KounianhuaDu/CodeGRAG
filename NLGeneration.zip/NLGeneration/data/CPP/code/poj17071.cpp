// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define Max 20
int init[Max];
int record[Max];
int n,num;
int Binary_search(int number){
	for(int i=1;i<=n;i++)
		record[i]=number*50-init[i];
	int Sum=0;
	int first,second,third;
	int fmax,smax,tmax;
	bool trag;
	while(Sum<=num){
		fmax=-1,smax=-1,tmax=-1;
		trag=true;
		for(int i=1;i<=n;i++)
			if(record[i]>0 && record[i]>fmax){
				fmax=record[i];
				first=i;
			}
		for(int i=1;i<=n;i++)
			if(record[i]>0 && record[i]>smax && i!=first){
				smax=record[i];
				second=i;
			}
		for(int i=1;i<=n;i++)
			if(record[i]>0 && record[i]>tmax && i!=first && i!=second){
				trag=false;
				tmax=record[i];
				third=i;
			}
		if(trag)
		    break;
		Sum++;
		record[first]--,record[second]--,record[third]--;
	}
	if(Sum<num)
		return -1;
	else if(Sum==num)
		return 0;
	else
		return 1;
}
int main(){
	while(scanf("%d",&n),n){
		int max_v=-1;
		for(int i=1;i<=n;i++){
			scanf("%d",&init[i]);
			if(init[i]>max_v)
				max_v=init[i];
		}
		scanf("%d",&num);
		if(max_v==0 && num==0){
			printf("0\n");
			continue;
		}
		else{
			int left,right,mid;
			if(max_v%50==0){
				left=max_v/50;
			    right=left+num/50+1;
			}
			else{
				left=max_v/50+1;
				right=left+num/50+1;
			}
			bool flag=false;
		    while(left<=right){
				mid=(left+right)>>1;
				if(Binary_search(mid)==-1)
					left=mid+1;
				else if(Binary_search(mid)==0){
					flag=true;
					break;
				}
				else
					right=mid-1;
			}
			if(flag)
				printf("%d\n",mid);
			else
				printf("%d\n",left);
		}
	}
	return 0;
}