// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define Del(a,b) memset(a,b,sizeof(a))
const int N = 500;
int w[N][N];
int dp[N][45];
int dis[N];
int main()
{
    
    int n,k;
    while(~scanf("%d%d",&n,&k))
    {
        for(int i=1;i<=n;i++)
            scanf("%d",&dis[i]);
        Del(w,0);
        for(int i=1;i<=n;i++)
        {
            for(int j=i+1;j<=n;j++)
            {
                w[i][j] = w[i][j-1]+  dis[j]  -  dis[(i+j)/2];
            }
            
        }
        Del(dp,0x3f3f3f3f);
        for(int i=1;i<=n;i++)
        {
            dp[i][1]=w[1][i];
            dp[i][i]=0;
        }
        for(int j=2;j<=k;j++)
        {
            for(int i=j+1;i<=n;i++)
            {
                dp[i][j]=0x3f3f3f3f;
                for(int f=j-1;f<=i-1;f++)
                    dp[i][j]=min(dp[i][j],dp[f][j-1]+w[f+1][i]);
            }
        }
        printf("%d\n",dp[n][k]);
    }
    return 0;
}