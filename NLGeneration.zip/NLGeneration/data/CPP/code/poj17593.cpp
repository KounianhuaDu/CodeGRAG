// Math and Computational Geometry->Probability / Counting / Combinatorics
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int MaxState = 1 << 10;
const int Max = 12;
int dp[MaxState][Max];
int len[Max][Max];
std::string word[Max];
int n;
int main() {
    while (std::cin >> n, n) {
        memset(len, 0, sizeof(len));
        memset(dp, 0, sizeof(dp));
        for (int i = 0; i < n; ++i) {
            std::cin>>word[i];
        }
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                if (i != j) {
                    int maxDiff = -1;
                    for (int k = 0; k < word[j].length(); ++k) {
                        int diff = 0;
                        for (int m = 0, n = k; m < word[i].length() && n < word[j].length(); ++m, ++n) {
                            if (word[i][m] == word[j][n]) {
                                diff++;
                            }
                        }
                        maxDiff = std::max(maxDiff, diff);
                    }
                    len[i][j]=len[j][i] = std::max(len[i][j], maxDiff);
                }
            }
        }
        for (int i = 0; i < (1 << n); ++i) {
            for (int j = 0; j < n; ++j) {
                if (i&(1 << j)) {
                    for (int k = 0; k < n; ++k) {
                        if (!(i&(1 << k))) {
                            dp[i|1<<k][k] = std::max(dp[i|1<<k][k], dp[i][j] + len[j][k]);
                        }
                    }
                }
            }
        }
        int count = 0;
        for (int i = 0; i < n; ++i) {
            count = std::max(count, dp[(1 << n) - 1][i]);
        }
        std::cout << count << std::endl;
    }
    return 0;
}