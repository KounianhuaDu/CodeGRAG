// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct LL{                
   int x,y;
}w[13];
int m,a[13];
int dis(LL &n1,LL &n2)             
{
    return abs(n1.x-n2.x)+abs(n1.y-n2.y);
}
int deal()                
{
    int i,ans=0;
    ans=dis(w[0],w[a[1]]);
    for(i=1;i<m;i++)
        ans+=dis(w[a[i]],w[a[i+1]]);
    ans+=dis(w[0],w[a[m]]);
    return ans;
}
int main()
{
    int i,T;
    scanf("%d",&T);
    while(T--){
       scanf("%d%d",&w[0].x,&w[0].y);       
       scanf("%d%d",&w[0].x,&w[0].y);
       scanf("%d",&m);     
       for(i=1;i<=m;i++)
          scanf("%d%d",&w[i].x,&w[i].y);
       for(i=1;i<=m;i++)  
           a[i]=i;
       int ans=0x3f3f3f3f;
       do{                                
         ans=min(ans,deal());
       }while(next_permutation(a+1,a+1+m));  
                                            
      cout<<"The shortest path has length "<<ans<<endl;
    }
    return 0;
}