// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define eps 1e-9
#define PI 3.141592653589793
#define bs 1000000007
#define bsize 256
#define MEM(a) memset(a,0,sizeof(a))
typedef long long ll;
using namespace std;
int f[1000],r[1000],book[2500];
void init(int x)
{
	for(int i=0;i<=x;i++)
	f[i]=i,r[i]=0;
}
int find_(int x)
{
	if(f[x]==x)
	return x;
	int fa=find_(f[x]);
	r[x]=(r[x]+r[f[x]])%3;
	return f[x]=fa;
}
int fun(char c)
{
    if(c=='=')
    return 0;
    else if(c=='>')
    return 1;
    else
    return 2;
}
struct node
{
    int u,v;
    int f;
}q[2005];
int main()
{
	int n,m,i,j,t1,t2,rea1,rea2,k;
	while(cin>>n>>m)
	{
        memset(book,0,sizeof(book));
		int cnt=0,u,v;
		char c;
		int ans=-1,ans1=0;
		for(i=0;i<m;i++)
		{
		    node temp;
			scanf("%d%c%d",&u,&c,&v);
			temp.u=++u,temp.v=++v;
			temp.f=fun(c);
			q[i]=temp;
		}
		for(i=1;i<=n;i++)
        {
            init(n);
            for(j=0;j<m;j++)
            {
                if(q[j].u==i||q[j].v==i);
                else
                {
                    u=q[j].u,v=q[j].v;
                    t1=find_(u);
                    t2=find_(v);
                    if(t1!=t2)
                    {
                        f[t2]=t1;
                        r[t2]=((r[u]-r[v])%3+3+q[j].f)%3;
                    }
                    else
                    {
                        if(((r[v]-r[u])%3+3)%3!=q[j].f)
                        {
                            book[i]=j+1;
                            break;
                        }
                    }
                }
            }
        }
        for(i=1;i<=n;i++)
        {
            if(book[i]==0)
            {
                cnt++;
                ans=i;
            }
            else
                ans1=max(ans1,book[i]);
        }
		if(cnt==0)
        cout<<"Impossible"<<endl;
        else if(cnt>1)
		cout<<"Can not determine"<<endl;
		else
        {
            printf("Player %d can be determined to be the judge after %d lines\n",ans-1,ans1);
        }
	}
	return 0;
 }