// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define eps 1e-8
#define INF 0x7fffffff
#define FOR(i,a) for((i)=0;i<(a);(i)++)
#define MEM(a) (memset((a),0,sizeof(a)))
#define sfs(a) scanf("%s",a)
#define sf(a) scanf("%d",&a)
#define sfI(a) scanf("%I64d",&a)
#define pf(a) printf("%d\n",a)
#define pfI(a) printf("%I64d\n",a)
#define pfs(a) printf("%s\n",a)
#define sfd(a,b) scanf("%d%d",&a,&b)
#define sft(a,b,c)scanf("%d%d%d",&a,&b,&c)
#define for1(i,a,b) for(int i=(a);i<b;i++)
#define for2(i,a,b) for(int i=(a);i<=b;i++)
#define for3(i,a,b)for(int i=(b);i>=a;i--)
#define MEM1(a) memset(a,0,sizeof(a))
#define MEM2(a) memset(a,-1,sizeof(a))
const double PI=acos(-1.0);
template<class T> T gcd(T a,T b){return b?gcd(b,a%b):a;}
template<class T> T lcm(T a,T b){return a/gcd(a,b)*b;}
template<class T> inline T Min(T a,T b){return a<b?a:b;}
template<class T> inline T Max(T a,T b){return a>b?a:b;}
using namespace std;
#define ll __int64_t
int n,m,c;
#define N  100100
char ch[20][20];
int mp[20][20];
int vis[20][20];
int step;
int flag;
vector<pair<int,int> > v;
void Init(){
	for (int i = 0; i < 4; i++)
		for (int j = 0; j < 4; j++) {
			if (ch[i][j] == '-')
				mp[i][j] = 0;
			else
				mp[i][j] = 1;
		}
}
bool check(){
	for(int i=0;i<4;i++)
		for(int j=0;j<4;j++)
			if(mp[i][j]!=0) return false;
	return true;
}
void flip(int row,int col){
	for(int i=0;i<4;i++)
		mp[row][i] = 1-mp[row][i];
	for(int i=0;i<4;i++){
		if(i==row) continue;
		mp[i][col] = 1-mp[i][col];
	}
}
void dfs(int row,int col,int dep){
	if(dep == step){
		flag = check();
		return;
	}
	if(flag) return;
	if(row == 4) return;
	if(col<3)
		dfs(row,col+1,dep);
	else
		dfs(row+1,0,dep);
	if(flag) return;			
	flip(row,col);							
	vis[row][col] = !vis[row][col];
	if(col<3)
		dfs(row,col+1,dep+1);
	else
		dfs(row+1,0,dep+1);
	if(flag) return;					
	flip(row,col);
	vis[row][col] = !vis[row][col];
	return;
}
int main(){
#ifndef ONLINE_JUDGE
    freopen("in.txt","r",stdin);
#endif
    while(sfs(ch[0])!=EOF){
    	for(int i=1;i<4;i++)
    		sfs(ch[i]);
    	Init();
    	flag=0;
    		memset(vis,0,sizeof vis);
    	for(step=0;step<=16;step++){
    		dfs(0,0,0);
    		if(flag)
    			 break;
    	}
    	if(flag){
    		printf("%d\n",step);
    		for(int i=0;i<4;i++)
    			for(int j=0;j<4;j++){
    				if(vis[i][j]){
    					printf("%d %d\n",i+1,j+1);
    				}
    			}
    	}
    }
return 0;
}