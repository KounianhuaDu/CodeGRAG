// Basic Algorithm->Bitwise Operation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define ROW 4
int main()
{
    bool HANDLES[ROW][ROW] = {false};
    char handle;
    for(int i = 0; i < ROW; ++i)
    {
        for(int j = 0; j < ROW; ++j)
        {
            cin >> handle;
            if(handle == '+')
            {
                HANDLES[i][j] = !HANDLES[i][j];
                for(int k = 0; k < ROW; ++k)
                {
                    HANDLES[i][k] = !HANDLES[i][k];
                    HANDLES[k][j] = !HANDLES[k][j];
                }
            }
        }
    }
    int result = 0;
    for(int i = 0; i < ROW; ++i)
    {
        for(int j = 0; j < ROW; ++j)
        {
            if(HANDLES[i][j])
            {
                ++result;
            }
        }
    }
    cout << result << endl;
    for(int i = 0; i < ROW; ++i)
    {
        for(int j = 0; j < ROW; ++j)
        {
            if(HANDLES[i][j])
            {
                cout << i + 1 << " " << j + 1 << endl;
            }
        }
    }
    return 0;
}