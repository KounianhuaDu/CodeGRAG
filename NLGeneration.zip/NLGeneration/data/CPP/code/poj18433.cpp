// Data Structure->Stack
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
const int maxn = 1e5 + 10;
int a[maxn], n;
int L[maxn], R[maxn], sta[maxn];
ll max_, F[maxn];
void solve()
{
	int t = 0;
	for( int i=0; i<n; ++i )
	{
		while( t > 0 && a[sta[t-1]] >= a[i] ) --t;
		L[i] = t == 0 ? 0 : (sta[t - 1] + 1);
		sta[t++] = i;
	}
	t = 0;
	for( int i=n-1; i>=0; --i )
	{
		while( t > 0 && a[sta[t-1]] >= a[i] ) --t;
		R[i] = t == 0 ? n : sta[t - 1];
		sta[t++] = i;
	}
	max_ = -1;
	int max_l, max_r;
	for( int i=0; i<n; ++i )
	{
		ll sum = F[R[i]-1] - F[L[i]-1];
		if( max_ < sum * (ll)a[i] )
		{
		    max_ = sum * a[i];
		    max_l = L[i];
		    max_r = R[i] - 1;
		}
	}
	printf("%I64d\n%d %d\n", max_, max_l + 1, max_r + 1);
}
int main()
{
	while( ~scanf("%d", &n) )
	{
		scanf("%d", &a[0]);
		F[0] = a[0];
		for( int i=1; i<n; ++i )
		{
			scanf("%d", &a[i]);
			F[i] = F[i-1] + a[i];
		}
		solve();
	}
	return 0;
}