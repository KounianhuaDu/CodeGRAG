// Basic Algorithm->Bitwise Operation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define INF 0x3f3f3f3f
#define LL long long
using namespace std;
const int N = 12;
const int MAXN = 60000;
int n,m;
int dis[N][N];
int dp[MAXN][N];
int three[N],digit[MAXN][N];
void Init()
{
    three[0] = 1;
    for(int i = 1;i <= 10;i ++) three[i] = three[i-1] * 3;
    for(int i = 0;i < three[10];i ++)
    {
        int temp = i;
        for(int j = 0;j < 10;j ++)
        {
            digit[i][j] = temp % 3;
            temp /= 3;
        }
    }
}
int main()
{
    Init();
    while(~scanf("%d%d",&n,&m))
    {
        memset(dis,INF,sizeof(dis));
        memset(dp,INF,sizeof(dp));
        int ans = INF;
        int a,b,c;
        for(int i = 0;i < m;i ++)
        {
            scanf("%d%d%d",&a,&b,&c);
            if(dis[a-1][b-1] > c) dis[a-1][b-1] = dis[b-1][a-1] = c;
        }
        for(int i = 0;i < n;i ++) dp[three[i]][i] = 0;
        for(int S = 0;S < three[n]; S ++)
        {
            bool flag = true;
            for(int i = 0;i < n;i ++)
            {
                if(digit[S][i] == 0) flag = false;
                if(dp[S][i] == INF) continue;
                for(int j = 0;j < n;j ++)
                {
                    if(dis[i][j] != INF && digit[S][j] < 2)
                        dp[S+three[j]][j] = min(dp[S+three[j]][j] , dp[S][i] + dis[i][j]);
                }
            }
            if(flag)
            {
                for(int i = 0;i < n;i ++)
                    ans = min(ans,dp[S][i]);
            }
        }
        if(ans == INF)
            printf("-1\n");
        else
            printf("%d\n",ans);
    }
    return 0;
}