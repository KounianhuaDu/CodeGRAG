// Graph Algorithm->Maximum Flow Algorithm,Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Graph Algorithm->Min-Cost Max-Flow
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
using namespace std;
int n,dis[200],ans;
struct node
{
	int v,cap,cost,id;
	node(int v1,int cap1,int cost1,int id1)
	{
		v=v1;
		cap=cap1;
		cost=cost1;
		id=id1;
	}
};
struct node2
{
	int u,id;
}pre[200];
vector<node> s[200];
void add(int u,int v,int cost,int cap)
{
	int l1=s[u].size();
	int l2=s[v].size();
	s[u].push_back(node(v,cap,cost,l2));
	s[v].push_back(node(u,0,-cost,l1));
}
void init()
{
	for(int i=0;i<200;i++)
	s[i].clear();
	for(int i=1;i<n-1;i++)
	{
		add(i,i+n,0,1);
	}
	add(0,n,0,2);
	add(n-1,2*n-1,0,2);
}
bool spfa()
{
	queue<int> que;
	int vis[200];
	memset(vis,0,sizeof(vis));
	for(int i=0;i<200;i++) dis[i]=inf;
	dis[0]=0;vis[0]=1;
	que.push(0);
	while(!que.empty())
	{
		int u=que.front();
		que.pop();
		vis[u]=0;
		for(int i=0;i<s[u].size();i++)
		{
			node tp=s[u][i];
			int v=tp.v;
			if(tp.cap>0&&dis[v]>tp.cost+dis[u])
			{
				dis[v]=tp.cost+dis[u];
				pre[v].u=u,pre[v].id=i;
				if(!vis[v])
				{
					vis[v]=1;
					que.push(v);
				}
			}
		}
	}
	if(dis[2*n-1]==inf) return false;
	ans+=dis[n-1];
	 return true;
}
int main()
{
	
	int m,cnt=1,a,b,c;
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		if(!n&&!m) break;
		printf("Instance #%d: ",cnt++);
		init();
		while(m--)
		{
			scanf("%d%d%d",&a,&b,&c);
			add(a+n,b,c,1);
		}
		ans=0;
		while(spfa())
		{
			int minflow=inf;
			for(int i=2*n-1;i!=0;i=pre[i].u)
			{
				int u=pre[i].u;
				minflow=min(minflow,s[u][pre[i].id].cap);
			}
			for(int i=2*n-1;i!=0;i=pre[i].u)
			{
				int u=pre[i].u,id=s[u][pre[i].id].id;
				s[u][pre[i].id].cap-=minflow;
				s[i][id].cap+=minflow;
			}
		}
		if(s[0][0].cap==0) printf("%d\n",ans);
		else printf("Not possible\n");
	}
	return 0;
}