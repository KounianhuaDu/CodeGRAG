// Basic Algorithm->Recurrence,Math and Computational Geometry->Probability / Counting / Combinatorics
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double eps(1e-8);
typedef long long lint;
double dp[1 << 8][1 << 7];
double p[1 << 7][1 << 7];
int main()
{
    int n;
    while(scanf("%d", &n), n != -1)
    {
        for(int i = 0; i < (1 << n); i++)
            for(int j = 0; j < (1 << n); j++)
                scanf("%lf", &p[i][j]);
        memset(dp, 0, sizeof(dp));
        for(int i = 0; i < (1 << n); i++)
            dp[(1 << n) - 1 + i][i] = 1;
        for(int i = (1 << n) - 2; i >= 0; i--)
        {
            for(int j = 0; j < (1 << n); j++)
                for(int k = 0; k < (1 << n); k++)
                {
                    if(dp[2*i + 1][j] > eps && dp[2*i + 2][k] > eps)
                        dp[i][j] += dp[2*i + 1][j]*dp[2*i + 2][k]*p[j][k];
                    if(dp[2*i + 1][k] > eps && dp[2*i + 2][j] > eps)
                        dp[i][j] += dp[2*i + 1][k]*dp[2*i + 2][j]*p[j][k];
                }
        }
        int ans = 0;
        double tmp = dp[0][0];
        for(int i = 0; i < (1 << n); i++)
            if(tmp < dp[0][i])
            {
                tmp = dp[0][i];
                ans = i;
            }
        printf("%d\n", ans + 1);
    }
    return 0;
}