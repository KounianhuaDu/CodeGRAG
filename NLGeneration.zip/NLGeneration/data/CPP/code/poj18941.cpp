// Basic Algorithm->Recurrence,Math and Computational Geometry->Linear Algebra
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=12;
int n,b;
__int64_t C[maxn][maxn],s[maxn][maxn],f[maxn],ans;
void init()
{
    int i,j;
    s[0][0]=C[0][0]=f[0]=1;
    for(i=1;i<=11;i++)
    {
        f[i]=f[i-1]*i;
        C[i][0]=C[i][i]=1;
        s[i][0]=0;
        s[i][i]=1;
        for(j=1;j<=i;j++)
        {
            C[i][j]=C[i-1][j-1]+C[i-1][j];
            s[i][j]=s[i-1][j-1]+s[i-1][j]*j;
        }
    }
}
int main()
{
    int i,j,cas=1;
    init();
    scanf("%d",&n);
    while(n--)
    {
        scanf("%d",&b);
        ans=0;
        for(i=1;i<=b;i++)
        {
            for(j=1;j<=i;j++)
            {
                 ans+=C[b][i]*s[i][j]*f[j];
            }
        }
        printf("%d %d %I64d\n",cas++,b,ans);
    }
    return 0;
}