// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
const int maxn = 10000;
bool isPrime[maxn];
bool inq[maxn];
int x, y;
struct node{
	int x;
	int step;
	node(){
		step = 0;
	}
};
void prime(){
	for(int i = 2; i <= maxn; i++)
		isPrime[i] = 1;
	for(int i = 2; i <= maxn; i++){
		if( isPrime[i] )
			for(int j = 2 * i; j <= maxn; j += i)
				isPrime[j] = 0;
	}
}
int BFS(int x){
	queue<node> q;
	node start;
	start.x = x;
	start.step = 0;
	q.push(start);
	while(!q.empty()){
		node now = q.front();
		q.pop();
		if(now.x == y){
			return now.step;
		}
		node next;
		for(int i = 0;i < 4; i++){
			for(int j = 0; j < 10;j ++){
				if(i == 3 && j == 0)
					continue;
				int temp = pow(10, i);
				int x = now.x % temp;
				int tem = now.x / temp;
				int y = tem / 10;
				next.x = y * 10 * temp + j * temp + x;
				if(isPrime[next.x] && !inq[next.x]){
					inq[next.x] = 1;
					next.step = now.step + 1;
					q.push(next);
				}
			}
		}
	}
	return -1;
}
int main(){
	int T;
	cin >> T;
	memset(isPrime, 0, sizeof(isPrime));
	prime();
	while(T--){
		memset(inq, 0, sizeof(inq));
	 	cin >> x >> y;
	 	int ans = BFS(x);
		if(ans == -1){
			cout << "Impossible" << endl;
		}else{
			cout << ans << endl;
		}
	 }
	return 0;
}