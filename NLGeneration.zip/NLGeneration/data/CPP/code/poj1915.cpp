// Dynamic Programming->Slope Optimization,Basic Algorithm->Blocking,Dynamic Programming->Monotone Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=10005;
long long dp[maxn];
int st[maxn],sf[maxn],t[maxn],f[maxn],q[maxn];
int n,s;
double cal(int x,int y)
{
       return double(dp[x]-dp[y])/double(st[x]-st[y]);
}
int main()
{
    freopen("pin.txt","r",stdin);
    freopen("pou.txt","w",stdout);
    int i,h,r,j;
    scanf("%d",&n);
    scanf("%d",&s);
    for (i=1;i<=n;i++)
        scanf("%d%d",&t[i],&f[i]);
    for (i=n;i;i--)
    {
        st[i]=st[i+1]+t[i];
        sf[i]=sf[i+1]+f[i];
    }
    h=1;r=0;
    dp[n]=(s+st[n])*sf[n];
    q[++r]=n;
    long long tt;
    for (i=n-1;i;i--)
    {
        while (r-h+1>=2 && cal(q[h],q[h+1])<sf[i]) h++;
        tt=s+st[i];
        tt*=sf[i];
        dp[i]=tt;
        j=q[h];
        tt=s+st[i]-st[j];
        tt*=sf[i];
        dp[i]=min(dp[i],dp[j]+tt);
        while (r-h>=1 && cal(q[r-1],q[r])>cal(q[r],i)) r--;
        q[++r]=i;
    }
    cout << dp[1] << endl;
    return 0;
}