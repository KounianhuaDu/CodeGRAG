// Basic Algorithm->Memorization,Basic Algorithm->Blocking,Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int mod = 10007;
struct Node{
    int x[31];
    int xs;
    double exp;
    void init(){
        memset(x, 0, sizeof(x));
        xs = 0;
    }
    bool operator==(Node &a){
        for(int i = 0; i != 31; i ++){
            if(a.x[i] != x[i])
                return false;
        }
        return true;
    }
    void sort(){
        std::sort(x, x+31);
    }
    
    unsigned int hash(){
        unsigned int hash = 0, seed = 131;
        for(int i = 30 ; i >=0 && x[i] ; i--){
            hash = hash * seed + x[i];
        }
        return (hash & 0x7fffffff)%mod;
    }
};
std::vector<Node> hh[mod];
double search(Node &a){
    unsigned int x = a.hash();
    for(int i = 0; i != hh[x].size(); i ++){
        if(a == hh[x][i]){
            return hh[x][i].exp;
        }
    }
    return -1;
}
int p[31], tot[31];
int n, m, tu, tv;
int find(int x){
    return x == p[x] ? x : (p[x] = find(p[x]));
}
double DP(Node ost){
    
    if(ost.xs == 1){
        return 0;
    }
    double x = search(ost);
    if(x != -1.0)
        return x;
    double tmp = 0, ans = 0;
    
    for(int i = 0; i != 31; i ++){
        tmp += ost.x[i] * (ost.x[i]-1)/2;
    }
    
    for(int i = 0; i != 31; i ++){
        for(int  j = i+1; j != 31; j ++){
            if(ost.x[i]==0 || ost.x[j]==0)
                continue;
            Node sst = ost;
            sst.x[i] = sst.x[i] + sst.x[j];
            sst.x[j] = 0;
            sst.xs --;
            sst.sort();
            ans += ost.x[i] * ost.x[j] * DP(sst);
        }
    }
    ans = ans / (n*(n-1)/2) + 1 ;
    ans = ans / (1 - tmp/(n*(n-1)/2) ) ;
    ost.exp = ans;
    hh[ost.hash()].push_back(ost);
    return ans;
}
int main(){
    scanf("%d%d", &n, &m);
    for(int i = 1; i != 31; i ++){
        p[i] = i;
        tot[i] = 0;
    }
    
    for(int i = 0; i < m; i ++){
        scanf("%d%d", &tv, &tu);
        p[find(tv)] = find(tu);
    }
    for(int i = 1; i <= n; i ++){
        tot[find(i)] ++;
    }
    Node st;
    st.init();
    for(int i = 1; i <= n; i ++){
        if(tot[i]){
            st.x[st.xs ++] = tot[i];
        }
    }
    
    st.sort();
    printf("%.10lf\n", DP(st));
    return 0;
}