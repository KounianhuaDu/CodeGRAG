// Data Structure->Link List
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef class node{
public:
    int idx;
    class node *next;
    node(){
        next = 0;
    }
}htable;
int n, k;
htable *hashtable[150000];
int maxlen;
int cow[100010][40];
int sum[100010][40];
int c[100010][40];
bool cmp(int l_idx, int n_idx)
{
    for(int i = 0; i < k; i++){
        if(c[l_idx][i] != c[n_idx][i])
            return false;
    }
    return true;
}
void Hash(int i)
{
    
    int key = 0;        
    for(int j = 1; j < k; j++){    
        key += c[i][j];
    }
    if(key < 0)
        key *= -1;
    key = key%149999;
    
    if(!hashtable[key]){        
        htable *p = new htable;
        p -> idx = i;
        hashtable[key] = p;
    }else{
        htable *pn = hashtable[key];
        if(cmp(pn->idx, i)){
            
            maxlen = (i - (pn -> idx)) > maxlen ? (i - (pn -> idx)) : maxlen;
            return ;
        }else{
             
            while(pn -> next){
                if(cmp(pn->next->idx, i)){
                    
                    maxlen = (i - (pn -> next -> idx)) > maxlen ? (i - (pn -> next -> idx)) : maxlen;
                     
                    return ;
                }
                pn = pn -> next;
            }
            htable* temp = new htable;
            temp -> idx = i;
            pn -> next = temp;
        }
    }
    return ;
}
int main()
{
    while(scanf("%d%d", &n, &k) != EOF){
        
        int var;
        memset(hashtable, 0, sizeof(hashtable));
        maxlen = 0;
        for(int i = 0; i < k+1; i++){
            cow[0][i] = 0;
            sum[0][i] = 0;
            c[0][i] = 0;
        }
        Hash(0);
        for(int i = 1; i <= n; i++){
            scanf("%d", &var);
            for(int j = 0; j < k; j++){
                cow[i][j] = var % 2;
                sum[i][j] = sum[i-1][j] + cow[i][j];
                c[i][j] = sum[i][j] - sum[i][0];
                var /= 2;
            }
            
            Hash(i);
        }
        printf("%d\n", maxlen);
    }
    return 0;
}