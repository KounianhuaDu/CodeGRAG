// Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX = 100010;
const int Mod = 1001007;
int Hash[Mod+100];
int sum[MAX][40],cmp[MAX][40];
int n,k;
int has(int *s)
{
    int p=0;
    for(int i=0; i<k; i++)
    {
        p = ((p<<2)+(s[i]>>4))^(s[i]<<10);
    }
    p%=Mod;
    if(p<0)
    {
        p+=Mod;
    }
    return p;
}
int main()
{
    int data;
    int Max = 0;
    scanf("%d %d",&n,&k);
    memset(Hash,-1,sizeof(Hash));
    Hash[has(cmp[0])]=0;
    for(int i=1; i<=n; i++)
    {
        scanf("%d",&data);
        for(int j=0; j<k; j++)
        {
            
            sum[i][j]+=sum[i-1][j]+data%2;
            cmp[i][j]=sum[i][j]-sum[i][0];
              data=data>>1;
        }
        int ans = has(cmp[i]);
        while(Hash[ans]!=-1)
        {
            int R;
            for(R=0; R<k; R++)
            {
                if(cmp[i][R]!=cmp[Hash[ans]][R])
                {
                    break;
                }
            }
            if(R==k)
            {
                if(Max<i-Hash[ans])
                {
                    Max=i-Hash[ans];
                    break;
                }
            }
            ans++;
        }
        if(Hash[ans]==-1)
        {
            Hash[ans]=i;
        }
    }
    printf("%d\n",Max);
    return  0;
}