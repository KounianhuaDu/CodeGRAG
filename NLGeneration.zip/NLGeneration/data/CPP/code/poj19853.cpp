// Data Structure->Queue,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define maxn 1000500
struct point {
    int x;
    int step;
};
point start;
queue<point> Q;
bool used[maxn];
bool flag;
int fj, cow;
int mint;
void bfs( point s )
{
    while( !Q.empty() )
        Q.pop();
    int x;
    Q.push(s);
    used[fj] = 1;
    flag = 0;
    while( !Q.empty() && !flag )
    {
        point hd = Q.front();
 
        Q.pop();
        for( int i=0; i<3; i++ )
        {
            if( i == 0 )
                x = hd.x - 1;
            else if( i == 1 )
                x = hd.x + 1;
            else if( i == 2 )
                x = hd.x * 2;
            if( x>=0 && x <= 1000000 && !used[x] )
            {
                used[x] = 1;
                point t;
                t.x = x;
                t.step = hd.step + 1;
                Q.push( t );
                if( x == cow )
                {
                    mint = t.step;
                    flag = 1;
                    break;
                }
            }
        }
    }
}
int main()
{
    while( scanf("%d%d", &fj, &cow) != EOF )
    {
        if( fj == cow )
        {
            printf("0\n");
            continue;
        }
        start.x = fj;
        start.step = 0;
        memset( used, 0, sizeof(used) );
        bfs( start );
        printf("%d\n", mint);
    }
    return 0;
}