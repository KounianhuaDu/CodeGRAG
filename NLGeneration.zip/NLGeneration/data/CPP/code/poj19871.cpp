// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 88888*4;
const int oo = 0x3f3f3f3f;
int head[N], start, End, cnt, vis[N];
struct da
{
    int v, flow, next;
} as[N];
void add(int u, int v, int flow)
{
    as[cnt].v = v;
    as[cnt].flow = flow;
    as[cnt].next = head[u];
    head[u] = cnt++;
}
int bfs()
{
    queue<int >Q;
    memset(vis, 0, sizeof(vis));
    vis[start] = 1;
    Q.push(start);
    while(!Q.empty())
    {
       int u = Q.front();
       Q.pop();
       if(u == End) return 1;
       for(int j = head[u]; j != -1; j = as[j].next)
       {
           int v = as[j].v;
           if(!vis[v] && as[j].flow)
           {
               vis[v] = vis[u] + 1;
               Q.push(v);
           }
       }
    }
    return 0;
}
int dfs(int u, int Maxflow)
{
    int v, flow, uflow=0;
    if(u == End) return Maxflow;
    for(int j = head[u]; j != -1; j = as[j].next)
    {
        v = as[j].v;
        if(vis[v] == vis[u]+1 && as[j].flow)
        {
            flow = min(as[j].flow, Maxflow-uflow);
            flow = dfs(v, flow);
            as[j].flow -= flow;
            as[j^1].flow += flow;
            uflow += flow;
            if(uflow == Maxflow)break;
        }
    }
    if(uflow == 0)vis[u] = 0;
    return uflow;
}
int dinic()
{
    int ans = 0;
    while(bfs())
        ans += dfs(start, oo);
    return ans;
}
int main()
{
    int N, F, D, i, j, num, ans, fi, di;
    while(~scanf("%d %d %d", &N, &F, &D))
    {
        memset(head, -1, sizeof(head));
        cnt = 0;
        start = 0;
        End = F+D+2*N+2;
        for(i = 1; i <= N; i++)
        {
            scanf("%d %d", &fi, &di);
            for(j = 1; j <= fi; j++)
            {
                scanf("%d", &num);
                add(num, F+i, 1);
                add(F+i, num, 0);
            }
            for(j = 1; j <= di; j++)
            {
                scanf("%d", &num);
                add(F+i+N, F+2*N+num, 1);
                add(F+2*N+num, F+N+i, 0);
            }
            add(F+i, F+N+i, 1);
            add(F+N+i, F+i, 0);
        }
        for(i = 1; i <= F; i++)
        {
            add(start, i, 1);
            add(i, start, 0);
        }
        for(i = 1; i <= D; i++)
        {
            add(2*N+F+i, End, 1);
            add(End, 2*N+F+i, 0);
        }
        ans = dinic();
        printf("%d\n", ans);
    }
    return 0;
}