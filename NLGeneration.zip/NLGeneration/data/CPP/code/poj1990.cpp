// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define inf 0x3f3f3f3f
#define Max 110
#define MOD 11380
int max(int a,int b)
{
	return a>b?a:b;
}
int min(int a,int b)
{
	return a<b?a:b;
}
int l1,l2,l3,D;
int dp[11][11][11][32];
inline int count(int ma,int mb,int mc,int md)
{
    int rec=0;
    int a,b,c;
    if(!ma&&!mb&&!mc)
    return 1;
    if(mc)
    {
        for(c=1;c<=mc;c++)
        {
            rec=(rec+(dp[0][0][c-1][md-1])*(dp[ma][mb][mc-c][md]))%MOD;
        }
    }
    if(mb)
    {
        for(b=1;b<=mb;b++)
            for(c=0;c<=mc;c++)
            {
                rec=(rec+(dp[0][b-1][c][md-1]*dp[ma][mb-b][mc-c][md]))%MOD;
            }
    }
    if(ma)
    {
        for(a=1;a<=ma;a++)
            for(b=0;b<=mb;b++)
                for(c=0;c<=mc;c++)
                {
                    rec=(rec+(dp[a-1][b][c][md-1]*dp[ma-a][mb-b][mc-c][md]))%MOD;
                }
    }
    return rec;
}
int main()
{
    int a,b,c,d;
    int i;
    scanf("%d%d%d%d",&l1,&l2,&l3,&D);
    dp[0][0][0][0]=1;
    for(i=1;i<=D;i++)
    {
        for(a=0;a<=l1;a++)
            for(b=0;b<=l2;b++)
                for(c=0;c<=l3;c++)
                {
                    dp[a][b][c][i]=count(a,b,c,i);
                  
                }
    }
    printf("%d\n",D?(((dp[l1][l2][l3][D]-dp[l1][l2][l3][D-1])+MOD)%MOD):(dp[l1][l2][l3][D]%MOD));
}