// Graph Algorithm->Floyd-Warshall Algorithm,Dynamic Programming->Bitmask Dynamic Programming (DP),Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n;
int dist[15][15];
int min_dist[15][15];
int d[15][1<<15];
bool vis[15][1<<15];
int dp(int i,int s)
{
    if(vis[i][s])return d[i][s];
    vis[i][s]=true;
    int &ans = d[i][s];
    ans = 1e9;
    for(int j=0;j<=n;j++)if(s&(1<<j)&&j!=i)
    {                                      
        if(ans>dp(j,s^(1<<i))+min_dist[j][i])
        {
            ans = dp(j,s^(1<<i))+min_dist[j][i];
        }
    }
    return ans;
}
void floyd()
{
    for(int k=0;k<=n;k++)
        for(int i=0;i<=n;i++)
            for(int j=0;j<=n;j++)
                if(min_dist[i][j]>min_dist[i][k]+min_dist[k][j])
                    min_dist[i][j] = min_dist[i][k]+min_dist[k][j];
}
int main()
{
    while( scanf("%d",&n)==1&&n )
    {
        for(int i=0;i<=n;i++)
            for(int j=0;j<=n;j++)
            {
                scanf("%d",&dist[i][j]);
                min_dist[i][j]= dist[i][j];
            }
        floyd();
        memset(vis,0,sizeof(vis));
        d[0][0]=0;
        vis[0][0]=true;
        for(int i=1;i<=n;i++)
        {
            vis[i][1<<i]=true;
            d[i][1<<i]=min_dist[0][i];
        }
        printf("%d\n",dp(0,(1<<(n+1))-1 ));
    }
    return 0;
}