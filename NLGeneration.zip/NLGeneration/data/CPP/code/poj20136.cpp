// Math and Computational Geometry->Hyperplan Intersection
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1e5+100;
const double eps = 0;
const double pi = acos(-1.0);
int dblcmp(double x)
{
    if(fabs(x)<eps)
        return 0;
    return x>0?1:-1;
}
struct point
{
    double x,y;
    point() {};
    point(double _x,double _y)
    {
        x = _x;
        y = _y;
    }
};
point points[maxn],p[maxn],q[maxn];
int cCnt,curCnt;
void getline(point s,point e,double &a,double &b,double &c)
{
    
    a = e.y-s.y;
    b = s.x-e.x;
    c = e.x*s.y-e.y*s.x;
}
void init(int n)
{
    for(int i=1;i<=n;i++)
        p[i] = points[i];
    p[n+1] = p[1];
    p[0] = p[n];
    cCnt = n;
}
point cross(point p1,point p2,double a,double b,double c)
{
    
    double u = fabs(a*p1.x+b*p1.y+c);
    double v = fabs(a*p2.x+b*p2.y+c);
    return point((p1.x*v+p2.x*u)/(u+v),(p1.y*v+p2.y*u)/(u+v));
}
double x_mul(point p0,point p1,point p2)
{
    return (p1.x-p0.x)*(p2.y-p0.y)-(p2.x-p0.x)*(p1.y-p0.y);
}
void cut(double a,double b,double c)
{
    curCnt = 0;
    for(int i=1;i<=cCnt;i++)
    {
        if(a*p[i].x+b*p[i].y+c>=eps)
            q[++curCnt] = p[i];
        else
        {
            if(a*p[i-1].x+b*p[i-1].y+c > eps)
                q[++curCnt] = cross(p[i],p[i-1],a,b,c);
            if(a*p[i+1].x+b*p[i+1].y+c > eps)
                q[++curCnt] = cross(p[i],p[i+1],a,b,c);
        }
    }
    for(int i=1;i<=curCnt;i++)
        p[i] = q[i];
    p[curCnt+1] = q[1];
    p[0] = p[curCnt];
    cCnt = curCnt;
}
void slove(int n)
{
    
    init(n);
    for(int i=1;i<=n;i++)
    {
        double a,b,c;
        getline(points[i],points[i+1],a,b,c);
        cut(a,b,c);
    }
}
int main(void)
{
    int t;
    cin>>t;
    while(t--)
    {
        int n;
        scanf("%d",&n);
        for(int i=1;i<=n;i++)
            scanf("%lf %lf",&points[i].x,&points[i].y);
        points[n+1] = points[1];
        slove(n);
        if(cCnt>=1)
            puts("YES");
        else
            puts("NO");
    }
    return 0;
}