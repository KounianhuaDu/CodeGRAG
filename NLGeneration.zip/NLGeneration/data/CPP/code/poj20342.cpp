// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 2000005;
int trie[maxn][26], n, kmp[maxn], len[maxn], ekmp[maxn], tot;
char s[maxn];
bool a[maxn];
int t, slen;
long long ans;
void work(bool b) {
	slen = 0;
	memset(a, 0, sizeof(a));
	for (int i = 1; i <= n; ++i) {
		if (len[i] == 1) {
			a[slen] = true;
			slen += len[i];
			continue;
		}
		kmp[0] = len[i];
		t = 0;
		while (t < len[i] - 1 && s[slen + t] == s[slen + t + 1])
			++t;
		kmp[1] = t;
		t = 1;
		for (int j = 2; j < len[i]; ++j) {
			int p = t + kmp[t] - 1;
			int k = kmp[j - t];
			if (j - 1 + k >= p) {
				int q = max(p - j + 1, 0);
				while (j + q < len[i] && s[slen + j + q] == s[slen + q])
					++q;
				kmp[j] = q;
				t = j;
			} else {
				kmp[j] = k;
			}
		}
		t = 0;
		while (t < len[i] && s[slen + t] == s[slen + len[i] - 1 - t])
			++t;
		ekmp[0] = t;
		t = 0;
		for (int j = 1; j < len[i]; ++j) {
			if (kmp[j - t] + j < ekmp[t] + t)
				ekmp[j] = kmp[j - t];
			else {
				int q = max(ekmp[t] + t - j, 0);
				while (j + q < len[i] && s[slen + q] == s[slen + len[i] - 1 - j - q])
					++q;
				ekmp[j] = q;
				t = j;
			}
		}
		for (int j = 0; j < len[i]; ++j)
			if (ekmp[j] + j == len[i])
				a[slen + len[i] - 1 - j] = true;
		slen += len[i];
	}
	tot = 0;
	slen = 0;
	memset(trie, -1, sizeof(trie));
	memset(kmp, 0, sizeof(kmp));
	for (int i = 1; i <= n; ++i) {
		t = 0;
		for (int j = 0; j < len[i]; ++j) {
			if (trie[t][s[slen + j] - 97] == -1)
				trie[t][s[slen + j] - 97] = ++tot;
			t = trie[t][s[slen + j] - 97];
		}
		++kmp[t];
		slen += len[i];
	}
	slen = 0;
	for (int i = 1; i <= n; ++i) {
		t = 0;
		for (int j = 0; j < len[i]; ++j) {
			if (trie[t][s[slen + len[i] - 1 - j] - 97] == -1)
				break;
			t = trie[t][s[slen + len[i] - 1 - j] - 97];
			if (kmp[t] > 0 && (j == len[i] - 1 || a[slen + len[i] - 2 - j])
				&& (b || j != len[i] - 1))
				ans += kmp[t];
		}
		slen += len[i];
	}
}
int main() {
	freopen("a.txt", "r", stdin);
	freopen("b.txt", "w", stdout);
	scanf("%d", &n);
	ans = 0;
	slen = 0;
	for (int i = 1; i <= n; ++i) {
		scanf("%d%s", &len[i], s + slen);
		slen += len[i];
	}
	work(true);
	slen = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = 0; j < len[i]; ++j)
			kmp[j] = s[slen + j];
		for (int j = 0; j < len[i]; ++j)
			s[slen + j] = kmp[len[i] - 1 - j];
		slen += len[i];
	}
	work(false);
	cout << ans;
	return 0;
}