// Basic Algorithm->Recursion,Graph Algorithm->Lowest Common Ancestor (LCA),Data Structure->Disjoint Set Union (DSU),Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

const int MAX = 910;
struct TreeNode {
    int NextBroId;
    int parentId;
};
typedef struct TreeNode TreeNode;
int LCACounter[MAX];
int querys[MAX][MAX];
int childListHead[MAX];
int UF_Ancestor[MAX];
int queryNum;
int caseNum;
int nodeNum;
TreeNode tree[MAX];
int ancestor[MAX];
char fullyVisited[MAX];
int querySolvedNum;
void insertIntoChildList(int parentId, int childId) {
    tree[childId].parentId = parentId;
    int prevChildListHeadId = childListHead[parentId];
    tree[childId].NextBroId = prevChildListHeadId;
    childListHead[parentId] = childId;
}
inline int UF_find(int nodeId) {
    
    int parentNodeUFId = nodeId;
    if (UF_Ancestor[parentNodeUFId] != parentNodeUFId) {
        UF_Ancestor[nodeId] = UF_find(UF_Ancestor[parentNodeUFId]);
        return UF_Ancestor[nodeId];
    } else {
        return parentNodeUFId;
    }
}
inline void UF_Merge(int parentId, int childId) {
    int parentUFId = UF_find(parentId);
    int childUFId = UF_find(childId);
    UF_Ancestor[childUFId] = parentUFId;
    UF_Ancestor[childId] = parentUFId;
}
int DFSWithUF(int curNodeId) {
    
    UF_Ancestor[curNodeId] = curNodeId;
    
    int curChildNodeId = childListHead[curNodeId];
    while(curChildNodeId) {
        if (DFSWithUF(curChildNodeId)) {
            return 1;
        }
        UF_Merge(curNodeId, curChildNodeId);
        
        curChildNodeId = tree[curChildNodeId].NextBroId;
    }
    
    fullyVisited[curNodeId] = 1;
    for (int i = 1; i <= querys[curNodeId][0]; i++) {
        if (fullyVisited[querys[curNodeId][i]]) {
            int res = UF_Ancestor[UF_find(querys[curNodeId][i])];
            LCACounter[res]++;
            
            
            querySolvedNum++;
            if (querySolvedNum == queryNum) {
                return 1;
            }
        }
    }
    return 0;
}
int main() {
    while(scanf("%d", &nodeNum) != EOF) {
        memset(childListHead, 0, sizeof(childListHead));
        memset(tree, 0, sizeof(tree));
        memset(UF_Ancestor, 0, sizeof(UF_Ancestor));
        memset(LCACounter, 0, sizeof(LCACounter));
        memset(querys, 0, sizeof(querys));
        memset(fullyVisited, 0, sizeof(fullyVisited));
        memset(ancestor, 0, sizeof(ancestor));
        querySolvedNum = 0;
        for (int nodeId = 1; nodeId <= nodeNum; nodeId++) {
            int parentId;
            int childId;
            int childNum;
            scanf("%d", &parentId);
            
            while(getchar() != '(');
            scanf("%d", &childNum);
            while(getchar() != ')');
            
            
            for (int j = 0; j < childNum; j++) {
                scanf("%d", &childId);
                
                insertIntoChildList(parentId, childId);
            }
        }
        scanf("%d", &queryNum);
        for (int i = 1; i <= queryNum; i++) {
            int A, B;
            while(getchar() != '(');
            scanf("%d%d", &A, &B);
            while(getchar() != ')');
            querys[A][0]++;
            querys[A][querys[A][0]] = B;
            querys[B][0]++;
            querys[B][querys[B][0]] = A;
        }
        int rootNodeId = 0;
        for (int i = 1; i <= nodeNum; i++) {
            if (tree[i].parentId == 0) {
                rootNodeId = i;
                break;
            }
        }
        DFSWithUF(rootNodeId);
        for (int i = 1; i <= nodeNum; i++) {
            if (LCACounter[i] > 0) {
                printf("%d:%d\n", i, LCACounter[i]);
            }
        }
    }
}