// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define zero(x) memset(x,0,sizeof(x))
using namespace std;
bool v[200001];
int d[200001],l[200001],nxt[400001],to[400001],deg[200001],w[400001],f[200001],n,t,tot;
inline void dp(register int x)
{
    v[x]=true;
    d[x]=0;
    for(register int i=l[x];i;i=nxt[i])
    {
        int y=to[i];
        if(v[y]) continue;
        dp(y);
        if(deg[y]==1) d[x]+=w[i];
        else d[x]+=min(d[y],w[i]);
    }
}
inline void dfs(register int x)
{
    v[x]=true;
    for(register int i=l[x];i;i=nxt[i])
    {
        int y=to[i];
        if(v[y]) continue;
        if(deg[x]==1) f[y]=d[y]+w[i];
        else f[y]=d[y]+min(f[x]-min(d[y],w[i]),w[i]);
        dfs(y);
    }
}
inline void add(register int u,register int v,register int z)
{
    to[++tot]=v;w[tot]=z;nxt[tot]=l[u];l[u]=tot;return;
}
signed main()
{
    scanf("%d",&t);
    while(t--)
    {
        zero(d);zero(l);zero(nxt);zero(to);zero(deg);
        zero(w);zero(f);zero(v);tot=0;
        scanf("%d",&n);
        for(register int i=1,x,y,z;i<n;i++) 
        {
            scanf("%d%d%d",&x,&y,&z);deg[x]++;deg[y]++;
            add(x,y,z);
            add(y,x,z);
        }
        dp(1);
        zero(v);
        f[1]=d[1];
        dfs(1);
        int ans=0;
        for(register int i=1;i<=n;i++) ans=max(ans,f[i]);
        printf("%d\n",ans);
    }
}