// Graph Algorithm->Floyd-Warshall Algorithm,Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion,Dynamic Programming->Matrix Multiplication,Math and Computational Geometry->Linear Algebra
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 111
using namespace std;
class Matrix{
    public:
        int m[MAXN][MAXN];
        Matrix(){
            memset(m, -1, sizeof(m));
        }
};
int N = 0;
Matrix mtMul(Matrix A, Matrix B){
    Matrix tmp;
    for(int i = 0;i < N;i ++)
        for(int j = 0;j < N;j ++)
            for(int k = 0;k < N;k ++){
                if(A.m[i][k] == -1 || B.m[k][j] == -1) continue;
                int temp = A.m[i][k] + B.m[k][j];
                if(tmp.m[i][j] == -1 || tmp.m[i][j] > temp) tmp.m[i][j] = temp;
            }
    return tmp;
}
Matrix mtPow(Matrix A, int k){
    if(k == 1) return A;
    Matrix tmp = mtPow(A,  k >> 1);
    Matrix res = mtMul(tmp, tmp);
    if(k & 1) res = mtMul(res, A);
    return res;
}
int main(){
    int cnt[1111];
    int n, t, s, e;
    int u, v, w;
    
    while(~scanf("%d%d%d%d", &n, &t, &s, &e)){
        N = 0;
        Matrix G;
        memset(cnt, -1, sizeof(cnt));
        for(int i = 0;i < t;i ++){
            scanf("%d%d%d", &w, &u, &v);
            if(cnt[u] == -1) cnt[u] = N++;
            if(cnt[v] == -1) cnt[v] = N++;
            G.m[cnt[u]][cnt[v]] = w;
            G.m[cnt[v]][cnt[u]] = w;
        }
        Matrix tmp = mtPow(G, n);
        printf("%d\n",tmp.m[cnt[s]][cnt[e]]);
    }
    return 0;
}