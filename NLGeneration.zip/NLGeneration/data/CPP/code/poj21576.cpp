// Basic Algorithm->Greedy Algorithm,Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ls (t<<1)
#define rs (t<<1|1)
#define midt (tr[t].l+tr[t].r>>1)
using namespace std;
const int maxn=1e5+9;
struct
{
    int l,r,max1;
}tr[maxn<<2];
struct D
{
    int a,b;
    bool operator <(const D & xx) const
    {
        return b>xx.b;
    }
}cow[maxn];
struct T
{
    int a,b;
    bool operator <(const T &xx) const
    {
        return a<xx.a;
    }
}grass[maxn];
void maketree(int t,int l,int r)
{
    tr[t].l=l;
    tr[t].r=r;
    if(l==r)
    {
        tr[t].max1=grass[l].b;
        return ;
    }
    int mid=midt;
    maketree(ls,l,mid);
    maketree(rs,mid+1,r);
    tr[t].max1=max(tr[ls].max1,tr[rs].max1);
}
void modify(int t,int x)
{
    if(tr[t].l==x&&tr[t].r==x)
    {
        tr[t].max1=-1;
        return ;
    }
    int mid=midt;
    if(x<=mid) modify(ls,x);
    else modify(rs,x);
    tr[t].max1=max(tr[ls].max1,tr[rs].max1);
}
int query(int t,int l,int r)
{
    if(tr[t].l==l&&tr[t].r==r)
    return tr[t].max1;
    int mid=midt;
    if(r<=mid)
    return query(ls,l,r);
    else if(mid+1<=l)
    return query(rs,l,r);
    else
    {
        int ret=query(ls,l,mid);
        ret=max(ret,query(rs,mid+1,r));
        return ret;
    }
}
int main()
{
    int n,m;
    while(scanf("%d %d",&n,&m)!=EOF)
    {
        for(int i=1;i<=n;i++)
        scanf("%d %d",&cow[i].a,&cow[i].b);
        for(int i=1;i<=m;i++)
        scanf("%d %d",&grass[i].a,&grass[i].b);
        sort(cow+1,cow+1+n);
        sort(grass+1,grass+1+m);
        maketree(1,1,m);
        long long ans=0;
        bool flag=false;
        for(int k=1;k<=n;k++)
        {
            if(grass[m].a<cow[k].a)
            {
                flag=true;
                break;
            }
            int st=1,ed=m,mid;
            while(st<ed)
            {
                mid=st+ed>>1;
                if(grass[mid].a>=cow[k].a) ed=mid;
                else st=mid+1;
            }
            if(query(1,st,m)<cow[k].b)
            {
                flag=true;
                break;
            }
            ed=m;
            while(st<ed)
            {
                mid=st+ed>>1;
                if(query(1,st,mid)>=cow[k].b) ed=mid;
                else st=mid+1;
            }
            ans+=grass[st].a;
            modify(1,st);
        }
        if(!flag)
        cout<<ans<<endl;
        else
        printf("-1\n");
    }
    return 0;
}