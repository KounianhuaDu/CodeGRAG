// Basic Algorithm->Blocking,Basic Algorithm->Recurrence,Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define p 2005
using namespace std;
int n,m;
int f[10003][2][2][2][2],g[10003][2][2],ans[10003][2][2];
int pd(int a,int b,int c)
{
	if (a==1&&b==0&&c==1) return false;
	if (a==1&&b==1&&c==1) return false;
	return true;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("my.out","w",stdout);
	while (scanf("%d",&n)!=EOF)
	{
		m=sqrt(n); 
		if (n==1) {
			cout<<"2"<<endl;
			continue;
		}
		if (n==2){
			cout<<"4"<<endl;
			continue;
		}
		if (n==3){
			cout<<"6"<<endl;
			continue;
		}
		memset(f,0,sizeof(f));
		for (int i=0;i<=1;i++)
		 for (int j=0;j<=1;j++) f[2][i][j][i][j]=1;
		for (int i=0;i<=1;i++)
		 for (int j=0;j<=1;j++)
		  for (int k=0;k<=1;k++) if (pd(i,j,k)) f[3][i][j][j][k]=1;
		for (int i=0;i<=1;i++)
		 for (int j=0;j<=1;j++)
		  for (int a=0;a<=1;a++)
		   for (int b=0;b<=1;b++)
		     if (pd(i,j,a)&&pd(j,a,b))  f[4][i][j][a][b]=1;
		int x=1;
		for (int i=5;i<=m;i++)
		 for (int j=0;j<=1;j++)
		  for (int k=0;k<=1;k++)
		   for (int a=0;a<=1;a++)
		    for (int b=0;b<=1;b++)
		     for (int c=0;c<=1;c++)
		     {
		     	if (pd(a,b,c))
		     	 f[i][j][k][b][c]=(f[i][j][k][b][c]+f[i-1][j][k][a][b])%p;
			 }
		int t=n/m; 
		memset(g,0,sizeof(g));
		for (int i=0;i<=1;i++)
		 for (int j=0;j<=1;j++) 
		  for (int a=0;a<=1;a++)
		   for (int b=0;b<=1;b++)
		      g[1][i][j]=(g[1][i][j]+f[m][a][b][i][j])%p;
		for (int i=1;i<=t-1;i++)
		 for (int x=0;x<=1;x++)
		  for (int y=0;y<=1;y++)
			for (int j=0;j<=1;j++)
			 for (int k=0;k<=1;k++)
			  for (int a=0;a<=1;a++)
			   for (int b=0;b<=1;b++){
			   	if (pd(x,y,j)&&pd(y,j,k))
			   	 g[i+1][a][b]=(g[i+1][a][b]+g[i][x][y]*f[m][j][k][a][b])%p;
			   }
		int size=n-t*m;
		memset(ans,0,sizeof(ans));
		for (int i=0;i<=1;i++)
		 for(int j=0;j<=1;j++)
		  ans[1][i][j]=g[t][i][j]%p;
		for (int i=2;i<=size+1;i++)
		 for (int j=0;j<=1;j++)
		  for (int k=0;k<=1;k++)
		   for (int a=0;a<=1;a++)
		    {
		    	if (pd(j,k,a))  ans[i][k][a]=(ans[i][k][a]+ans[i-1][j][k])%p;
			}     
		int tot=0;
		for(int i=0;i<=1;i++)
		 for (int j=0;j<=1;j++)
		  tot=(tot+ans[(size+1)][i][j])%p;
		printf("%d\n",tot);
    }
}