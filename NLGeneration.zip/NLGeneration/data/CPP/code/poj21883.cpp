// Dynamic Programming->Priority Queue,Data Structure->Queue,Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXN 100010
#define INF 0x3f3f3f3f
int n,m;
int indegree[MAXN];
vector<int> v[MAXN];
struct cmp
{
    bool operator()(const int &a,const int &b)
    {
        return a<b;
    }
};
void Topsort()
{
    priority_queue<int,vector<int>,cmp> q;
    int p[MAXN];
    int ip=0;
    memset(p,0,sizeof(p));
    for(int i=0; i<n; i++)
        if(indegree[i]==0)
            q.push(i);
    while(!q.empty())
    {
        int temp=q.top();
        p[++ip]=temp;
        q.pop();
        for(int i=0; i<v[temp].size(); i++)
        {
            indegree[v[temp][i]]--;
            if(indegree[v[temp][i]]==0)
                q.push(v[temp][i]);
        }
    }
    int ans[MAXN];
    if(ip<n) printf("-1\n");
    else
    {
        int cnt=1;
        for(int i=ip; i>=1; --i)
            ans[p[i]+1]=cnt++;
        for(int i=1; i<cnt-1; ++i)
            printf("%d ",ans[i]);
        printf("%d\n",ans[cnt-1]);
    }
}
int main()
{
#ifdef ONLINE_JUDGE
#else
    freopen("G:/cbx/read.txt","r",stdin);
#endif
    int t;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&n,&m);
        for(int i=0; i<=n; i++) v[i].clear();
        memset(indegree,0,sizeof(indegree));
        for(int i=0; i<m; ++i)
        {
            int a,b;
            scanf("%d%d",&a,&b);
            --a,--b;
            v[b].push_back(a);
            ++indegree[a];
        }
        Topsort();
    }
    return 0;
}