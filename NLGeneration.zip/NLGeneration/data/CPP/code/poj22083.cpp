// Basic Algorithm->Searching
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 1000000+10;
int vis[maxn]={0};
int main()
{
	int n,k;
	while(~scanf("%d%d",&n,&k))
	{
		memset(vis,0,sizeof(vis));
		int t;
		queue<int> q;
		q.push(n);
		
		while(!q.empty()){
			t = q.front();
			q.pop();
			if(t==k) break;
			if(t > 0 && !vis[t-1]){
				int z;z=t-1;vis[z]=vis[t]+1;
				q.push(z);
			}
			if(t<k && !vis[t+1]){
				int z=t+1;
				vis[z]=vis[t]+1;
				q.push(z);
			}
			if(t*2< maxn && !vis[t*2]){
				int z=t*2;
				vis[z]=vis[t]+1;
				q.push(z);
			}
		}
		printf("%d\n",vis[k]);
	}
	return 0;
}