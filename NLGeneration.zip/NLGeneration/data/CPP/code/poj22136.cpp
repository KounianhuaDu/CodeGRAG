// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 10010;
const int M = 110;
bool dp[N][M];
int num[N];
int main()
{
	int n, k;
	while (~scanf("%d%d", &n, &k))
	{
		for (int i = 1; i <= n; ++i)
		{
			scanf("%d", &num[i]);
		}
		memset (dp, 0, sizeof(dp));
		dp[0][0] = 1;
		for (int i = 1; i <= n; ++i)
		{
			for (int j = 0; j < k; ++j)
			{
				for (int l = 0; l < k; ++l)
				{
					if (dp[i - 1][l])
					{
						dp[i][j] = (((l + k) % k + (num[i] + k) % k) % k) == j ? 1 : 0 || dp[i][j];
						dp[i][j] = ((((l + k) % k - (num[i] + k) % k) + k) % k) == j ? 1 : 0 || dp[i][j];
					}
				}
			}
			if (i == n)
			{
				break;
			}
		}
		bool flag = dp[n][0];
		if (flag)
		{
			printf("Divisible\n");
			continue;
		}
		printf("Not divisible\n");
	}
	return 0;
}