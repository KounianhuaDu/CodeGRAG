// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Divide and Conquer,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define mo 100005
#define mk make_pair
vector< pair<int ,int > > d[mo];
int sz[mo];
int sd[mo];
int dist[mo];
int jl[mo];
void dfsz(int node,int dad,int &maxs,int &v,int n) 
{
    sz[node]=1;
    for(int i=0;i<d[node].size();i++)
    {
        int son=d[node][i].first;
        if(son!=dad&&!jl[son])
        {
            dfsz(son,node,maxs,v,n);
            sz[node]+=sz[son];
            if(sz[son]<maxs)
            {
                maxs=sz[son];
                v=son;
            }
        }
    }
    if(n-sz[node]<maxs)
    {
        maxs=n-sz[node];
        v=node;
    }
}
void dis(int node,int dad,int s,int &l)
{
    dist[l++]=s;
    for(int i=0;i<d[node].size();i++)
    {
        int son=d[node][i].first;
        int ls=d[node][i].second;
        if(son!=dad&&!jl[son])
            dis(son,node,s+ls,l);
    }
}
int shu(int k,int v,int d)
{
    int l=0;
    dis(v,0,d,l);
    sort(dist,dist+l);
    int i=0,j=l-1;
    int ans=0;
    while(i<j)
    {
        while(dist[i]+dist[j]>k) j--;
        ans+=j-i;
        i++;
    }
    return ans;
}
void dx(int node,int dad,int &l)
{
    l++;
    for(int i=0;i<d[node].size();i++)
    {
        int son=d[node][i].first;
        if(son!=dad&&!jl[son])
            dx(son,node,l);
    }
}
void dfs(int x,int &ans,int k)
{
    int n=0;
    dx(x,0,n);
    int mins=10000005,v=x;
    dfsz(x,0,mins,v,n);
    ans+=shu(k,v,0); 
    jl[v]=1;
    for(int i=0;i<d[v].size();i++)
    {
        int son=d[v][i].first;
        if(!jl[son])
        {
            int le=d[v][i].second;
            ans-=shu(k,son,le);
            dfs(son,ans,k);
        }
    }
}
int main()
{
    int n,k;
    while(cin>>n>>k&&n+k)
    {
        int x,y,z;
        for(int i=1;i<n;i++)
        {
            cin>>x>>y>>z;
            d[x].push_back(mk(y,z));
            d[y].push_back(mk(x,z));
        }
        int ans=0;
        dfs(1,ans,k);
        cout<<ans<<endl;
    }
}