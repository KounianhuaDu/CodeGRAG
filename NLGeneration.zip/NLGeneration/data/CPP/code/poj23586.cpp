// Basic Algorithm->Iteration
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int SIZEN = 51;
const int SIZEM = 101;
struct S{
	char sequence[SIZEN];
	int unsortedness;
} DNA[SIZEM];
int n, m;
int cnt[4];	
enum {LETTERA, LETTERC, LETTERG, LETTERT};
bool cmp(S a, S b) {
	return a.unsortedness < b.unsortedness;
}
int main() {
	int i, j;
	while (cin >> n >> m) {
		cin.get();
		for (i = 0; i < m; i++) {
			cin.getline(DNA[i].sequence, SIZEN);
		}
		for (i = 0; i < m; i++) {
			memset(cnt, 0, sizeof(cnt));
			for (j = 0; j < n; j++) {
				if (DNA[i].sequence[j] == 'A') {
					cnt[LETTERA]++;
					DNA[i].unsortedness += cnt[LETTERC];
					DNA[i].unsortedness += cnt[LETTERG];
					DNA[i].unsortedness += cnt[LETTERT];
				} else if (DNA[i].sequence[j] == 'C') {
					cnt[LETTERC]++;
					DNA[i].unsortedness += cnt[LETTERG];
					DNA[i].unsortedness += cnt[LETTERT];
				} else if (DNA[i].sequence[j] =='G') {
					cnt[LETTERG]++;
					DNA[i].unsortedness += cnt[LETTERT];
				} else {
					cnt[LETTERT]++;
				}
			}
		}
		stable_sort(DNA, DNA+m, cmp);
		for (i = 0; i < m; i++) {
			cout << DNA[i].sequence << endl;
		}
	}
	return 0;
}