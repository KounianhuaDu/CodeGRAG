// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Maxm 100000
#define Maxn 1000
using namespace std;
struct Edge{
	int u,v,len;
}edge[Maxm];
int fa[Maxn];
int n,m;
bool cmp(Edge a,Edge b){
	return a.len<b.len;
}
int getfather(int x){
	if (x!=fa[x]) return fa[x]=getfather(fa[x]);
	return fa[x];
}
int Kruskal(){
	int ans=0,u,v;
	for (int i=1;i<=n;i++) fa[i]=i;
	for (int i=1;i<=m;i++){
		u=getfather(edge[i].u);v=getfather(edge[i].v);
		if (u==v) continue;
		fa[v]=u;
		ans+=edge[i].len;
	}
	return ans;
}
int main(){
	while (scanf("%d",&n),n!=0){
		scanf("%d",&m);
		for (int i=1;i<=m;i++){
			scanf("%d%d%d",&edge[i].u,&edge[i].v,&edge[i].len);
		}
		sort(edge+1,edge+1+m,cmp);
		printf("%d\n",Kruskal());
	}
}