// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Lowest Common Ancestor (LCA),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define N 300100
struct s
{
	int u,v,next;
}edge[100100<<1];
int num[100100],head[100100],cnt;
int first[N*2],node[N*2],deep[N*2],minv[N<<1][25],hah[N],pre[N],vis[N];
void add(int u,int v)
{
	edge[cnt].u=u;
	edge[cnt].v=v;
	edge[cnt].next=head[u];
	head[u]=cnt++;
}
int tot;    
void dfs(int u,int dep)    
{    
    tot++;    
   
    node[tot]=u;    
    deep[tot]=dep;    
    vis[u]=1;    
    first[u]=tot;    
    int i;    
    for(i=head[u];i!=-1;i=edge[i].next)    
    {    
        int v=edge[i].v;    
        if(!vis[v])    
        {    
            dfs(v,dep+1);    
            tot++;    
            node[tot]=u;    
            deep[tot]=dep;    
        }    
    }    
}    
void init_RMQ(int n)      
{      
    int i,j,k;      
    for(i=1;i<=n;i++)      
    {      
        minv[i][0]=i;      
    }      
    int kk = (int) (log((double) n) / log(2.0));  
    for(j=1;j<=kk;j++)      
    {      
        for(k=1;k+(1<<j)-1<=n;k++)      
        {      
            if(deep[minv[k][j-1]]>deep[minv[k+(1<<(j-1))][j-1]])    
                minv[k][j]=minv[k+(1<<(j-1))][j-1];    
            else    
                minv[k][j]=minv[k][j-1];    
        }      
    }      
}      
int q_min(int l,int r)      
{      
    int k=(int)(log((double)(r-l+1))/(log(2.0)));      
    if(deep[minv[l][k]]>deep[minv[r-(1<<k)+1][k]])    
        return minv[r-(1<<k)+1][k];    
    else    
        return minv[l][k];    
}     
int lca(int a,int b)    
{    
    int x=first[a];    
    int y=first[b];    
    int k;    
   if(x<y)  
   {  
       k=q_min(x,y);  
   }  
   else  
       k=q_min(y,x);  
   return node[k];    
}   
void Tree_DP(int u,int pre)
{
	int i;
	for(i=head[u];i!=-1;i=edge[i].next)
	{
		int v=edge[i].v;
		if(v==pre)
			continue;
		Tree_DP(v,u);
		num[u]+=num[v];
	}
} 
int main()
{
	int n,m;
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		int i;
		memset(head,-1,sizeof(head));
		cnt=0;
		for(i=1;i<n;i++)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			add(u,v);
			add(v,u);
		}
		tot=0;
		memset(vis,0,sizeof(vis));
		memset(first,0,sizeof(first));
		dfs(1,0);
		init_RMQ(tot-1);
		memset(num,0,sizeof(num));
		for(i=0;i<m;i++)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			num[u]++;
			num[v]++;
			num[lca(u,v)]-=2;
		}
		Tree_DP(1,-1);
		int ans=0;
		for(i=2;i<=n;i++)
		{
			if(num[i]==0)
				ans+=m;
			else
				if(num[i]==1)
					ans++;
		}
		printf("%d\n",ans);
	}
}