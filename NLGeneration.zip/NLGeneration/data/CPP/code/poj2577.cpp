// Sorting->Quick Sort,Graph Algorithm->Shortest Path Faster Algorithm (SPFA),Basic Algorithm->Binary Search
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

#define N 1005
int n,m,k,num,adj[N],low[N],f[N],q[N];
struct edge
{
	int v,w,c,pre;
}e[N*20];
void insert(int u,int v,int w)
{
	e[num].v=v;
	e[num].c=w;
	e[num].pre=adj[u];
	adj[u]=num++;
}
int spfa(int x)
{
	int i,v,head=0,tail=0;
	memset(f,0,sizeof(f));
	memset(low,0x7f,sizeof(low));
	low[x]=0;
	q[++tail]=x;
	while(head!=tail)
	{
		x=q[head=(head+1)%N];
		f[x]=0;
		for(i=adj[x];~i;i=e[i].pre)
			if(low[v=e[i].v]>low[x]+e[i].w)
			{
				low[v]=low[x]+e[i].w;
				if(!f[v])
				{
					f[v]=1;
					q[tail=(tail+1)%N]=v;
				}
			}
	}
	return low[n]<=k;
}
int ok(int x)
{
	int i,j;
	for(i=1;i<=n;i++)
		for(j=adj[i];~j;j=e[j].pre)
			if(e[j].c<=x)
				e[j].w=0;
			else
				e[j].w=1;
	return spfa(1);
}
int main()
{
	int u,v,w;
	while(~scanf("%d%d%d",&n,&m,&k))
	{
		num=0;
		memset(adj,-1,sizeof(adj));
		int l=0,r=0,mid,ans=-1;
		while(m--)
		{
			scanf("%d%d%d",&u,&v,&w);
			insert(u,v,w);
			insert(v,u,w);
			if(w>r)
				r=w;
		}
		while(l<=r)
		{
			mid=(l+r)/2;
			if(ok(mid))
			{
				ans=mid;
				r=mid-1;
			}
			else
				l=mid+1;
		}
		printf("%d\n",ans);
	}
}