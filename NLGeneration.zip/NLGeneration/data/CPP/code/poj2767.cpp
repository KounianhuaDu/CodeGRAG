// Dynamic Programming->Knuth-Morris-Pratt (KMP) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define FOR(i,a,b) for(i = (a); i < (b); ++i)
#define FORE(i,a,b) for(i = (a); i <= (b); ++i)
#define FORD(i,a,b) for(i = (a); i > (b); --i)
#define FORDE(i,a,b) for(i = (a); i >= (b); --i)
#define CLR(a,b) memset(a,b,sizeof(a))
const int MAXN = 10010;
char st[MAXN * 100], sp[MAXN];
int n, cnt, len, m;
int p[MAXN];
void next() {
    int k = 0, i;
    p[1] = 0;
    FORE(i, 2, m) {
        while(k > 0 && sp[i] != sp[k + 1])
            k = p[k];
        if(sp[k + 1] == sp[i])
            k = k + 1;
        p[i] = k;
    }
}
int kmp() {
    int k = 0, i;
    FORE(i, 1, len) {
        while(k > 0 && st[i] != sp[k + 1])
            k = p[k];
        if(sp[k + 1] == st[i])
            k = k + 1;
        if(k == m) {
            ++cnt;
            k = p[k];
        }
    }
    return cnt;
}
int main() {
    int i;
    while(scanf("%d", &n) != EOF) {
        FOR(i, 0, n) {
            cnt = 0;
            CLR(p, 0);
            scanf("%s %s", sp + 1, st + 1);
            len = strlen(st + 1);
            m = strlen(sp + 1);
            next();
            cout<<kmp()<<endl;
        }
    }
    return 0;
}