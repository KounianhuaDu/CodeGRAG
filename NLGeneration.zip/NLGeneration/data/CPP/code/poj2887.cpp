// Basic Algorithm->Recurrence,Dynamic Programming->Knapsack Problem
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 10;
const int MAXCASH = 100000;
void zeroPack(int cost, int dp[], const int cash)
{
	
	for (int V = cash; V >= cost; --V)
	{
		dp[V] = max(dp[V], dp[V - cost] + cost);
	}
}
void completePack(int cost, int dp[], const int cash)
{
	for (int V = cost; V <= cash; ++V)
	{
		dp[V] = max(dp[V], dp[V - cost] + cost);
	}
}
void multiplePack(int count, int cost, int dp[], const int cash)
{
	if (count * cost >= cash)
	{
		
		
		completePack(cost, dp, cash);
	}
	else
	{
		
		int k = 1;
		while (k < count)
		{
			zeroPack(k * cost, dp, cash);
			count -= k;
			k <<= 1;
		}
		zeroPack(count * cost, dp, cash);
	}
}
int main()
{	
	int count[MAXN], cost[MAXN];
	int dp[MAXCASH + 1];
	int cash, N;
	while (scanf("%d%d", &cash, &N) != EOF)
	{
		for (int i = 0; i <= cash; ++i)
		{
			dp[i] = 0;
		}
		for (int i = 0; i < N; ++i)
		{
			scanf("%d%d", &count[i], &cost[i]);
		}
		for (int i = 0; i < N; ++i)
		{
			multiplePack(count[i], cost[i], dp, cash);
		}
		printf("%d\n", dp[cash]);
	}
	return 0;  
}