// Dynamic Programming->Priority Queue,Data Structure->Queue
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[3005];
priority_queue<int>q;
bool cmp(int a, int b)
{
    return a>b;
}
int main()
{
    int n,m;
    while(cin>>n>>m)
    {
        for(int i = 0;i < n ;i++)
        {
            scanf("%d",&a[i]);
        }
        sort(a,a+n,cmp);
        int x =0;
        for(int i = 0;i < n ;i++)
        {
            for(int j = i+1 ; j < n ;j++)
            {
                if(x>=500000)
                    break;
                x++;
                q.push(a[i]+a[j]);
            }
        }
        int b = q.top();
        q.pop();
        cout<<b;
        for(int i = 1;i < m ;i++)
        {
            b = q.top();
            q.pop();
            cout<<" "<<b;
        }
        cout<<endl;
    }
}