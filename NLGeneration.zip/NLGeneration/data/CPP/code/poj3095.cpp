// Data Structure->Segment Tree,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAX = 8010 * 2;
set<int> lineVisibleInfo[8000];
struct TreeNode {
	int left;
	int right;
	int lineId;
};
typedef struct TreeNode TreeNode;
struct LineInfo {
	int y1;
	int y2;
	int x;
};
typedef struct LineInfo LineInfo;
TreeNode tree[MAX<<2];
LineInfo lines[8003];
void buildTree(int pos, int begin, int end1) {
	
	TreeNode & curNode = tree[pos];
	curNode.left = begin;
	curNode.right = end1;
	curNode.lineId = -1;
	if (begin == end1) {
		return;
	} else {
		int mid = (begin + end1)>>1;
		buildTree(pos<<1, begin, mid);
		buildTree(pos<<1|1, mid+1, end1);
	}
}
void pushDown(int pos) {
	TreeNode & curNode = tree[pos];
	
	TreeNode & leftNode = tree[pos<<1];
	TreeNode & rightNode = tree[pos<<1|1];
	if (curNode.lineId > -1) {
		leftNode.lineId = curNode.lineId;
		rightNode.lineId = curNode.lineId;
		
		
		curNode.lineId = -1;
	}
}
int lineNum;
int caseNum;
int comp(const void * p1, const void * p2) {
	return (*((LineInfo*)p1)).x - (*((LineInfo*)p2)).x;
}
#define INF 999999
void query(int pos, int rangeLeft, int rangeRight, int newLineId) {
	TreeNode & curNode = tree[pos];
	int left = curNode.left;
	int right = curNode.right;
	int lineId = curNode.lineId;
	
	if (lineId > -1) {
		
			
			lineVisibleInfo[newLineId].insert(lineId);
			
			return;
		
	}
	if (left < right) {
		pushDown(pos);
		int mid = (left + right)>>1;
		if (rangeRight <= mid) {
			query(pos<<1, rangeLeft, rangeRight, newLineId);
		} else if (rangeLeft <= mid && rangeRight > mid) {
			query(pos<<1, rangeLeft, mid, newLineId);
			query(pos<<1|1, mid + 1, rangeRight, newLineId);
		} else if (rangeLeft > mid) {
			query(pos<<1|1, rangeLeft, rangeRight, newLineId);
		}
	}
}
void update(int pos, int rangeLeft, int rangeRight, int newLineId) {
	
	TreeNode & curNode = tree[pos];
	int left = curNode.left;
	int right = curNode.right;
	int lineId = curNode.lineId;
	if (rangeLeft <= left && rangeRight >= right) {
		curNode.lineId = newLineId;
		
		return;
	}
	pushDown(pos);
	int mid = (left + right)>>1;
	if (rangeRight <= mid) {
		update(pos<<1, rangeLeft, rangeRight, newLineId);
	} else if (rangeLeft <= mid && rangeRight > mid) {
		update(pos<<1, rangeLeft, mid, newLineId);
		update(pos<<1|1, mid + 1, rangeRight, newLineId);
	} else if (rangeLeft > mid) {
		update(pos<<1|1, rangeLeft, rangeRight, newLineId);
	}
}
int main() {
	scanf("%d", &caseNum);
	for (int i = 0; i < caseNum; i++) {
		scanf("%d", &lineNum);
		for (int i = 0; i < lineNum; i++) {
			lineVisibleInfo[i].clear();
		}
		int minY1 = INF;
		int maxY2 = -INF;
		for (int j = 0; j < lineNum; j++) {
			int y1, y2, x;
			scanf("%d %d %d", &y1, &y2, &x);
			y1 *= 2;
			y2 *= 2;
			minY1 = minY1 < y1 ? minY1: y1;
			maxY2 = maxY2 > y2 ? maxY2: y2;
			lines[j].y1 = y1;
			lines[j].y2 = y2;
			lines[j].x = x;
		}
		qsort(lines, lineNum, sizeof(LineInfo), comp);
		
		
		
		buildTree(1, minY1, maxY2);
		for (int k = 0; k < lineNum; k++) {
			query(1, lines[k].y1, lines[k].y2, k);
			update(1, lines[k].y1, lines[k].y2, k);
		}
		int res = 0;
		for (int k = lineNum-1; k >= 0; k--) {
			
			set<int>::iterator it = lineVisibleInfo[k].begin();
			for (;it != lineVisibleInfo[k].end(); it++) {
				
				set<int>::iterator it2 = lineVisibleInfo[k].begin();
				for (;it2 != lineVisibleInfo[k].end(); it2++) {
					if (*it2 <= *it) {
						continue;
					}
					
					if (lineVisibleInfo[*it2].find(*it) != lineVisibleInfo[*it2].end()) {
						res++;
					}
				}
			}
			
		}
		printf("%d\n", res);
	}
}