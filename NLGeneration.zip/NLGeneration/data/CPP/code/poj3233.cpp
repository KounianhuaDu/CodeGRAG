// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
vector<int> adj[105];
int n,root,son;
int dfn[105],low[105],cut[105];
int min(int a,int b){
	return (a>b?b:a);
}
void dfs(int u,int dep){
	int i,v;
	dfn[u]=low[u]=dep;
	for(i=0;i<adj[u].size();i++){
		v=adj[u][i];
		if(!dfn[v]){
			dfs(v,dep+1);
			if(u==root)
				son++;
			else{
				low[u]=min(low[u],low[v]);
				if(low[v]>=dfn[u])
					cut[u]=1;
			}
		}
		else
			low[u]=min(low[u],dfn[v]);
	}
}
int main(){
	int u,v,i;
	while(~scanf("%d",&n)&&n){
		for(i=1;i<=n;i++)
			adj[i].clear();
		memset(dfn,0,sizeof(dfn));
		memset(cut,0,sizeof(cut));
		while(scanf("%d",&u)&&u){
			while(getchar()!='\n'){
				scanf("%d",&v);
				adj[u].push_back(v);
				adj[v].push_back(u);
			}
		}
		root=1;
		son=0;
		dfs(root,1);
		if(son>1)
			cut[root]=1;
		int sum=0;
		for(i=1;i<=n;i++)
			sum+=cut[i];
		printf("%d\n",sum);
	}
	return 0;
}