// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long ll;
ll n,k,qz=0,cnt=0;
int visit[10];
char a[15][15];
void dfs(ll l)
{
    if(qz==k) {cnt++; return ;}
                               
    if(l>=n) return;
    for(int i=0;i<n;i++)
    {
        if(a[l][i]=='#'&&visit[i]==0)
        {
            qz++,visit[i]=1;
            dfs(l+1);  
            visit[i]=0;
            qz--;      
                       
                       
                       
                       
        }
    }
    dfs(l+1);
}
int main()
{
    while(cin>>n>>k&&n!=-1)
    {
        for(int i=0;i<n;i++) for(int j=0;j<n;j++) cin>>a[i][j];
        dfs(0);
        cout<<cnt<<endl;
        cnt=0;qz=0;
        memset(visit,0,sizeof(visit));
    }
}