// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a[110][110];
int num[110];
int ans,n,m;
void dfs(int x,int y)		
{
	if(a[x][y]==1||x<1||x>n||y<1||y>m)		
		return ;
	num[ans]++;		
	a[x][y]=1;
	dfs(x-1,y);
	dfs(x+1,y);
	dfs(x,y+1);
	dfs(x,y-1);
}
int main()
{
	int i,j,k,x,y;
	while(~scanf("%d%d%d",&n,&m,&k))
	{
		ans=-1;
		memset(num,0,sizeof(num));		
		for(i=1;i<=n;i++)		
			for(j=1;j<=m;j++)
				a[i][j]=1;
		while(k--)
		{
			scanf("%d%d",&x,&y);		
			a[x][y]=0;
		}
		for(i=1;i<=n;i++)
			for(j=1;j<=m;j++)
			{
				if(a[i][j]==0)		
				{
					ans++;
					dfs(i,j);
				}
			}
		sort(num,num+ans+1);		
		printf("%d\n",num[ans]);
	}
	return 0;
}