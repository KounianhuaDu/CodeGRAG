// Sorting->Topological Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 15
using namespace std;
int n,m,ans;
int a[10][10];
int node[5][5][5];
int num[maxn];
char s[50];
vector<int>v[maxn];
stack<int>sta;
void addedge()          
{
    int i,j,k,nx;
    memset(num,0,sizeof(num));
    for(i=1; i<=4; i++)
    {
        for(j=1; j<=4; j++)
        {
            nx=a[i][j];
            for(k=1;node[i][j][k]!=0;k++)
            {
                if(node[i][j][k]!=nx)
                {
                    num[node[i][j][k]]++;
                    v[nx].push_back(node[i][j][k]);
                }
            }
        }
    }
}
bool tuopusort()
{
    int i,j,nx,cnt=0,sz;
    while(!sta.empty()) sta.pop();
    for(i=1;i<=9;i++)
    {
        if(num[i]==0) sta.push(i);
    }
    while(!sta.empty())
    {
        nx=sta.top();
        cnt++;
        sta.pop();
        sz=v[nx].size();
        for(i=0;i<sz;i++)
        {
            num[v[nx][i]]--;
            if(num[v[nx][i]]==0) sta.push(v[nx][i]);
        }
    }
    if(cnt==9) return true ;
    return false ;
}
int main()
{
    int i,j;
    memset(node,0,sizeof(node));
    node[1][2][1]=1;    node[1][2][2]=2;    
    node[1][3][1]=2;    node[1][3][2]=3;
    node[2][1][1]=1;    node[2][1][2]=4;
    node[2][2][1]=1;    node[2][2][2]=2;    node[2][2][3]=4;    node[2][2][4]=5;
    node[2][3][1]=2;    node[2][3][2]=3;    node[2][3][3]=5;    node[2][3][4]=6;
    node[2][4][1]=3;    node[2][4][2]=6;
    node[3][1][1]=4;    node[3][1][2]=7;
    node[3][2][1]=4;    node[3][2][2]=5;    node[3][2][3]=7;    node[3][2][4]=8;
    node[3][3][1]=5;    node[3][3][2]=6;    node[3][3][3]=8;    node[3][3][4]=9;
    node[3][4][1]=6;    node[3][4][2]=9;
    node[4][2][1]=7;    node[4][2][2]=8;
    node[4][3][1]=8;    node[4][3][2]=9;
    while(scanf("%s",s),strcmp(s,"ENDOFINPUT")!=0)
    {
        for(i=1; i<=4; i++)
        {
            for(j=1; j<=4; j++)
            {
                scanf("%d",&a[i][j]);
            }
        }
        for(i=1; i<=9; i++)
        {
            v[i].clear();
        }
        addedge();
        if(tuopusort()) printf("THESE WINDOWS ARE CLEAN\n");
        else printf("THESE WINDOWS ARE BROKEN\n");
        scanf("%s",s);
    }
    return 0;
}