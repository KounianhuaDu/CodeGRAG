// Basic Algorithm->Randomization,Basic Algorithm->Simulation,Basic Algorithm->Simulated Annealing (SA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int MAXN = 1005;
const int MAXP = 20; 
const double PI = acos(-1.0);
double X, Y;
int n;
double dis[100];
struct P
{
    double x, y;
    P() {}
    P(double _x, double _y) : x(_x), y(_y) {}
    P operator - (P p)
    {
        return P(x - p.x, y - p.y);
    }
    double dis()
    {
        return sqrt(x * x + y * y);
    }
}a[MAXN], ans[MAXN];
double getMinDis(P p)
{
    double as = 1e9;
    for(int i = 0; i < n; i++)
    {
        as = min(as, (p - a[i]).dis());
    }
    return as;
}
P SA()
{
    for(int i = 0; i < MAXP; i++)
    {
        ans[i].x = (rand() % 1000 + 1) / 1000.0 * X;
        ans[i].y = (rand() % 1000 + 1) / 1000.0 * Y;
        dis[i] = getMinDis(ans[i]);
    }
    double delta = max(X, Y) / sqrt(n * 1.0), d = 0.9;
    while(delta > 0.01) 
    {
        for(int i = 0; i < MAXP; i++)
        {
            for(int j = 0; j < 20; j++)
            {
                P t = ans[i];
                double angle = rand() % 1000 / 1000.0 * 2 * PI;
                t.x += delta * cos(angle) * (rand() % 1000 / 1000.0);
                t.y += delta * sin(angle) * (rand() % 1000 / 1000.0);
                if(t.x < 0 || t.x > X || t.y < 0 || t.y > Y)  continue;
                double tmp = getMinDis(t);
                if(tmp > dis[i])
                {
                    dis[i] = tmp;
                    ans[i] = t;
                }
            }
        }
        delta *= d;
    }
    double dd = 0;
    int pp = 0;
    for(int i = 0; i < MAXP; i++)
    {
        if(dis[i] > dd)
        {
            dd = dis[i];
            pp = i;
        }
    }
    return ans[pp];
}
int main()
{
    srand(time(0));
    int T;
    for(scanf("%d", &T); T--;)
    {
        scanf("%lf%lf%d", &X, &Y, &n);
        for(int i = 0; i < n; i++)
        {
            scanf("%lf%lf", &a[i].x, &a[i].y);
        }
        P p = SA();
        printf("The safest point is (%.1f, %.1f).\n", p.x, p.y);
    }
    return 0;
}