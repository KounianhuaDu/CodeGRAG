// Sorting->Merge Sort,Basic Algorithm->Simulation,Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

int num[50001];
int C[50001];
int n;
int lowbit(int x)
{
	return x&(-x);
}
void Init()
{
	memset(C,0,sizeof(C));
	memset(num,0,sizeof(num));
}
void update(int x,int d)
{
	while(x<=n){
		C[x]+=d;
		x+=lowbit(x);
	}
}
int sum(int x)
{
	int ret=0;
	while(x>0){
		ret+=C[x];
		x-=lowbit(x);
	}
	return ret;
}
int main()
{
	while(scanf("%d",&n)!=EOF){
		Init();
		for(int i=1;i<=n;i++){
			scanf("%d",&num[i]);
		}
		int c;
		long res=0;
		for(int i=n;i>=1;i--){
			if(num[i]==0){
				c=i;
				continue;	
			}
			update(num[i],1);
			res+=sum(num[i]-1);
		}	
		res=res+c-1;
		
		long min1=res,tmp=res; 
		for(int i=1;i<=n-1;i++){
			tmp=tmp-num[i]+n-num[i]-1;
			if(tmp<min1) min1=tmp;
		}
		printf("%ld\n",min1);
	}
	return 0;
}