// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma GCC optimize(2)
#define gt() (p1==p2&&(p2=(p1=buf)+fread(buf,1,1000000,stdin),p1==p2)?EOF:*p1++)
#define Out() (fwrite(St,1,Top,stdout))
#define pt(ch) (Top<1000000?St[Top++]=ch:(Out(),St[(Top=0)++]=ch))
#define Tp double
#define db double
#define Vc Vector
using namespace std;
int Top;static char St[1000000],buf[1000000],*p1=buf,*p2=buf;
const int maxn=25;const db eps=1e-6,INF=-(1e100);
int n;db Ans;
struct Vc{
	Tp x,y;
	Vc operator -(const Vc B){return (Vc){x-B.x,y-B.y};}
	Vc operator +(const Vc B){return (Vc){x+B.x,y+B.y};}
	Vc operator *(const Tp p){return (Vc){x*p,y*p};}
}a[maxn],b[maxn],C,D;
Tp Cross(Vc A,Vc B){return A.x*B.y-A.y*B.x;}
Vc getpos(Vc P,Vc v,Vc Q,Vc w){
	Vc u=P-Q;
	db t=Cross(w,u)/Cross(v,w);
	return (P+(v*t));
}
bool sameside(Vc A,Vc B){return (Cross(D-C,A-C)*Cross(D-C,B-C)>eps);}
Tp read(){
	int ret=0;bool f=0;char ch=gt();
	while(ch<'0'||ch>'9') f|=(ch=='-'),ch=gt();
	while(ch>='0'&&ch<='9') ret=ret*10+ch-'0',ch=gt();
	db res=ret;
	if(ch=='.'){db d=1;ch=gt();while(ch>='0'&&ch<='9') res+=(ch-'0')/(d*=10),ch=gt();}
	return f?-res:res;
}
void write(int x){if(x>9) write(x/10);pt(x%10+'0');}
bool check(Vc A,Vc B){return (Cross(C-A,D-A)*Cross(C-B,D-B)<-eps);}
bool Across(Vc A,Vc B){return (Cross(C-A,D-A)*Cross(C-B,D-B)<eps);}
int main(){
	#ifdef hhh
	freopen("data.in","r",stdin);
	freopen("data.out","w",stdout);
	#endif
	for(n=read();n;n=read()){
		for(int i=1;i<=n;i++) b[i]=a[i]=(Vc){read(),read()},b[i].y-=1.0;
		bool flg=1;Ans=INF;
		for(int i=1;i<=n&&flg;i++)
		  for(int j=1,k;j<=n;j++)if(i!=j){
		  	C=a[i],D=b[j];
		  	for(k=1;k<n;k++) 
			  if(check(a[k],a[k+1])||check(b[k],b[k+1])||sameside(a[k+1],b[k+1])||sameside(a[k],b[k])) break;
		  	if(k==n){flg=0;break;}
		  	if(k>=i&&k>=j){
		  	  db tep_a=INF,tep_b=INF;
		  	  if(Across(a[k],a[k+1])) tep_a=getpos(a[k],a[k+1]-a[k],C,D-C).x;
			  if(Across(b[k],b[k+1])) tep_b=getpos(b[k],b[k+1]-b[k],C,D-C).x;
		  	  if(tep_a>Ans) Ans=tep_a;if(tep_b>Ans) Ans=tep_b;
		  	}
		  }
		if(!flg) puts("Through all the pipe.");
		  else printf("%.2f\n",Ans);
	}
	return 0;
}