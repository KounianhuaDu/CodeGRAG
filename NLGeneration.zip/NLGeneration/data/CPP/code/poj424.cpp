// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const double PI = acos(-1.0);
const double E = exp(1.0);
const short maxorder = 22; 
const short maxsta = 8; 
short cap, sta, order; 
short down[maxsta]; 
short ans; 
struct ticket
{
    short start, des, pass;
    bool operator < (const ticket & p) const{
        if (start == p.start)
            return des < p.des;
        return start < p.start;
    } 
} ord[maxorder];
void dfs(short ord_num, short passe, short money);
int main()
{
    ios::sync_with_stdio(false);
    while (cin >> cap >> sta >> order && (cap || sta || order))
    {
        for (int i=0; i<order; i++)
            cin >> ord[i].start >> ord[i].des >> ord[i].pass; 
        sort(ord, ord+order);
        ans = 0;
        dfs(0, 0, 0);
        cout << ans << endl;
    }
    return 0;
}
void dfs(short ord_num, short passe, short money)
{
    if (ord_num == order) 
    {
        ans = max(ans, money);
        return;
    }
    if (ord_num > 0)
        for (int i=ord[ord_num-1].start+1; i<=ord[ord_num].start; ++i)
            passe -= down[i]; 
    if (passe+ord[ord_num].pass <= cap) 
    {
        down[ord[ord_num].des] += ord[ord_num].pass; 
        dfs(ord_num+1, passe+ord[ord_num].pass, money+ord[ord_num].pass*(ord[ord_num].des-ord[ord_num].start));
        down[ord[ord_num].des] -= ord[ord_num].pass; 
    }
    dfs(ord_num+1, passe, money); 
}