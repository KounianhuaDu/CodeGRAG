// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=110;
bool grid[maxn][maxn];
int node[maxn],ans[maxn],dp[maxn];
int n,m,max1;
int v[maxn][maxn];
void dfs(int s,int t)
{
    if(t==0)
    {
        if(s>max1)
        {
            max1=s;
            for(int i=1;i<=max1;i++)ans[i]=node[i];
        }
        return;
    }
    for(int i=1;i<=t;i++)
    {
        int u=v[s][i];
        if(s+dp[u]<=max1)return;
        int sum=0;
        for(int j=i+1;j<=t;j++)
            if(grid[u][v[s][j]])
                v[s+1][++sum]=v[s][j];
        node[s+1]=u;
        dfs(s+1,sum);
    }
}
void solve()
{
    max1=0;
    for(int i=n;i>0;i--)
    {
        int sum=0;
        for(int j=i+1;j<=n;j++)
            if(grid[i][j])v[1][++sum]=j;
        node[1]=i;
        dfs(1,sum);
        dp[i]=max1;
    }
    cout<<max1<<endl;
    if(max1<1)return ;
    cout<<ans[1];
    for(int i=2;i<=max1;i++)
        cout<<" "<<ans[i];
    cout<<endl;
}
int main()
{
    freopen("in.txt","r",stdin);
    ios::sync_with_stdio(false);
    int t,a,b;
    cin>>t;
    while(t--)
    {
        cin>>n>>m;
        for(int i=0;i<=n;i++)fill(grid[i],grid[i]+n+1,1);
        while(m--)
        {
            cin>>a>>b;
            grid[a][b]=grid[b][a]=0;
        }
        solve();
    }
    return 0;
}