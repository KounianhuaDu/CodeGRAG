// Graph Algorithm->Euler Circuit / Euler Path
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define rep(i,j,k) for(int i=j;i<k;++i)
#define mst(a,b) memset((a),(b),sizeof(a))
using namespace std;
typedef long long LL;
typedef vector<int,int> pii;
const int MAXN = 50;
const int MAXM = 2005;
int nV,nE,top;
int stk[MAXM];
int deg[MAXN];
bool vis[MAXM];
int G[MAXN][MAXM];
void init(){
    top = nV = nE = 0;
    mst(vis,false);
    mst(G,0);
    mst(deg,0);
}
void euler(int u){
    for(int i = 1; i <= nE; ++i){
        if(!vis[i] && G[u][i]){
            vis[i] = true;
            euler(G[u][i]);
            stk[++top] = i;
        }
    }
}
int main()
	{
        int x,y,z,st;
        while(scanf("%d%d",&x,&y) && x!=0 && y != 0){
            init();
            st = (int)min(x,y);
            scanf("%d",&z);
            nE = (int)max(z,nE);
            nV = (int)max((int)max(x,y),nV);
            ++deg[x];
            ++deg[y];
            G[x][z] = y;
            G[y][z] = x;
            while(scanf("%d%d",&x,&y) && x&& y){
                scanf("%d",&z);
                nE = max(z,nE);
                nV = max((int)max(x,y),nV);
                ++deg[x];
                ++deg[y];
                G[x][z] = y;
                G[y][z] = x;
            }
            
            
            bool flag = true;
            for(int i = 1; i <= nV; i++)
                if(deg[i] & 1)
                    flag = false;
            if(!flag){
                printf("Round trip does not exist.\n");
            }
            else{
                euler(st);
                printf("%d", stk[top]);
                for(int i = top - 1; i > 0; i--)
                    printf(" %d", stk[i]);
                printf("\n");
            }
        }
		return 0;
	}