// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=12345;
vector< pair<int,int> > vec[N];
int dist[N];
int vis[N];
int sum;
int pos;
void bfs(int v0,int n){
    for(int i=1;i<=n;i++){
        dist[i]=0;
        vis[i]=0;
    }
    vis[v0]=1;
    pair<int,int> p,q,temp;
    queue< pair<int,int> > que;
    while(!que.empty()) que.pop();
    p={v0,0};
    que.push(p);
    dist[v0]=0;
    sum=0;
    pos=v0;
    while(!que.empty()){
        temp=que.front();
        que.pop();
        for(int i=0;i<vec[temp.first].size();i++){
            q=vec[temp.first][i];
            if(!vis[q.first]){
                dist[q.first]=dist[temp.first]+q.second;
                vis[q.first]=1;
                que.push(q);
                if(dist[q.first]>sum){
                    sum=dist[q.first];
                    pos=q.first;
                }
            }
        }
    }
}
int main(){
    int u,v,w;
    int Max=0;
    while(~scanf("%d %d %d",&u,&v,&w)){
        vec[u].push_back(make_pair(v,w));
        vec[v].push_back(make_pair(u,w));
        Max=max(Max,max(u,v));
    }
    bfs(1,Max);
    bfs(pos,Max);
    printf("%d\n",sum);
    return 0;
}