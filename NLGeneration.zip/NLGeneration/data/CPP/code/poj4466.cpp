// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define INF 0x3f3f3f3f
#define MAXN 50002
#define memset0(a) memset(a,0,sizeof(a))
#define EPS 1e-8
struct It
{
    int b, h, S, V;
}its[MAXN];
int N, V;
void fun()
{
    int sumV = 0;
    for (int p = 0; p < N; p++) {
        int w, d;
        scanf("%d%d%d%d", &its[p].b, &its[p].h, &w, &d);
        its[p].S = w*d, sumV += its[p].V = its[p].S*its[p].h;
    }
    scanf("%d", &V);
    if (V > sumV) {
        printf("OVERFLOW\n");
        return;
    }
    double low = 0, high = 2e9, mid;
    while (high - low > 4e-3) {
        mid = (high + low) / 2;
        double sum = 0;
        for (int p = 0; p < N; p++) {
            if (mid > its[p].b) {
                double v = (mid - its[p].b)*its[p].S;
                sum += v > its[p].V ? its[p].V : v;
            }
        }
        if (sum >= V)
            high = mid;
        else
            low = mid;
    }
    printf("%.2lf\n", mid);
}
int main(void)
{
    
    
    int times;
    scanf("%d", &times);
    while (times--) {
        scanf("%d", &N);
        fun();
    }
}