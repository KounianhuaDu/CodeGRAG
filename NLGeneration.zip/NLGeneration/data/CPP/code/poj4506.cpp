// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
typedef long long LL;
#define N 2010
#define M 4000010
#define inf 2147483647
int n,m,t=1,tot,idx;
int head[N],dfn[N],low[N];
struct edge
{
    int u,v,next;
    bool vis,cut,left,dir,exit;
}ed[M];
void add(int u,int v,bool dir,bool exit)
{
    ed[tot].u=u;
    ed[tot].v=v;
    ed[tot].next=head[u];
    ed[tot].vis=ed[tot].cut=ed[tot].left=false;
    ed[tot].dir=dir;
    ed[tot].exit=exit;
    head[u]=tot++;
}
void tarjan(int u)
{
    int i,v;
    dfn[u]=low[u]=++idx;
    for(i=head[u];~i;i=ed[i].next)
    {
        v=ed[i].v;
        if(ed[i].vis) continue;
		ed[i].vis=ed[i^1].vis=true;
        if(dfn[v]==-1)
        {
            tarjan(v);
            low[u]=min(low[u],low[v]);
            if(dfn[u]<low[v])
            {
                ed[i].cut=ed[i^1].cut=true;
                ed[i].left=ed[i^1].left=true;
            }
        }
        else low[u]=min(low[u],dfn[v]);
    }
}
void dfs(int u)
{
    int i,v;
    dfn[u]=low[u]=++idx;
    for(i=head[u];~i;i=ed[i].next)
    {
        if(ed[i].cut||!ed[i].exit) continue;
        v=ed[i].v;
        if(dfn[v]==-1)
        {
            ed[i].vis=ed[i^1].vis=true;
            dfs(v);
            low[u]=min(low[u],low[v]);
            if(!ed[i].dir)
            {
                if(low[v]>dfn[u]) ed[i^1].left=true;
                else ed[i].left=true;
            }
        }
        else
        {
            low[u]=min(low[u],dfn[v]);
            if(!ed[i].vis&&!ed[i].dir) ed[i].left=true;
            ed[i].vis=ed[i^1].vis=true;
        }
    }
}
void solve()
{
	int i;
	memset(dfn,-1,sizeof(dfn));
	idx=0;
	tarjan(1);
	memset(dfn,-1,sizeof(dfn));
	idx=0;
	for(i=0;i<tot;i++) ed[i].vis=false;
	for(i=1;i<=n;i++)
    {
        if(dfn[i]==-1) dfs(i);
    }
}
int main()
{
    int i,u,v,k;
    while(~scanf("%d%d",&n,&m))
    {
        tot=0;
        memset(head,-1,sizeof(head));
        for(i=1;i<=m;i++)
        {
            scanf("%d%d%d",&u,&v,&k);
            if(k&1)
            {
                add(u,v,true,true);
                add(v,u,true,false);
            }
            else
            {
                add(u,v,false,true);
                add(v,u,false,true);
            }
        }
        solve();
        for(i=0;i<tot;i+=2)
        {
            if(ed[i].dir) continue;
            if(ed[i].left&&ed[i^1].left) printf("%d %d 2\n",ed[i].u,ed[i].v);
            else if(ed[i].left) printf("%d %d 1\n",ed[i].u,ed[i].v);
            else printf("%d %d 1\n",ed[i].v,ed[i].u);
        }
    }
	return 0;
}