// Graph Algorithm->Hungarian (KM) Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=5e2+10;
int N,K;
bool mp[maxn][maxn];
bool used[maxn];
int mate[maxn];
bool Findm(int x)
{
    for(int i=0;i<N;i++)
    {
        if(!used[i]&&mp[x][i])
        {
            used[i]=1;
            if(!mate[i]||Findm(mate[i]))
            {
                mate[i]=x;
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    while(scanf("%d",&N)==1&&N)
    {
        memset(mp,0,sizeof(mp));
        for(int i=1;i<=N;i++)
        {
            int I,like;
            scanf("%d: (%d) ",&I,&like);
            for(int j=1;j<=like;j++)
            {
                int t;
                scanf("%d",&t);
                mp[I][t]=1;
            }
        }
        int re=0;
        memset(mate,0,sizeof(mate));
        for(int i=0;i<N;i++)
        {
            memset(used,0,sizeof(used));
            re+=Findm(i);
        }
        printf("%d\n",N-re/2);
    }
}