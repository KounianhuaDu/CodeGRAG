// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int g[305][305];
int vis[305];
int link[305];
int p,n;
bool dfs(int u)
{
	for(int i=1;i<=n;i++)
		if( !vis[i] && g[u][i] )
		{
			vis[i]=1;
			if( link[i]==-1 || dfs(link[i]) )
			{
				link[i]=u;
				return 1;
			}
		}
	return 0;
}
int Hangary()
{
	memset(link,-1,sizeof(link));
	for(int i=1;i<=p;i++)
	{
		memset(vis,0,sizeof(vis));
		if( !dfs(i) ) return 0;
	}
	return 1;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&p,&n);
		memset(g,0,sizeof(g));
		for(int i=1;i<=p;i++)
		{
			int c;
			scanf("%d",&c);
			for(int j=0;j<c;j++)
			{
				int a;
				scanf("%d",&a);
				g[i][a]=1;
			}
		}
		if(Hangary()) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}