// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define QUESIZE 100000
#define MAPSIZE 30
char Map[MAPSIZE][MAPSIZE];
char dir_box[] = {'N', 'S', 'W', 'E'};
char dir_man[] = {'n', 's', 'w', 'e'};
int gor[] = {-1, 1, 0, 0};
int goc[] = {0, 0, -1, 1};
int map_r, map_c;
using namespace std;
typedef struct{
	string way;
	int r, c; 
	int mr, mc; 
}Point;
int judge_edge(int r, int c)
{
	if(r >= 0 && r < map_r && c >= 0 && c < map_c && Map[r][c] != '#')
		return 1;
	return 0;
}
string man_can_go(Point beg, Point end1)
{
	queue<Point>que;
	int vis[MAPSIZE][MAPSIZE];
	memset(vis, 0, sizeof(vis));
	beg.way = "";
	que.push(beg);
	vis[beg.mr][beg.mc] = 1;
	while(!que.empty()){
		Point cur = que.front();
		que.pop();
		if(cur.mr == end1.mr && cur.mc == end1.mc)
			return cur.way;
		for(int i = 0; i < 4; i++){
			Point next;
			next.mr = cur.mr + gor[i];
			next.mc = cur.mc + goc[i];
			next.way = cur.way;
			if(!judge_edge(next.mr, next.mc) || vis[next.mr][next.mc] || (next.mr == beg.r && next.mc == beg.c))
				continue;
			next.way.append(1, dir_man[i]);
			que.push(next);
			vis[next.mr][next.mc] = 1;
		}
	}
	return "Impossible.";
}
string box_bfs(Point box, Point tar)
{
	queue<Point>que;
	int vis[4][MAPSIZE][MAPSIZE];
	memset(vis, 0, sizeof(vis));
	que.push(box);
	while(!que.empty()){
		Point cur = que.front();
		que.pop();
		if(cur.r == tar.r && cur.c == tar.c)
			return cur.way;
		for(int i = 0; i < 4; i++){
			Point next;
			
			next.r = cur.r + gor[i];
			next.c = cur.c + goc[i];
			
			next.mr = cur.r - gor[i];
			next.mc = cur.c - goc[i];
			next.way = cur.way;
			if(vis[i][next.r][next.c]) 
				continue;
			if(!judge_edge(next.r, next.c))
				continue;
			if(!judge_edge(next.mr, next.mc))
				continue;
			string mway = man_can_go(cur, next);
			if(mway != "Impossible."){
				next.way.append(mway);
				next.way.append(1, dir_box[i]);
				
				next.mr = cur.r;
				next.mc = cur.c;
				que.push(next);
				vis[i][next.r][next.c] = 1;
			}
		}
	}
	return "Impossible.";
}
int main()
{
#if 0
	freopen("in.txt","r",stdin);
#endif
	int w = 0;
	while(scanf("%d%d", &map_r, &map_c) == 2, map_r && map_c){
		int i, j;
		Point box;
		Point tar;
		for(i = 0; i < map_r; i++){
			scanf("%s", Map[i]);
			for(j = 0; j < map_c; j++){
				if(Map[i][j] == 'S') {box.mr = i; box.mc = j;}
				if(Map[i][j] == 'B') {box.r = i; box.c = j; box.way = "";}
				if(Map[i][j] == 'T') {tar.r = i; tar.c = j; tar.way = "";}
			}
		}
		cout << "Maze #" << ++w << endl;
		cout << box_bfs(box, tar) << endl << endl;
	}
	return 0;
}