// Basic Algorithm->Recurrence
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 10010
#define inf 0x3f3f3f3f
using namespace std;
int dp[maxn][3];
int cnt,head[maxn];
struct node
{
    int f,t,next;
}edge[maxn];
void init()
{
    cnt=0;
    memset(head,-1,sizeof(head));
    memset(dp,0,sizeof(dp));
}
void add(int f,int t)
{
    edge[cnt].f=f;
    edge[cnt].t=t;
    edge[cnt].next=head[f];
    head[f]=cnt++;
}
void DP(int u,int p)
{
    dp[u][2]=0;
    dp[u][0]=1;
    bool sign=false;
    int sum=0,inc=inf;
    for(int i=head[u];i!=-1;i=edge[i].next)
    {
        int v=edge[i].t;
        if(v==p)
            continue;
        DP(v,u);
        dp[u][0]+=min(dp[v][0],dp[v][2]);
        
        if(dp[v][0]<=dp[v][1])
        {
            sum+=dp[v][0];
            sign=true;
        }
        else
        {
            sum+=dp[v][1];
            inc=min(inc,dp[v][0]-dp[v][1]);
        }
        if(dp[v][1]!=inf&&dp[u][2]!=inf)
            dp[u][2]+=dp[v][1];
        else
            dp[u][2]=inf;
    }
    if(inc==inf&&!sign)
        dp[u][1]=inf;
    else
    {
        dp[u][1]=sum;
        if(!sign)
            dp[u][1]+=inc;
    }
}
int main()
{
    int n,a,b;
    while(scanf("%d",&n)&&(n!=-1))
    {
        init();
        for(int i=1;i<n;++i)
        {
            scanf("%d%d",&a,&b);
            add(a,b);
            add(b,a);
        }
        DP(1,n);
        int ans=min(dp[1][0],dp[1][1]);
        printf("%d\n",ans);
        scanf("%d",&a);
        if(a==0)
            continue;
        else if(a==-1)
            return 0;
    }
    return 0;
}