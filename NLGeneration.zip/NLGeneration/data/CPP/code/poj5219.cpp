// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define FOR(i,a,b) for(i = (a); i < (b); ++i)
#define FORE(i,a,b) for(i = (a); i <= (b); ++i)
#define FORD(i,a,b) for(i = (a); i > (b); --i)
#define FORDE(i,a,b) for(i = (a); i >= (b); --i)
#define CLR(a,b) memset(a,b,sizeof(a))
#define PB(x) push_back(x)
const int MAXN = 50010;
const int MAXM = 50010;
const int hash_size = 25000002;
const int INF = 0x7f7f7f7f;
bool vis[MAXN];
int cnt, n;
int maxb = -1, minb = INF;
int head[MAXN], dist[MAXN], cnt0[MAXN];
struct edge {
    int v, w, nxt;
}p[MAXM * 4];
void addedge(int u, int v, int w) {
    p[cnt].v = v;
    p[cnt].w = w;
    p[cnt].nxt = head[u];
    head[u] = cnt++;
}
int spfa(int x) {
    int i;
    CLR(cnt0, 0);
    CLR(vis, false);
    FORE(i, minb - 1, maxb)
        dist[i] = INF;
    dist[x] = 0;
    queue<int> q;
    q.push(x);
    vis[x] = true;
    ++cnt0[x];
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        vis[u] = false;
        for(i = head[u]; i != -1; i = p[i].nxt) {
            int v = p[i].v;
            if(p[i].w + dist[u] < dist[v]) {
                dist[v] = p[i].w + dist[u];
                if(!vis[v]) {
                    q.push(v);
                    vis[v] = true;
                }
            }
        }
    }
    return dist[minb - 1];
}
void init() {
    int i, ai, bi, ci;
    while(scanf("%d", &n) != EOF) {
        cnt = 0;
        CLR(head, -1);
        maxb = -1, minb = INF;
        FORE(i, 1, n) {
            scanf("%d %d %d", &ai, &bi, &ci);
            addedge(bi, ai - 1, -ci);
            maxb = max(maxb, bi);
            minb = min(minb, ai);
        }
        FORE(i, minb, maxb) {
            addedge(i, i - 1, 0);
            addedge(i - 1, i, 1);
        }
        printf("%d\n", -spfa(maxb));
    }
}
int main() {
    init();
    return 0;
}