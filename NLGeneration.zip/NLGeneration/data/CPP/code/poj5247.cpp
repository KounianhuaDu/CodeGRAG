// Graph Algorithm->Shortest Path Faster Algorithm (SPFA)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define N  1005000
#define inf 0x3f3f3f3f
using namespace std;
struct Edge
{
    int u;
    int v;
    long long c;
    int next;
} p[N];
int head[N];
long long dis[N];
int visit[N];
int T,m,n,e;
void addnode(int u,int v,long long c)
{
    p[e].u=u;
    p[e].v=v;
    p[e].c=c;
    p[e].next=head[u];
    head[u]=e;
    e++;
}
void init()
{
    memset(head,-1,sizeof(head));
    for(int i=1;i<N;i++)
        p[i].next=-1;
    e=0;
    int u,v;
    long long c;
    for(int i=0; i<n; i++)
    {
        scanf("%d%d%lld",&u,&v,&c);
        addnode(u,v,c);
    }
}
void reinit()
{
    memset(head,-1,sizeof(head));
    for(int i=1;i<=N;i++)
        p[i].next=-1;
    e=0;
    for(int i=0;i<n;i++)
    {
        addnode(p[i].v,p[i].u,p[i].c);
    }
}
int Spfa(int src)
{
    int u,v,weight;
    memset(visit,0,sizeof(visit));
    memset(dis,inf,sizeof(dis));
    dis[src]=0;
    queue<int>q;
    while(!q.empty())
        q.pop();
    q.push(src);
    visit[src]=1;
    while(!q.empty())
    {
        u=q.front();
        q.pop();
        visit[u]=0;
        for(int i=head[u]; i!=-1; i=p[i].next)
        {
            v=p[i].v;
            weight=p[i].c;
            if(dis[v]>dis[u]+weight)
            {
                dis[v]=dis[u]+weight;
                if(!visit[v])
                {
                    q.push(v);
                    visit[v]=1;
                }
            }
        }
    }
}
int main()
{
    scanf("%d",&T);
    while(T--)
    {
        long long sum1=0,sum2=0,sum;
        scanf("%d%d",&m,&n);
        init();
        Spfa(1);
        for(int i=1;i<=m;i++)
            sum1+=dis[i];
        reinit();
        Spfa(1);
        for(int i=1;i<=m;i++)
            sum2+=dis[i];
        sum=sum1+sum2;
        cout<<sum<<endl;
    }
    return 0;
}