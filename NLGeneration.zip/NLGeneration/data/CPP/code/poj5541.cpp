// Data Structure->Stack,Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,m;
struct node
{
    int l,r;
    int lsum,rsum,sum;
}segtree[200005];
stack<int> s;
void pushup(int root)
{
    segtree[root].lsum=segtree[root<<1].lsum;
    segtree[root].rsum=segtree[root<<1|1].rsum;
    segtree[root].sum=max(max(segtree[root<<1].sum,segtree[root<<1|1].sum),segtree[root<<1].rsum+segtree[root<<1|1].lsum);
    if(segtree[root<<1].lsum==segtree[root<<1].r-segtree[root<<1].l+1)
        segtree[root].lsum=segtree[root<<1].sum+segtree[root<<1|1].lsum;
    if(segtree[root<<1|1].rsum==segtree[root<<1|1].r-segtree[root<<1|1].l+1)
        segtree[root].rsum=segtree[root<<1|1].sum+segtree[root<<1].rsum;
}
void buildtree(int root,int l,int r)
{
    segtree[root].l=l;
    segtree[root].r=r;
    if(l==r)
    {
        segtree[root].sum=segtree[root].lsum=segtree[root].rsum=1;
        return ;
    }
    int mid=(l+r)>>1;
    buildtree(root<<1,l,mid);
    buildtree(root<<1|1,mid+1,r);
    pushup(root);
}
void update(int root,int id,int tag)
{
    int ll=segtree[root].l;
    int rr=segtree[root].r;
    if(ll==rr)
    {
        if(tag==1)
            segtree[root].sum=segtree[root].lsum=segtree[root].rsum=0;
        if(tag==0)
            segtree[root].sum=segtree[root].lsum=segtree[root].rsum=1;
        return;
    }
    int mid=(ll+rr)>>1;
    if(id<=mid)update(root<<1,id,tag);
    else update(root<<1|1,id,tag);
    pushup(root);
}
int query(int root,int id)
{
    int ll=segtree[root].l;
    int rr=segtree[root].r;
    if(ll==rr)
        return segtree[root].sum;
    if(segtree[root].sum==segtree[root].r-segtree[root].l+1)
        return segtree[root].sum;
    int mid=(ll+rr)>>1;
    int ans=0;
    if(id<=mid)
    {
        if(id>=segtree[root<<1].r-segtree[root<<1].rsum+1)
            return segtree[root<<1].rsum+segtree[root<<1|1].lsum;
        else
             return query(root<<1,id);
    }
    else
    {
        if(id<=segtree[root<<1|1].l+segtree[root<<1|1].lsum-1)
            return segtree[root<<1|1].lsum+segtree[root<<1].rsum;
        else
            return query(root<<1|1,id);
    }
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        buildtree(1,1,n);
        char str[3];
        for(int i=1;i<=m;i++)
        {
            int x;
            scanf("%s%d",str,&x);
            if(str[0]=='D')
            {
                update(1,x,1);
                s.push(x);
            }
            else if(str[0]=='Q')
            {
                int ans=query(1,x);
                cout<<ans<<endl;
            }
            else if(str[0]=='R')
            {
                int x=s.top();
                s.pop();
                update(1,x,0);
            }
        }
    }
    return 0;
}