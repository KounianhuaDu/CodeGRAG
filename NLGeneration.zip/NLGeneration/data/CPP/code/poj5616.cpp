// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MIN(a,b) ((a)>(b)? (b):(a))
using namespace std;
const int F=25*25+5;
const int E=25+5;
const int INF=0x3f3f3f3f;
typedef struct tagNode{
    int p,t,d;
    tagNode(){}
    tagNode(int P,int T,int D):
        p(P),t(T),d(D){}
}Node;
int n;
vector<int> edge[F];
bool used[F];
int belong[F];
Node line[F];
int maptt1[E][E];
bool cmp(Node a,Node b)
{
    return a.t<b.t;
}
bool dfs(int s)
{
    for(int i=0;i<edge[s].size();i++){
        int end1=edge[s].at(i);
        if(used[end1])
            continue;
        used[end1]=true;
        if(belong[end1]==-1||dfs(belong[end1])){
            belong[end1]=s;
            return true;
        }
    }
    return false;
}
int main()
{
    
    int x,y;
    while(scanf("%d%d",&x,&y),!(x==-1&&y==-1)){
        memset(maptt1,0,sizeof(maptt1));
        n=0;
        maptt1[x][y]=++n;
        for(int i=0;i<F;i++)
            edge[i].clear();
        memset(belong,-1,sizeof(belong));
        while(scanf("%d%d",&x,&y),!(!x&&!y))
            maptt1[x][y]=++n;
        for(int i=1;i<E;i++)
            for(int j=1;j<E;j++)
                if(maptt1[i][j]){
                    for(int y=j+1;y<E;y++)
                        if(maptt1[i][y]){
                            edge[maptt1[i][j]].push_back(maptt1[i][y]);
                            break;
                        }else{
                            for(int x=i+1;x<E;x++)
                                if(maptt1[x][y]){
                                    edge[maptt1[i][j]].push_back(maptt1[x][y]);
                                    break;
                                }
                        }
                    for(int x=i+1;x<E;x++)
                        if(maptt1[x][j]){
                            edge[maptt1[i][j]].push_back(maptt1[x][j]);
                            break;
                        }else{
                            for(int y=j+1;y<E;y++)
                                if(maptt1[x][y]){
                                    edge[maptt1[i][j]].push_back(maptt1[x][y]);
                                    break;
                                }
                        }
                }
        int sum=0;
        for(int i=1;i<=n;i++){
            memset(used,false,sizeof(used));
            if(dfs(i))
                ++sum;
        }
        printf("%d\n",n-sum);
    }
    return 0;
}