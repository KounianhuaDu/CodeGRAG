// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define INF 0x3f3f3f3f
#define MOD 1000000007
const int maxn = 500 + 5;
const double eps = 1e-8;
using namespace std;
bool vis[maxn];
double d[maxn];
double maps[maxn][maxn];
int dcmp(double x){
    if(fabs(x) < eps) return 0;
    if(x < 0) return -1;
    else return 1;
}
struct Point{
    double x,y;
    Point(){}
    Point(double xx, double yy):x(xx),y(yy){}
}pt[maxn][6];
struct Line{
    Point s,e;
    Line(){}
    Line(Point aa, Point bb):s(aa),e(bb){}
};
double cross(Point a, Point b, Point c){
    return  (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
}
double Line_Inter(Line l1, Line l2){
    return dcmp(cross(l2.s,l1.s,l1.e)) * dcmp(cross(l2.e,l1.s,l1.e)) < 0;
}
double getdis(Point p1, Point p2){
    double x1 = p1.x, x2 = p2.x;
    double y1 = p1.y, y2 = p2.y;
    return sqrt((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2));
}
bool check(Point p1, Point p2, int from, int to){
    if(from > to)
        return true;
    Line l1 = Line(p1,p2);
    for(int i=from; i<=to; i++){
        Line l2 = Line(pt[i][0],pt[i][1]);
        if(Line_Inter(l1, l2))
            return false;
        l2 = Line(pt[i][2],pt[i][3]);
        if(Line_Inter(l1, l2))
            return false;
        l2 = Line(pt[i][4],pt[i][5]);
        if(Line_Inter(l1, l2))
            return false;
    }
    return true;
}
int main(){
    int n;
    while(scanf("%d",&n) == 1 && n != -1){
        int ptcnt = 4*n+1;
        for(int i=0; i<=ptcnt; i++)
            for(int j=0; j<=ptcnt; j++){
                if(i == j) maps[i][j] = maps[j][i] = 0;
                else maps[i][j] = maps[j][i] = INF;
            }
        Point begin = Point(0,5);
        Point end1 = Point(10,5);
        for(int i=1; i<=n; i++){
            double x,a,b,c,d;
            scanf("%lf%lf%lf%lf%lf",&x,&a,&b,&c,&d);
            pt[i][0] = Point(x,0);
            pt[i][1] = Point(x,a);
            pt[i][2] = Point(x,b);
            pt[i][3] = Point(x,c);
            pt[i][4] = Point(x,d);
            pt[i][5] = Point(x,10);
        }
        if(check(begin,end1,1,n)){
            printf("10.00\n");
            continue;
        }
        for(int i=1; i<=n; i++){
            for(int k=1; k<=4; k++){
                if(check(begin,pt[i][k],1,i-1)){
                    double c = getdis(begin,pt[i][k]);
                    maps[0][(i-1)*4+k] = maps[(i-1)*4+k][0] = c;
                }
                if(check(end1,pt[i][k],i+1,n)){
                    double c = getdis(end1,pt[i][k]);
                    maps[4*n+1][(i-1)*4+k] = maps[(i-1)*4+k][4*n+1] = c;
                }
            }
        }
        for(int i=1; i<n; i++)
            for(int k=i+1; k<=n; k++){
                for(int p=1; p<=4; p++){
                    for(int q=1; q<=4; q++){
                        if(check(pt[i][p],pt[k][q],i+1,k-1)){
                            double c = getdis(pt[i][p],pt[k][q]);
                            maps[(i-1)*4+p][(k-1)*4+q] = maps[(k-1)*4+q][(i-1)*4+p] = c;
                        }
                    }
                }
            }
        for(int k=0; k<=ptcnt; k++)
            for(int i=0; i<=ptcnt; i++)
                for(int j=0; j<=ptcnt; j++)
                    if(maps[i][k] + maps[k][j] < maps[i][j])
                        maps[i][j] = maps[i][k] + maps[k][j];
        printf("%.2f\n",maps[0][ptcnt]);
    }
}