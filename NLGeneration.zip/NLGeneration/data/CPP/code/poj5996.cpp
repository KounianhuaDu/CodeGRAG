// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ll long long
#define rep(i, x) for(int i = 0; i < x; ++i)
#define clr(x) memset(x, 0, sizeof(x))
using namespace std;
const int MaxN = 1005;
int t, n;
int maptt1[MaxN][MaxN];
int money[MaxN];
int par[MaxN], r[MaxN];
struct Edge{
    int x, y, val;
    bool operator < (const Edge &e) const{
        return val > e.val;
    }
};
int Find(int x){
    if(x == par[x]) return x;
    return par[x] = Find(par[x]);
}
void unite(int x, int y){
    x = Find(x);
    y = Find(y);
    if(x == y)  return;
    if(r[x] < r[y]) par[x] = y;
    else{
        par[y] = x;
        if(r[x] == r[y])    ++r[x];
    }
}
bool check(int x, int y){
    return Find(x) == Find(y);
}
int main(){
    ios::sync_with_stdio(false);
    cin >> t;
    while(t--){
        priority_queue<Edge> que;
        clr(r);
        rep(i, MaxN) par[i] = i;
        cin >> n;
        rep(i, n)   cin >> money[i];
        rep(i, n){
            rep(j, n){
                cin >> maptt1[i][j];
            }
        }
        rep(i, n){
            rep(j, i){
                que.push(Edge{i, j, money[i] + money[j] + maptt1[i][j]});
            }
        }
        int ans = 0;
        while(--n){
            Edge e = que.top();
            que.pop();
            if(check(e.x, e.y)){
                ++n;
                continue;
            }
            ans += e.val;
            unite(e.x, e.y);
        }
        cout << ans << endl;
    }
    return 0;
}