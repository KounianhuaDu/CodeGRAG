// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
bool vis[2][205];     
bool maptt1[205][205];   
int asize;  
int bsize; 
bool dp[205][205];
int m,r;
void init()
{
    memset(maptt1,0,sizeof(maptt1));
    memset(dp,0,sizeof(dp));
    memset(vis,0,sizeof(vis));
}
void Input()
{
    cin>>m>>r;
    int a,b;
    while(r--)
    {
        cin>>a>>b;
        maptt1[a][b]=1;
    }
}
void DFS(int part,int id)  
{
    vis[part][id]=1;
    if(part==0)
    {
        asize++;
        for(int i=1;i<=m;i++)
        if(maptt1[id][i]&&!vis[1][i])
        DFS(1,i);
    }
    else
    {
        bsize++;
        for(int i=1;i<=m;i++)
        if(maptt1[i][id]&&!vis[0][i])
        DFS(0,i);
    }
}
void bag()
{
    dp[0][0]=true;
    for(int i=m/2;i>=asize;i--)  
    for(int j=m/2;j>=bsize;j--)  
    if(dp[i][j]||dp[i-asize][j-bsize]) dp[i][j]=true;
}
void Ouput()
{
    for(int i=m/2;i>=0;i--)
    if(dp[i][i])
    {
        cout<<i<<endl;
        break;
    }
}
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        init();
        Input();
        for(int i=1;i<=m;i++)
        if(!vis[0][i])
        {
            asize=0;
            bsize=0;
            DFS(0,i);
            bag();
        }
        for(int i=1;i<=m;i++)
        if(!vis[1][i])
        {
            asize=0;
            bsize=0;
            DFS(1,i);
            bag();
        }
        Ouput();
    }
    return 0;
}