// Dynamic Programming->Matrix Multiplication
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 5;
const int MOD = 10000;
struct Matrix
{
    int mat[maxn][maxn];
    Matrix()        
    {
        memset(mat, 0, sizeof(mat));
    }
    Matrix operator * (Matrix A)    
    {
        Matrix res;
        for (int i = 0; i < 2; i++) 
        {
            for (int j = 0; j < 2; j++)
            {
                for (int k = 0; k < 2; k++)
                    res.mat[i][j] = (res.mat[i][j] + (mat[i][k] * A.mat[k][j]) % MOD) % MOD;
            }
        }
        return res;
    }
};
Matrix pow_mul(Matrix A, int n)
{
    Matrix res;
    
    for (int i = 0; i < maxn; i++) res.mat[i][i] = 1;
    while (n)
    {
        if (n & 1) res = res * A;   
        A = A * A;
        n >>= 1;                    
    }
    return res;
}
int main()
{
    int n;
    while (~scanf("%d", &n) && n != -1)
    {
        Matrix A;
        A.mat[0][0] = A.mat[0][1] = A.mat[1][0] = 1;
        A = pow_mul(A, n);
        cout << A.mat[0][1] << endl;
    }
    return 0;
}