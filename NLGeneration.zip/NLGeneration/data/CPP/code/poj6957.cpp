// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=110,oo=1<<30;
int f[maxn][maxn],g[maxn][maxn],h[maxn][maxn],a[maxn],b[maxn],c[maxn];
int cc,i,j,k,n,m,p,ans;
int main()
{
    freopen("pin.txt","r",stdin);
    freopen("pou.txt","w",stdout);
    scanf("%d",&cc);
    while (cc--)
    {
          scanf("%d%d%d",&n,&m,&p);
          for (i=1;i<=n;i++)
              scanf("%d",&a[i]);
          for (i=1;i<=m;i++)
              scanf("%d",&b[i]);
          for (i=1;i<=p;i++)
              scanf("%d",&c[i]);
          memset(f,30,sizeof(f));
          memset(g,30,sizeof(g));
          memset(h,30,sizeof(h));
          f[n+1][0]=0;
          for (i=n;i;i--)
              for (j=1;j<=m;j++)
                  f[i][j]=min(f[i+1][j-1],min(f[i][j-1],f[i+1][j]))+abs(a[i]-b[j]);
          g[0][p+1]=0;
          for (i=1;i<=n;i++)
              for (j=p;j;j--)
                  g[i][j]=min(g[i-1][j+1],min(g[i-1][j],g[i][j+1]))+abs(a[i]-c[j]);
          h[0][m+1]=0;
          for (i=1;i<=p;i++)
              for (j=m;j;j--)
                  h[i][j]=min(h[i-1][j+1],min(h[i][j+1],h[i-1][j]))+abs(c[i]-b[j]); 
          ans=oo;
          for (i=0;i<=n;i++)
              for (j=0;j<=m;j++)
                  for (k=0;k<=p;k++)
                  {
                      ans=min(ans,f[i][j]+g[i][k]+h[k][j]);
                      ans=min(ans,f[i][j]+g[i][k]+h[k][j+1]);
                      ans=min(ans,f[i+1][j]+g[i][k]+h[k][j]);
                      ans=min(ans,f[i][j]+g[i][k+1]+h[k][j]);
                      ans=min(ans,f[i+1][j]+g[i][k]+h[k][j+1]);
                      ans=min(ans,f[i][j]+g[i][k+1]+h[k][j+1]);
                      ans=min(ans,f[i+1][j]+g[i][k+1]+h[k][j]);
                      ans=min(ans,f[i+1][j]+g[i][k+1]+h[k][j+1]);
                  } 
          cout << ans << endl;
          getchar();
          if (cc) getchar();
    }
    return 0;
}