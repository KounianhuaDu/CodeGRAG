// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int a1[110],a2[110],a3[110];
int dp1[110][110],dp2[110][110],dp3[110][110];
int  main()
{
    int cas;
    cin>>cas;
    while(cas--){
        memset(dp1,0x3f3f,sizeof(dp1));
        memset(dp2,0x3f3f,sizeof(dp2));
        memset(dp3,0x3f3f,sizeof(dp3));
        int n,m,k;
        cin>>n>>m>>k;
        for(int i=1;i<=n;i++)
            scanf("%d ",&a1[i]);
        for(int i=1;i<=m;i++)
            scanf("%d",&a2[i]);
        for(int i=1;i<=k;i++)
            scanf("%d",&a3[i]);
        dp1[0][k+1]=dp2[n+1][0]=dp3[0][m+1]=0;
        for(int i=1;i<=n;i++)
            for(int j=k;j>0;j--)
            dp1[i][j]=min(dp1[i-1][j+1],min(dp1[i-1][j],dp1[i][j+1]))+fabs(a1[i]-a3[j]);
        for(int i=n;i>0;i--)
            for(int j=1;j<=m;j++)
            dp2[i][j]=min(dp2[i+1][j-1],min(dp2[i+1][j],dp2[i][j-1]))+fabs(a1[i]-a2[j]);
        for(int i=1;i<=k;i++)
            for(int j=m;j>0;j--)
            dp3[i][j]=min(dp3[i-1][j+1],min(dp3[i-1][j],dp3[i][j+1]))+fabs(a3[i]-a2[j]);
        int ans=1e9;
        for(int i=1;i<=n;i++)
            for(int j=1;j<=k;j++){
                for(int p=1;p<=m;p++){
                    int tem1,tem2;
                    tem1=min(dp2[i][p],dp2[i+1][p]);
                    tem2=min(min(dp3[j][p],dp3[j-1][p]),min(dp3[j][p+1],dp3[j-1][p+1]));
                    ans=min(ans,dp1[i][j]+tem1+tem2);
                }
            }
        for(int i=1;i<=n;i++)
            ans=min(ans,dp1[i][1]+min(dp2[i][m],dp2[i+1][m]));
        for(int i=1;i<=m;i++)
            ans=min(ans,dp2[1][i]+min(dp3[k][i],dp3[k][i+1]));
        for(int i=1;i<=k;i++)
            ans=min(ans,dp1[n][i]+min(dp3[i][1],dp3[i-1][1]));
        cout<<ans<<endl;
    }
    return 0;
}