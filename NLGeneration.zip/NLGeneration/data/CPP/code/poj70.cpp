// Sorting->Bubble Sort
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

struct Ron
{
	char c[101];
    int Rev;
};
Ron ron[101] = { 0,0 };
Ron temp = { 0,0 };
int main()
{
	int m,n,i,j,k;
	scanf("%d%d", &m, &n);
	for (i = 0; i < n; i++)
	{
		scanf("%s", ron[i].c);
		for (j = 0; j < m; j++)  
		{
			for (k = j; k < m; k++)
			{
				if (ron[i].c[j] > ron[i].c[k])
				{
					ron[i].Rev++;
				}
			}
		}
	}
	
	for (i = 0; i < n; i++) 
	{
		for (j = i + 1; j < n; j++)
		{
			if (ron[i].Rev > ron[j].Rev)
			{
				temp = ron[i];
				ron[i] = ron[j];
				ron[j] = temp;
			}
		}
	}
	for (i = 0; i < n; i++)
	{
		printf("%s\n", ron[i].c);
	}
}