// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define Pr pair<int,int>
#define fread() freopen("in.in","r",stdin)
#define fwrite() freopen("out.out","w",stdout)
using namespace std;
const int INF = 0x3f3f3f3f;
const int msz = 10000;
const int mod = 1e9+7;
const double eps = 1e-8;
struct Range
{
	int x1,y1,x2,y2,c;
	bool f;
	bool operator < (const struct Range r)const
	{
		return x1 == r.x1? y1 < r.y1: x1 < r.x1;
	}
};
Range rg[33];
bool mp[111][111];
int n,mn;
void col(int pos)
{
	for(int i = rg[pos].y1; i <= rg[pos].y2; ++i)
		mp[rg[pos].x2][i] = 1;
}
bool can(int pos)
{
	if(rg[pos].x1 == 0) return true;
	for(int i = rg[pos].y1; i <= rg[pos].y2; ++i)
		if(!mp[rg[pos].x1][i]) return false;
	return true;
}
bool cal(int c,int *tmp,int &tp)
{
	tp = 0;
	for(int i = 0; i < n; ++i)
	{
		if(rg[i].f || rg[i].c != c) continue;
		if(can(i))
		{
			rg[i].f = 1;
			tmp[tp++] = i;
			col(i);
		}
	}
	return tp != 0;
}
void reset(int *tmp,int tp)
{
	for(int i = 0; i < tp; ++i)
	{
		rg[tmp[i]].f = 0;
		for(int j = rg[tmp[i]].y1; j <= rg[tmp[i]].y2; ++j)
			mp[rg[tmp[i]].x2][j] = 0;
	}
}
void dfs(int ok,int us)
{
	if(ok == n)
	{
		mn = min(mn,us);
		return;
	}
	int tmp[33];
	int tp;
	for(int i = 1; i <= 20; ++i)
	{
		if(!cal(i,tmp,tp)) continue;
		
		dfs(ok+tp,us+1);
		reset(tmp,tp);
	}
}
int main()
{
	
	
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(int i = 0; i < n; ++i)
		{
			scanf("%d%d%d%d%d",&rg[i].x1,&rg[i].y1,&rg[i].x2,&rg[i].y2,&rg[i].c);
			rg[i].f = 0;
		}
		sort(rg,rg+n);
		mn = INF;
		memset(mp,0,sizeof(mp));
		dfs(0,0);
		printf("%d\n",mn);
	}
	return 0;
}