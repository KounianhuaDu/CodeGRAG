// Data Structure->Suffix Automata (SAM)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define rep(i,j,k) for(int i = j;i <= k;++i)
#define repp(i,j,k) for(int i = j;i >= k;--i)
#define rept(i,x) for(int i = linkk[x];i;i = e[i].n)
#define P pair<int,int>
#define Pil pair<int,ll>
#define Pli pair<ll,int>
#define Pll pair<ll,ll>
#define pb push_back 
#define pc putchar
#define mp make_pair
#define file(k) memset(k,0,sizeof(k))
#define ll long long
char s[101000];
int tr[201000][26] , par[201000] , mx[201000] , cnt , last , R[201000];
int dep[201000];
int read()
{
    int sum = 0;char c = getchar();bool flag = true;
    while( c < '0' || c > '9' ) {if(c == '-') flag = false;c = getchar();}
    while( c >= '0' && c <= '9' ) sum = sum * 10 + c - 48 , c = getchar();
    if(flag)  return sum;
     else return -sum;
}  
void extand(int x)
{
    int np = ++cnt , p = last;R[np] = 1;
    mx[np] = mx[p] + 1;last = np;
    while(p && !tr[p][x]) tr[p][x] = np , p = par[p];
    if(!p) par[np] = 1;
    else
    {
        int q = tr[p][x];
        if(mx[q] == mx[p] + 1) par[np] = q;
        else
        {
            int nq = ++cnt;mx[nq] = mx[p] + 1;
            rep(i,0,25) tr[nq][i] = tr[q][i];
            par[nq] = par[q];par[q] = par[np] = nq;
            while(p && tr[p][x] == q) tr[p][x] = nq , p = par[p];
        }
    }
}
queue<int>q;
bool vis[201000];
int main()
{
    scanf("%s",s+1);
    int len = strlen(s+1);cnt = last = 1;
    rep(i,1,len) extand(s[i]-'a');
    scanf("%s",s+1);
    len = strlen(s+1);
    int now = 1;int ans = 0;
    int sum = 0;
    rep(i,1,len)
    {
        int x = s[i] - 'a';
        if(tr[now][x]) sum++ , now = tr[now][x];
        else
        {
            while(now != 1 && !tr[now][x]) now = par[now];
            if(!tr[now][x]) sum = 0;
            else if(tr[now][x]) sum = mx[now] + 1 , now = tr[now][x];
        }
        ans = max(ans,sum);
    }
    printf("%d\n",ans);
    return 0;
}