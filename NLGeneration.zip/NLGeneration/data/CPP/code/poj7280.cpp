// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

const int N = 40005, M = N * 2;
#define adj(i,j) for(int i=h[j];i;i=p[i])if(v[i]!=fa&&!vis[v[i]])
using namespace std;
int h[N], p[M], w[M], v[M], cnt = 0;
int n, k, vis[N], ans, rt, c;
void add(int a, int b, int c) {
    v[++cnt] = b; w[cnt] = c; p[cnt] = h[a]; h[a] = cnt;
}
int mx[N], sz[N], mi, dis[N];
void dfssize(int x, int fa) {
    sz[x] = 1; mx[x] = 0;
    adj(i,x) {
        dfssize(v[i], x);
        sz[x] += sz[v[i]];
        if (sz[v[i]] > mx[x]) mx[x] = sz[v[i]];
    }
}
void dfsrt(int r, int x, int fa) {
    if (sz[r] - sz[x] > mx[x]) mx[x] = sz[r] - sz[x];
    if (mx[x] < mi) mi = mx[x], rt = x;
    adj(i,x) dfsrt(r, v[i], x);
}
void dfsdis(int x, int d, int fa) {
    dis[c++] = d;
    adj(i,x) dfsdis(v[i], d + w[i], x);
}
int calc(int x, int d) {
    int ans = 0;
    c = 0;
    dfsdis(x, d, 0);
    sort(dis, dis + c);
    for (int i = 0, j = c - 1; i < j; ++i) {
        for (; dis[i] + dis[j] > k && i < j; --j);
        ans += j - i;
    }
    return ans;
}
void dfs(int x) {
    int fa = 0;
    mi = n;
    dfssize(x, fa); dfsrt(x, x, fa);
    ans += calc(rt, 0);
    vis[rt] = 1;
    adj(i, rt) {
        ans -= calc(v[i], w[i]);
        dfs(v[i]);
    }
}
int main() {
    int u, v, w, i, m; char redundancy[8];
    while(scanf("%d%d", &n, &m) != EOF && (n || k)) {
        memset(vis, 0, sizeof vis);
        memset(h, 0, sizeof h);
        cnt = ans = 0;
        for (i = 0; i < m; i++) {
            scanf("%d%d%d%s", &u, &v, &w, redundancy);
            add(u, v, w); add(v, u, w);
        }
        scanf("%d", &k);
        dfs(1);
        printf("%d\n", ans);
    }
    return 0;
}