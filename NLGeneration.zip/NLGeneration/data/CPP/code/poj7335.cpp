// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=1010;
int vis[maxn],match[maxn],g[maxn][maxn];
int r,c;
bool dfs(int k )
{
    for( int i = 1; i <= c; ++ i )
    {
        if( g[k][i] && !vis[i] )
        {
            vis[i] = true;
            if( match[i] == -1 || dfs(match[i]) )
            {
                match[i] = k;
                return true;
            }    
        }    
    }        
    return false;
}
int Hungary()
{
	    int all = 0;
	    memset(match,-1,sizeof(match));
        for( int i = 1; i <= r; ++ i )
        {
            memset(vis,0,sizeof(vis));
            if( dfs(i) ) 
			all++;
        } 
		return all;   
}
int main()
{
  int x,u,v;
  scanf("%d",&x);
  while(x--)
  {
       scanf("%d%d",&r,&c);
        memset(g,0,sizeof(g));
        for( int i = 1; i <= c; ++ i )
        {
            scanf("%d%d",&u,&v);
            g[u][i] =g[v][i] = 1; 
        }    
        if(r>c)
        {
               printf("NO\n");
               continue;
        }
        int ans=Hungary();
        if( ans == r )
        {
            for( int i = 1; i <= c; ++ i )
                if( match[i] != -1 )  
				printf("%d ",match[i]);
                else
                {
                   for( int j = 1; j <= r; ++ j )
                     if( g[j][i] != 0 )
					{
						printf("*");
						printf("%d ",j); 
						break ;
					} 
                }    
            printf("\n");
        }    
        else printf("NO\n");
  }	
  return 0;
}