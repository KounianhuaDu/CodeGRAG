// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Prune and Search,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define Lson(p) (p<<1)
#define Rson(p) (p<<1|1)
#define Min(a,b) ((a+b)>>1)
#define lowbit(x) (x&(-x))
#define PI acos(-1.0)
#define Max(a,b) (a)>(b)?(a):(b)
#define Minn(a,b) (a)<(b)?(a):(b)
#define Inf 100000010
#define Maxx 110
using namespace std;
typedef struct Point{
	int index;
	int len;
	int cost;
	struct Point *next;
}point,*ppoint;
struct Node{
	ppoint first;
}node[Maxx];
bool vis[Maxx];
int k,n,r;
int s,d,l,t;
int ans;
void add_edge(){
	for(int i=1;i<=n;i++)
		node[i].first=NULL;
	for(int i=0;i<r;i++){
		scanf("%d%d%d%d",&s,&d,&l,&t);
		ppoint temp=(ppoint)malloc(sizeof(point));
		temp->index=d;
		temp->len=l;
		temp->cost=t;
		temp->next=node[s].first;
		node[s].first=temp;
	}
}
void dfs(int index,int tlen,int tsum){
	if(index==n){
		ans=tlen;
		return ;
	}
	ppoint temp=node[index].first;
	while(temp){
		if(!vis[temp->index] && temp->len+tlen<ans && temp->cost+tsum<=k){ 
			vis[temp->index]=true;
			dfs(temp->index,temp->len+tlen,temp->cost+tsum);
			vis[temp->index]=false; 
		}
		temp=temp->next;
	}
}
int main(){
	scanf("%d%d%d",&k,&n,&r);
    add_edge();
	memset(vis,0,sizeof(vis));
	vis[1]=true;
	ans=Inf;
	dfs(1,0,0);
	if(ans==Inf) 
		printf("-1\n");
	else 
		printf("%d\n",ans); 
	return 0;
}