// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
struct cs{
    int x,y,z;
}F[1000001];
int fa[1000001],c[100001][5];
int ff,n,m,x,y,z,nn,xx,yy,xxx,yyy;
string s;
bool cmp(cs x,cs y){return x.z<y.z;}
int get(int x){
    if(fa[x]==x)return x;
    fa[x]=get(fa[x]);
    return fa[x];
}
void merge(int x,int y){fa[get(x)]=get(y);}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        cin>>s;
        c[i][1]=x;
        c[i][2]=y;
        if(s=="odd")c[i][3]=1;
        F[++ff].z=x;F[ff].x=i;F[ff].y=1;
        F[++ff].z=y;F[ff].x=i;F[ff].y=2;
    }
    sort(F+1,F+ff+1,cmp);
    for(int i=1;i<=ff;i++){
        if(F[i].z!=F[i-1].z){
            nn++;
            if(F[i].z!=F[i-1].z+1)nn++;
        }
        c[F[i].x][F[i].y]=nn;
    }
    for(int i=1;i<=nn*2+2;i++)fa[i]=i;
    for(int i=1;i<=m;i++){
        x=c[i][1];
        y=c[i][2];
        z=c[i][3];
        xx=get(x-1);
        yy=get(y);
        xxx=get(x-1+nn+1);
        
        yyy=get(y+nn+1);
        if(z)if(xx==yy||xxx==yyy){printf("%d",i-1);return 0;}else merge(xxx,yy),merge(yyy,xx);
        if(!z)if(xx==yyy||yy==xxx){printf("%d",i-1);return 0;}else merge(xx,yy),merge(xxx,yyy);
    }
    printf("%d",m);
}