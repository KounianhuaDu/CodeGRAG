// Basic Algorithm->Discretization,Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 10005;
int pa[N], n, q, cnt, rel[N], l[N], r[N];
char str[N][10];
map<int, int> mp;
int get_parent(int x) {
    if (pa[x] != x) {
        int px = get_parent(pa[x]);
        rel[x] = (rel[x] + rel[pa[x]]) % 2;
        pa[x] = px;
    }
    return pa[x];
}
int main() {
    while (scanf("%d", &n) == 1) {
        scanf("%d", &q);
        mp.clear();
        cnt = 1;
        for (int i = 1; i <= q; i++) {
            scanf("%d%d%s", &l[i], &r[i], str[i]);
            if (!mp[l[i] - 1])
                mp[l[i] - 1] = cnt++;
            if (!mp[r[i]])
                mp[r[i]] = cnt++;
        }
        for (int i = 0; i <= cnt; i++) {
            pa[i] = i;
            rel[i] = 0;
        }
        int res = -1;
        for (int i = 1; i <= q; i++) {
            int flag = str[i][0] == 'e' ? 0 : 1;
            int px = get_parent(mp[l[i] - 1]);
            int py = get_parent(mp[r[i]]);
            if (px != py) {
                if (px < py) {
                    pa[px] = py;
                    rel[px] = (flag + rel[mp[r[i]]] - rel[mp[l[i] - 1]] + 2) % 2;
                }
                else {
                    pa[py] = px;
                    rel[py] = (rel[mp[l[i] - 1]] - flag - rel[mp[r[i]]] + 4) % 2;
                }
            }
            else {
                if ((rel[mp[l[i] - 1]] - rel[mp[r[i]]] + 2) % 2 != flag) {
                    res = i - 1;
                    break;
                }
            }
        }
        if (res == -1)
            res = q;
        printf("%d\n", res);
    }
    return 0;
}