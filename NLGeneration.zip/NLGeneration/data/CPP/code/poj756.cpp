// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define LL long long
#define Pr pair<int,int>
#define fread() freopen("in.in","r",stdin)
#define fwrite() freopen("out.out","w",stdout)
using namespace std;
const int INF = 0x3f3f3f3f;
const int msz = 10000;
const int mod = 1e9+7;
const double eps = 1e-8;
int mp[12][33][33];
int dp[12][33][33];
int tmp[33][33];
int dirx[] = { 1, 1,-1,-1};
int diry[] = { 1,-1, 1,-1};
int d,n;
int dis(int x1,int y1,int x2,int y2)
{
	return (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
}
void cal(int t,int x,int y)
{
	int xx,yy;
	for(int i = 0; i <= d; ++i)
		for(int j = 0; j <= d; ++j)
		{
			if(!i && !j)
			{
				dp[t][x][y] += mp[t][x][y];
				tmp[x][y] = dp[t][x][y];
				dp[t+1][x][y] = max(dp[t+1][x][y],dp[t][x][y]);
				
				continue;
			}
			if(dis(x,y,x+i,y+j) > d*d) continue;
			for(int k = 0; k < 4; ++k)
			{
				if(!i && dirx[k] < 0) continue;
				xx = x+i*dirx[k];
				if(!j && diry[k] < 0) continue;
				yy = y+j*diry[k];
				if(xx < 0 || xx >= n || yy < 0 || yy >= n) continue;
				int g = __gcd(abs(xx-x),abs(yy-y));
				tmp[xx][yy] = tmp[xx+(x-xx)/g][yy+(y-yy)/g]+mp[t][xx][yy];
				dp[t+1][xx][yy] =  max(dp[t+1][xx][yy],tmp[xx][yy]);
				
			}
		}
}
int main()
{
	
	
	int m,x,y,t;
	while(~scanf("%d%d%d",&n,&d,&m) && (n+d+m))
	{
		memset(mp,0,sizeof(mp));
		memset(dp,0,sizeof(dp));
		int tim = 0;
		n += 10;
		while(m--)
		{
			scanf("%d%d%d",&x,&y,&t);
			mp[t][x+5][y+5] = 1;
			tim = max(tim,t);
		}
		for(int i = 1; i <= tim; ++i)
			for(int j = 0; j < n; ++j)
				for(int k = 0; k < n; ++k)
					cal(i,j,k);
		int mx = 0;
		for(int i = 0; i < n; ++i)
			for(int j = 0; j < n; ++j)
				mx = max(mx,dp[tim+1][i][j]);
		printf("%d\n",mx);
	}
	return 0;
}