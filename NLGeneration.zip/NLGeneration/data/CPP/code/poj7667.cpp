// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
unsigned short qState[65535];
int step[65535];
bool flag[65535];
int top = 0;
int rear = 0;
void Init()
{
	char c;
	unsigned short temp = 0;
	for(int i = 0; i < 4; i++)
	{
		for(int j = 0; j < 4; j++)
		{
			cin>>c;
			if(c == 'b')
				temp |= (1<<(i*4+j));
		}
	}
	qState[rear++] = temp;
	flag[temp] = true;
}
unsigned short move(unsigned short state, int i)
{
	unsigned short temp = 0;
	temp |= (1<<i);
	
	if((i) % 4 != 0)
		temp |= (1<<(i-1));
	if((i+1) % 4 != 0)
		temp |= (1<<(i+1));
	if(i-4 >=0)
		temp |= (1<<(i-4));
	if(i+4 < 16)
		temp |= (1<<(i+4));
	return (state^temp);
}
bool BFS()
{
	while( top < rear)
	{
		unsigned short state = qState[top++];
		for(int  i = 0; i < 16; i++)
		{
			unsigned short temp = move(state, i);
			if(0 == state || 65535 == state)
			{
				cout<<step[state];
				return true;
			}
			else if(!flag[temp])
			{
				qState[rear++] = temp;
				flag[temp] = true;
				step[temp] = step[state] + 1;
			}
		}
	}
	return false;
}
int main()
{
	Init();
	if(!BFS())
		cout<<"Impossible";
	cout<<endl;
	return 0;
}