// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 210
#define PB push_back
#define Clear(x) memset(x,0,sizeof(x))
using namespace std;
int n,m,a[maxn],vis[maxn],f[maxn][2];
bool b[2000020];
vector<int>g[maxn];
void dfs(int u){
	vis[u]=1;
	for(int i=0;i<g[u].size();i++){
		int v=g[u][i];
		if(vis[v])continue;
		dfs(v);
		f[u][0]+=max(f[v][1],f[v][0]);
		f[u][1]+=f[v][0];
	}
	f[u][1]+=a[u];
}
int main(){
	while(scanf("%d%d",&n,&m)!=EOF&&m+n){
		Clear(a);Clear(f);Clear(b);Clear(vis);
		for(int i=1;i<=n;i++)g[i].clear();
		for(int i=1;i<=n;i++)scanf("%d",a+i);
		for(int x,i=1;i<=m;i++){
			scanf("%d",&x);
			b[x]=true;
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(i==j)continue;
				if(b[abs(a[i]-a[j])])
					g[i].PB(j);
			}
		}
		int ans=0;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				dfs(i);
				ans+=max(f[i][0],f[i][1]);
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}