// Data Structure->Spanning Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=2010,inf=~0U>>1;
char s[maxn][10];
int dist[maxn][maxn],d[maxn],vis[maxn];
int n,ans;
void Build_Graph()
{
	memset(dist,0,sizeof(dist));
	for (int i=1;i<=n;i++)
	for (int j=1;j<=n;j++)
	for (int k=0;k<7;k++)
	dist[i][j]+=s[i][k]!=s[j][k];
}
void Prim()
{
	memset(vis,0,sizeof(vis));
	for (int i=0;i<=n;i++) d[i]=inf;
	int now=1;d[now]=0;
	for (int time=1;time<n;time++)
	{
		vis[now]=1;
		for (int i=1;i<=n;i++) if (!vis[i] && d[i]>dist[now][i]) d[i]=dist[now][i];
		now=0;
		for (int i=1;i<=n;i++) if (!vis[i] && d[i]<d[now]) now=i;
	}
	int ans=0;
	for (int i=1;i<=n;i++) ans+=d[i];
	printf("The highest possible quality is 1/%d.\n",ans);
}
int main()
{
	while (scanf("%d",&n) && n)
	{
		for (int i=1;i<=n;i++) scanf("%s",s[i]);
		Build_Graph();
		Prim();
	}
	return 0;
}