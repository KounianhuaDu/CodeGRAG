// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int n,st,en;
struct edge {
	int v,f,next;
}e[90000];
int head[410],cnt;
int b[210][210],a[210][210];
int gap[410],h[410];
int pr[210],hehe;
int read_int () {
	char c = getchar();
	int re = 0;
	for(;c > '9' || c < '0';c = getchar());
	for(;c >= '0' && c <= '9';c = getchar())
		re = re * 10 + c - '0';
	return re;
}
void adde (int u,int v,int f) {
	e[cnt].v = v;
	e[cnt].f = f;
	e[cnt].next = head[u];
	head[u] = cnt++;
	e[cnt].v = u;
	e[cnt].f = 0;
	e[cnt].next = head[v];
	head[v] = cnt++;
}
int dfs (int u,int minf) {
	if(u == en + n)
		return minf;
	int chan = n + n - 1;
	int leftf = minf;
	for(int i = head[u];i != -1;i = e[i].next) {
		int v = e[i].v;
		if(e[i].f) {
			if(h[v] == h[u] - 1) {
				int t = dfs(v,min(leftf,e[i].f));
				e[i].f -= t;
				e[i ^ 1].f += t;
				leftf -= t;
				if(h[st] >= n + n)
					return minf - leftf;
				if(!leftf)
					break;
			}
			chan = min(chan,h[v]);
		}
	}
	if(leftf == minf) {
		if(--gap[h[u]] == 0)
			h[st] = n + n;
		++gap[h[u] = chan + 1];
	}
	return minf - leftf;
}
int sap () {
	int re = 0;
	while(h[st] < n + n)
		re += dfs(st,0x3f3f3f3f);
	return re;
}
void build () {
	memset(head,-1,sizeof head);
	cnt = 0;
	for(int i = 1;i <= n;++i)
		for(int j = 1;j <= n;++j) {
			if(j > i && a[i][j]) {
				adde(i + n,j,0x3f3f3f3f);
				adde(j + n,i,0x3f3f3f3f);
			}
		}
	for(int i = 1;i <= n;++i) {
		if(i != st && i != en)
			adde(i,i + n,1);
	}
	adde(st,st + n,0x3f3f3f3f);
	adde(en,en + n,0x3f3f3f3f);
}
int main () {
	n = read_int();
	st = read_int();
	en = read_int();
	for(int i = 1;i <= n;++i)
		for(int j = 1;j <= n;++j) {
			b[i][j] = a[i][j] = read_int();
		}
	build();
	gap[0] = n + n;
	int sta = sap();
	if(sta < 0x3f3f3f3f)
		printf("%d\n",sta);
	else {
		printf("NO ANSWER!\n");
		return 0;
	}
	int tot = n + n;
	for(int i = 1;i <= n;++i) {
		if(i != st && i != en) {
			memset(gap,0,sizeof gap);
			memset(h,0,sizeof h);
			gap[0] = --(--tot);
			for(int j = 1;j <= n;++j)
				a[i][j] = a[j][i] = 0;
			build();
			int t = sap();
			if(t < sta) {
				pr[++hehe] = i;
				sta = t;
				for(int j = 1;j <= n;++j) {
					b[i][j] = a[i][j];
					b[j][i] = a[j][i];
				}
			}
			else {
				++(++tot);
				for(int j = 1;j <= n;++j) {
					a[i][j] = b[i][j];
					a[j][i] = b[j][i];
				}
			}
		}
	}
	if(hehe >= 1) {
		printf("%d",pr[1]);
		for(int i = 2;i <= hehe;++i)
			printf(" %d",pr[i]);
		printf("\n");
	}
	return 0;
}