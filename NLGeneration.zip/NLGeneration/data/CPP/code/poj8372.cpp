// Data Structure->Segment Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define ls (o<<1)
#define rs (o<<1|1)
using namespace std;
const int N = 16005;
struct Node {
    int maxl, maxr, maxv;
    int cover; 
    void calc(int L, int R) {
        if(cover == 1) 
            maxl = maxr = maxv = 0;
        else if(cover == 0) 
            maxl = maxr = maxv = (R-L+1);
    }
} node[N<<2];
void pushUp(int o, int L, int R) {
    int M = (L+R)/2;
    int lenL = (M-L+1), lenR = (R-M);
    if(node[ls].maxl == lenL) node[o].maxl = node[ls].maxv + node[rs].maxl;
    else node[o].maxl = node[ls].maxl;
    if(node[rs].maxr == lenR) node[o].maxr = node[rs].maxv + node[ls].maxr;
    else node[o].maxr = node[rs].maxr;
    node[o].maxv = (node[ls].maxr + node[rs].maxl);
    node[o].maxv = max(node[o].maxv, max(node[ls].maxv, node[rs].maxv));
    if(node[ls].cover == node[rs].cover)
        node[o].cover = node[ls].cover;
    else
        node[o].cover = -1;
}
void pushDown(int o, int L, int R) {
    if(node[o].cover == -1) return;
    node[ls].cover = node[rs].cover = node[o].cover;
    node[o].cover = -1;
    int M = (L+R)/2;
    node[ls].calc(L, M);
    node[rs].calc(M+1, R);
}
void build(int o, int L, int R) {
    if(L == R) {
        node[o].cover = 0;
        node[o].calc(L, R);
        return ;
    }
    int M = (L+R)/2;
    build(ls, L, M);
    build(rs, M+1, R);
    pushUp(o, L, R);
}
int ql, qr, op;
void modify(int o, int L, int R) {
    if(ql <= L && R <= qr) {
        if(op == 1) node[o].cover = 1;
        else node[o].cover = 0;
        node[o].calc(L, R);
        return ;
    }
    pushDown(o, L, R);
    int M = (L+R)/2;
    if(ql <= M) modify(ls, L, M);
    if(qr > M) modify(rs, M+1, R);
    pushUp(o, L, R);
}
int n, m;
int main() {
    
    while(scanf("%d%d", &n, &m) != EOF) {
        build(1, 1, n);
        int x, y;
        while(m--) {
            scanf("%d", &op);
            if(op == 1 || op == 2) {
                scanf("%d%d", &x, &y);
                ql = x, qr = x+y-1;
                modify(1, 1, n);
            }else {
                printf("%d\n", node[1].maxv);
            }
        }
    }
    return 0;
}