// Basic Algorithm->Greedy Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define M (t[k].l+t[k].r)/2
#define lson k*2
#define rson k*2+1
using namespace std;
struct mon
{
    int need;
    int strength;
}a[50005];
int cmp(mon x,mon y)
{
    if(x.strength!=y.strength)
        return x.strength>y.strength;
    return x.need>y.need;
}
int vis[50005];
int main()
{
    int i,j,k,n,m,tag;
    long long s;
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        if(n==0&&m==0)
            break;
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i].need);
        }
        for(i=0;i<n;i++)
        {
            scanf("%d",&a[i].strength);
        }
        memset(vis,0,sizeof(vis));
        sort(a,a+n,cmp);
        s=0;
        for(i=0;i<n;i++)
        {
            tag=0;
            for(j=a[i].need;j>=1;j--)
            {
                if(!vis[j])
                {
                    tag=1;
                    vis[j]=1;
                    break;
                }
            }
            if(!tag)
            {
                s+=a[i].strength;
            }
        }
        printf("%lld\n",s);
    }
    return 0;
}