// Data Structure->Disjoint Set Union (DSU)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=16050;
int fa[N],rankk[N];
struct node
{
    int num,x,y;
}pos[N];
void init()
{
    for(int i=0;i<N;i++)
        fa[i]=i;
}
bool cmp1(const node &a, const node &b)
{
    if(a.x==b.x) return a.y<b.y;
    else return a.x<b.x;
}
bool cmp2(const node &a, const node &b)
{
    if(a.y==b.y) return a.x<b.x;
    else return a.y<b.y;
}
bool cmp3(const int a,const int b)
{
    return a>b;
}
int findd(int x)
{
    if(x==fa[x]) return x;
    else return fa[x]=findd(fa[x]);
}
void unite(int x,int y)
{
    x=findd(x);
    y=findd(y);
    if(x==y) return ;
    else fa[x]=y;
}
int main()
{
    
    memset(rankk,0,sizeof(rankk));
    int n,m;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
    {
        scanf("%d%d",&pos[i].x,&pos[i].y);
        pos[i].num=i+1;
    }
    init();
    sort(pos,pos+n,cmp1);
    for(int i=0;i<n-1;i++)
    {
        if(pos[i].x==pos[i+1].x&&pos[i].y==pos[i+1].y-1)
        {
            unite(pos[i].num,pos[i+1].num);
        }
    }
    sort(pos,pos+n,cmp2);
    for(int i=0;i<n-1;i++)
    {
        if(pos[i].y==pos[i+1].y&&pos[i].x==pos[i+1].x-1)
        {
            unite(pos[i].num,pos[i+1].num);
        }
    }
    for(int i=0;i<=n;i++)
    {
        fa[i]=findd(i);
    }
    for(int i=0;i<N;i++)
    {
        rankk[fa[i]]++;
    }
    sort(rankk,rankk+n+1,cmp3);
    int ans=0;
    for(int i=0;i<m;i++)
    {
        ans+=rankk[i];
    }
    printf("%d\n",ans);
    return 0;
}