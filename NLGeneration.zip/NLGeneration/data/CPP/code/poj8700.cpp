// Basic Algorithm->Depth First Search (DFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define N 1005
char a[N][N];
int n,m;
int minx,maxx,miny,maxy;
int temp;
void dfs(int x,int y)
{
    a[x][y]='.';
    temp++;
    int i,j;
    minx=min(minx,x);
    maxx=max(maxx,x);
    miny=min(miny,y);
    maxy=max(maxy,y);
    for(i=-1;i<=1;i++)
        for(j=-1;j<=1;j++)
    {
        int xx=x+i;
        int yy=y+j;
        if(xx>=0&&xx<n&&yy>=0&&yy<m&&a[xx][yy]=='#')
            dfs(xx,yy);
    }
}
int main()
{
    int i,j;
    while(scanf("%d%d",&n,&m),n+m)
    {
        for(i=0;i<n;i++)
            scanf("%s",a[i]);
        int ans=0,flag=0;
        for(i=0;i<n;i++)
            for(j=0;j<m;j++)
            if(a[i][j]=='#')
            {
                minx=maxx=i;
                miny=maxy=j;
                temp=0;
                dfs(i,j);
                if(temp==(maxx-minx+1)*(maxy-miny+1))
                   ans++;
                   else
                {
                    flag=1;
                    i=n;
                    j=m;
                }
            }
            if(flag)
                printf("Bad placement.\n");
            else
                printf("There are %d ships.\n",ans);
    }
    return 0;
}