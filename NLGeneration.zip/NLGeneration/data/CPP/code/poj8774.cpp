// Graph Algorithm->Maximum Flow Algorithm,Basic Algorithm->Breadth First Search (BFS),Graph Algorithm->Dinic's Algorithm,Basic Algorithm->Recursion,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#pragma comment (linker,"/STACK:102400000,102400000")
#define mem(a,b) memset(a,b,sizeof(a));
#define pi acos(-1.0);
#define eps 1e-6
#define ll long long
#define maxx 100000
#define inf 0x3f3f3f3f
using namespace std;
struct Edge
{
    int u,v,cap,next;
}edge[maxx];
int n,d,dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
int head[maxx],level[maxx],cur[maxx];
int num,cnt,all;
char mapp[30][30];
int Mapp[30][30];
int Num[30][30];
void init()
{
    cnt=0;
    num=0;
    all=0;
    mem(head,-1);
}
void add_edge(int u,int v,int w)
{
    edge[num].u=u;
    edge[num].v=v;
    edge[num].cap=w;
    edge[num].next=head[u];
    head[u]=num++;
    edge[num].u=v;
    edge[num].v=u;
    edge[num].cap=0;
    edge[num].next=head[v];
    head[v]=num++;
}
int bfs(int s,int t)
{
    mem(level,0);
    queue<int >q;
    level[s]=1;
    q.push(s);
    while(!q.empty())
    {
        int u=q.front();
        q.pop();
        for(int i=head[u];i!=-1;i=edge[i].next)
        {
            int v=edge[i].v;
            if(level[v]==0&&edge[i].cap>0)
            {
                level[v]=level[u]+1;
                q.push(v);
            }
        }
    }return level[t]!=0;
}
int dfs(int u,int t,int f)
{
    if(u==t) return f;
    for(int &i=cur[u];i!=-1;i=edge[i].next)
    {
        int v=edge[i].v;
        if(edge[i].cap>0&&level[v]==level[u]+1)
        {
            int d=dfs(v,t,min(f,edge[i].cap));
            if(d>0)
            {
                edge[i].cap-=d;
                edge[i^1].cap+=d;
                return d;
            }
        }
    }return 0;
}
int dinic(int s,int t,int cnt)
{
    int flow=0;
    while(bfs(s,t))
    {
        for(int i=0;i<=cnt;i++) cur[i]=head[i];
        int f;
        while((f=dfs(s,t,inf))>0)
            flow+=f;
    }
    return flow;
}
int main()
{
    int t;
    scanf("%d",&t);
    for(int T=1;T<=t;T++)
    {
        init();
        int len;
        scanf("%d%d",&n,&d);
        for(int i=0;i<n;i++)
        {
            scanf("%s",mapp[i]);
            len=strlen(mapp[i]);
            for(int j=0;j<len;j++)
            {
                Mapp[i][j]=mapp[i][j]-'0';
                Num[i][j]=++cnt;
            }
        }
        mem(mapp,0);
        for(int i=0;i<n;i++)
        {
            scanf("%s",mapp[i]);
        }
        int t=2*cnt+1;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<len;j++)
            {
                if(Mapp[i][j])
                {
                    if(i<d||j<d||n-i<=d||len-j<=d)
                        add_edge(Num[i][j]+cnt,t,inf);
                    add_edge(Num[i][j],Num[i][j]+cnt,Mapp[i][j]);
                    for(int k=0;k<n;k++)
                    {
                        for(int p=0;p<len;p++)
                        {
                            int dx=abs(i-k);
                            int dy=abs(j-p);
                            double mm=sqrt(dx*dx*1.0+dy*dy*1.0);
                            if(mm>d) continue;
                            add_edge(Num[i][j]+cnt,Num[k][p],inf);
                        }
                    }
                }
                if(mapp[i][j]=='L')
                {
                    add_edge(0,Num[i][j],1);
                    all++;
                }
            }
        }
        int s=dinic(0,t,t+1);
        int ans=all-s;
        if(!ans)
            printf("Case #%d: no lizard was left behind.\n",T);
        else if(ans==1)
            printf("Case #%d: 1 lizard was left behind.\n",T);
        else
            printf("Case #%d: %d lizards were left behind.\n",T,ans);
    }return 0;
}