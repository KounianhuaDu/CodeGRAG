// Data Structure->Stack,Data Structure->Queue,Basic Algorithm->Simulation
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Max = 7005;
int mem[Max], mark[Max];
int gcd(int a, int b)
{
    return b == 0 ? a : gcd(b,a%b);
}
int lcm(int a, int b)
{
    return a * b / gcd(a,b);
}
void solve(int n)
{
    queue<int> q;
    stack<int> mins, f_mins, hours;  
    for(int i = 0; i < n; i++)  
        q.push(i);
    for(int t = 0; t < 1440; t++)  
    {
        int num = q.front();
        q.pop();
        if(mins.size() == 4) 
        {
            for(int i = 0; i < 4; i++)
            {
                q.push(mins.top());
                mins.pop();
            }
            if(f_mins.size() == 11) 
            {
                for(int i = 0; i < 11; i++)
                {
                    q.push(f_mins.top());
                    f_mins.pop();
                }
                if(hours.size() == 11) 
                {
                    for(int i = 0; i < 11; i++)
                    {
                        q.push(hours.top());
                        hours.pop();
                    }
                    q.push(num); 
                }
                else
                    hours.push(num);
            }
            else
                f_mins.push(num);
        }
        else
            mins.push(num);
    }
    for(int j = 0; j < n; j++)
    {
        mem[j] = q.front();
        q.pop();
    }
}
int main()
{
    int n;
    while(scanf("%d",&n)&&n!=0)
    {
        memset(mem,0,sizeof(mem));
        memset(mark,0,sizeof(mark));
        solve(n);
        int ans = 1;
        for(int i = 0; i < n; i++)
        {
            if(!mark[i])
            {
                mark[i] = 1;
                int j = mem[i];
                int counts = 1;
                while(!mark[j])
                {
                    mark[j] = 1;
                    counts++;
                    j = mem[j];
                }
                ans = lcm(ans,counts);
            }
        }
        printf("%d balls cycle after %d days.\n",n,ans);
    }
    return 0;
}