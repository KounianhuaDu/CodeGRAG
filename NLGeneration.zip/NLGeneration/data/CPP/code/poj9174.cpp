// Basic Algorithm->Enumerate
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define MAXN 30
using namespace std;
int n,a[MAXN];
char s[1005];
map<int ,int > F;
int bitcount(int x) {return x? bitcount(x/2)+(x&1):0;} 
int main()
{
	while(~scanf("%d",&n))
	{
		for(int i=0;i<n;++i)
		{
			scanf("%s",s);
			a[i]=0;
			for(int j=0;s[j];++j) a[i]^=(1<<(s[j]-'A'));
		}
		F.clear();
		int n1=n/2,n2=n-n1;
		for(int i=0;i < (1<< n1);++i) 
		{
			int x=0;
			for(int j=0;j<n1;++j) x^=((i>>j)&1)*a[j];
			if(F.count(x) || bitcount(i)>bitcount(F[x])) F[x]=i;
		}
		int ans=0;
		for(int i=0;i < (1<< n2);++i)  
		{
			int x=0;
			for(int j=0;j<n2;++j) x^=((i>>j)&1)*a[j+n1];
			if(F.count(x) && bitcount(i)+bitcount(F[x])>bitcount(ans)) ans=(i<<n1)|F[x];
			
		}
		printf("%d\n",bitcount(ans));
		for(int i=0;i<n;++i) if((ans>>i)&1) printf("%d ",i+1);
		printf("\n");
	}
	return 0;
}