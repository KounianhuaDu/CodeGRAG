// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Euler Circuit / Euler Path,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
int head[30], cnt;
struct node {
    int u ,v, id, next; 
    bool flag;
};
node edge[2020];
int ans;
string str[1010];
int path[1010];
int in[30], out[30];
void init(){
    cnt = 0;
    memset(head, -1, sizeof(head));
    memset(in, 0, sizeof(in));
    memset(out, 0, sizeof(out));
}
void add(int u ,int v, int id){
    edge[cnt] = {u, v, id, head[u]};
    head[u] = cnt++;
}
void dfs(int u){
    for(int i = head[u]; i != -1; i = edge[i].next){
        if(!edge[i].flag){
            edge[i].flag = true;
            dfs(edge[i].v);
            path[ans++] = edge[i].id;
        }
    }
}
int main (){
    int T, n;
    scanf("%d", &T);
    while(T--){
        scanf("%d", &n);
        for(int i = 0 ; i < n ;++i)
            cin >> str[i];
        sort(str, str + n);
        init();
        int st = 1000;
        for(int i = n - 1; i >= 0; i--){
            int len = str[i].length();
            int u = str[i][0] - 'a';
            int v = str[i][len - 1] - 'a';
            add(u, v, i);
            in[v]++, out[u]++;
            st = min(st, u);
            st = min(st, v);
        }
        int numst, numed, num;
        numst = numed = num = 0;
        for(int i = 0 ; i < 26; ++i){
            if(!in[i] && !out[i]) continue;
            if(in[i] != out[i]) num++;
            if(out[i] - in[i] == 1){
                numst++;
                st = i;
            }
            else if(out[i] - in[i] == -1)
                numed++;
        }
        if(num > 0){
            if(!(num ==2 && numst == 1 && numed == 1)){
                cout <<"***"<<endl;
                continue;
            }
        }
        ans = 0;
        dfs(st);
        if(ans != n){ 
            cout <<"***"<<endl;
            continue;
        }
        for(int i = ans - 1; i >= 0; --i){
             cout<<str[path[i]];
             if(i > 0)
                printf(".");
             else
                printf("\n");
        }
    }
    return 0;
}