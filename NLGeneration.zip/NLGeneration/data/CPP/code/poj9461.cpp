// Graph Algorithm->Floyd-Warshall Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 100+10;
int n;
bool maptt1[maxn][maxn],connect[maxn][maxn];
int val[maxn],d[maxn];
int main()
{
    while(scanf("%d",&n)==1&&n!=-1)
    {
        memset(maptt1,0,sizeof(maptt1));
        memset(connect,0,sizeof(connect));
        memset(d,-1,sizeof(d));
        for(int i=1;i<=n;i++)
        {
            int num;
            scanf("%d%d",&val[i],&num);
            while(num--)
            {
                int v;
                scanf("%d",&v);
                maptt1[i][v]=connect[i][v]=true;
            }
        }
        for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        if(connect[i][k]&&connect[k][j])
            connect[i][j]=true;
        if(connect[1][n]==false)
        {
            printf("hopeless\n");
            continue;
        }
        connect[n][n]=true;
        d[1]=100;
        int k;
        for(k=0;k<n;k++)
        {
            bool flag=true;
            for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
            if(maptt1[i][j] && connect[j][n] && d[i]>0 && d[j] <d[i]+val[j])
            {
             
                d[j]=d[i]+val[j];
                flag=false;
            }
            if(flag) break;
        }
        if(k>=n || d[n]>=0)
            printf("winnable\n");
        else
            printf("hopeless\n");
    }
    return 0;
}