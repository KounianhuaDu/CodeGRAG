// Basic Algorithm->Depth First Search (DFS),Graph Algorithm->Tarjan's Algorithm,Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define L(rt) (rt<<1)
#define R(rt) (rt<<1|1)
#define ll long long
using namespace std;
const int maxn=1005;
const int INF=1000000000;
struct node
{
    int v,next;
}edge[maxn*maxn];
struct node1
{
    int x,y;
}p[maxn];
int head[maxn],scc[maxn],stacktt1[maxn];
int low[maxn],dfn[maxn],hat[maxn][2],fri[maxn][2];
bool ins[maxn];
int n,num,cnt,top,snum,a,b;
node1 s1,s2;
void init()
{
    memset(head,-1,sizeof(head));
    num=0;
}
void add(int u,int v)
{
    edge[num].v=v;
    edge[num].next=head[u];
    head[u]=num++;
}
int dis(node1 a,node1 b)
{
    return abs(a.x-b.x)+abs(a.y-b.y);
}
void input()
{
    scanf("%d%d%d%d",&s1.x,&s1.y,&s2.x,&s2.y);
    for(int i=1;i<=n;i++)
    scanf("%d%d",&p[i].x,&p[i].y);
    for(int i=1;i<=a;i++)
    scanf("%d%d",&hat[i][0],&hat[i][1]);
    for(int i=1;i<=b;i++)
    scanf("%d%d",&fri[i][0],&fri[i][1]);
}
void dfs(int u)
{
    int x;
    dfn[u]=low[u]=++cnt;
    stacktt1[top++]=u;
    ins[u]=true;
    for(int i=head[u];i!=-1;i=edge[i].next)
    {
        int v=edge[i].v;
        if(!dfn[v])
        {
            dfs(v);
            low[u]=min(low[u],low[v]);
        }
        else if(ins[v]) low[u]=min(low[u],dfn[v]);
    }
    if(low[u]==dfn[u])
    {
        snum++;
        do{
            x=stacktt1[--top];
            ins[x]=false;
            scc[x]=snum;
        }while(x!=u);
    }
}
void tarjan()
{
    memset(dfn,0,sizeof(dfn));
    memset(ins,false,sizeof(ins));
    cnt=top=snum=0;
    for(int i=1;i<=2*n;i++)
    if(!dfn[i]) dfs(i);
}
bool judge(int d)
{
    init();
    for(int i=1;i<=a;i++)
    {
        add(hat[i][0],hat[i][1]+n);
        add(hat[i][0]+n,hat[i][1]);
        add(hat[i][1],hat[i][0]+n);
        add(hat[i][1]+n,hat[i][0]);
    }
    for(int i=1;i<=b;i++)
    {
        add(fri[i][0],fri[i][1]);
        add(fri[i][0]+n,fri[i][1]+n);
        add(fri[i][1],fri[i][0]);
        add(fri[i][1]+n,fri[i][0]+n);
    }
    for(int i=1;i<=n;i++)
    for(int j=i+1;j<=n;j++)
    {
        if(dis(p[i],s1)+dis(p[j],s1)>d)
        {
            add(i,j+n);
            add(j,i+n);
        }
        if(dis(p[i],s2)+dis(p[j],s2)>d)
        {
            add(i+n,j);
            add(j+n,i);
        }
        if(dis(p[i],s1)+dis(s1,s2)+dis(p[j],s2)>d)
        {
            add(i,j);
            add(j+n,i+n);
        }
        if(dis(p[i],s2)+dis(s1,s2)+dis(p[j],s1)>d)
        {
            add(i+n,j+n);
            add(j,i);
        }
    }
    tarjan();
    for(int i=1;i<=n;i++)
    if(scc[i]==scc[i+n]) return false;
    return true;
}
void solve()
{
    int low=0,high=INF;
    int mid,ans=INF;
    while(low<=high)
    {
        mid=(low+high)>>1;
        if(judge(mid))
        {
            ans=min(ans,mid);
            high=mid-1;
        }
        else low=mid+1;
    }
    if(ans==INF) printf("-1\n");
    else printf("%d\n",ans);
}
int main()
{
    while(~scanf("%d%d%d",&n,&a,&b))
    {
       input();
       solve();
    }
    return 0;
}