// Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
long long h=1000000000;
long long list[1001];
long long sum[1000000];
long long x, y;
int main()
{
	int t, n;
	cin >> t;
	while (t--)
	{
		cin >> n;
		for (int i = 0; i < n; i++)
		{
			cin >> x >> y;
			list[i] = x*(h * 2 + 2) + y;	
		}
		memset(sum, 0x80, sizeof(sum));
		for (int i = 0; i < n; i++)for (int j = i+1; j < n; j++)
			sum[i*n + j] = list[i] + list[j];	
		sort(sum, sum + n*n);
		int ii = 0;
		while (sum[ii] == 0x8080808080808080)ii++;
		int num = 0, sumnum = 0;
		for (; ii < n*n; ii++)
		{
			if (sum[ii] == sum[ii - 1])num++;
			else
			{
				sumnum += num*(num + 1) / 2;
				num = 0;
			}
		}
		cout << sumnum << endl;
	}
	return 0;
}