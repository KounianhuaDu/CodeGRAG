// Basic Algorithm->Recursion,Basic Algorithm->Breadth First Search (BFS),Data Structure->Link List,Basic Algorithm->Depth First Search (DFS)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N = 50000;
struct Node
{
	int to,cap;
};
vector<Node> v[N];
int vis[N],dis[N];
int ans;
int BFS(int x)
{
	memset(dis,0,sizeof(dis));
	memset(vis,0,sizeof(vis));
	queue<int> q;
	q.push(x);
	vis[x]=1;
	int point = 0;
	while(!q.empty())
	{
		int f=q.front();
		q.pop();
		if(dis[f]>ans)
		{
			ans = dis[f];
			point = f;
		}
		for(int i=0;i<v[f].size();i++)
		{
			Node tmp = v[f][i];
			if(vis[tmp.to]==0)
			{
				vis[tmp.to]=1;
				dis[tmp.to] = dis[f] + tmp.cap;
				q.push(tmp.to);
			}
		}
	}
	return point;
}
int main()
{
	int n,m;
	while(~scanf("%d%d",&n,&m))
	{
		for(int i=0;i<=n;i++)
			v[i].clear();
		for(int i=0;i<m;i++)
		{
			int x,y,z;
			char c;
			scanf("%d %d %d %c",&x,&y,&z,&c);
			v[x].push_back((Node){y,z});
			v[y].push_back((Node){x,z});
		}
		ans = 0;
		int point = BFS(1);
		ans = 0;
		BFS(point);
		printf("%d\n",ans);
	}
	return 0;
}