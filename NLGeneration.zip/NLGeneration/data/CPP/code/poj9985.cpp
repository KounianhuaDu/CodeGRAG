// Basic Algorithm->Breadth First Search (BFS),Basic Algorithm->Recursion
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#define MAXV 50000
#define MAXE 100000
typedef struct{
	int t,w,next;
}Edge;
Edge edge[MAXE];
int n,m;
int e,head[MAXV],record[MAXV];
void addedge(int s,int t,int w){
	edge[e].t=t;
	edge[e].w=w;
	edge[e].next=head[s];
	head[s]=e++;
}
int bfs(int s,int flag){
	int i,v,t;
	int tmp=0,tmpi=s;
	queue <int>q;
	memset(record,-1,sizeof(record));
	record[s]=0;
	q.push(s);
	while(!q.empty()){
		v=q.front();q.pop();
		for(i=head[v];i!=-1;i=edge[i].next){
			t=edge[i].t;
			if(record[t]==-1){
				record[t]=record[v]+edge[i].w;
				if(record[t]>tmp){
					tmp=record[t];
					tmpi=t;
				}
				q.push(t);
			}
		}
	}
	return flag?tmpi:tmp;
}
int main(){
	int a,b,w,ans;
	char c;
	while(~scanf("%d%d\n",&n,&m)){
		memset(head,-1,sizeof(head));
		e=0;
		while(m--){
			scanf("%d %d %d %c\n",&a,&b,&w,&c);
			addedge(a,b,w);
			addedge(b,a,w);
		}
		a=bfs(1,1);
		ans=bfs(a,0);
		printf("%d\n",ans);
	}
	return 0;
}