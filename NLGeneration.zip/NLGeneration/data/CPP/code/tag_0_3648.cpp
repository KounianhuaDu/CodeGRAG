// Data Structure->Hashing
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>
using namespace std;

struct MyNode
{
 int data;
 MyNode *pNext;
};
struct HashTable
{
 MyNode *val[10];
};
HashTable* createHashTable()
{
 HashTable *pHash = new HashTable;
 memset(pHash, 0, sizeof(HashTable));
 return pHash;
}
bool insertHashTable(HashTable *pHash,int data)
{
 if (pHash == nullptr)return false;
 MyNode* pNode;
 pNode = pHash->val[data % 10];
 if (pNode == nullptr)
 {
  pHash->val[data % 10] = new MyNode;
  pHash->val[data % 10]->data = data;
  pHash->val[data % 10]->pNext = nullptr;
  return true;
 }
 else
 {
  while (pNode->pNext)pNode = pNode->pNext;
  pNode->pNext = new MyNode;
  pNode->pNext->data = data;
  pNode->pNext->pNext = nullptr;
  return true;
 }
 return true;
}
MyNode * findDataInHash(HashTable* pHash, int findData)
{
 if (pHash == nullptr)return nullptr;
 MyNode* pNode = pHash->val[findData % 10];
 if (pNode == nullptr)return nullptr;
 while (pNode)
 {
  if (pNode->data == findData)return pNode;
  pNode = pNode->pNext;
 }
 return nullptr;
}
bool deleteDataFromHash(HashTable* pHash, int data)
{
 MyNode* pNode = findDataInHash(pHash, data);
 if (pNode == nullptr)return false;
 MyNode* pHead = pHash->val[data % 10];
 if (pHead == pNode)
 {
  pHash->val[data % 10] = pNode->pNext;
 }
 else
 {
  while (pHead->pNext!=pNode)
  {
   pHead = pHead->pNext;
  }
  pHead->pNext = pNode->pNext;
 }
 delete pNode;
 return true;
}
void clearHashTable(HashTable*& pHash)
{
 if (pHash == nullptr)return;
 MyNode* pHead;
 MyNode* pNode;
 for (int i = 0; i < 10; ++i)
 {
  if ((pHead = pHash->val[i]) != nullptr)
  {
   while (pHead)
   {
    pNode = pHead;
    pHead = pHead->pNext;
    delete pNode;
   }
  }
 }
 delete[] pHash;
 pHash = nullptr;
}
int main()
{
 HashTable *pHash = nullptr;
 pHash = createHashTable();
 insertHashTable(pHash, 1);
 insertHashTable(pHash, 10);
 insertHashTable(pHash, 11);
 insertHashTable(pHash, 32);
 insertHashTable(pHash, 21);
 deleteDataFromHash(pHash, 11);
 deleteDataFromHash(pHash, 1);
 getchar();
 return 0;
}