// Data Structure->Link Cut Tree (LCT)
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=200005,Mod=51061;
typedef long long LL;
int n,m,r[N],f[N];
int a[N],c[N][2],sz[N];
LL st[N],add[N],s[N];
LL mul[N],v[N];
bool nroot(int x) {
	return c[f[x]][0]==x||c[f[x]][1]==x;
}
void Pushup(int x) {
	s[x]=(s[c[x][0]]+s[c[x][1]]+v[x])%Mod;
	sz[x]=sz[c[x][0]]+sz[c[x][1]]+1;
}
void Pushdown(int x) {
	int &lc=c[x][0],&rc=c[x][1];
	if (r[x]&&x) {
		r[x]=0;
		if (c[x][0]) {
			swap(c[lc][0],c[lc][1]);
			r[lc]^=1;
		}
		if (c[x][1]) {
			swap(c[rc][0],c[rc][1]);
			r[rc]^=1;
		}
	}
	if (mul[x]!=1) {
		s[lc]*=mul[x];s[lc]%=Mod;
		v[lc]*=mul[x];v[lc]%=Mod;
		mul[lc]*=mul[x];mul[lc]%=Mod;
		add[lc]*=mul[x];add[lc]%=Mod;
		s[rc]*=mul[x];s[rc]%=Mod;
		v[rc]*=mul[x];v[rc]%=Mod;
		mul[rc]*=mul[x];mul[rc]%=Mod;
		add[rc]*=mul[x];add[rc]%=Mod;
		mul[x]=1;
	}
	if (add[x]) {
		s[lc]+=sz[lc]*add[x];s[lc]%=Mod;
		v[lc]+=add[x];v[lc]%=Mod;
		add[lc]+=add[x];add[lc]%=Mod;
		s[rc]+=sz[rc]*add[x];s[rc]%=Mod;
		v[rc]+=add[x];v[rc]%=Mod;
		add[rc]+=add[x];add[rc]%=Mod;
		add[x]=0;
	}
}
void Rotate(int x) {
	int y=f[x],z=f[y];
	int k=(c[y][1]==x),kk=(c[z][1]==y);
	if (nroot(y)) c[z][kk]=x;
	f[y]=x;
	c[y][k]=c[x][k^1];
	if (c[x][k^1]) f[c[x][k^1]]=y;
	c[x][k^1]=y;
	f[x]=z;
	Pushup(x);
	Pushup(y);
}
void Splay(int x) {
	int y=x,z=0;
	st[++z]=x;
	while (nroot(y)) st[++z]=(y=f[y]);
	while (z) Pushdown(st[z--]);
	while (nroot(x)) {
		y=f[x];z=f[y];
		if (nroot(y))
			Rotate((c[y][0]==x)^(c[z][0]==y)?x:y);
		Rotate(x);
	}
	Pushup(x);
}
void Access(int x) {
	for (int y=0;x;x=f[y=x]) {
		Splay(x);
		c[x][1]=y;
		Pushup(x);
	}
}
void Makeroot(int x) {
	Access(x);
	Splay(x);
	swap(c[x][0],c[x][1]);
	r[x]^=1;
}
void Split(int x,int y) {
	Makeroot(x);
	Access(y);
	Splay(y);
}
void Link(int x,int y) {
	Makeroot(x);
	f[x]=y;
}
void Cut(int x,int y) {
	Split(x,y);
	f[x]=c[y][0]=0;
}
void Add(int x,int y,int z) {
	Split(x,y);
	add[y]+=z;add[y]%=Mod;
	v[y]+=z;v[y]%=Mod;
	s[y]+=sz[y]*z;s[y]%=Mod;
	Pushdown(y);
}
void Mul(int x,int y,int z) {
	Split(x,y);
	mul[y]*=z;mul[y]%=Mod;
	add[y]*=z;add[y]%=Mod;
	v[y]*=z;v[y]%=Mod;
	s[y]*=z;s[y]%=Mod;
	Pushdown(y);
}
void Ask(int x,int y) {
	Split(x,y);
	printf("%lld\n",s[y]);
}
int main() {
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) v[i]=mul[i]=1;
	for (int i=1;i<n;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		Link(u,v);
	}
	for (int i=1;i<=m;i++) {
		char op[10];
		int x,y,z,w;
		scanf("%s%d%d",op,&x,&y);
		if (op[0]=='+') {
			scanf("%d",&z);
			Add(x,y,z);
		} else if (op[0]=='-') {
			scanf("%d%d",&z,&w);
			Cut(x,y);
			Link(z,w);
		} else if (op[0]=='*') {
			scanf("%d",&z);
			Mul(x,y,z);
		} else {
			Ask(x,y);
		}
	}
	return 0;
}