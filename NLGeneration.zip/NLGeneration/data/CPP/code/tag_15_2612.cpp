// Dynamic Programming->Slope Optimization
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100005
#define LL long long
using namespace std;
int s[maxn],n,l,r,ret;
LL cnt[10010],sum[maxn],f[maxn];
vector<int> a[10010];
inline int rd(){
  int x=0,f=1;char c=' ';
  while(c<'0' || c>'9') {if(c=='-') f=-1;c=getchar();}
  while(c<='9' && c>='0') x=x*10+c-'0',c=getchar();
  return x*f;
}
inline LL squ(LL x) {return x*x;}
#define y(i) (f[i-1]+squ(sum[i]-1)*s[i])
#define x(i) 2*(sum[i]-1)
int main(){
  n=rd();
  for(int i=1;i<=n;i++){
    s[i]=rd();
    cnt[s[i]]++;
    sum[i]=cnt[s[i]];
  }
  for(int i=1;i<=n;i++){
    int t;
    while((t=a[s[i]].size()-1)>0 && (x(i) - x(a[s[i]][t])) * (y(a[s[i]][t - 1]) - y(a[s[i]][t])) - (y(i) - y(a[s[i]][t])) * (x(a[s[i]][t - 1]) - x(a[s[i]][t])) > 0) a[s[i]].pop_back();
    a[s[i]].push_back(i);
    l=1,r=a[s[i]].size()-1,ret=0;
    while(l<=r){
      int mid=(l+r)>>1;
      if(f[a[s[i]][mid]-1]+s[i]*squ(sum[i]-sum[a[s[i]][mid]]+1)>f[a[s[i]][mid-1]-1]+s[i]*squ(sum[i]-sum[a[s[i]][mid-1]]+1)) ret=mid,l=mid+1;
      else r=mid-1;
    }
    int x=a[s[i]][ret];
    f[i]=f[x-1]+s[i]*squ(sum[i]-sum[x]+1);
  }
  printf("%lld\n",f[n]);
  return 0;
}