// Graph Algorithm->Tarjan's Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int N=100010;
bool used[N];
int size,id[N];
bool iscut[N];
int dfn[N], low[N], Index, n,m;
struct Pool
{
    int pre,k;
}p[100*N];
int v[N],num;
stack<int>sta;
void add(int a,int b)
{
    p[++num].pre=v[a];
    p[num].k=b;
    v[a]=num;
}
void init() {
    Index = 0;
    memset(v, 0, sizeof (v));
    num = 0;
    memset(dfn, 0, sizeof (dfn));
    memset(iscut, 0, sizeof (iscut));
}
void tarjan(int x) {
    dfn[x] = low[x] = ++Index;
    for (int tmp = v[x], k; k = p[tmp].k, tmp; tmp = p[tmp].pre)
        if (!dfn[k]) {
            tarjan(k);
            if (dfn[x] <= low[k])
                iscut[x] = true;
            low[x] = min(low[ x], low[k]);
        } else low[x] = min(low[x], dfn[k]);
}
void cutpoint() {
    int num = 0;
    dfn[1] = Index = 1;
    for (int tmp = v[1], k; k = p[tmp].k, tmp; tmp = p[tmp].pre)
        if (!dfn[k]) {
            num++;
            tarjan(k);
        }
    iscut[1] = num > 1;
}
int main(){
    scanf("%d%d",&n,&m);
    while(m--){
        int x,y;
        scanf("%d%d",&x,&y);
        add(x,y);
        add(y,x);
    }
  
    cutpoint();
    for(int i=1;i<=n;i++)
        printf("%d ",iscut[i]);
    return 0;
}