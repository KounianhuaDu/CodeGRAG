// Math and Computational Geometry->Pigeonhole Principle
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define inf 0x3f3f3f3f
#define LL long long
using namespace std;
int sum[10010];
int mod[10010];
int a[10010];
int main()
{
    int n;
    while(cin>>n)
    {
        for(int i=1;i<=n;i++)
            cin>>a[i];
        sum[0]=0;
        memset(mod,-1,sizeof(mod));
        for(int i=1;i<=n;i++)
        {
            sum[i]+=sum[i-1]+a[i];
            if(sum[i]%n==0)
            {
                cout<<i<<endl;
                for(int j=1;j<=i;j++)
                    cout<<a[j]<<endl;
                break;
            }
            if(mod[sum[i]%n]!=-1)
            {
                cout<<i-mod[sum[i]%n]<<endl;
                for(int j=mod[sum[i]%n]+1;j<=i;j++)
                    cout<<a[j]<<endl;
                break;
            }
            mod[sum[i]%n]=i;
        }
    }
    return 0;
}