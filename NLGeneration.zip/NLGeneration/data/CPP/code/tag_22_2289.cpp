// Graph Algorithm->Steiner Tree
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

typedef long long LL;
using namespace std;
const LL MAXN=1e6+10;
struct node
{
    LL next,v;
    LL w;
} edge[MAXN*2];
LL head[MAXN],tot;
LL son[MAXN];
LL dis2[MAXN];
LL n,k;
void add(LL u,LL v,LL  w)
{
    edge[tot].v=v;
    edge[tot].w=w;
    edge[tot].next=head[u];
    head[u]=tot++;
}
void init()
{
    memset(head,-1,sizeof(head));
    tot=0;
}
void dfs(LL u,LL pre)
{
    son[u]=1;
    LL v;
    for(LL i=head[u]; i!=-1; i=edge[i].next)
    {
        v=edge[i].v;
        if(v==pre)
            continue;
        dis2[v]=edge[i].w;
        dfs(v,u);
        son[u]+=son[v];
    }
}
int main()
{
    LL u,v,w;
    while(scanf("%lld%lld",&n,&k)!=-1)
    {
        init();
        for(LL i=1; i<n; i++)
        {
            scanf("%lld%lld%lld",&u,&v,&w);
            add(u,v,w);
            add(v,u,w);
        }
        dfs(1,-1);
        LL sum=0;
        for(LL i=2; i<=n; i++)
            sum+=(LL)(dis2[i]*min(son[i],k));
        printf("%lld\n",sum);
    }
    return 0;
}