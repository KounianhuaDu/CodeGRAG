// Math and Computational Geometry->Hyperplan Intersection
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int Maxn=550;
const int INF=0x3f3f3f3f;
int n,tot,L,R,cnt;
struct point{
    double x,y;
    point(double x=0,double y=0):x(x),y(y){}
    friend inline point operator -(const point &a,const point &b){
        return point(b.x-a.x,b.y-a.y);
    }
    friend inline double operator *(const point &a,const point &b){
        return a.x*b.y-a.y*b.x;
    }
}p[Maxn];
struct line{
    point a,b;
    double slope;
    line(){}
    line(point a,point b):a(a),b(b){}
    friend inline bool operator <(const line &a,const line &b){
        if(a.slope!=b.slope)return a.slope<b.slope;
        return (a.a-b.b)*(b.a-b.b)>0;
    }
    friend inline point inter(const line &a,const line &b){
        double k1=(a.b-b.b)*(a.a-b.b);
        double k2=(a.a-b.a)*(a.b-b.a);
        #define t (k1)/(k1+k2)       
        return point(b.b.x+(b.a.x-b.b.x)*t,b.b.y+(b.a.y-b.b.y)*t);
        #undef t 
    }
}l[Maxn];
inline bool judge(line now,line a,line b){
    point q=inter(now,a);
    return (q-b.a)*(q-b.b)>0;
}
inline void hpi(){
    sort(l+1,l+n);
    for(int i=1;i<n;i++){
        if(i==1||l[i].slope!=l[i-1].slope)l[++cnt]=l[i];
    }
    L=1,R=2;
    for(int i=3;i<=cnt;i++){
        while(L<R&&judge(l[i],l[R-1],l[R]))R--;
        l[++R]=l[i];
    }
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%lf",&p[i].x);
    for(int i=1;i<=n;i++){
        scanf("%lf",&p[i].y);
        if(i!=1){
            l[i-1].a=p[i-1];l[i-1].b=p[i];
            l[i-1].slope=atan2(l[i-1].b.y-l[i-1].a.y,l[i-1].b.x-l[i-1].a.x);
        }
    }
    hpi();
    int pos=L;
    double ans=(double)INF*(double)INF;
    for(int i=1;i<=n;i++){
        while(pos!=R&&inter(l[pos],l[pos+1]).x<p[i].x)pos++;
        point q=inter(line(p[i],point(p[i].x,-1.0)),l[pos]);
        ans=min(ans,q.y-p[i].y);
    }
    pos=1;
    for(int i=L;i<R;i++){
        point q=inter(l[i],l[i+1]);
        if(q.x<p[1].x)continue;
        while(pos<n&&p[pos+1].x<q.x)pos++;
        if(pos==n)break;
        point t=inter(line(p[pos],p[pos+1]),line(q,point(q.x,-1.0)));
        ans=min(ans,q.y-t.y);
    }
    printf("%.3f",ans);
}