// Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
#pragma comment(linker, "/STACK:1024000000,1024000000") 
#define eps 1e-10
#define inf 0x3f3f3f3f
#define PI pair<int, int> 
typedef long long LL;
const int maxn = 1000000+5;
const int Tot = 500000+5;
struct Aho{
    struct state{
        int next[26];
        int fail, cnt;
    }stateTable[Tot];
    queue<int>que;
    
    int size;
    void init() {
        while(!que.empty()) que.pop();
        for(int i = 0; i < Tot; ++i) {
            memset(stateTable[i].next, 0, sizeof(stateTable[i].next));
            stateTable[i].fail = stateTable[i].cnt = 0;
        }
        size = 1;
    }
    
    void insert(char *S){
        int n = strlen(S);
        int now = 0;
        for(int i = 0; i < n; ++i) {
            char c = S[i];
            if(!stateTable[now].next[c-'a']) {
                stateTable[now].next[c-'a'] = size++;
            }
            
            now = stateTable[now].next[c-'a']; 
        }
        stateTable[now].cnt++;
    }
    void build() {
        stateTable[0].fail = -1;
        que.push(0);
        while(!que.empty()) {
            int u = que.front(); que.pop();
            for(int i = 0; i < 26; ++i) {
                if(stateTable[u].next[i]) {
                    
                    if(u == 0) stateTable[stateTable[u].next[i]].fail = 0;
                    else {
                        int v = stateTable[u].fail;
                        while(v != -1) {
                            if(stateTable[v].next[i]) {
                                stateTable[stateTable[u].next[i]].fail = stateTable[v].next[i];
                                break;
                            }
                            v = stateTable[v].fail;
                        }
                        if(v == -1) stateTable[stateTable[u].next[i]].fail = 0;
                    }
                    que.push(stateTable[u].next[i]);
                }
            }
        }
    }
    int Get(int u) {
        int res = 0;
        while(u) {
            res += stateTable[u].cnt;
            stateTable[u].cnt = 0;
            u = stateTable[u].fail;
        }
        return res;
    }
    int match(char *S) {
        int n= strlen(S);
        int res = 0, now = 0;
        for(int i = 0; i < n; ++i) {
            char c = S[i];
            if(stateTable[now].next[c-'a']) 
                now = stateTable[now].next[c-'a'];
            else {
                int p = stateTable[now].fail;
                while(p != -1 && !stateTable[p].next[c-'a']) p = stateTable[p].fail;
                if(p == -1) now = 0;
                else now = stateTable[p].next[c-'a'];
            }
            if(stateTable[now].cnt) 
                res += Get(now);
        }
        return res;
    } 
}aho;
char S[maxn];
int main() {
    int T, n;
    scanf("%d", &T);
    while(T--) {
        aho.init();
        scanf("%d", &n);
        for(int i = 0; i < n; ++i) {
            scanf("%s", S);
            aho.insert(S);
        }
        aho.build();
        scanf("%s", S);
        printf("%d\n", aho.match(S));
    }
    return 0;
}