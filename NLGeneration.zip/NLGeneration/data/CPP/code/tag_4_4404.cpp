// Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn=10000,maxl=50,maxT=maxn*maxl,maxL=1000000,maxi=26;
struct Node
{
    Node *son[maxi],*fa,*lst;
    int w;
};
typedef Node* P_node;
Node tem[maxT+5];
P_node null=tem,P_tem=null,que[maxT+5];
P_node newNode(P_node son)
{
    P_tem++;P_tem->fa=P_tem->lst=son;P_tem->w=0;
    for (int i=0;i<maxi;i++) P_tem->son[i]=son;
    return P_tem;
}
int getid(char ch) {return ch-'a';}
struct AC 
{
    P_node ro;
    void clear() {ro=newNode(null);for (int i=0;i<maxi;i++) ro->son[i]=ro;ro->fa=ro->lst=ro;} 
    void Insert(char *s) 
    {
        P_node now=ro;
        for (int i=1;s[i];i++)
        {
            if (now->son[getid(s[i])]==ro) now->son[getid(s[i])]=newNode(ro);
            
            now=now->son[getid(s[i])];
        }
        now->w++;
    }
    void get_Fail()
    {
        int Head=0,Tail=0;
        for (int i=0;i<maxi;i++)
            if (ro->son[i]!=ro)
            {
                que[++Tail]=ro->son[i];
                ro->son[i]->fa=ro->son[i]->lst=ro;
            }
        while (Head!=Tail)
        {
            P_node x=que[++Head];
            for (int i=0;i<maxi;i++)
                if (x->son[i]!=ro)
                {
                    P_node now=x->son[i];now->fa=x->fa->son[i];
                    if (now->fa->w) now->lst=now->fa; else now->lst=now->fa->lst;
                    que[++Tail]=now;
                } else x->son[i]=x->fa->son[i]; 
                
        }
    }
    int get_num(P_node now)
    {
        int num=0;
        for (;now!=ro;now=now->lst) num+=now->w;
        return num;
    }
    int Find(char *s)
    {
        P_node j=ro;int num=0;
        for (int i=1;s[i];i++) j=j->son[getid(s[i])],num+=get_num(j);
        return num;
    }
};
AC tr;
int te,n;
char now[maxL+5];
bool Eoln(char ch) {return ch==10||ch==13||ch==EOF;}
int reads(char* s)
{
    int len=0;char ch=getchar();if (ch==EOF) return EOF;
    s[++len]=ch;while (!Eoln(s[len])) s[++len]=getchar();s[len--]=0;
    return 0;
}
void readln() {scanf("%*[^\n]");getchar();}
int main()
{
    freopen("AC.in","r",stdin);
    freopen("AC.out","w",stdout);
    scanf("%d",&te);
    while (te--)
    {
        scanf("%d",&n);readln();P_tem=null;tr.clear();
        for (int i=1;i<=n;i++) reads(now),tr.Insert(now);tr.get_Fail();
        reads(now);printf("%d\n",tr.Find(now));
    }
    return 0;
}