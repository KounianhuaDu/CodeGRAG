// Data Structure->Aho-Corasick Algorithm
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

#define maxn 100050
using namespace std;
struct smg
{
    int fail,w[26],deep;
}a[maxn];
int cnt=0,n,i,j,now,que,wz[maxn],top1,top2,v,u,len1,len2,c;
int head,tail,x,y,ans,l,ii;
bool m1[maxn],m2[maxn];
string s[maxn],s1,s2;
inline void build(string s)
{
    l=s.length(); now=0;
    for (ii=0;ii<l;ii++)
    {
        if (a[now].w[s[ii]-'a']==0) 
        {
            a[now].w[s[ii]-'a']=++cnt;
            a[cnt].deep=ii+1;
        }
        now=a[now].w[s[ii]-'a'];
    }
    wz[i]=now;
}
void getfail()
{
    queue<int> q;
    for(int i=0;i<26;++i)
    {
        if(a[0].w[i]!=0)
        {
            a[a[0].w[i]].fail=0;
            q.push(a[0].w[i]);
        }
    }
    while(!q.empty())
    {
        int u=q.front();
        q.pop();
        for(int i=0;i<26;++i)
        {
            if(a[u].w[i]!=0)
            {
                a[a[u].w[i]].fail=a[a[u].fail].w[i];
                q.push(a[u].w[i]);
            }
            else a[u].w[i]=a[a[u].fail].w[i];
        }
    }
}
int main()
{
    scanf("%d",&n);
    for (i=1;i<=n;i++)
    {
        cin>>s[i]; build(s[i]);
    }
    getfail();
    scanf("%d",&que);
    while (que--)
    {
        scanf("%d%d",&x,&y); ans=0; 
        memset(m1,0,sizeof(m1)); memset(m2,0,sizeof(m2));
        s1=s[x]; s2=s[y]; len1=s1.length(); len2=s2.length();
        u=0;
        for (i=0;i<len1;i++)
        {
            c=s1[i]-'a'; u=a[u].w[c];
            for (v=u;v&&(!m1[v]);v=a[v].fail) m1[v]=1;
        }
        u=0;
        for (i=0;i<len2;i++)
        {
            c=s2[i]-'a'; u=a[u].w[c];
            for (v=u;v&&(!m2[v]);v=a[v].fail) m2[v]=1;
        }
        for (i=1;i<=cnt;i++)
            if (m1[i]&&m2[i])
                if (a[i].deep>ans) ans=a[i].deep;
        printf("%d\n",ans);
    }
    return 0;
}