// Data Structure->Suffix Array
#include<iostream>
#include<stdio.h>
#include<string>
#include<string.h>
#include<cmath>
#include<cstdio>
#include<algorithm>
#include<set>
#include<vector>
#include<map>
#include<stack>
#include<queue>
#include<memory.h>
#include <cstring>
#include<iomanip>

using namespace std;
const int maxn = 100000 + 10;
int t1[maxn], t2[maxn], c[maxn];
bool cmp(int* r, int a,int b,int l){
    return r[a] == r[b] && r[a+l] == r[b+l];
}
void da(int str[], int sa[], int Rank[], int lcp[], int n, int m){
    ++n;
    int i, j, p, *x = t1, *y = t2;
    for (i = 0; i < m; ++i) c[i] = 0;
    for (i = 0; i < n; ++i) c[x[i] = str[i] ]++;
    for (i = 1; i < m; ++i) c[i] += c[i-1];
    for (i = n-1; i >= 0; --i) sa[--c[x[i] ] ] = i;
    for (j = 1; j <= n; j <<= 1){
        p = 0;
        for (i = n-j; i < n; ++i) y[p++] = i;
        for (i = 0; i < n; ++i) if (sa[i] >= j) y[p++] = sa[i] - j;
        for (i = 0; i < m; ++i) c[i] = 0;
        for (i = 0; i < n; ++i) c[x[y[i] ] ]++;
        for (i = 1; i < m; ++i) c[i] += c[i-1];
        for (i = n-1; i >= 0; --i) sa[--c[x[y[i] ] ] ] = y[i];
        swap(x,y);
        p = 1; x[sa[0] ] = 0;
        for (i = 1; i < n; ++i){
            x[sa[i] ] = cmp(y, sa[i-1], sa[i], j) ? p-1 : p++;
        }
        if (p >= n)break;
        m= p;
    }
    int k = 0;
    n--;
    for (i = 0; i <= n; ++i) Rank[sa[i] ] = i;
    for (i = 0; i < n; ++i){
        if (k)--k;
        j = sa[Rank[i]-1 ];
        while(str[i+k] == str[j+k])++k;
        lcp[Rank[i] ] = k;
    }
}
int lcp[maxn], a[maxn], sa[maxn], Rank[maxn];
char s[maxn];
int d[maxn][40];
int len;
void rmq_init(int* A, int n){
    for (int i = 0; i < n; ++i) d[i][0] = A[i];
    for (int j = 1; (1<<j) <= n; ++j)
        for (int i = 0; i + (1<<j) - 1 < n ; ++i)
            d[i][j] = min(d[i][j-1], d[i + (1<< (j-1))][j-1]);
}
int ASK(int l,int r){
    int k = 0;
    while((1<<(k+1)) <= r-l + 1)++k;
    return min(d[l][k], d[r-(1<<k) + 1][k]);
}
int ask(int l,int r){
    if (l == r) return len - sa[r]; 
    return ASK(l + 1, r); 
}
int main(){
    int T;
    scanf("%d", &T);
    while(T--){
        int k;
        scanf("%d", &k);
        scanf("%s", s);
        len = strlen(s);
        for (int i = 0; i < len; ++i){
            a[i] = s[i] - 'a' + 1;
        }
        a[len] = 0;
        da(a, sa, Rank, lcp, len, 30);
        rmq_init(lcp, len + 1);
        long long ans = 0;
        for (int i = 1; i + k - 1 <= len; ++i){
            ans += ask(i, i + k - 1);
            if (i - 1 > 0)ans -= ask(i - 1, i + k - 1); 
            if (i + k <= len)ans -= ask(i, i + k);
            if (i - 1 > 0 && i + k <= len)ans += ask(i - 1 , i + k);
        }
        printf("%I64d\n", ans);
    }
    return 0;
}